"""在隔离的临时库里造一条已发布的演示案例，供手工验证使用（不碰 backend/data/app.db）。"""
import os
import sys

os.environ.setdefault("DATABASE_URL", sys.argv[1])
from backend.app import models  # noqa: E402
from backend.app.db import Base, SessionLocal, engine  # noqa: E402
from backend.app.seed import seed_demo_case  # noqa: E402

Base.metadata.create_all(engine)
with SessionLocal() as db:
    case = seed_demo_case(db)
    db.commit()
    print("case_id=%s student_token=%s status=%s nodes=%d" % (
        case.id, case.student_token, case.status, len(case.nodes or [])))
