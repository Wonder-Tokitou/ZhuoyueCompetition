"""跨设备/跨标签页重复开始的端到端验证（绕开本机 http_proxy，直连 127.0.0.1:8110）。

场景：同一学生账号在两个"标签页"（两个不带 sessionStorage 的客户端）先后打开同一案例
并点击"开始推演"——第一次 200，第二次必须 409 且 detail.code=submission_exists。
"""
import json
import urllib.request

BASE = "http://127.0.0.1:8111/api"
opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def call(method, path, payload=None, token=None):
    data = json.dumps(payload).encode() if payload is not None else None
    request = urllib.request.Request(BASE + path, data=data, method=method)
    if data is not None:
        request.add_header("Content-Type", "application/json")
    if token:
        request.add_header("Authorization", "Bearer " + token)
    try:
        with opener.open(request, timeout=20) as response:
            return response.status, json.loads(response.read() or b"null")
    except urllib.error.HTTPError as exc:
        return exc.code, json.loads(exc.read() or b"null")


def main():
    status, login = call("POST", "/teacher/login", {"password": "test123"})
    print("教师登录", status)
    teacher = login.get("teacher_token") or login.get("access_token") or login.get("token")
    status, cases = call("GET", "/cases?token=" + teacher)
    print("案例列表", status, "共", len(cases) if isinstance(cases, list) else cases)
    published = []
    for summary in cases if isinstance(cases, list) else []:
        if summary.get("status") not in ("ready", "published"):
            continue
        detail_status, detail = call("GET", "/cases/%s?token=%s" % (summary["id"], teacher))
        if detail_status == 200 and detail["case"].get("student_token"):
            published.append(detail["case"])
    if not published:
        print("没有已发布案例，无法验证")
        return
    case = published[0]
    print("使用案例", case["id"], case["title"], "token", case["student_token"][:8] + "…")

    username = "concurrency-probe-1"
    status, created = call("POST", "/teacher/students?token=" + teacher,
                           {"username": username, "real_name": "并发验证学生", "password": "probe-password-1"})
    print("建学生账号", status, created if status >= 400 else created.get("username"))
    if status >= 400 and "exist" not in json.dumps(created, ensure_ascii=False):
        return

    status, session = call("POST", "/student/login", {"username": username, "password": "probe-password-1"})
    print("学生登录", status)
    student = session["access_token"]

    path = "/play/%s/sessions" % case["student_token"]
    first, body = call("POST", path, {"student_name": "并发验证学生"}, student)
    print("标签页 A 开始推演 ->", first, "session_id=%s" % body.get("session_id"))
    second, conflict = call("POST", path, {"student_name": "并发验证学生"}, student)
    print("标签页 B 开始推演 ->", second)
    print("响应体 ->", json.dumps(conflict, ensure_ascii=False))
    detail = conflict.get("detail") or {}
    assert first == 200, "首次开始应成功"
    assert second == 409, "第二次必须 409"
    assert detail.get("code") == "submission_exists", "必须保留 submission_exists 业务码"
    assert detail.get("session_id") == body.get("session_id"), "必须带回可恢复的 session_id"
    status, records = call("GET", "/student/records", token=student)
    print("我的提交记录", status, "条数", len(records), "首条 session_id", records[0]["session_id"] if records else None)
    print("OK: 后端在重复开始时返回真实原因与可恢复的 session_id")


main()
