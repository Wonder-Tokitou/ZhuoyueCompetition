// 手工验收（真实浏览器）：同一学生账号在第二标签页重复"开始推演"必须看到
// "已有本案例推演记录，请从「我的记录」继续" + 可点击入口，并能在「我的记录」恢复进度。
// 用 Chrome DevTools Protocol 驱动本机 Chrome，不依赖 playwright。
const http = require('node:http')
const path = require('node:path')
const os = require('node:os')
const fs = require('node:fs')
const { spawn } = require('node:child_process')

const BASE = 'http://127.0.0.1:8111'
const CASE_TOKEN = 'benchmark-demo-v4'
const PORT = 9223

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

function httpJson(pathname) {
  return new Promise((resolve, reject) => {
    http.get({ host: '127.0.0.1', port: PORT, path: pathname }, (res) => {
      let body = ''
      res.on('data', (chunk) => { body += chunk })
      res.on('end', () => { try { resolve(JSON.parse(body)) } catch (e) { reject(e) } })
    }).on('error', reject)
  })
}

class Cdp {
  constructor(ws) { this.ws = ws; this.id = 0; this.pending = new Map() }
  static async connect(url) {
    const ws = new WebSocket(url)
    const client = new Cdp(ws)
    ws.onmessage = (event) => {
      const message = JSON.parse(event.data)
      const slot = client.pending.get(message.id)
      if (!slot) return
      client.pending.delete(message.id)
      message.error ? slot.reject(new Error(JSON.stringify(message.error))) : slot.resolve(message.result)
    }
    await new Promise((resolve, reject) => { ws.onopen = resolve; ws.onerror = reject })
    return client
  }
  send(method, params = {}) {
    const id = ++this.id
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject })
      this.ws.send(JSON.stringify({ id, method, params }))
    })
  }
  async eval(expression) {
    const result = await this.send('Runtime.evaluate', {
      expression, awaitPromise: true, returnByValue: true, allowUnsafeEvalBlockedByCSP: true,
    })
    if (result.exceptionDetails) throw new Error(JSON.stringify(result.exceptionDetails))
    return result.result.value
  }
}

async function waitFor(cdp, expression, label, timeout = 20000) {
  const deadline = Date.now() + timeout
  while (Date.now() < deadline) {
    if (await cdp.eval(expression)) return true
    await sleep(150)
  }
  throw new Error('超时未满足：' + label)
}

const clickByText = (text) => `
  (() => {
    const button = [...document.querySelectorAll('button')].find((b) => (b.textContent || '').includes(${JSON.stringify(text)}));
    if (!button) return false;
    button.click();
    return true;
  })()
`

const bodyText = `document.body.innerText`

async function main() {
  const stamp = Date.now().toString(36)
  const username = 'ui-probe-' + stamp

  const teacher = await (await fetch(BASE + '/api/teacher/login', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ password: 'test123' }),
  })).json()
  const created = await fetch(BASE + '/api/teacher/students?token=' + teacher.teacher_token, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, real_name: 'UI 验证学生', password: 'probe-password-1' }),
  })
  console.log('建学生账号 %s -> %s', username, created.status)

  const profile = path.join(os.tmpdir(), 'case-sim-ui-probe-' + stamp)
  fs.mkdirSync(profile, { recursive: true })
  const chrome = spawn('C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', [
    '--headless=new', '--remote-debugging-port=' + PORT, '--user-data-dir=' + profile,
    '--no-first-run', '--no-default-browser-check', '--disable-gpu', '--disable-extensions',
    '--window-size=1280,900', 'about:blank',
  ], { stdio: 'ignore' })

  let cdp
  try {
    for (let i = 0; i < 60 && !cdp; i++) {
      try {
        const targets = await httpJson('/json/list')
        const page = targets.find((t) => t.type === 'page')
        if (page) cdp = await Cdp.connect(page.webSocketDebuggerUrl)
      } catch { await sleep(500) }
    }
    if (!cdp) throw new Error('无法连接 Chrome 调试端口')
    await cdp.send('Page.enable')
    await cdp.send('Runtime.enable')

    const go = async (url) => {
      await cdp.send('Page.navigate', { url })
      await waitFor(cdp, `document.readyState === 'complete'`, 'load ' + url)
      await sleep(800)
    }

    await go(BASE + '/student/login')
    const login = await cdp.eval(`
      fetch('/api/student/login', { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: ${JSON.stringify(username)}, password: 'probe-password-1' }) })
        .then((r) => r.json()).then((data) => { sessionStorage.setItem('student_access_token', data.access_token); return data.access_token ? 'ok' : 'fail' })
    `)
    console.log('页面内学生登录 ->', login)

    // 标签页 A：首次开始推演
    await go(BASE + '/student/' + CASE_TOKEN)
    await waitFor(cdp, `document.body.innerText.includes('开始推演')`, '案例页渲染')
    console.log('标签页 A 点击开始推演 ->', await cdp.eval(clickByText('开始推演')))
    await waitFor(cdp, `document.body.innerText.includes('第 1 / 3 轮')`, '首次开始后进入第 1 轮')
    console.log('标签页 A 已进入推演，正文片段：', (await cdp.eval(bodyText)).replace(/\s+/g, ' ').slice(0, 60))

    // 标签页 B：清掉本地会话（等价于另一台设备/新标签页）后再次开始
    await cdp.eval(`sessionStorage.removeItem('student_session:${CASE_TOKEN}'); 'cleared'`)
    await go(BASE + '/student/' + CASE_TOKEN)
    await waitFor(cdp, `document.body.innerText.includes('开始推演')`, '第二次进入案例页')
    console.log('标签页 B 点击开始推演 ->', await cdp.eval(clickByText('开始推演')))
    await waitFor(cdp, `document.body.innerText.includes('已有本案例推演记录')`, '出现冲突文案')

    const text = await cdp.eval(bodyText)
    const entry = await cdp.eval(`
      [...document.querySelectorAll('button')].some((b) => (b.textContent || '').includes('我的记录'))
    `)
    console.log('标签页 B 页面文案含指定提示 ->', text.includes('已有本案例推演记录，请从「我的记录」继续'))
    console.log('标签页 B 页面文案含误导旧提示 ->', text.includes('请求参数不符合要求'))
    console.log('标签页 B 存在「我的记录」可点击入口 ->', entry)
    console.log('标签页 B 正文片段：', text.replace(/\s+/g, ' ').slice(0, 120))

    // 顶部截图：冲突文案（Alert）
    const topShot = await cdp.send('Page.captureScreenshot', { format: 'png' })
    const topPath = path.join(__dirname, '验证截图', 'concurrency-409-alert.png')
    fs.mkdirSync(path.dirname(topPath), { recursive: true })
    fs.writeFileSync(topPath, Buffer.from(topShot.data, 'base64'))
    console.log('截图已保存 ->', topPath)

    // 把入口按钮滚到视口内，截图才能同时看到提示文案和可点击入口
    await cdp.eval(`
      (() => {
        const button = [...document.querySelectorAll('button')].find((b) => (b.textContent || '').includes('我的记录'));
        button?.scrollIntoView({ block: 'center' });
        return true;
      })()
    `)
    await sleep(400)
    const shot = await cdp.send('Page.captureScreenshot', { format: 'png' })
    const shotPath = path.join(__dirname, '验证截图', 'concurrency-409-records-entry.png')
    fs.mkdirSync(path.dirname(shotPath), { recursive: true })
    fs.writeFileSync(shotPath, Buffer.from(shot.data, 'base64'))
    console.log('截图已保存 ->', shotPath)

    console.log('点击入口 ->', await cdp.eval(clickByText('我的记录')))
    await waitFor(cdp, `location.pathname === '/student/records'`, '跳转 /student/records')
    console.log('当前路径 ->', await cdp.eval('location.pathname'))
    await waitFor(cdp, `document.body.innerText.includes('继续推演')`, '记录页渲染继续入口')
    console.log('点击"继续推演" ->', await cdp.eval(clickByText('继续推演')))
    await waitFor(cdp, `location.pathname === '/student/${CASE_TOKEN}'`, '回到案例页')
    await waitFor(cdp, `document.body.innerText.includes('第 1 / 3 轮')`, '进度已恢复')
    console.log('恢复后路径 ->', await cdp.eval('location.pathname'))
    console.log('恢复后的进度文案 ->', (await cdp.eval(bodyText)).match(/第 \d \/ 3 轮/)?.[0])
    console.log('RESULT: PASS')
  } finally {
    try { cdp?.ws.close() } catch {}
    chrome.kill()
  }
}

main().catch((error) => { console.error('RESULT: FAIL', error.message); process.exitCode = 1 })
