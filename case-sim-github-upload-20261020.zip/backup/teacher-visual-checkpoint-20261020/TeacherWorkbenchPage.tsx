import { listCaseAiTasks } from '../../features/ai/api'
import TaskStatus, { pendingTask } from '../../features/ai/TaskStatus'
import type { AiTaskResponse } from '../../api/types'
import { useContext, useEffect, useRef, useState } from 'react'
import { TeacherDraftContext } from '../../context/TeacherDraftContext'
import { Alert, App as AntdApp, Button, Card, Popconfirm, Input, Steps, Space, Spin, Tag, Typography } from 'antd'
import { createCase, deleteCase, getCase, listCases } from '../../api/client'
import type { CaseListItem, CreateCasePayload, GetCaseResponse, PublishResponse } from '../../api/types'
import { useTeacherToken } from '../../context/TeacherTokenContext'
import AiFixDrawer from '../../features/ai/AiFixDrawer'
import CalibratePanel from './components/CalibratePanel'
import GeneratePanel from '../../features/ai/GeneratePanel'
import PublishPanel from './components/PublishPanel'
import { STATUS_META } from './teacherConstants'
import './teacher.css'

const SELECTION_KEY = 'teacher_selected_case'
export default function TeacherWorkbenchPage() {
  const teacherToken = useTeacherToken()
  const { message } = AntdApp.useApp()
  const registerDraft = useContext(TeacherDraftContext)
  const [stage, setStage] = useState(1)
  const [creating, setCreating] = useState(false)
  const [search, setSearch] = useState('')
  const [dirtyParts, setDirtyParts] = useState<string[]>([])
  const [sourceDirty, setSourceDirty] = useState(false)
  const hasDraft = dirtyParts.length > 0 || sourceDirty
  const dirtyRef = useRef(false)
  dirtyRef.current = hasDraft
  useEffect(() => { registerDraft(hasDraft); return () => registerDraft(false) }, [hasDraft, registerDraft])
  useEffect(() => {
    const warn = (e: BeforeUnloadEvent) => { if (dirtyRef.current) { e.preventDefault(); e.returnValue = '' } }
    window.addEventListener('beforeunload', warn)
    return () => window.removeEventListener('beforeunload', warn)
  }, [])
  function mayDiscard() { return !hasDraft || window.confirm('还有未保存的编辑或正在执行的操作。切换案例会丢弃未保存内容，是否继续？') }
  function chooseCase(id: number) {
    if (id === caseId && !creating) return
    if (!mayDiscard()) return
    setDirtyParts([]); setSourceDirty(false); setCreating(false); setCaseId(id); setStage(1); setGenErrors([])
  }
  const [caseList, setCaseList] = useState<CaseListItem[]>([])
  const [listLoading, setListLoading] = useState(true)
  const [caseId, setCaseId] = useState<number | null>(null)
  const [detail, setDetail] = useState<GetCaseResponse | null>(null)
  const [task, setTask] = useState<AiTaskResponse | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const [connectionError, setConnectionError] = useState('')
  const [listError, setListError] = useState('')
  const [genErrors, setGenErrors] = useState<string[]>([])
  const [publishResult, setPublishResult] = useState<PublishResponse | null>(null)
  const [refresh, setRefresh] = useState(0), [listRefresh, setListRefresh] = useState(0)
  const [draftRevision, setDraftRevision] = useState(0)
  const saveRead = useRef(0)
  const currentDetailId = useRef<number | null>(null)
  const currentScope = useRef({ caseId, teacherToken })
  currentScope.current = { caseId, teacherToken }
  const mounted = useRef(false), uploadLock = useRef(false)
  useEffect(() => { mounted.current = true; return () => { mounted.current = false } }, [])

  useEffect(() => {
    let active = true, timer: number | undefined
    async function pollList() {
      let retry = true
      try {
        const rows = await listCases(teacherToken)
        if (!active) return
        setCaseList(rows)
        setListError('')
        setCaseId((current) => {
          if (current !== null) return current
          let saved = 0
          try { saved = Number(sessionStorage.getItem(SELECTION_KEY)) } catch { /* optional */ }
          return rows.find((row) => row.id === saved)?.id ?? rows.find((row) => row.status === 'generating')?.id ?? rows[0]?.id ?? null
        })
      } catch (e) {
        if (!active) return
        const status = (e as { status?: number }).status
        retry = status !== 401 && status !== 403
        setListError('案例列表暂不可用；已受理的任务仍由后台执行。')
      } finally {
        if (active) { setListLoading(false); if (retry) timer = window.setTimeout(() => void pollList(), 5000) }
      }
    }
    void pollList()
    return () => { active = false; window.clearTimeout(timer) }
  }, [teacherToken, listRefresh])

  useEffect(() => {
    let active = true, timer: number | undefined, failures = 0
    setConnectionError('')
    if (currentDetailId.current !== caseId) { setDetail(null); setTask(null); setPublishResult(null); currentDetailId.current = caseId }
    if (caseId === null) return
    try { sessionStorage.setItem(SELECTION_KEY, String(caseId)) } catch { /* optional */ }
    async function poll() {
      let again = false
      try {
        const [response, tasks] = await Promise.all([getCase(caseId!, teacherToken), listCaseAiTasks(caseId!, teacherToken)])
        if (!active) return
        const latest = tasks[0] ?? null
        setDetail(response); setDraftRevision(n => n + 1); setTask(latest); setConnectionError(''); failures = 0
        setCaseList((rows) => rows.map((row) => row.id === response.case.id ? { ...row, status: response.case.status } : row))
        again = response.case.status === 'generating' || pendingTask(latest)
      } catch (e) {
        if (!active) return
        failures++
        const status = (e as { status?: number }).status
        again = ![401, 403, 404].includes(status ?? 0)
        setConnectionError(again ? '进度连接暂时中断，正在自动重连；不会取消后台任务。' : '无法读取案例，请重新登录或选择其他案例。')
      } finally {
        if (active && again) timer = window.setTimeout(() => void poll(), Math.min(15000, 2000 * (1 + failures)))
      }
    }
    void poll()
    return () => { active = false; window.clearTimeout(timer) }
  }, [caseId, teacherToken, refresh])

  // Saving is a metadata synchronization, not a navigation/generation refresh.
  // Keep the editor mounted and leave all unsaved drafts untouched.
  async function syncAfterSave() {
    if (caseId === null) return
    const request = ++saveRead.current
    try {
      const response = await getCase(caseId, teacherToken)
      if (!mounted.current || request !== saveRead.current || currentScope.current.caseId !== caseId || currentScope.current.teacherToken !== teacherToken) return
      setDetail(response)
      setPublishResult(null)
      setCaseList(rows => rows.map(row => row.id === response.case.id ? { ...row, title: response.case.title, status: response.case.status } : row))
    } catch {
      if (mounted.current && currentScope.current.caseId === caseId && currentScope.current.teacherToken === teacherToken) message.warning('保存已完成，但最新状态同步失败；当前编辑内容已保留。')
    }
  }

  async function handleGenerate(payload: CreateCasePayload): Promise<boolean> {
    if (uploadLock.current) return false
    uploadLock.current = true; setSubmitting(true); setGenErrors([])
    try {
      const created = await createCase(payload)
      try { sessionStorage.setItem(SELECTION_KEY, String(created.case_id)) } catch { /* optional */ }
      if (mounted.current) {
        setCreating(false); setStage(1); setSourceDirty(false); setDirtyParts([]); setCaseId(created.case_id); setRefresh((n) => n + 1); setListRefresh((n) => n + 1)
        if (created.warning) setGenErrors(created.errors ?? [created.warning])
        else message.success('素材已受理，任务已保存到后台；可以切换页面，稍后回来查看。')
      }
      return true
    } catch {
      if (mounted.current) setGenErrors(['上传或受理未确认，请刷新案例列表确认是否已创建，再决定是否重试。'])
      return false
    } finally {
      uploadLock.current = false
      if (mounted.current) setSubmitting(false)
    }
  }

  async function handleDeleteSelectedCase() {
    if (caseId === null) return
    const deletingId = caseId
    try {
      await deleteCase(deletingId, teacherToken)
      try { sessionStorage.removeItem(SELECTION_KEY) } catch { /* optional */ }
      setCaseId(null)
      setDetail(null)
      setCaseList((rows) => rows.filter((row) => row.id !== deletingId))
      setListRefresh((n) => n + 1)
      message.success('案例及其关联记录已删除。')
    } catch (e) {
      const detail = (e as { detail?: string }).detail
      message.error(detail || '删除失败；若案例仍有后台任务，请等待任务结束后重试。')
    }
  }

  const selected = detail?.case.id === caseId ? detail : null
  const selectedTask = selected ? task : null
  const busy = selected?.case.status === 'generating' || pendingTask(selectedTask)
  const statusMeta = selected ? STATUS_META[selected.case.status] : null
  const running = caseList.filter((row) => row.status === 'generating')
  return <div className="teacher-workspace">
    <div className="teacher-page-head"><div><Typography.Title level={3} style={{ margin: 0 }}>案例工作区</Typography.Title><Typography.Text type="secondary">按教学任务准备案例。草稿保存与发布分开，已有推演保持原版本。</Typography.Text></div>
      <Button type="primary" disabled={submitting} onClick={() => { if (mayDiscard()) { setCreating(true); setStage(0); setDirtyParts([]) } }}>新建案例</Button>
    </div>
    <div className="case-workspace-grid">
    <aside className="case-library" aria-label="案例库"><Card title="案例库" size="small">
      <Input.Search aria-label="搜索案例" placeholder="搜索案例标题" value={search} onChange={e => setSearch(e.target.value)} />
      {listLoading && <Spin />}
      <div className="case-library-list">{caseList.filter(r => r.title.toLowerCase().includes(search.trim().toLowerCase())).map(row => <Button key={row.id} data-case-id={row.id} block type={!creating && row.id === caseId ? 'primary' : 'text'} onClick={() => chooseCase(row.id)}>
        <span>{row.title}<small>{STATUS_META[row.status].text}</small></span>
      </Button>)}</div>
      {!listLoading && !caseList.length && <p>还没有案例，点击“新建案例”开始。</p>}
      {!!search && !caseList.some(r => r.title.toLowerCase().includes(search.trim().toLowerCase())) && <p>没有匹配案例</p>}
    </Card></aside>
    <section className="case-editor" aria-label="案例编辑">
    {listError && <Alert showIcon type="warning" message={listError} />}
    {connectionError && <Alert showIcon type="warning" message={connectionError} />}
    <Steps size="small" current={creating ? 0 : stage} onChange={next => setStage(next)} items={[
      { title: '素材与生成', disabled: creating }, { title: '财务基准', disabled: creating || !selected },
      { title: '节点与规则', disabled: creating || !selected?.nodes.length }, { title: '检查与发布', disabled: creating || !selected },
    ]} />
    {creating ? <GeneratePanel generating={submitting} statusText="正在上传并保存任务，请等待受理确认" errors={genErrors} onGenerate={handleGenerate} onDirtyChange={setSourceDirty} /> : <>
      {selected && <div className="editor-status"><Space wrap><Typography.Text strong>{selected.case.title}</Typography.Text>{statusMeta && <Tag color={statusMeta.color}>{statusMeta.text}</Tag>}<Tag>草稿版本 {selected.case.version}</Tag></Space>
        <Space wrap><Button onClick={() => { setRefresh(n => n + 1); setListRefresh(n => n + 1) }}>刷新进度</Button><Popconfirm title="确定删除当前案例？" description="案例、学生提交记录及关联 AI 产物将一并删除，且无法撤销。" okText="删除" cancelText="取消" okButtonProps={{ danger: true }} onConfirm={() => void handleDeleteSelectedCase()}><Button danger disabled={!!busy || hasDraft}>删除案例</Button></Popconfirm></Space>
      </div>}
      <div role="status" className="draft-status">{dirtyParts.length ? `待处理：${dirtyParts.join('、')}。切换阶段会保留编辑，离开页面前请保存。` : '当前无未保存编辑。保存草稿后仍需发布，新推演才会使用修改。'}</div>
      {selectedTask && <TaskStatus task={selectedTask} busy={!!busy} />}
      {stage === 0 && <Card title="素材与生成"><p>当前案例已受理。原始素材用于教师核对，创建另一案例请使用“新建案例”。</p><details><summary>查看原始素材</summary><Typography.Paragraph style={{ whiteSpace: 'pre-wrap' }}>{selected?.case.source_text || '暂无可展示素材'}</Typography.Paragraph></details><Button onClick={() => setStage(1)} disabled={!selected}>进入财务基准</Button></Card>}
      {selected ? <>
        <div hidden={stage !== 1 && stage !== 2}><CalibratePanel key={selected.case.id} stage={stage} onDirtyChange={setDirtyParts} teacherToken={teacherToken} detail={selected} draftRevision={draftRevision} onSaveRefresh={syncAfterSave} onRefresh={async () => { setRefresh(n => n + 1) }} /></div>
        <div hidden={stage !== 3}><PublishPanel teacherToken={teacherToken} detail={selected} publishResult={publishResult} onPublished={setPublishResult} blocked={dirtyParts} onEdit={setStage} /></div>
        <AiFixDrawer key={selected.case.id} teacherToken={teacherToken} caseId={caseId} nodes={selected.nodes} />
        <Space wrap className="stage-actions"><Button disabled={stage === 0} onClick={() => setStage(s => Math.max(0, s - 1))}>上一阶段</Button><Button disabled={stage >= 3 || (stage === 1 && !selected.nodes.length)} onClick={() => setStage(s => Math.min(3, s + 1))}>下一阶段</Button>{stage === 1 && !selected.nodes.length && <Typography.Text type="secondary">确认财务基准并生成节点后，进入下一阶段。</Typography.Text>}</Space>
      </> : <Card>{busy || caseId !== null ? <Spin /> : <Typography.Text>选择已有案例，或新建案例开始备课。</Typography.Text>}</Card>}
    </>}
    {running.length > 0 && <Typography.Text type="secondary">后台有 {running.length} 个案例生成中，可从案例库查看。</Typography.Text>}
    </section></div>
  </div>
}
