# case_sim 前端改造：AI 自治执行清单（GitHub 优秀项目驱动）

> **目标**：让 AI 承担 90% 以上的开发工作，用户仅在关键决策点确认。每个改造点都直接关联到可验证的 GitHub 开源项目资源。
>
> **参考项目**：
> - [ant-design/ant-design-pro](https://github.com/ant-design/ant-design-pro)（38.8k★）— ProLayout、Step Form、Dashboard Analysis、暗色模式
>   - ProLayout 文档：https://procomponents.ant.design/components/layout
>   - StepsForm 文档：https://procomponents.ant.design/components/steps-form
>   - 主题 Token 文档：https://ant.design/docs/react/customize-theme
> - [learnhouse/learnhouse](https://github.com/learnhouse/learnhouse)（2.4k★）— 学生端仪表盘、Playgrounds 交互、Analytics 追踪
> - [Starmax-technology/wuqingnan-star.github.io](https://github.com/Starmax-technology/wuqingnan-star.github.io) — React + AntD + ECharts KPI 卡片与图表
>   - Dashboard.tsx（23KB）：KPI 卡片行 + 多种图表组合布局
>   - HmcOptionsStats.tsx（9.8KB）：选项分布统计柱状图——与我们阶段 5 的 A/B/C 直方图 1:1 对应
>   - SubmissionsTable.tsx（11KB）：提交记录表格——可替换教师记录页两层 Collapse 套娃
> - [BizOn](https://bizonland.com/) — 商业模拟教学游戏，F12 可直接查看 clay 色值、风险卡片样式、双设计语域实现
> - [recharts/recharts](https://github.com/recharts/recharts)（27.6k★）— React 原生图表库（基于 D3），D3 决策的中间选项
>   - BarChart 示例：https://recharts.org/en-US/examples/SimpleBarChart（对应 A/B/C 选项分布）
>   - LineChart 示例：https://recharts.org/en-US/examples/SimpleLineChart（对应 3 轮财务对比）
>   - RadarChart 示例：https://recharts.org/en-US/examples/SimpleRadarChart（对应复盘 5 维评分）
> - [apache/echarts](https://github.com/apache/echarts)（60k★）— Canvas 渲染，视觉最专业；**按需引入后仅 80–130KB gzipped**
>   - 按需引入文档：https://echarts.apache.org/handbook/zh/basics/import
>   - React 封装 `echarts-for-react`：https://github.com/hustcc/echarts-for-react
>   - 中文示例库：https://echarts.apache.org/examples/zh/index.html

---

## 执行模式说明

| 角色 | 职责 | 占比 |
|---|---|---|
| **AI Agent（Codex/Claude Code）** | 代码分析、方案设计、自动修改、集成测试、文档生成 | ~90% |
| **用户（你）** | 关键决策确认、运行启动命令、浏览器目视验收、财务数字人工复核 | ~10% |

**用户只需做三件事**：
1. 复制提示词到 AI 工具 → 发出去
2. AI 完成后，运行 `npm run dev` → 浏览器看一眼
3. 财务联动数字对不对 → 对就继续，不对就截图发回

### 全局铁律：路径别名"配而未用"，禁止 AI 主动启用

阶段 1.5 已配置 7 条别名（`@` / `@components` / `@features` / `@api` / `@pages` / `@layouts` / `@domain`），但**全部 50 个源码文件仍用相对路径导入，0 处使用别名**。这是有意为之：

- **测试的 vm 沙箱以相对路径作为 mock key**（`'./baselineFinance'`、`'./ProgressivePanel'`、`'./teacherConstants'` 等），一旦某个组件改成别名导入，`require` 拦截表匹配不到 → 测试崩。
- 因此：**任何阶段的 AI 都不得"顺手美化 import"**。别名配置放着不动，等测试体系整体迁移到 vitest/别名 mock 之后再用。

这条要写进每一个阶段的提示词，否则 AI 看到已配置的 alias 会忍不住用。

---

## 关键决策点（仅这些需要用户拍板）

| 决策点 | 出现在 | 默认选择 | 用户可改 |
|---|---|---|---|
| D1：是否安装 `@ant-design/pro-components`？ | 阶段 2 | **否**（用原生 AntD ConfigProvider，减少依赖风险） | 可改为"是" |
| D2：是否支持暗色模式？ | 阶段 2 | **否**（交付优先，暗色模式可后续追加） | 可改为"是" |
| D3：图表库选哪个？ | 阶段 5 | **ECharts 按需引入**（视觉最专业，80–130KB） | 用户于 2026-10-20 19:09 确认选 C；阶段 5/7 均按 ECharts 执行 |
| D4：复盘页雷达图是否用真实 5 维评分？ | 阶段 7 | **先用 mock 数据占位** | 等后端接口补充后替换 |
| D5：学生端 FAB 点击后展开面板还是全屏？ | 阶段 8 | **面板**（360×480 桌面 / 100%宽 60%高 移动端） | 可改 |

### D3 图表库三选一对比（**体积数据已修正**）

> ⚠️ **重要纠正**：此前流传的"ECharts 1MB gzipped"是**错误数据**。1MB 是**未压缩**体积，gzipped 后约 320KB；**按需引入后仅 80–130KB**，与 recharts 持平甚至更小。下表为修正后的真实数据。

| 对比项 | 纯 CSS | recharts | ECharts（按需引入） | ECharts（全量引入） |
|---|---|---|---|---|
| **体积（gzipped）** | 0 KB | **~130 KB** | **~80–130 KB** | ~320–340 KB |
| 渲染方式 | DOM/SVG 手撸 | SVG | Canvas（10万点流畅） | Canvas |
| React 原生 | ❌ | ✅ 声明式组件 | ❌ 命令式 option + `echarts-for-react` 封装 | 同左 |
| **错误可见性** | 人眼 | **✅ TS 编译期报错** | ⚠️ **option 字段名写错静默失败** | 同左 |
| 与 AntD 5 视觉协调 | 高 | 高 | 中高（可配 theme 对齐） | 同左 |
| 柱状图/折线图/雷达图 | 全部手撸 | 各一行组件 | 各一段 option | 同左 |
| 视觉专业度 | 一般 | 中高 | **最高**（默认动画/渐变/阴影精致） | 同左 |
| 中文文档 | — | 英文为主 | **✅ 国产，中文文档一流** | 同左 |
| 星数 | — | 27.6k★ | 60k★ | 同左 |
| 适用场景 | 1–2 个简易柱状图 | 中小型图表，要 TS 类型安全 | **比赛演示、追求视觉专业度** | 不推荐（没必要全量） |

**结论修正**：体积不再构成 ECharts 的劣势（按需引入 80–130KB ≈ recharts）。真正的差异只剩两条：

1. **错误可见性**——recharts 的 props 写错 TS 直接报错；ECharts 的 option 里 `xAxis` 写成 `xaxis`，**不报错、不显示、无日志**，AI 自己 review 代码看不出来，必须人眼在浏览器里确认。
2. **视觉专业度**——ECharts 默认效果明显更"商业级"，对评委现场演示更有说服力。

**推荐策略**：
- **求稳 → recharts**：TS 类型安全兜底，AI 出错概率最低，体积相当。
- **求效果 → ECharts（按需引入）**：视觉最好、中文文档最全，代价是每个图表必须人眼验证一次。

**版本与写法约束（ECharts 若启用）**：
- 安装 `npm install echarts echarts-for-react`（5.x，无需锁小版本）
- **必须按需引入**，禁止 `import * as echarts from 'echarts'`（全量 320KB）：
  ```ts
  import * as echarts from 'echarts/core'
  import { BarChart, LineChart, RadarChart } from 'echarts/charts'
  import { GridComponent, TooltipComponent, LegendComponent, TitleComponent } from 'echarts/components'
  import { CanvasRenderer } from 'echarts/renderers'
  echarts.use([BarChart, LineChart, RadarChart, GridComponent, TooltipComponent, LegendComponent, TitleComponent, CanvasRenderer])
  ```
- 只允许在阶段 5、阶段 7 的组件内引入
- `npm run build` 后 `dist/assets/*.js` 总增量 ≤ 250 KB

**版本约束（recharts 若启用）**：
- 安装 `npm install recharts@^2.15.0`（React 18 稳定兼容版；3.x 有 breaking change，本项目不用）
- 只允许在阶段 5、阶段 7 的组件内 `import`，禁止在 `main.tsx` 全局引入
- `npm run build` 后检查 `dist/assets/*.js` 总大小增量 ≤ 250 KB

---

## 阶段 0：AI 自动盘点（零用户操作）

### 【复制给 AI 的提示词】（发送给项目总控）

```
你是一个自主前端改造 Agent。请对 C:\Users\huang2006\Desktop\Work\upload2\case_sim-\frontend\ 执行全自动只读盘点。

必须读取的文件（逐行分析）：
1. package.json —— 提取 dependencies + devDependencies 及版本
2. vite.config.ts —— 提取端口、代理、别名
3. src/App.tsx —— 提取路由结构（/teacher/*、/student/* 子路由）
4. src/api/types.ts —— 提取所有 export 的 interface/type 名称及关键字段
5. src/api/client.ts —— 提取所有 API 函数名
6. src/layouts/TeacherLayout.tsx + TeacherLayout.css
7. src/layouts/StudentLayout.tsx + StudentLayout.css
8. src/pages/teacher/TeacherWorkbenchPage.tsx
9. src/pages/teacher/components/CalibratePanel.tsx —— 统计行数、组件拆分建议
10. src/pages/teacher/components/baselineFinance.ts —— 完整提取三个导出函数的逻辑
11. src/pages/student/StudentPlayPage.tsx
12. src/pages/student/StudentReviewPage.tsx
13. src/features/ai/StudentTutorSidebar.tsx
14. tests/ 下所有测试文件

输出格式（Markdown）：
- 一页式现状摘要（技术栈、依赖数、测试数、关键文件行数）
- 路由表
- API 类型清单
- 风险标记（文件超过 500 行、复杂度高的函数）
- 改造难度评估（1-10分）

禁止修改任何文件。如果文件不存在，明确报告"缺失"。
```

### 【用户操作】

**无。AI 完成后直接输出报告。**

---

## 阶段 1：AI 自动冻结接口契约 ✅ 已完成（2026-10-20）

> ### ⚠️ 原提示词有重大错误，已修正（务必知悉）
>
> 原提示词写的是"读取 **contracts/** 下所有 .py 文件，比对 `frontend/src/api/types.ts`"。**这是错的。**
>
> `contracts/README.md:36` 原文明确：
> > 「HTTP DTO 的权威定义仍是 **backend/app/schemas.py**；前端静态类型在 **frontend/src/api/types.ts**。内部 Python interface 不等同于 HTTP DTO，不复制一份新的 HTTP schema；联调测试验证两侧兼容。」
>
> 也就是说：
> | 位置 | 真实职责 | 是否该用来核对接口契约 |
> |---|---|---|
> | `backend/app/schemas.py`（**537 行**） | **HTTP DTO 权威定义** | ✅ **必须读** |
> | `frontend/src/api/types.ts`（372 行） | 前端静态类型 | ✅ **必须读** |
> | `contracts/`（7 个 .py，共 223 行） | **AI 内部 seam**（TeachingPolicy / ReviewInput / TutorTools / JsonModel / 错误语义 / presentation / telemetry） | ❌ **与 HTTP 接口契约无关** |
>
> 若按原提示词执行，AI 会读到一堆 AI 内部 Protocol 和 dataclass，**拿不到任何 T/S 接口字段**，产出的"冻结清单"是空的。此项已由你另行完成，结论见 `case-sim接口契约核对与冻结清单.md`。

### 【原始提示词（存档，已被修正版取代）】

```
你是一个接口契约核对 Agent。请执行以下只读核对：

1. 读取 backend/app/schemas.py（HTTP DTO 权威定义，约 537 行）
2. 读取 frontend/src/api/types.ts（前端静态类型，约 372 行）
3. 读取 backend/app/routers/ 下的路由实现，确认每个 response_model 与返回形状
4. 比对：
   - schemas.py 中每个 DTO，types.ts 是否有对应 TypeScript 类型
   - 字段名是否完全一致（大小写、下划线）
   - 字段类型是否语义兼容（Python Optional → TS 可选属性、Python str → TS string 等）
   - 路由实际返回的字段是否超出 response_model（运行期多返回的情况）
5. 列出所有不一致项：字段缺失 / 名称不同 / 类型不兼容 / 前端多余字段 / 前端缺失字段
6. 输出《接口契约冻结清单》：
   - 教师端接口（T1–T9）字段表
   - 学生端接口（S1–S9）字段表（先确认 SPEC.md 里到底有哪些 S 编号）
   - 标注"本次改造禁止新增/删除/重命名字段"

注意：不要读 contracts/ 目录，那是 AI 内部 seam，不是 HTTP DTO。
禁止修改任何文件。
```

### 已完成结论摘要（详见 `case-sim接口契约核对与冻结清单.md`）

- HTTP DTO 权威 = `backend/app/schemas.py`（**537 行**）
- `contracts/` 共 7 个 .py / **223 行**，只含 2 个 dataclass（`TeachingPolicy`/`ReviewInput`）+ 2 个 Protocol（`TutorTools`/`JsonModel`）+ 错误类 + 工具函数，**无 T/S 字段，属 AI 内部 seam**
- 编号范围纠正两处：
  - **S7/S8/S9 不存在**，学生端只到 **S6**（全文检索无匹配）
  - **T10 存在但原清单漏了**：`PATCH /api/reviews/{review_id}`，教师端复盘校准，已补入冻结范围
- **15 项不一致**（P0 3 项 / P1 8 项 / P2 4 项）
- 字段命名：**零不一致**——两侧全 snake_case，前端未做驼峰转换
- 冻结范围实际覆盖：T1–T10（10）+ 教师端未编号接口（14）+ S1–S6（6）+ 学生端未编号接口（14）+ 共享子结构（4）+ 枚举（12 组）+ AI 入口（4）+ AI 内部模型（9 组）+ HTTP 兼容约定（4）+ 前端类型位置约定（4）
- 另冻结 **8 处"后端无结构 dict、前端却按精确键名硬取值"的隐式契约**（`financial_basis.indicators`、`path_comparison.rounds[].difference` 等）——不受 Pydantic 保护，但最容易在改造中被无意破坏
- **后续所有阶段的改造都必须以 `schemas.py` + `types.ts` 为准，不以 contracts/ 为准**
- 唯一允许的契约变更路径：**新增可选字段**，且顺序必须为 双方确认 → SPEC.md → schemas.py → types.ts → 两侧测试

### 存量缺陷（不属本次前端改造范围，但是真实存在的既有 bug）

| 编号 | 缺陷 | 实测确认 | 现状影响 |
|---|---|---|---|
| **D-01** | `DecideResult.financial_state` 后端定义并确实返回（`student.py:390`），前端 `types.ts` 无声明 | ✅ 已确认 | 前端静默丢弃该字段；目前靠"提交后重取整个会话"侥幸正常 |
| **D-02** | 前端 `StudentRecord` 声明 **16** 字段，后端 `schemas.py:381` 实际只返回 **8** 个 | ✅ 已确认（后端字段：student_name/student_id/attempt_no/turns/session_id/review_id/review_status/review） | **教师记录页真实故障**：`TeacherRecordsPage.tsx:31` 的版本集合恒为 `['unknown']` → `:39` 筛选器只有"全部版本/历史版本未知"两项 → `:51` 版本列恒显示"未记录" → `:58` 详情恒显示"案例版本 未记录"。**版本筛选功能实质失效** |
| **D-03** | 递进模拟接口是全项目唯一 `extra="forbid"` 严格契约（多传字段即 422），且 DTO 藏在 `domain/progressive.py` 而非 `schemas.py` | ✅ 已确认 | 改造中极易漏看；改动该接口请求体时多一个字段就 422 |

> **处置建议（不强制）**：
> - **D-02 建议单独修**（价值最高，是用户可见的功能失效）。两条路线：① 后端补 `case_version`/`case_title` 字段（**超出本次改造的"只改 frontend/"边界，需你单独批准**）；② 前端删掉版本列与版本筛选器（纯前端、诚实，但丢功能）。**当前清单所有阶段都不处理它**，避免 scope creep。
> - D-01、D-03 记录在案即可，改造时不要碰。

---

## 阶段 1.5：基建补齐 ✅ 已完成（2026-10-20，复核通过）

> 此项原不在清单中，来自阶段 0 盘点报告的建议。**已完成，无需再执行。**

### 已落地的三项

| 项 | 实际结果 |
|---|---|
| **路径别名** | `vite.config.ts` 7 条 alias（`@` / `@components` / `@features` / `@api` / `@pages` / `@layouts` / `@domain`）；`tsconfig.app.json` 对应 `paths`（无 `baseUrl`，TS 6.0 bundler 模式相对 tsconfig 解析）。**已用临时探针文件实测 `tsc -b` 通过，别名真实可解析**。业务文件当前使用别名 import 数 = 0（有意不批量改，避免 diff 噪音） |
| **测试保卫战** | 3 处源码文本契约改写为行为断言：`baseline-finance.test.cjs`（直接调纯函数验证返回值）、`merged-calibration.test.cjs`（vm 挂载组件遍历渲染树断言 Table 列结构）、`teacher-background.test.cjs`（触发保存后断言编辑器不卸载 / draftRevision 不变） |
| **基线数据** | `npm test` 60/60、`tsc -b` 0 错误、`vite build` 4.36s 成功；`dist/assets/antd-vendor` 单包 1047.79 kB / gzip 318.63 kB |

### 遗留（不影响后续阶段）

- `index.css` 的 `--color-primary-teacher` / `--color-primary-student` **无消费方**（死代码），留待阶段 3 的视觉收尾接上。
- 除上述 3 个文件外，其余 12 个测试文件仍含 `readFileSync`，但多数是 `transpileModule` 后挂载组件的合法行为测试，**不是源码文本断言**，无需处理。

---

## 阶段 2：AI 自动配置主题 ✅ 已完成（2026-10-20，复核通过）

> **实际落地情况**（与下方原始提示词的差异）：
> - `main.tsx` 新增 `ThemedApp` 组件，在 `RouterProvider` 内用 `useLocation()` 读 `pathname` 切 `ConfigProvider` 的 `colorPrimary`；未用 `window.location`。
> - `index.css` 变量名实际为 `--color-primary-teacher` / `--color-primary-student`（非 `--teacher-primary`）。
> - **未做**第 5 步"在 TeacherLayout.css / StudentLayout.css 中使用变量"——这两个 CSS 当时没有硬编码品牌色，所以没改；代价是**这两个 CSS 变量目前无消费方（死代码）**，留待阶段 3 接上。
> - 复核数据：`npm test` 60/60、`tsc -b` 0 错误、`vite build` 4.36s 成功。
>
> 若需重跑或给新成员讲解，保留下方原始提示词作为参考。

### 【原始提示词（存档，无需再执行）】

```
你是 case_sim 前端改造的教师端 Agent。请执行主题配置改造，参考 ant-design-pro 的主题配置模式：

参考资源：
- AntD v5 定制主题官方文档：https://ant.design/docs/react/customize-theme
- AntD ConfigProvider 组件文档：https://ant.design/components/config-provider

任务：
1. 在 frontend/src/main.tsx 中包裹全局 ConfigProvider：
   - 教师端路由（/teacher/*）：主色 #1a3a5c（深蓝），辅助色 #c9a227（金色），错误色 #ff4d4f
   - 学生端路由（/student/*）：主色 #db2777（玫红），成功色 #16a34a，警告色 #ca8a04，危险色 #dc2626
   - 判断路由的方式：用 window.location.pathname.startsWith('/teacher') 或从 router 配置中读取
2. 不要安装 @ant-design/pro-components（保持零新增重量级依赖）。
3. 不要实现暗色模式（简化交付）。
4. 修改 src/index.css，添加全局变量：
   :root { --teacher-primary: #1a3a5c; --student-primary: #db2777; }
5. 在 TeacherLayout.css 和 StudentLayout.css 中使用这些 CSS 变量替换硬编码颜色。

禁止：
- 修改 backend/、contracts/、ai_component/
- 修改 baselineFinance.ts、financials.ts
- 新增 LLM 调用或密钥

验收：
- npm run dev 启动后，教师端按钮/链接为深蓝色，学生端为玫红色
- npm test 通过
- 浏览器控制台无红色报错

交付：修改文件列表 + 主题色截图描述 + 测试通过证明。
```

### 【用户操作】

1. AI 完成后，在终端运行：
   ```bash
   cd "C:\Users\huang2006\Desktop\Work\upload2\case_sim-\frontend"
   npm run dev
   ```
2. 浏览器打开 `http://localhost:5174/teacher/login`，确认颜色是深蓝色。
3. 打开 `http://localhost:5174/student`，确认颜色是玫红色。
4. 终端按 `Ctrl+C` 停止，然后运行 `npm test`。

---

## 阶段 3：教师端布局 ⚠️ 经复核——**核心功能已存在，仅剩视觉收尾**

> **重要更正（2026-10-20 读码核实）**：原清单写的"把 Select 下拉选案例改造为侧栏案例列表"是**过时描述**。实际代码中**根本没有 Select**，双栏布局早已实现：
>
> | 能力 | 现状 | 代码位置 |
> |---|---|---|
> | 双栏网格（220px 侧栏 + 主区） | ✅ 已实现 | `teacher.css:129` `.case-workspace-grid { grid-template-columns: 220px minmax(0,1fr) }` |
> | 侧栏吸附滚动 | ✅ 已实现 | `teacher.css:130-131` `position: sticky` + `max-height: 65vh` |
> | 搜索框 | ✅ 已实现 | `TeacherWorkbenchPage.tsx:183` `Input.Search` + 前端过滤 |
> | 案例列表 + 选中态 | ✅ 已实现 | `TeacherWorkbenchPage.tsx:185` `type={... ? 'primary' : 'text'}` |
> | 状态文字标签 | ✅ 已实现（灰色小字） | `TeacherWorkbenchPage.tsx:186` `<small>{STATUS_META[row.status].text}</small>` |
> | 空态 / 无匹配提示 | ✅ 已实现 | `TeacherWorkbenchPage.tsx:188-189` |
> | 窄屏折叠单列 | ✅ 已实现 | `teacher.css:151` `@media (max-width:1100px)` |
> | 顶层 4 步向导 | ✅ 已实现 | `TeacherWorkbenchPage.tsx:194` Steps（素材与生成/财务基准/节点与规则/检查与发布） |
>
> **结论：阶段 3 可以跳过，或只花 15 分钟做视觉收尾。**

### 剩余可做的视觉收尾（全部可选，优先级从高到低）

1. **状态标签从灰字升级为彩色 Tag**：`<small>` → `<Tag color={STATUS_META[row.status].color}>`，与 `editor-status` 区（第 199 行）的 Tag 风格统一。
2. **接上主题 CSS 变量**：把 `.case-library-list .ant-btn` 的选中态改成用 `var(--color-primary-teacher)`，让阶段 2 定义的两个变量不再是死代码。
3. 面包屑（当前无，但 `editor-status` 已有 `案例标题 + 状态 Tag + 版本 Tag`，信息上等价，可不做）。

### 【复制给 AI 的提示词（仅做视觉收尾时用）】

```
你是 case_sim 教师端 Agent。教师工作台的双栏布局、搜索、案例列表、状态文字均已实现，不要重做。

只做两件视觉收尾（改前先 git commit 建立检查点）：

1. 状态标签彩色化：src/pages/teacher/TeacherWorkbenchPage.tsx 第 186 行
   把 <small>{STATUS_META[row.status].text}</small> 改为 <Tag color={STATUS_META[row.status].color}>{STATUS_META[row.status].text}</Tag>
   确认文件顶部已 import Tag（已 import，见第 6 行）。确认 STATUS_META 在 teacherConstants.ts 中有 color 字段；若没有，按 draft=default、ready=green、published=purple 补齐。

2. 接上主题变量：src/pages/teacher/teacher.css 中 .case-library-list .ant-btn 相关规则
   选中态（.ant-btn-primary）改用 var(--color-primary-teacher)，替换任何硬编码蓝色。

禁止：
- 重写布局、改动 .case-workspace-grid 栅格
- 修改 chooseCase / listCases / 搜索过滤逻辑
- 修改 CalibratePanel、backend/、contracts/

验收：
- npm test 60/60 通过（含 merged-calibration 的行为断言）
- 浏览器：案例列表未选中项为文字按钮，选中项为深蓝主色，状态为彩色 Tag
- 窄屏（<1100px）仍折叠为单列

交付：改动行号 + 前后对比描述 + 测试结果。
```

### 【用户操作】

1. 跑 `npm run dev`，打开教师端看一眼**就够**——如果认可当前的灰色状态文字，**这个阶段直接跳过**，进阶段 4。

---

## 阶段 4：CalibratePanel 拆分 ⚠️ 架构冲突已修正（读码核实）

> **致命问题（原清单错误）**：原提示词要求"拆成 3 步 Step Form：基础信息 / 节点校准 / 发布预览，顶部用 AntD Steps 显示三步进度"。**这会与现有架构冲突**：
>
> 1. `TeacherWorkbenchPage.tsx:194` **已经有一个 4 步 Steps**（素材与生成 / 财务基准 / 节点与规则 / 检查与发布），由父组件 `stage` 状态驱动。
> 2. `CalibratePanel` 已经被父组件按 stage 渲染（`stage===1 || stage===2` 时显示，见第 206 行 `hidden` 切换），内部第 470 行已按 stage 分支标题：`stage === 1 ? '财务基准与案例信息' : '节点与递进规则'`。
> 3. 若在 CalibratePanel 内再加一个独立 3 步 Steps，用户会看到**两层步骤条嵌套**，且"发布预览"在第 3 步、但父组件第 4 步才是发布——**步骤语义重复且矛盾**。
>
> **正确做法**：不新增任何 Steps。把 680 行按 stage 拆成两个子组件 + 一个共用状态 hook，**保持"顶层 4 步是唯一向导"**。拆分目的是降复杂度，不是加导航。

> **必读约束（AI 动手前必须遵守）**：
> - **props 契约不可变**：`{ teacherToken, detail, onRefresh, onSaveRefresh, draftRevision, stage = 1, onDirtyChange }`。父组件第 206 行按此签名传参，改动会导致 TS 编译失败。
> - 🚨 **绝对不要在这个阶段启用路径别名**：`tests/merged-calibration.test.cjs:50-52` 的 vm 沙箱用**相对路径作为 mock key**（`'./ProgressivePanel'`、`'./baselineFinance'`、`'./metricAnnotation'`）。一旦 CalibratePanel 或新拆出的子组件改用 `@components/...` / `@domain/...` 导入，`require` 拦截表匹配不到，测试会直接崩。**拆分后所有 import 必须继续用相对路径。** 已核实同类风险存在于 `task-workspace.test.cjs`（`'./baselineFinance'`、`'./metricAnnotation'`）与 `teacher-background.test.cjs`（`'./teacherConstants'`）。
> - **`merged-calibration.test.cjs` 是行为断言且盯着 Table 结构**：它断言选项表 **6 列**、**无 `financial_assumptions` 列**、impact 单元格 render 为函数。拆分后若 Table 列数或列顺序变化，该测试会失败——**必须同步更新断言，不得删除测试**。
> - **`baselineFinance.test.cjs` 已改为直接调函数验证返回值**（不一致返回错误文案、一致返回 null、margin 联动重算成本）。不要因为它"不再检查源码"就以为可以随便改。
> - **不要碰 `domain/progressive.py` 对应的递进模拟接口**：它是全项目唯一 `extra="forbid"` 严格契约（多传一个字段即 422），DTO 不在 `schemas.py` 里。改造只改展示，不改该接口请求体。
> - 文件实际 **680 行**（字节级核验：LF=680、CR=0、CRLF=0、splitlines=680。此前"673 行"是 Get-Content 口径的少报，**以 680 为准**），17 个 `useState` + 5 个 `useEffect`。

### 【复制给 AI 的提示词】（发送给教师端对话）

```
你是 case_sim 教师端校准改造 Agent。目标：把 680 行的 CalibratePanel.tsx 按现有 stage 拆成两个子组件 + 一个状态 hook，降低单文件复杂度。

【重要：不要新增 Steps 组件】
项目顶层 TeacherWorkbenchPage.tsx:194 已有 4 步 Steps 作为唯一向导，CalibratePanel 由父组件 stage 驱动（stage=1 财务基准，stage=2 节点与规则）。你不得在 CalibratePanel 内再加任何 Steps/StepsForm，否则会出现双层向导。

【必须保持的 props 契约】
export default function CalibratePanel({ teacherToken, detail, onRefresh, onSaveRefresh, draftRevision, stage = 1, onDirtyChange }: CalibratePanelProps)
父组件 TeacherWorkbenchPage.tsx:206 按此签名调用，签名与字段名一个字都不能改。

【拆分目标】
1. 新建 hooks/useCalibrationState.ts：把现有的 drafts 状态与联动逻辑收拢为一个 hook
   - 承载：title / background / dilemma / metrics / nodes / revenueLink / netProfit / operatingCost / operatingExpense 等 useState
   - 承载：detail 变化时的同步 effect（**已知陈旧闭包风险点，已逐行核实**：现第 130-149 行，依赖数组为 `[detail?.case.id, draftRevision === undefined ? detail : draftRevision]`（第 149 行，用了条件表达式），但 effect 体内第 132/144 行读 `baselineDirty`、第 141 行读 `savedNodes`、第 142 行读 `dirtyNodes`——**三者均未列入依赖**。拆分时必须改为完整依赖数组，或用 `useRef` 持有最新值后读取，**不要把旧 bug 原样搬进 hook**）
   - 返回：状态 + setters + 保存函数（saveCase / saveNode）
2. 新建 components/BaselineSection.tsx：stage=1 的财务基准与案例信息 UI
   - 营收/毛利率/营业成本联动必须 100% 调用 baselineFinance.ts 的 linkedBaseline / baselineError，禁止复制或内联公式
   - 原第 470 行此处标题、原第 576 行之前的案例信息字段整体迁入
3. 新建 components/NodeSection.tsx：stage=2 的节点与递进规则 UI
   - 原 Tabs + Table + Collapse 结构整体迁入（第 576-620 行区间）
   - Table 的列顺序与列数**保持 6 列不变**（这是 merged-calibration.test.cjs 的断言对象）
4. CalibratePanel.tsx 保留为薄壳：调用 hook，按 stage 渲染 BaselineSection 或 NodeSection，把保存回调接上。目标 ≤ 120 行。

【测试同步要求】
- 改完先跑 npm test。若 merged-calibration.test.cjs 因拆文件（import 路径变化/组件导出位置变化）失败，**只允许修改该测试的挂载路径与 mock 映射**，断言内容（6 列、无 financial_assumptions 列、impact 为函数）保持原样。
- 不得删除、跳过、注释任何测试。
- baseline-finance.test.cjs 不得改动（它测的是纯函数，与拆分无关）。

【禁止】
- 新增 Steps / StepsForm 组件
- 在 CalibratePanel 及新拆出的子组件里使用路径别名（@components / @domain / @pages 等）。必须继续用相对路径 './baselineFinance'、'./ProgressivePanel'、'./metricAnnotation'——因为 tests/merged-calibration.test.cjs 的 vm 沙箱以相对路径为 mock key，改用别名会导致 require 拦截失效、测试直接崩
- 修改 baselineFinance.ts、domain/financials.ts 的计算逻辑
- 修改 backend/、contracts/、api/ 下任何文件
- 修改递进模拟接口的请求体（该接口是 extra="forbid"，多一个字段即 422）
- 改变 saveCase / patchCase / patchNode 的调用参数

【验收（逐条自检后报告）】
- CalibratePanel.tsx 行数 ≤ 120
- 全项目 import 语句零新增别名（拆分后仍为相对路径）
- tsc -b 0 错误（props 契约未破）
- npm test 60/60 通过
- 财务联动：营收 1000 + 毛利率 60% → 成本自动 400（误差≤0.02）；成本手改 350 → 毛利率自动 65%
- 在 stage=1 与 stage=2 之间切换，表单数据不丢失
- 保存草稿、发布流程与拆分前一致

交付：新增/修改文件清单 + CalibratePanel 最终行数 + 陈旧闭包风险点的处理方式（怎么改的依赖数组）+ 测试结果 + 财务联动自检数据。
```

### 【用户操作】

1. 跑 `npm run dev`，教师端打开案例。
2. **关键验证**：财务基准里营收改 1000、毛利率 60% → 看成本是否自动变 400；成本改 350 → 看毛利率是否变 65%。
3. 切到"节点与规则"，确认选项表还是 **6 列**（多了或少了都算回归）。
4. 数字不对就**立即停止**，截图发回。

---

## 阶段 5：AI 自动实现班级仪表盘（用户确认图表方案）

### 【复制给 AI 的提示词】（发送给教师端对话）

```
你是 case_sim 仪表盘改造 Agent。请新增教师班级仪表盘。

参考资源（必须逐行读取以下文件，提取可直接复用的布局与组件模式）：
- wuqingnan-star Dashboard.tsx：https://github.com/Starmax-technology/wuqingnan-star.github.io/blob/main/src/components/Dashboard.tsx（23KB，KPI 卡片行 + 图表网格布局）
- wuqingnan-star HmcOptionsStats.tsx：https://github.com/Starmax-technology/wuqingnan-star.github.io/blob/main/src/components/HmcOptionsStats.tsx（9.8KB，选项分布统计柱状图——直接对应我们 A/B/C 直方图需求）
- wuqingnan-star SubmissionsTable.tsx：https://github.com/Starmax-technology/wuqingnan-star.github.io/blob/main/src/components/SubmissionsTable.tsx（11KB，提交记录表格——可借鉴为教师记录页表格化替代方案）

任务：
1. 在 TeacherStudentsPage.tsx 或 TeacherWorkbenchPage.tsx 中新增"班级仪表盘"区域（你判断最合适的位置）。
2. KPI 卡片行（4 个 Statistic 卡片）：
   - 已完成人数 / 总人数（从现有学生列表数据计算）
   - 卡在节点 2 的人数（从现有数据计算，如果没有节点信息则 mock 为 3）
   - 人均营收（mock 为 86 万，标注 TODO）
   - 平均时长（mock 为 22 分钟，标注 TODO）
3. 选项分布图（按 D3 决策分三种实现路径，**执行前先向我确认 D3 选哪个**）：
   - **路径 A（纯 CSS）**：3 个垂直柱子（A/B/C），用 div + height 百分比实现，颜色区分，mock 数据 A=30%、B=50%、C=20%
   - **路径 B（recharts）**：`npm install recharts@^2.15.0`，用 `<BarChart>` + `<Bar>` + `<XAxis>` + `<YAxis>` + `<Tooltip>`，参考 https://recharts.org/en-US/examples/SimpleBarChart ，容器 240px，外层 `ResponsiveContainer`
   - **路径 C（ECharts，必须按需引入）**：`npm install echarts echarts-for-react`，在组件内按需注册：
     ```ts
     import * as echarts from 'echarts/core'
     import { BarChart, LineChart, RadarChart } from 'echarts/charts'
     import { GridComponent, TooltipComponent, LegendComponent, TitleComponent } from 'echarts/components'
     import { CanvasRenderer } from 'echarts/renderers'
     echarts.use([BarChart, LineChart, RadarChart, GridComponent, TooltipComponent, LegendComponent, TitleComponent, CanvasRenderer])
     ```
     用 `ReactECharts` 渲染，option 参考 https://echarts.apache.org/examples/zh/editor.html?c=bar-simple ，容器 240px
     **⚠️ 禁止 `import * as echarts from 'echarts'`（全量 320KB）**
4. 最近活跃趋势（按 D3 决策）：
   - **路径 A（纯 CSS）**：SVG polyline 画迷你折线，mock 7 个点
   - **路径 B（recharts）**：`<LineChart>` + `<Line>`，参考 https://recharts.org/en-US/examples/SimpleLineChart
   - **路径 C（ECharts）**：复用上面已注册的 `LineChart`，`ReactECharts` + `series: [{ type: 'line' }]`

禁止：
- 未经 D3 确认就安装 echarts/recharts
- 修改 backend/ 添加聚合接口
- 伪造不存在的数据为"真实数据"（必须标注 TODO/mock）
- 若选 recharts，禁止安装 3.x 版本（先 `npm view recharts versions` 确认 2.15.x 可用）
- 若选 ECharts，禁止全量引入

验收：
- 仪表盘区域渲染正常
- D3 选中的图表方案成功渲染，无控制台报错
- **若选 ECharts：必须逐个图表在浏览器里目视确认真的画出来了**（option 写错不会报错）
- 480px 以上屏幕正常显示
- `npm run build` 成功，`dist/assets/*.js` 总增量 ≤ 250 KB（若选 recharts/ECharts）
- npm test 通过

交付：新增组件路径 + D3 实际选择 + 数据来源说明（哪些是真数据、哪些是 mock）+ 构建体积增量 + 每个图表的浏览器验证结论（画出来了/没画出来）+ 需要后端补充的接口清单。
```

### 【用户操作】

1. 运行 `npm run dev`
2. 浏览器看教师端仪表盘，确认有 4 个数字卡片和柱状图。
3. **决策点 D3**（阶段 5 开始前就要定，不要等做完再改）：三选一
   - **选 A 纯 CSS**：零依赖，最快，但 3 类图 × 4 个位置要手撸 SVG
   - **选 B recharts**（默认）：~130KB，React 原生组件，TS 编译期就能查出 props 写错
   - **选 C ECharts**（视觉最优）：**按需引入后 ~80–130KB，体积并不比 recharts 大**；默认动画/渐变/阴影最专业，中文文档一流；代价是 option 写错**静默失败**，必须逐个图表人眼确认
4. 安装命令：
   - 选 B：`npm install recharts@^2.15.0`（不要装 3.x）
   - 选 C：`npm install echarts echarts-for-react`（必须按需引入，禁止 `import * as echarts from 'echarts'`）

---

## 阶段 6：AI 自动改造学生推演页（用户只需手机看一眼）

### 【复制给 AI 的提示词】（发送给学生端对话）

```
你是 case_sim 学生端推演改造 Agent。请改造 StudentPlayPage.tsx 的展示层。

参考资源：
- BizOn 官网：https://bizonland.com/（F12 查看风险卡片样式、clay 色值、双设计语域实现）
- learnhouse 学生播放器 UI：https://github.com/learnhouse/learnhouse/tree/main/apps/web（参考其进度展示方式）

任务：
1. 进度条升级：
   - 把现有 Progress 替换为 AntD Steps（size="small"，3 步）
   - 每步显示"第 X 轮：[节点标题]"
   - 当前轮次高亮，已完成打勾，未开始置灰
2. 财务指标卡片（2×2 Grid）：
   - 营收：大数字（万元）
   - 毛利率：百分比 + 趋势箭头
   - 市场份额：百分比 + 趋势箭头
   - 现金流：文字描述
   - 如果后端返回 net_profit，再加一行净利润
   - 增减趋势用颜色：增=绿（#16a34a）、降=红（#dc2626）
3. 策略选项卡片：
   - 把等宽 Button 改为垂直堆叠的 Card
   - 每张卡片：选项字母（大）+ 策略名称 + 一行描述 + 风险标签
   - 保守=绿色边框 #16a34a、稳健=黄色边框 #ca8a04、激进=红色边框 #dc2626
   - 选中状态=填充对应颜色 + 白色文字
   - 必须确保 480px 宽度下垂直堆叠、不溢出
4. 决策理由输入：
   - TextArea 保留，增加 `showCount` 显示字数，placeholder 提示"至少 20 字"
5. 提交后结果展示：
   - 用 Alert 或 Card 展示"本轮结果"
   - 显示选择策略、财务变化、与上一轮的对比
   - mock 班级均值和标杆路径（标注 TODO）

禁止：
- 修改 decide/startStudent/restoreStudent 等 API 调用逻辑
- 修改后端/契约
- 修改 StudentLayout.tsx 的 480px 限宽
- 使用固定像素宽度导致移动端溢出

验收：
- 480px 下无横向溢出（DevTools iPhone SE 验证）
- 策略卡片可点击选中
- 提交后结果展示完整
- npm test 通过

交付：修改文件列表 + 移动端适配说明 + 测试通过证明。
```

### 【用户操作】

1. 运行 `npm run dev`
2. 手机扫码或 DevTools 切 iPhone SE 进入学生推演页。
3. 确认进度条、财务卡片、策略卡片都正常显示，不溢出。
4. 点选策略，确认选中效果明显。

---

## 阶段 7：AI 自动改造学生复盘页（用户确认雷达图方案）

### 【复制给 AI 的提示词】（发送给学生端对话）

```
你是 case_sim 学生端复盘改造 Agent。D3 已确定为 ECharts 按需引入，请改造复盘页的可视化展示。

参考资源：
- ECharts 雷达图示例：https://echarts.apache.org/examples/zh/editor.html?c=radar
- ECharts 折线图示例：https://echarts.apache.org/examples/zh/editor.html?c=line-simple
- AntD Statistic 组件文档：https://ant.design/components/statistic

任务：
1. 读取 `src/features/ai/StudentReview.tsx` 和 `src/pages/student/StudentReviewPage.tsx`，了解复盘数据结构与布局。
2. 在 `StudentReviewPage.tsx` 中新增可视化区域（放在 `<StudentReview />` 文字复盘上方）。
3. ECharts 按需引入：
   - 必须复用阶段 5 已注册的 `RadarChart` / `LineChart`（若阶段 5 未注册，则补齐 `echarts.use([...])`）
   - 禁止 `import * as echarts from 'echarts'` 全量引入
   - 推荐复用阶段 5 的 `OptionDistributionChart.tsx` 中的 `EChart` 轻量封装，或新建 `src/pages/student/components/ReviewCharts.tsx` 并 export `RadarScoreChart` 和 `RoundLineChart` 两个组件
4. 5 维度雷达图：
   - 维度：营收能力、市场份额、成本控制、风险应对、战略执行
   - 每个维度 max=100
   - 若后端返回维度分数则使用真实数据；否则 mock `[82, 75, 68, 90, 78]` 并标注 TODO
   - 容器高度 280px，宽度 100%
5. 3 轮对比折线图：
   - 横轴：第 1 轮 / 第 2 轮 / 第 3 轮
   - 两条线：我的路径（深蓝 #1a3a5c）、标杆路径（玫红 #db2777）
   - 指标默认展示净利润；若后端有每轮净利润则使用真实数据，否则 mock 并标注 TODO
   - 容器高度 220px，宽度 100%
6. 保持现有文字复盘内容不动。

禁止：
- 修改 AI 复盘生成逻辑（只改展示）
- 新增图表库依赖（复用阶段 5 的 `echarts`）
- ECharts 全量引入
- 修改后端/契约
- 使用路径别名

验收：
- 复盘页显示 5 维度雷达图 + 3 轮对比折线图
- **雷达图和折线图必须确认真的画出来了**（不是空白容器）
- 文字复盘内容完整保留
- 480px 下正常显示、图表自适应不溢出
- npm test 通过
- npm run build 成功

交付：修改文件列表 + 数据来源说明 + 每个图表"画出来了/没画出来"的确认结论 + 移动端测试结果。
```

### 【用户操作】

1. 运行 `npm run dev`
2. 完成一轮推演，进入复盘页。
3. 确认有 5 维雷达图 + 3 轮对比折线图（不是 Progress 条替代）。
4. 检查图表是否真的渲染（不是空白 div）。

---

## 阶段 8：AI 自动改造 AI 助教入口为 FAB（用户只需点一下）

### 【复制给 AI 的提示词】（发送给学生端对话）

```
你是 case_sim 学生端 FAB 改造 Agent。请把 AI 助教从侧边栏改为右下角悬浮按钮。

参考资源：
- AntD FloatButton：https://ant.design/components/float-button
- learnhouse AI 助手入口设计：https://github.com/learnhouse/learnhouse/tree/main/apps/web（参考其 AI 入口的轻量设计）

任务：
1. 修改 StudentLayout.tsx：
   - 移除桌面端的右侧固定侧边栏（student-tutor-column）
   - 移除移动端的 Drawer
   - 改为 AntD FloatButton（或自定义 position: fixed 按钮）：
     - 位置：右下角，right: 16px, bottom: 80px（避开底部操作区）
     - 大小：56px 圆形
     - 颜色：学生端主色 #db2777
     - 图标：MessageOutlined
2. 点击 FloatButton 后展开聊天气泡面板：
   - 桌面端：360px 宽 × 480px 高，右下角弹出
   - 移动端：100% 宽 × 60vh 高，从底部滑出
   - 面板内嵌 StudentTutorSidebar 组件（不修改其内部逻辑）
   - 面板可关闭（右上角 ×）
3. z-index 管理：面板 z-index=1000，低于 AntD Modal（通常 1050）
4. 确保 FAB 在 480px 下不遮挡"提交"按钮等关键操作。

禁止：
- 修改 StudentTutorSidebar.tsx 内部逻辑
- 修改聊天 API 调用
- 修改后端/契约

验收：
- 学生端任何页面都能看到右下角 FAB
- 点击展开，能提问、能收到回复
- 点击关闭或再次点击 FAB，面板收起
- 移动端提交按钮不被遮挡
- npm test 通过

交付：修改文件列表 + FAB 技术方案 + 移动端验证结果。
```

### 【用户操作】

1. 运行 `npm run dev`
2. 学生端任意页面，确认右下角有粉色 FAB。
3. 点击 FAB，提问"测试"，确认能收到回复。
4. 关闭面板，确认正常收起。
5. **决策点 D5**：如果面板尺寸不合适 → 发指令调整；如果满意 → 继续。

---

## 阶段 9：AI 自动回归测试（用户只需跑两条命令）

### 【复制给 AI 的提示词】（发送给项目总控）

```
你是 case_sim 回归测试 Agent。请执行最终验收检查。**全程只读，禁止修改任何代码、禁止安装依赖、禁止改动配置文件。**

【环境事实（已核实，不要重新假设）】
- 项目根：C:\Users\huang2006\Desktop\Work\upload2\case_sim-\
- **本仓库不是 git 仓库**（无 .git），因此 `git diff` 不可用 → 用文件 mtime + 哈希清单代替变更审计。
- `backend/` 与 `backend/tests/` 都没有 `__init__.py`，也没有 pytest.ini / pyproject.toml / setup.cfg。
- 测试统一写 `from backend.app import ...`，所以 **pytest 必须从项目根跑**；从 `backend/` 跑会 25 个 collection error。

【执行步骤】
1. 前端测试（工作目录 `case_sim-\frontend`）：
   `npm test`
   记录 pass / fail 数量与失败详情。

2. 后端测试（工作目录 `case_sim-\`，**不是 backend/**）：
   `.venv\Scripts\python.exe -m pytest`
   记录 pass / fail 数量。预期收集数 184（2026-10-20 实测）；若收集数不等于 184 或出现 collection error，必须原样粘贴错误。

3. 前端构建（工作目录 `case_sim-\frontend`）：
   `npx tsc -b` → 记录错误数，应为 0。
   `npm run build` → 记录是否成功、dist 体积、index chunk 大小。

4. 红线文件巡检（只读，逐个记录文件是否存在、大小、mtime、SHA256）：
   - `frontend/src/pages/teacher/components/baselineFinance.ts`
   - `frontend/src/domain/financials.ts`（如不存在则记 .js）
   - `backend/` 目录整体：列出 mtime 晚于 2026-10-20 00:00 的文件（应只有数据库/日志类，不应有 .py 源文件）
   - `contracts/` 目录整体：同上
   - `ai_component/` 目录整体：同上
   判据：四个红线区域**不得出现被修改的源码文件**。若出现，逐条列出路径并判定是否属于本次前端改造。

5. 变更清单（代替 git diff）：
   在工作目录 `case_sim-\frontend` 下执行：
   `find src tests -newermt "2026-10-20 00:00" -type f`
   按「布局 / 组件 / 样式 / 测试 / 类型」分类输出，并标注每个文件属于阶段 1.5–8 中哪一步。

6. 代码卫生检查（只报告，不修改）：
   - 全仓搜索 `import * as echarts from 'echarts'`（**必须 0 命中**；`from 'echarts/core'` 不算违规）
   - 全仓搜索 `from '@` / `from "@` 的路径别名使用（预期 0 命中，别名"配而未用"是刻意状态）
   - 检查 `frontend/package.json` 依赖：应含 `echarts`，不应含 `echarts-for-react`

【输出《回归验收报告》（Markdown），必须包含】
- 前端测试：X passed / Y total（失败需附完整报错）
- 后端测试：X passed / Y total（收集数是否 = 184）
- 构建：tsc 错误数、build 成功与否、dist 总体积与 index chunk
- 红线文件检查：通过 / 异常（异常需给路径 + mtime + 判定理由）
- 变更文件清单（分类 + 阶段归属）
- 代码卫生：三条搜索结果各自命中数
- 已知限制清单（必须逐条列出，不得遗漏）：
  1. 教师班级仪表盘 4 个 KPI 中 3 个为 mock（已完成人数、卡节点 2 人数、人均营收、平均时长）
  2. 班级仪表盘 A/B/C 分布与活跃趋势为 mock
  3. 学生复盘 5 维雷达图为 mock（后端无 dimension_scores 字段）
  4. 学生推演页策略 risk_level / description 依赖后端下发，当前走中性占位色
  5. 学生推演结果里班级均值、标杆路径为 mock
  6. 后端缺 3 个聚合接口：/teacher/dashboard/option-distribution、/recent-activity、/summary
  7. 存量 bug D-02：TeacherRecordsPage 版本筛选器失效（后端 StudentRecord 只返 8 字段）——**本次未修，属已知问题**
- 是否建议收尾：是 / 否 + 理由（判据：前端 60/60、后端 184 全过、tsc 0 错误、build 成功、红线无改动）
```

### 【用户操作】

1. 打开终端 1（前端测试）：
   ```bash
   cd "C:\Users\huang2006\Desktop\Work\upload2\case_sim-\frontend"
   npm test
   ```
2. 打开终端 2（后端测试，**必须从项目根跑**，见下方踩坑说明）：
   ```bash
   cd "C:\Users\huang2006\Desktop\Work\upload2\case_sim-"
   .venv\Scripts\python.exe -m pytest
   ```
3. 确认前端测试通过 + 后端 **184** 测试通过（2026-10-20 实测 collect 数为 184，此前"118"是旧数）。
4. 确认 Git diff 只在 `frontend/` 目录。

> ### ⚠️ 后端启动命令（踩过坑，务必从项目根启动）
>
> 后端代码用 `from backend.app.xxx import ...` 导入，**必须从项目根目录 `case_sim-/` 启动**，且入口是 `backend.app.main:app`（不是 `app.main:app`）。
>
> 曾经踩坑：从 `backend/` 目录内跑 `uvicorn app.main:app` → `ModuleNotFoundError: No module named 'backend'`，因为 `app.main` 自身 import `backend.app.*`，但 cwd 在 `backend/` 时 `backend` 包不在 sys.path 上。
>
> 正确启动（浏览器验收时用）：
> ```bash
> cd "C:\Users\huang2006\Desktop\Work\upload2\case_sim-"
> .venv\Scripts\python.exe -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8110
> ```
> 已实测 `import backend.app.main` 从项目根导入成功。前端 `npm run dev` 在 `frontend/` 目录跑，`/api` 与 `/media` 由 vite 代理到 8110。
>
> **pytest 同理（2026-10-20 实测）**：`backend/` 与 `backend/tests/` 都**没有** `__init__.py`，无 pytest.ini/pyproject/setup.cfg，测试文件统一 `from backend.app import ...`。
> 从 `backend/` 目录跑 pytest → **25 个 collection error、仅收集到 2 个用例**（已实测）。
> 必须从项目根跑：`cd case_sim- && .venv\Scripts\python.exe -m pytest`（`-m` 让 cwd 进 sys.path，namespace package 才能解析 `backend`）。
> 实测收集数 **184**。

---

## 依赖关系与并行策略（含实际进度）

```
阶段 0（AI 盘点）                    ✅ 已完成
   ↓
阶段 1（AI 冻结契约）                ✅ 已完成
   ↓
阶段 1.5（别名 + 测试保卫战）        ✅ 已完成
   ↓
阶段 2（AI 配主题）                  ✅ 已完成
   ↓
   ├─→ 阶段 3（教师布局）            ✅ 已完成（视觉收尾：状态 Tag 彩色化 + 主题变量接上）
   │      ↓
   │   阶段 4（拆分 CalibratePanel）  ✅ 已完成（2026-10-20，89 行薄壳 + 60/60 测试）
   │      ↓
   │   阶段 5（班级仪表盘）✅ 已完成（2026-10-20，ECharts 按需引入 + 60/60 测试）
   │      ↓
   │   阶段 6（学生推演页改造）✅ 已完成（2026-10-20，Steps + 财务卡 + 策略卡 + 60/60 测试）
   │      ↓
   │   阶段 7（学生复盘页改造）✅ 已完成（2026-10-20，雷达图 + 折线图 + 60/60 测试）
   │      ↓
   │   阶段 8（AI 助教 FAB 改造）✅ 已完成（2026-10-20，FloatButton + 浮动面板 + 60/60 测试）
   │      ↓
   │   阶段 9（全量回归测试）✅ 已完成（2026-10-20，前端 60/60 + 后端 184/184 + 红线零改动）
   │
   └─→ 阶段 6（学生推演）
          ↓
       阶段 7（学生复盘）【需人工确认 D4】
          ↓
       阶段 8（FAB）【需人工确认 D5】
          ↓
       阶段 9（回归）【需人工跑测试命令】
```

**当前进度**：0 → 1 → 1.5 → 2 → 3 → 4 → 5 → 6 → 7 → 8 → 9 **全部完成**（2026-10-20）。

**终态证据**：前端 60/60、后端 184/184、`tsc -b` 0 错误、`vite build` 成功、红线四区域零源码改动、别名使用 0 处、ECharts 全量引入 0 处。

**收尾报告**：`case_sim-前端改造-收尾验收报告.md`

**后续待办（不阻塞收尾）**：
1. 后端补 3 个聚合接口：`/teacher/dashboard/option-distribution`、`/recent-activity`、`/summary`
2. 后端补 `dimension_scores`（学生复盘雷达图）
3. 存量 bug D-02：`TeacherRecordsPage` 版本筛选器失效（需后端 `StudentRecord` 补字段，或前端删列）

---

## 一键启动提示词（第一次使用时复制这一段）

```
你是一个自主前端改造 Agent。当前项目是 case_sim（高校商科 AI 案例推演平台）。

项目路径：C:\Users\huang2006\Desktop\Work\upload2\case_sim-\
前端路径：C:\Users\huang2006\Desktop\Work\upload2\case_sim-\frontend\

技术栈：React 18 + Vite 8 + TypeScript + Ant Design 5 + React Router 7。

你的第一个任务（阶段 0）：全自动只读盘点前端代码。必须读取并分析以下文件：
1. package.json
2. vite.config.ts
3. src/App.tsx（路由结构）
4. src/api/types.ts（所有接口类型）
5. src/api/client.ts（所有 API 函数）
6. src/layouts/TeacherLayout.tsx + .css
7. src/layouts/StudentLayout.tsx + .css
8. src/pages/teacher/TeacherWorkbenchPage.tsx
9. src/pages/teacher/components/CalibratePanel.tsx
10. src/pages/teacher/components/baselineFinance.ts
11. src/pages/student/StudentPlayPage.tsx
12. src/pages/student/StudentReviewPage.tsx
13. src/features/ai/StudentTutorSidebar.tsx
14. tests/ 下所有文件

输出：一页式现状摘要 + 路由表 + API 清单 + 风险标记 + 改造难度评分（1-10）。

禁止修改任何文件。完成后直接进入阶段 1（接口契约核对）。
```

---

## 附录：参考项目速查表

| 参考项目 | 仓库地址 | 可借鉴的具体特性 | 对应 case_sim 改造点 |
|---|---|---|---|
| ant-design-pro | https://github.com/ant-design/ant-design-pro | ProLayout（文档站）、StepsForm（文档站）、主题 Token（文档站） | 阶段 2/3/4 |
| learnhouse | https://github.com/learnhouse/learnhouse | 学生仪表盘、Playgrounds 交互、Analytics 追踪、AI 入口 | 阶段 6/7/8 |
| wuqingnan-star | https://github.com/Starmax-technology/wuqingnan-star.github.io | Dashboard.tsx（KPI 卡片行）、HmcOptionsStats.tsx（A/B/C 柱状图）、SubmissionsTable.tsx（提交记录表格） | 阶段 5（仪表盘） |
| recharts | https://github.com/recharts/recharts | `<BarChart>`（A/B/C 分布）、`<LineChart>`（3 轮对比）、`<RadarChart>`（5 维复盘）；~130KB gzipped，React 声明式 | 阶段 5/7（D3=选 B 时） |
| ECharts | https://github.com/apache/echarts | `bar`/`line`/`radar` series；按需引入 ~80–130KB gzipped，视觉最专业，中文文档一流 | 阶段 5/7（D3=选 C 时） |
| BizOn | https://bizonland.com/ | F12 查看 clay 色值、风险卡片样式、双设计语域实现 | 阶段 6（策略卡） |

### 已评估但排除的项目（决策记录，勿再重复讨论）

| 项目 | ★ | 结论 | 理由 |
|---|---|---|---|
| react-hook-form | 44.9k★ | ❌ 不引入 | 项目已用 AntD `Form`，两套表单状态体系并存会打架，且本项目无复杂动态表单需求 |
| lobe-charts | 119★ | ❌ 不引入 | 基于 recharts 的二次封装，星数低、生态未成熟；直接用 recharts 即可 |
| hypatia | 651★ | ❌ 不引入 | 2016 年老 LMS，React 版本过时，无可复用价值 |
| 其他 LMS（Canvas/Moodle 类） | — | ❌ 不引入 | 技术栈不匹配或已停止维护 |

**结论**：五年生态范围内无颠覆性新前端技术。D3 图表库从"纯 CSS vs ECharts"二选一升级为**三选一**：

| 选择 | 体积 | 核心优势 | 核心代价 |
|---|---|---|---|
| 纯 CSS | 0 KB | 零依赖，无构建风险 | 3 类图 × 4 位置要手撸 SVG |
| recharts | ~130 KB | TS 编译期可查错，AI 出错概率最低 | 视觉中规中矩 |
| **ECharts（按需引入）** | **~80–130 KB** | **视觉最专业，中文文档一流，比赛演示效果好** | **option 写错静默失败，必须人眼逐个确认** |

> **重要纠正**：此前"ECharts 1MB"是**未压缩**体积，gzipped 仅 ~320KB，按需引入后 **80–130KB**——与 recharts 相当甚至更小。**体积不再构成 ECharts 的劣势**。若追求演示效果，选 ECharts 完全合理。

---

### 附录 B：行数统计口径（已踩过的坑，勿再重复）

本项目里同一个文件用不同工具统计会出现**不同行数**，曾导致三份报告数据打架。以字节级统计为唯一准绳：

```bash
python -c "
b=open('文件路径','rb').read()
print('LF:', b.count(b'\n'), 'CR:', b.count(b'\r'), 'CRLF:', b.count(b'\r\n'))
print('splitlines:', len(b.decode('utf-8').splitlines()))
"
```

已核实的关键文件真实行数：

| 文件 | **真实行数** | 曾出现的错误值 | 原因 |
|---|---|---|---|
| `frontend/src/pages/teacher/components/CalibratePanel.tsx` | **680**（LF=680, CR=0） | 673 | PowerShell `Get-Content` 口径少报 |
| `backend/app/schemas.py` | **537**（LF=537, CR=0） | 514 | `Get-Content` 少报 23 行 |
| `frontend/src/api/types.ts` | **372** | — | — |
| `contracts/` 7 个 .py 合计 | **223** | — | — |
| `frontend/vite.config.ts` | **65**（阶段 1.5 加了 alias 后） | 52 | 52 是加 alias **之前**的值，文件确实变了 |

> **注意**：`vite.config.ts` 从 52 → 65 行不是统计误差，是阶段 1.5 真实新增了 7 条 alias 配置。任何"文件变了"的怀疑，先看 mtime（`ls -la --time-style=+"%m-%d %H:%M"`）再下结论。

### 附录 C：接口契约的权威顺序（避免再读错目录）

```
HTTP DTO 权威  →  backend/app/schemas.py
前端静态类型   →  frontend/src/api/types.ts
路由实际返回   →  backend/app/routers/*.py（response_model 与真实 return）
AI 内部 seam   →  contracts/（TeachingPolicy/ReviewInput/TutorTools/JsonModel/errors/review/presentation/telemetry）
                  ↑ 与 HTTP 接口字段无关，不要拿来核对接口契约
```

---

_本清单执行时，用户的平均操作时间约为每阶段 3-5 分钟（运行命令 + 浏览器看一眼），AI 的平均执行时间约为每阶段 10-30 分钟（代码分析 + 自动修改 + 自检）。_
