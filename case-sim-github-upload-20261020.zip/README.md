# upload2 — AI 商科案例推演平台工作区

本仓库包含 **AI 商科案例推演平台**（`case_sim-`）的完整源码，以及项目开发过程中的交付文档、验证报告与执行清单。

## 目录结构

| 路径 | 说明 |
|---|---|
| `case_sim-/` | **项目源码**：React/Ant Design 前端 + FastAPI 后端 + AI 组件 |
| `*.md`（根目录） | 项目交付文档：需求分析、缺陷修复清单、测试报告、部署操作单等 |
| `*.py` / `*.cjs` | 独立验证与检查脚本 |
| `验证截图/` | 页面运行效果截图与 DOM 快照 |
| `backup/` | 关键代码检查点备份 |

## 快速开始

完整安装、启动与测试步骤见 [case_sim-/README.md](case_sim-/README.md)，排错指南见 [case_sim-/USAGE.md](case_sim-/USAGE.md)。

核心流程：

```sh
# 安装与启动（Windows，需 Python 3.13 + Node.js 24）
cd case_sim-
python scripts/bootstrap.py local

# 开发与测试
python -m pytest backend/tests ai_component/tests -q
cd frontend && npm ci --ignore-scripts --no-audit --no-fund && npm test && npm run build
```

## 说明

- 本仓库不含生产数据、密钥与本地环境（`.env`、`*.db`、`node_modules`、`.venv`、`dist` 均不提交）。
- 首次启动会自动从 `.env.example` 生成 `backend/.env`，请自行配置 `LLM_API_KEY` 等密钥。
- 本项目以 MIT 协议开源，详见 [LICENSE](LICENSE)。
