# case_sim 并发能力与跨设备使用评估报告

> 评估对象：`C:\Users\huang2006\Desktop\Work\upload2\case_sim-\`
> 评估方式：源码逐行核查 + 本机实测（SQLite 写压测 / 锁行为 / 连接池 / 密码派生）
> 评估时间：2026-10-20
> **基线前提：按仓库自带 `deploy/systemd/case-sim.service` 的 `--workers 1` 单进程部署**

---

## 一、结论先行

| 问题 | 结论 |
|---|---|
| 10 个用户同时在线，会不会有性能瓶颈？ | **不会。** 典型课堂节奏下数据库写入量约为容量的 0.2%，实测 10 线程并发写零错误 |
| 会不会出现数据冲突？ | **单进程下不会。** 决策接口在单事件循环内是原子的；`Session` 有唯一约束兜底。多进程部署才会冲突 |
| 会不会有功能异常？ | **有一处：跨设备"直接点开始推演"会报错且提示误导**，可从"我的记录"恢复。属体验缺陷，非数据故障 |
| 支不支持跨设备同时使用？ | **支持多设备登录与接力，但不支持实时同步。** 同一账号可在多台设备登录；换设备需从"我的记录"手动恢复进度 |
| 明确的可行性结论 | **10 人同时使用可行，无需改造即可上线教学。** 前提是保持 `--workers 1`、AI 复盘并发控制在合理范围 |

---

## 二、架构与并发模型（源码事实）

### 2.1 进程模型：单进程，且**不能**扩成多进程

`deploy/systemd/case-sim.service` 明确写死 `--workers 1`，并注明原因：项目仍有**两处进程内存状态**。

| 内存状态 | 位置 | 多进程时的后果 |
|---|---|---|
| `TRY_STORE: OrderedDict`（试跑数据） | `backend/app/routers/student.py:571` | A 进程生成、B 进程打开 → "试跑内容已失效" |
| `_running: Dict[str, asyncio.Task]`（AI 任务句柄） | `backend/app/integrations/ai/task_runner.py:32` | 去重失效、取消静默失效；每个 worker 各跑一次 `recover_pending_tasks()` → **同一任务重复调用模型、双倍计费** |

`backend/app/main.py:49-53` 启动日志每次都会打印这条自检，属于**设计上的硬约束**，不是疏漏。

> 已经修好的一处：教师令牌原本也是进程内存 `TEACHER_TOKENS`，多 worker 会"登录即被踢出"。现在改为 `teacher_session` 表 + 进程缓存（`teacher.py:56-81`），**这一项已不受 worker 数影响**。

### 2.2 数据库：SQLite 单文件，未开 WAL

实测当前库状态：

```
journal_mode = delete          ← 不是 WAL
busy_timeout = 5000 ms         ← 默认值，代码里没有显式设置
sqlite 3.53.1 / 15 张表
```

- `backend/app/db.py:26` 只设了 `check_same_thread=False`，没有连接池参数、没有 PRAGMA。
- 连接池实测：`QueuePool`，`size=5`，`max_overflow=10`，`timeout=30s` → **最多 15 个并发连接**，超出后请求最多等 30 秒再报错。

### 2.3 路由的同步/异步混合

| 文件 | `async def` 路由 | 同步 `def` 路由 |
|---|---|---|
| `student.py` | 10 | 17 |
| `teacher.py` | 6 | 34 |
| `accounts.py` | 0 | 12 |

`async def` 里跑的是**同步 SQLAlchemy**。这意味着这些请求会在事件循环上串行执行——这是单进程的天然限流，也是唯一的 CPU 侧隐患（见风险 R6）。

### 2.4 关键写路径没有 `await`，反而成了保护

`decide()`（`student.py:305-427`）全程无 `await`：查案例 → 校验节点序号 → 算指标 → 写 Turn → 提交。

因此在**单进程**内，10 个学生同时提交也不会交错执行：要么 A 先写完、B 看到 `turns` 已变成 2 条并返回 409"请按顺序提交第 3 个节点"，要么反之。**不会产生重复回合。**

但 `models.Turn`（`models.py:159-179`）**没有** `(session_id, attempt_no, node_id)` 唯一约束。这是"单进程安全、多进程不安全"的原因——一旦有人把 worker 调成 2，冲突立刻可能出现。

### 2.5 AI 任务：无并发上限

`task_runner.py:35-41` 每次都是 `asyncio.create_task(...)`，没有 `Semaphore`、没有队列上限。10 个学生同时完成第 3 轮 → **同时发起 10 路复盘生成**，每路可能包含"生成 + 校验 + 重试（最多 4 次）"多次模型调用。

LLM 调用本身走 `httpx.AsyncClient`（`ai_component/providers/llm.py:155`），不阻塞事件循环，这是好的；但会撞上 DeepSeek 的并发/速率限制与费用。

---

## 三、本机实测数据

### 3.1 SQLite 并发写吞吐（复刻真实写入形态）

10 个线程各写 10 次事务，共 100 次 `BEGIN IMMEDIATE → INSERT → COMMIT`：

| 指标 | 实测值 |
|---|---|
| 总耗时 | 1.103 s |
| 吞吐 | **90.6 txn/s** |
| 单次写 p50 | 8.2 ms |
| 单次写 p95 | 413.6 ms |
| 单次写 max | 1030.8 ms |
| 错误数 | **0** |

参照：10 个学生每人 30–60 秒提交一次决策 ≈ **0.2–0.3 txn/s**，占实测容量的 **0.3%**。

> 结论：SQLite 在这个规模下**远不是瓶颈**。p95 的 413ms 是"十个线程同一瞬间抢写"的极端情形，仍远小于 5 秒超时。

### 3.2 长事务锁行为（排除一个误报）

原始 sqlite3 里 `BEGIN; SELECT ...`（不提交）会让另一个连接的 `COMMIT` 在超时后失败：

```
conn1: read txn OPEN
conn2: COMMIT FAILED after 1.16s -> OperationalError: database is locked
```

但**本项目不会踩这个坑**：SQLAlchemy + pysqlite 驱动在只执行 SELECT 时**不会真正 BEGIN**，实测：

```
db.get(Framework, 1) -> True | in_transaction = True
concurrent write COMMIT OK in 0.00s
```

即 `_run_case_nodes` 里"读 Framework → await 大模型"这段时间**不持有读锁**，不会阻塞学生写入。此前的担心可以排除。

真正会持锁的是"写了但没提交就 await"——全仓核查未发现这种写法。

### 3.3 密码派生（登录并发）

PBKDF2 60 万轮，5 个线程并发验证：**总耗时 0.30 s**（`hashlib.pbkdf2_hmac` 计算时释放 GIL，可吃多核）。

10 人同时登录 ≈ 0.3–0.6 s，可忽略。

---

## 四、跨设备使用评估

### 4.1 令牌与状态的存放位置

| 内容 | 存放位置 | 跨设备含义 |
|---|---|---|
| 教师令牌 | `sessionStorage.teacher_token`（`TeacherTokenContext.tsx:17`） | **每个标签页独立**，新开标签页要重新登录；不同设备互不影响 |
| 学生登录令牌 | `sessionStorage.student_access_token` | 同上，多设备可各自登录 |
| 学生"当前会话指针" | `sessionStorage['student_session:'+token]`（`StudentPlayPage.tsx:97`） | **设备本地，不共享** |
| 推演进度本身 | 服务端 `session` + `turn` 表 | 权威数据在服务端，设备只是"指针" |

### 4.2 三种跨设备场景

| 场景 | 结果 | 说明 |
|---|---|---|
| 同一账号在手机 + 平板分别登录 | ✅ 可以 | 每次登录新增一条 `student_login`，互不吊销。除非改密码（会清空该账号全部登录） |
| 设备 A 正在推演，设备 B 打开同一案例 | ⚠️ **需要手动接力** | B 的 sessionStorage 是空的，页面显示"开始推演" |
| 设备 B 点"开始推演" | ❌ **报错且提示误导** | 后端返回 409 `{code:"submission_exists", message:"已有本案例推演记录…"}`，但前端拦截器（`transport.ts:37-40`）发现 `detail` 是对象就替换成"请求参数不符合要求，请检查输入内容" |
| 设备 B 从"我的记录"进入 | ✅ 可恢复 | `StudentSpacePages.tsx:61` 会把 `session_id` 写回 sessionStorage，之后 `restoreStudent` 正常接力 |

### 4.3 双设备同时操作同一会话

| 操作 | 结果 |
|---|---|
| 两端同时提交同一节点 | 一端成功，另一端 409"请按顺序提交第 N 个节点"（提示准确） |
| 一端提交后，另一端还停留在旧界面提交 | 同上，409 拒绝 |
| 一端"覆盖重做"，另一端还在旧进度 | `reset_session` 内部有 `await`（取消 AI 任务），两端可能都执行覆盖，**后写覆盖先写**，不报错 |
| 两端都发 AI 助教提问 | 各自独立落 `message` 表，互不影响 |

### 4.4 教师端双设备

- 两处都能登录（各自签发令牌，均落 `teacher_session` 表）。
- **手动编辑无版本校验**：只有 AI 生成路径用了 `expected_version`（`teacher.py:497`）；教师手改基准/节点是标准 last-write-wins。两个人同时改同一个案例，后保存的覆盖前者，**不会提示冲突**。
- 无实时推送：一端发布后，另一端页面不会自动刷新。

---

## 五、风险点清单

| 编号 | 风险 | 等级 | 触发条件 | 后果 | 建议 |
|---|---|---|---|---|---|
| **R1** | 多 worker 部署破坏两处内存状态 | **高** | 有人把 `--workers` 调大 | 试跑失效、AI 任务重复执行、双倍计费 | 保持 `--workers 1`；要扩容先把 `TRY_STORE`/`_running` 外置到 DB/Redis |
| **R2** | 跨设备"开始推演"报错且提示误导 | **中** | 换设备后直接点开始 | 用户体验受损，误以为数据坏了 | 前端识别 409 `submission_exists`，引导到"我的记录"或自动 `restore` |
| **R3** | 10 人同时完成推演 → 10 路 LLM 复盘 | **中** | 全班同时提交第 3 轮 | 触发供应商限流/超时，复盘排队变慢，费用上升 | 给 AI 任务加信号量（如 3–5 并发）+ 排队提示 |
| **R4** | 教师双端并发编辑无冲突提示 | **中** | 两位老师/两个标签页改同一案例 | 后保存覆盖前者，静默丢改动 | 加 `expected_version` 或 `updated_at` 乐观锁 |
| **R5** | 连接池上限 15，长请求会占用 | 低-中 | 10+ 个 AI 助教 SSE 同时挂起 | 请求等 30s 后失败（`pool_timeout`） | 池调到 20，或 SSE 内部用完连接立即归还 |
| **R6** | `async def` 内跑同步 DB，阻塞事件循环 | 低 | 单次写 p95 达 400ms 时 | 期间其他请求排队 | 10 人规模可接受；上 30 人再考虑线程池化或换 PG |
| **R7** | `TRY_STORE` 全局上限 50 条 | 低 | 10 人各自反复试跑 | 先存被淘汰 → "试跑内容已失效" | 上限提到 200，或按用户分桶 |
| **R8** | `TEACHER_TOKENS` 只增不减 | 极低 | 长期运行、反复登录 | 内存缓慢增长（每小时几十字节） | 定期清理或加 TTL |
| **R9** | `Turn` 无唯一约束 | 条件性 | 仅当改成多进程 | 重复回合、指标错乱 | 加 `UniqueConstraint(session_id, attempt_no, node_id)` |
| **R10** | 无请求级限流 | 低 | 恶意/脚本刷接口 | 单用户可拖慢整体 | 教学场景可暂不处理 |

---

## 六、10 人并发的逐项判定

| 维度 | 判定 | 依据 |
|---|---|---|
| 页面加载（静态资源） | ✅ 无压力 | SPA + 拆包，单文件最大 antd-vendor 1MB，10 人 ≈ 150 个请求，FileResponse 异步流式 |
| 登录 | ✅ 无压力 | 5 并发 0.30s，10 人 < 1s |
| 推演决策（核心写路径） | ✅ 无压力 | 实测 90.6 txn/s，实际需求 0.2–0.3 txn/s |
| 复盘轮询（2s/次） | ✅ 无压力 | 10 人 × 0.5 rps = 5 rps 读，SQLite 读不阻塞写（已验证） |
| AI 复盘生成 | ⚠️ 需控制 | 无并发上限，10 路同发会撞限流；建议加信号量 |
| AI 助教问答 | ⚠️ 需观察 | 每条 SSE 会占一个连接，10 条同时挂起接近池上限 15 |
| 数据一致性 | ✅ 单进程安全 | `decide` 无 await → 原子；`Session` 有唯一约束；`Review` 有唯一约束 |
| 跨设备接力 | ⚠️ 有瑕疵 | 多设备可登录，但需手动从"我的记录"恢复；直接"开始推演"提示误导 |
| 服务重启 | ⚠️ 丢失试跑 | `TRY_STORE` 是内存态；正式推演数据不受影响（已落库） |

---

## 七、明确结论

### 7.1 技术上可行

**在保持单进程（`--workers 1`）的前提下，10 个用户同时在线使用不会出现性能瓶颈、数据冲突或功能性故障。**

依据是三条硬数据：
1. 写容量 90.6 txn/s，实际需求 0.2–0.3 txn/s（占用 0.3%）；
2. 10 线程并发写 100 次，**零错误**；
3. 核心写路径 `decide` 无 `await`，单进程内天然串行，不存在交错写。

### 7.2 但有两个"必须知道"的边界

**边界一：不能靠加 worker 扩容。**
这是代码里写死的约束，不是配置疏忽。想扩到 20–30 人同时在线，正确顺序是先把 `TRY_STORE` 和 `_running` 外置，再调 worker，或直接换 PostgreSQL + 多实例。

**边界二：跨设备是"接力"不是"同步"。**
同一账号可以在多台设备登录，但进度指针存在设备的 `sessionStorage` 里。换设备后**必须从"我的记录"进入**，否则会看到"开始推演"并收到一条误导性报错。

### 7.3 建议动作（按性价比排序）

| 优先级 | 动作 | 工作量 | 收益 |
|---|---|---|---|
| P1 | 前端识别 409 `submission_exists`，提示"请从我的记录继续"或直接跳转 | 30 分钟 | 消除唯一一个用户可见的跨设备故障 |
| P2 | AI 任务加 `asyncio.Semaphore(3~5)` | 20 分钟 | 避免 10 路复盘撞限流，成本可控 |
| P3 | SQLite 开 WAL + `busy_timeout=10000` | 10 分钟 | 读不再等写，p95 更稳 |
| P4 | 连接池 `pool_size=10, max_overflow=10` | 5 分钟 | 助教并发更从容 |
| P5 | `Turn` 加唯一约束 | 30 分钟 | 为将来多进程铺路（需迁移已有数据） |
| P6 | 教师手动保存加 `expected_version` | 1–2 小时 | 消除双端静默覆盖 |

> P1–P4 都不改变架构，属于低风险增量；P5/P6 建议在确实需要多教师协作或扩容时再做。

---

## 八、复现方式

```bash
# 1. 查看当前库状态
cd "C:\Users\huang2006\Desktop\Work\upload2\case_sim-"
.venv\Scripts\python.exe -c "import sqlite3;c=sqlite3.connect('backend/data/app.db');print(c.execute('pragma journal_mode').fetchone(), c.execute('pragma busy_timeout').fetchone())"

# 2. 查看连接池配置
.venv\Scripts\python.exe -c "from backend.app.db import engine;print(type(engine.pool).__name__, engine.pool.size(), engine.pool._max_overflow, engine.pool._timeout)"

# 3. 查看部署 worker 约束
type deploy\systemd\case-sim.service | findstr workers
```

---

*本报告所有"实测"数据均由本机脚本跑出，脚本在临时副本上执行，未写入 `backend/data/app.db`。*
