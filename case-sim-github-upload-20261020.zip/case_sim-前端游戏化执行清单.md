# case_sim 前端游戏化改造：AI 自治执行清单（限定版）

> **定位**：把学生端从"换了颜色的教师端"改成"暖色经营风"，教师端只补品牌层次，不动专业感。
>
> **采用范围**：P0 + P1（视觉层）。**明确不做** 3D 翻牌、勋章体系、桌面隐喻复盘页。
>
> **参考项目**：
> - [alyssaxuu/carden](https://github.com/alyssaxuu/carden)（490★）— 卡片 hover 抬升与选中反馈（**只借鉴 hover 位移，不借鉴 3D 翻转**）
> - [Starmax-technology/wuqingnan-star.github.io](https://github.com/Starmax-technology/wuqingnan-star.github.io) — KPI 卡片行布局（阶段 7）
> - [ant-design/ant-design](https://github.com/ant-design/ant-design) — 主题 Token 覆盖方式：https://ant.design/docs/react/customize-theme
> - [learnhouse/learnhouse](https://github.com/learnhouse/learnhouse) — 学生端轻量氛围（阶段 2/5）
>
> **已评估但排除**（勿再重复讨论）：`rohitg00/k8sgames`（3D/three.js，与 form 型推演不匹配）、`mental-os/Aurora-OS.js`（桌面隐喻，改动面过大）、`NationalSecurityAgency/skills-service`（勋章/等级体系，与商科严肃定位冲突）。

---

## 全局铁律（每个阶段都必须遵守）

1. **路径别名"配而未用"**：`vite.config.ts` 有 7 条 alias、`tsconfig.app.json` 有 paths，但业务代码全部相对导入。原因：测试用 vm 沙箱、以相对路径字符串作 mock key（`'./baselineFinance'`、`'./StudentTutorSidebar'` 等），启用别名会让 require 拦截表匹配不到 → 测试崩。**任何新代码禁止写 `@components/...`**。
2. **教师端零改动**：除阶段 7（KPI 卡片）外，`pages/teacher/**` 与 `teacher.css` 不许碰。
3. **主色不许漂**：教师端 `#1a3a5c`、学生端 `#db2777` 保持不变；游戏化只新增**辅助色**，不替换主色。
4. **测试只许改断言、不许删断言**：现有 60 个前端用例是行为契约。文案变了就同步改断言，禁止 `test.skip`、禁止删用例。
5. **移动端 480px 不允许横向溢出**：改动后必须验 `scrollWidth === clientWidth`。
6. **必须尊重 `prefers-reduced-motion`**：`StudentLayout.css:206` 已有全局降级块，新增动效不得绕开它。
7. **财务联动红线**：`pages/teacher/components/baselineFinance.ts`、`domain/financials.js` 不许动。
8. **不加新依赖**：图表用已有 ECharts 或内联 SVG；动画用 CSS；不装 framer-motion 之类。

---

## 决策点（开跑前确认，已预填推荐值）

| 编号 | 决策 | 推荐 | 备选 | 影响 |
|---|---|---|---|---|
| **D1** | 换肤范围 | **仅学生端** | 双端一起换 | 双端换会毁掉教师端专业感，且 40+ 教师端测试要重验 |
| **D2** | 策略卡配色依据 | **按选项序号 A/B/C 固定三色（中性区分色）** | 等后端补 `risk_level` | 现在 `OptionBrief` 只有 `key+label`，没有风险字段；按序号是唯一零后端改动的方案。**用蓝/紫/青而非绿/橙/红**，避免学生误以为 A=保守、B=稳健、C=激进 |
| **D3** | 教师端 KPI 是否升级 | **做**（只改 `TeacherStudentsPage.tsx`） | 跳过 | 只加图标 + SVG sparkline，零新依赖，风险低 |

> D2 说明：按序号配色**不代表风险语义**，只做视觉区分。卡片上仍显示"风险待评估"文字，避免误导学生。若将来后端给 `OptionBrief` 下发 `risk_level`，再切回语义配色（届时只改 `RISK_META` 一个对象）。

---

## 阶段 0：基线冻结与测试盘点（0.5 小时）

### 目标
把"改之前是什么样"钉死，避免后面分不清是回归还是原有问题。

### 【复制给 AI 的提示词】

```text
你是 case_sim 前端改造的基线盘点 Agent。本次只读，不改任何代码。

项目根：C:\Users\huang2006\Desktop\Work\upload2\case_sim-\
前端目录：case_sim-\frontend

任务：
1. 运行 npm test，记录 pass/fail 总数，把 60 个用例名完整列出。
2. 在 tests/ 目录里筛选出"断言了具体中文文案或 DOM 文本"的用例，逐条列出：文件 + 行号 + 被断言的原文字符串。
3. 在 src/pages/student/ 与 src/layouts/ 下，列出所有 className 名称（去重）。
4. 读取并原样输出以下文件的关键行（带行号）：
   - src/layouts/StudentLayout.css 第 1-20 行（body/背景）
   - src/layouts/StudentLayout.css 第 160-210 行（metric-card / strategy-option-card / prefers-reduced-motion）
   - src/pages/student/StudentPlayPage.tsx 第 10-45 行（RISK_META / RISK_PLACEHOLDER / MetricsBar）
5. 运行 npx tsc -b，记录错误数。

禁止修改任何文件。

交付：一份 Markdown《基线报告》，包含上述 5 项结果，以及"改动高风险清单"（哪些文案一旦修改会直接导致测试红）。
```

### 【用户操作】
1. 把提示词发给前端对话。
2. 等它输出基线报告，**先看"改动高风险清单"**——这份清单决定后面哪些文案不能动。
3. 报告里如果出现 `净利润 -12.35 万元` 这类断言，记住：**emoji 绝不能写进 label 的文本节点**。

### 【验收标准】
- 报告给出 60 个用例名，不是只给数字。
- 至少列出 5 条"断言具体文案"的用例（预期集中在 `student-play.test.cjs`、`merged-calibration.test.cjs`、`progressive-display.test.cjs`）。
- `tsc -b` 报 0 错误。

### 【失败处理】
若 npm test 不是 60/60：先停下，这不是本次改造引起的。按 `README-快速启动.md` 检查 node_modules 是否完整，跑 `npm install` 后重试。

---

## 阶段 1：设计令牌层（1 小时）

### 目标
把所有颜色、圆角、阴影收敛到 CSS 变量，后续阶段只引用变量，不写死色值。

### 【复制给 AI 的提示词】

```text
你是 case_sim 设计令牌 Agent。只改样式变量，不改任何组件结构与文案。

【必读约束】
- 路径别名禁止使用，全部相对导入。
- 不许改 pages/teacher/**。
- 已有变量 --color-primary-teacher / --color-primary-student 必须保留原值。

【任务】
1. 打开 frontend/src/index.css，在 :root 中追加以下变量（保留已有变量，不覆盖）：
   --student-bg: #FFF8E7;
   --student-surface: #FFFFFF;
   --student-radius-card: 16px;
   --student-radius-control: 10px;
   --student-shadow-card: 0 4px 12px rgba(31, 41, 55, 0.08);
   --student-shadow-card-hover: 0 8px 20px rgba(31, 41, 55, 0.12);
   --student-text: #1f2937;
   --student-text-muted: #4b5563;
   --option-a-border: #3b82f6;
   --option-a-bg: #eff6ff;
   --option-b-border: #8b5cf6;
   --option-b-bg: #f5f3ff;
   --option-c-border: #06b6d4;
   --option-c-bg: #ecfeff;

2. 在同一文件中追加一个媒体查询兜底（必须放在文件末尾）：
   @media (prefers-reduced-motion: reduce) {
     .student-page *, .student-page *::before, .student-page *::after {
       transition-duration: .01ms !important;
       animation-duration: .01ms !important;
     }
   }

3. 不要在任何组件里引用这些变量——本阶段只定义，不消费。

【禁止】
- 修改 .tsx / .ts 文件
- 删除或重命名已有变量
- 写内联 style

【验收】
- npx tsc -b 通过（虽然没改 ts，但要确认没误伤）
- npm test 60/60 通过
- 用 grep 确认 14 个新变量都已定义且各出现 1 次

交付：改动文件 + 行号 + grep 结果。
```

### 【用户操作】
1. 发提示词，等完成。
2. 打开 `frontend/src/index.css` 肉眼确认变量都在 `:root` 里。

### 【验收标准】
- `index.css` 新增 14 个变量 + 1 个媒体查询块。
- `npm test` 仍 60/60。
- 全仓 `grep -c "var(--student-bg)"` 为 0（本阶段不消费，正常）。

### 【失败处理】
若变量名冲突（已有同名），停下问用户，不要自行改名。

---

## 阶段 2：学生端换肤（2 小时）

### 目标
底色、卡片、按钮、输入框统一换成暖色经营风。**只改样式，不改任何 JSX 结构。**

### 【复制给 AI 的提示词】

```text
你是 case_sim 学生端换肤 Agent。只改 CSS，不改任何 .tsx 结构、不改任何文案。

【必读约束】
- 只改 frontend/src/layouts/StudentLayout.css 与 frontend/src/index.css。
- 不许改 pages/teacher/**、不许改 features/ai/**。
- 所有色值必须引用阶段 1 的 CSS 变量，禁止再写死新的十六进制。
- 不许把 body.student-body 的 max-width 从 1280px 改掉（注释写 480 是历史遗留，别动）。

【任务】
1. body.student-body：background-color 由 #fff 改为 var(--student-bg)。
2. .student-shell：background-color 改为 var(--student-bg)。
3. .student-main：background-color 改为 transparent。
4. .student-page .ant-card：border 去掉（border: 0），border-radius 改为 var(--student-radius-card)，box-shadow 改为 var(--student-shadow-card)，背景 var(--student-surface)。
5. .student-page .ant-card-head：加 padding 微调，标题字号保持原值。
6. 学生端主按钮（body.student-body .ant-btn-primary）：加
   background: linear-gradient(180deg, #ec4899 0%, #db2777 100%);
   border-color: #db2777;
   box-shadow: 0 2px 0 rgba(219, 39, 119, .25);
   不加 transform 动效（动效留给阶段 8）。
7. 输入框（body.student-body .ant-input、.ant-input-affix-wrapper）：
   border-radius 改为 var(--student-radius-control)。
8. 次要文字（body.student-body .ant-typography-secondary, .ant-form-item-explain）：
   颜色保持 rgba(0,0,0,.45) 不降级，但改为 color: var(--student-text-muted)（提高对比度，这是有意为之）。
9. 主文字（body.student-body）：color: var(--student-text)。

【禁止】
- 改任何 .tsx 文件
- 改文案
- 动 480px/800px 媒体查询里的布局规则
- 引入图片或字体文件

【验收】
- npm test 60/60
- npm run build 成功
- 用浏览器在 375px 宽度下打开学生推演页截图，确认：无横向溢出、卡片有圆角与阴影、背景是奶油色

交付：改动文件 + 行号 + 截图路径 + 60/60 证明。
```

### 【用户操作】
1. 发起后跑 `cd frontend && npm run dev`（后端可另开 `启动项目.bat`）。
2. 浏览器开 `/student/<token>`，DevTools 切 375px。
3. 看三点：背景是不是奶油黄、卡片是不是大圆角带阴影、有没有横向滚动条。

### 【验收标准】
- 背景 `#FFF8E7` 生效（截图可见）。
- 卡片圆角 16px、有阴影。
- 375px 无横向溢出。
- `npm test` 60/60。

### 【失败处理】
若底色没变：检查是不是 `.student-page` 上有更高优先级的白底规则，用 DevTools 看 computed style 的来源文件与行号。

---

## 阶段 3：策略卡三色化（2 小时）

### 目标
A/B/C 三个选项用三套可区分的配色，**按序号固定**，不带风险语义。

### 【复制给 AI 的提示词】

```text
你是 case_sim 策略卡配色 Agent。目标：让 A/B/C 三个选项一眼可区分。

【必读约束（关键）】
- 当前 OptionBrief 只下发 key + label，没有 risk_level，所以不能按"保守/稳健/激进"上色。
- 本阶段按选项下标（0/1/2 → A/B/C）固定配色，纯视觉区分。
- 卡片上的"风险待评估"文案必须保留，不能删，否则会误导学生以为已经评估过风险。
- 不许改 StudentPlayPage.tsx 里的 RISK_META 语义映射逻辑，只新增一套按序号的配色常量。

【任务】
1. 在 frontend/src/pages/student/StudentPlayPage.tsx 顶部新增：
   const OPTION_STYLE = [
     { border: '#3b82f6', bg: '#eff6ff' },
     { border: '#8b5cf6', bg: '#f5f3ff' },
     { border: '#06b6d4', bg: '#ecfeff' },
   ]
   保留原有 RISK_META 与 RISK_PLACEHOLDER 定义不动（将来后端下发 risk_level 时还要用）。

2. 修改选项渲染处的 meta 取值逻辑（当前约在 225-229 行）：
   若 (o as Partial<OptionDetail>).risk_level 存在 → 仍走 RISK_META（语义配色优先）
   否则 → 走 OPTION_STYLE[index % 3]（按序号配色）

3. 新增的按序号配色只用于边框色与浅底色；卡片内文字颜色保持原样（不要白字，因为底色是浅色）。

4. 在 StudentLayout.css 的 .strategy-option-card 规则中补：
   transition: border-color .15s ease, box-shadow .15s ease;

【禁止】
- 改选项文案、改"风险待评估"文字
- 改 Button 的 aria-pressed / type 逻辑（测试盯着这个契约）
- 改 disabled 逻辑
- 引入 3D 翻转 animation

【验收】
- npm test 60/60（若有断言因 class 变化失败，只允许改断言里的期望值，不允许删用例）
- npx tsc -b 0 错误
- 浏览器 375px 下：三张卡片边框颜色不同，点击后选中态仍明显

交付：改动行号 + 三色实际渲染色值 + 测试结果。
```

### 【用户操作】
1. 发提示词。
2. 完成后在 375px 下点 A/B/C，确认三张卡片颜色不同、选中后仍能看出选的是哪张。

### 【验收标准】
- 三张卡片边框分别是蓝/紫/青（中性区分色，不暗示风险等级）。
- 选中态有明确反馈（边框加粗或背景变化，不依赖白字）。
- "风险待评估"文字仍在。
- `npm test` 60/60。

### 【失败处理】
若测试因 `aria-pressed` 或 textContent 变化失败：只改断言期望值。若某用例整段依赖旧的灰色 class，先看它断言的是行为还是样式——**样式不断言，行为才断言**。

---

## 阶段 4：财务卡图标与趋势（1.5 小时）

### 目标
数字变得"一眼看懂好坏"，且**绝不改变 DOM 文本**。

### 【复制给 AI 的提示词】

```text
你是 case_sim 财务卡视觉 Agent。核心约束：不能改变任何现有文本节点内容。

【必读约束（关键）】
- tests/student-play.test.cjs 断言了 '净利润 -12.35 万元' 这类拼接文本。
- 因此 emoji 只能用 CSS ::before 注入，绝对不许写进 JSX 的文本节点。
- 不许改 MetricsBar 的 DOM 结构，只加 className 与 CSS。

【任务】
1. 在 StudentLayout.css 中为四类卡片补图标（CSS content 注入）：
   .student-metrics .metric-revenue .metric-label::before { content: "💰"; margin-right: 4px; }
   .student-metrics .metric-card:nth-child(2) .metric-label::before { content: "📊"; margin-right: 4px; }
   .student-metrics .metric-card:nth-child(3) .metric-label::before { content: "📈"; margin-right: 4px; }
   .student-metrics .metric-card:nth-child(4) .metric-label::before { content: "💵"; margin-right: 4px; }

2. emoji 字体栈统一（避免跨平台字形差异过大）：
   .student-metrics .metric-label::before {
     font-family: "Segoe UI Emoji", "Apple Color Emoji", "Noto Color Emoji", sans-serif;
     font-size: 14px;
   }

3. 可访问性补全（aria-label，不改变文本内容）：
   在 MetricsBar 组件的四个 .metric-label 元素上补 aria-label 属性，例如：
   <span className="metric-label" aria-label="营收">营收</span>
   只加属性，不改文本节点内容，测试断言的 textContent 不变。

4. 趋势箭头（现有 .metric-trend）增强：
   - 上升：color 保持 #16a34a，加 transition: transform .2s ease
   - 下降：color 保持 #dc2626
   - 在 prefers-reduced-motion 下自动失效（已有全局块覆盖，不额外写）

4. 营收大数字（.metric-card.metric-revenue .metric-value）加：
   font-variant-numeric: tabular-nums;
   letter-spacing: -0.02em;

【禁止】
- 修改 StudentPlayPage.tsx 的任何 JSX（本阶段纯 CSS）
- 在 label 里插入 emoji 字符
- 改数字格式与单位（"万元"不能丢）
- 加数字滚动动画（会导致测试断言期间读数不稳）

【验收】
- npm test 60/60（必须，任何失败都说明动了文本节点）
- 浏览器截图：四张卡左上角各有图标，营收数字明显更大更粗

交付：CSS 改动行号 + 60/60 证明 + 截图。
```

### 【用户操作】
1. 发提示词。
2. 看截图：四张卡是否都有图标。
3. **重点确认**：`npm test` 必须 60/60。如果挂了，说明 emoji 被写进了文本节点。

### 【验收标准】
- 四张卡分别有 💰📊📈💵。
- 测试 60/60。
- 数字单位"万元"仍在。

### 【失败处理】
若测试挂且报错信息里出现 emoji：立刻让 AI 把 emoji 从 JSX 移到 CSS `::before`，这是唯一正确解法。

---

## 阶段 5：关卡式进度（2.5 小时）

### 目标
把 AntD Steps 换成"三段路 + 三个站点"，保留全部无障碍信息与现有文案。

### 【复制给 AI 的提示词】

```text
你是 case_sim 学生端进度组件 Agent。把 Steps 换成自绘的"三段经营路"。

【必读约束】
- tests/student-play.test.cjs 里有 antd Steps 的 mock，替换后要同步调整 mock（只调整挂载，不删断言）。
- 现有文本"第 2 / 3 轮 · 已提交 1 轮"必须逐字保留，测试断言它。
- 必须保留可访问性：容器 role="list"，每个节点 role="listitem"，当前节点 aria-current="step"。
- 不许引入图片，全部用 CSS 画。

【任务】
1. 新建 frontend/src/pages/student/components/RoundMap.tsx（相对导入，不用别名）：
   参数：{ total: number; current: number; done: number }
   结构：一个横向 flex 容器，含 total 个节点，节点之间用 CSS 伪元素画连接线。
   每个节点显示：轮次数字、状态文字（已完成/进行中/未开始）。
   当前节点加 aria-current="step" 与 .is-current 类；已完成加 .is-done。
2. 在 StudentPlayPage.tsx 中用 RoundMap 替换原有 <Steps> 块（保留其上方的"第 X / 3 轮 · 已提交 Y 轮"文本不动）。
3. 在 StudentLayout.css 新增：
   .round-map { display: flex; align-items: flex-start; gap: 0; margin: 12px 0 4px; }
   .round-node { flex: 1; display: flex; flex-direction: column; align-items: center; position: relative; }
   .round-node::before { content: ""; position: absolute; top: 14px; left: -50%; width: 100%; height: 2px; background: #e5e7eb; }
   .round-node:first-child::before { display: none; }
   .round-node .dot { width: 28px; height: 28px; border-radius: 50%; background: #fff; border: 2px solid #d1d5db; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 700; }
   .round-node.is-done .dot { background: #db2777; border-color: #db2777; color: #fff; }
   .round-node.is-current .dot { border-color: #db2777; color: #db2777; box-shadow: 0 0 0 4px rgba(219,39,119,.15); }
   .round-node .round-label { margin-top: 6px; font-size: 12px; color: var(--student-text-muted); }
   .round-node.is-current .round-label { color: #db2777; font-weight: 600; }
4. 375px 下节点文字不得溢出：.round-label 加 overflow-wrap: anywhere; text-align: center;

【禁止】
- 删除"第 X / 3 轮 · 已提交 Y 轮"文本
- 使用 3D transform
- 引入新依赖
- 改动财务卡与策略卡的任何代码

【验收】
- npm test 通过（若 Steps mock 需要调整，只改挂载方式，不断言内容）
- npx tsc -b 0 错误
- 375px 截图：三个站点排列整齐，当前站点有粉色光环，已完成站点实心
- 键盘 Tab 能聚焦到当前节点，屏幕阅读器可读出"第 2 轮 进行中"

交付：新增/修改文件、组件 props、测试调整说明、截图。
```

### 【用户操作】
1. 发提示词。
2. 375px 下看三段路是否整齐、当前站点是否高亮。
3. 用 Tab 键走一遍，确认焦点能落在当前节点。

### 【验收标准】
- 三个节点 + 连接线，视觉上是"一条路"不是"三个圆圈"。
- 已完成实心、当前有光环、未开始灰色。
- 文本"第 X / 3 轮 · 已提交 Y 轮"仍在。
- `npm test` 通过。

### 【失败处理】
若测试因 Steps 的 mock 失败：让 AI 把 mock 里的 `Steps` 键保留（即使组件不再使用），只调整挂载入口，避免连锁失败。

---

## 阶段 6：FAB 气泡化（1.5 小时）

### 目标
把玫红圆形按钮改成"AI 助教头像气泡"，面板圆角与底色统一。

### 【复制给 AI 的提示词】

```text
你是 case_sim 学生端 FAB 改造 Agent。只改视觉，不改交互逻辑。

【必读约束】
- FloatButton 的 onClick、aria-label、z-index 逻辑不许改。
- 面板的展开/收起条件渲染逻辑不许改。
- StudentTutorSidebar 内部一行都不许动。

【任务】
1. frontend/src/layouts/StudentLayout.tsx：把 FloatButton 的 icon 从 <MessageOutlined /> 改为一个自绘气泡：
   <span className="tutor-fab-face" aria-hidden="true">🤖</span>
   保留 tooltip="询问助教" 与 aria-label="AI 商科助教"。
2. StudentLayout.css 新增：
   .tutor-fab-face { font-size: 24px; line-height: 1; font-family: "Segoe UI Emoji","Apple Color Emoji","Noto Color Emoji",sans-serif; }
   body.student-body .ant-float-btn-primary { background: #db2777; }
   body.student-body .ant-float-btn-primary:hover { background: #be185d; }
3. 面板样式：
   .student-tutor-panel { border-radius: var(--student-radius-card); background: var(--student-surface); box-shadow: var(--student-shadow-card-hover); }
   .student-tutor-panel-head { background: var(--student-surface); }
   .student-tutor-panel-body { background: var(--student-bg); }
4. hover 时 FAB 轻微上浮（必须在 prefers-reduced-motion 下失效，已有全局块覆盖）：
   body.student-body .ant-float-btn-primary { transition: transform .15s ease, background .15s ease; }
   body.student-body .ant-float-btn-primary:hover { transform: translateY(-2px); }

【禁止】
- 改 onClick / 展开状态 / z-index
- 改 StudentTutorSidebar
- 改 FAB 位置（right:16 bottom:80）
- 引入图片资源

【验收】
- npm test 60/60
- 375px 下 FAB 仍不遮挡提交按钮
- 点击展开、关闭、再展开，行为与改造前一致

交付：改动行号 + 行为一致性说明 + 截图。
```

### 【用户操作】
1. 发提示词。
2. 375px 下点 FAB 开关两次，确认行为没变。
3. 确认提交按钮仍可见可点。

### 【验收标准】
- FAB 是 🤖 气泡，不是线条图标。
- 面板圆角 16px、底色奶油。
- 展开/收起行为与改造前完全一致。
- `npm test` 60/60。

### 【失败处理】
若 emoji 在目标设备显示成方块：改用内联 SVG 简单笑脸（12 行以内），不要引入图标库。

---

## 阶段 7：教师端 KPI 升级（2 小时）【D3=做才执行】

### 目标
四个 KPI 卡片加图标与迷你趋势线，提升仪表盘完成度。**只改一个文件。**

### 【复制给 AI 的提示词】

```text
你是 case_sim 教师端 KPI Agent。只改 frontend/src/pages/teacher/TeacherStudentsPage.tsx。

【必读约束】
- 教师端主色 #1a3a5c 保持，不许改成学生端玫红。
- 该页所有数值当前是 mock，必须保留"以下为占位数据（mock）"的说明文字。
- 不许引入新依赖，不许用 ECharts 画 4 个迷你图（实例太重），用内联 SVG polyline。
- 不许改学生账号管理卡片与表格。

【任务】
1. 在文件顶部新增内联 SVG 迷你折线组件（约 15 行）：
   function Sparkline({ points, color }: { points: number[]; color: string })
   用 viewBox="0 0 100 28"，把 points 归一化后画 polyline，strokeWidth 1.5，fill none。
2. 四个 Statistic 卡片各加：
   - 左上角图标（用 @ant-design/icons 已有图标，不装新包）：TeamOutlined / WarningOutlined / RiseOutlined / ClockCircleOutlined
   - 底部一条 Sparkline（数据用硬编码的 mock 数组，注释标 TODO）
3. 卡片样式：border-radius 10px，background #ffffff，border 1px solid #e9edf3（保持教师端克制风格，不要大圆角）。

【禁止】
- 改 mock 说明文字
- 改学生表格列
- 用 ECharts
- 改教师端主色

【验收】
- npm test 60/60
- npx tsc -b 0 错误
- 教师端仪表盘截图：四卡有图标 + 迷你折线，风格仍是深蓝克制系

交付：改动行号 + 截图 + 测试结果。
```

### 【用户操作】
1. 发提示词。
2. 打开教师端 `/teacher/<token>/students`，看四张卡片。

### 【验收标准】
- 四卡有图标与迷你折线。
- 仍是深蓝系，没有变成玫红或奶油色。
- mock 说明文字仍在。
- `npm test` 60/60。

### 【失败处理】
若教师端测试有断言卡片结构：只改期望值，不删用例。

---

## 阶段 8：微动效与降级（1.5 小时）

### 目标
让界面"活"起来，同时保证低端设备与晕动症用户不受影响。

### 【复制给 AI 的提示词】

```text
你是 case_sim 微动效 Agent。只加 CSS transition，不加 animation keyframes，不改任何 JSX 逻辑。

【必读约束】
- prefers-reduced-motion 必须生效（StudentLayout.css:206 已有全局块，新增规则不得用 !important 绕开它）。
- 不许用 3D transform（rotateY / perspective），低端安卓会掉帧。
- 不许给数字加滚动动画（会干扰测试读数）。

【任务】
1. 卡片 hover（仅在有真实指针的设备生效）：
   @media (hover: hover) and (pointer: fine) {
     .student-page .ant-card { transition: box-shadow .2s ease, transform .2s ease; }
     .student-page .ant-card:hover { box-shadow: var(--student-shadow-card-hover); transform: translateY(-2px); }
   }
2. 策略卡 hover：
   @media (hover: hover) and (pointer: fine) {
     .strategy-option-card { transition: transform .15s ease, box-shadow .15s ease; }
     .strategy-option-card:hover { transform: translateY(-2px); box-shadow: var(--student-shadow-card); }
   }
3. 按钮按下反馈：
   body.student-body .ant-btn-primary:active { transform: scale(.98); }
4. 进度节点状态切换：
   .round-node .dot { transition: background-color .2s ease, border-color .2s ease, box-shadow .2s ease; }
5. 在 prefers-reduced-motion 块中补一句（如果尚未包含 transform 重置）：
   .student-page .ant-card, .strategy-option-card, body.student-body .ant-btn-primary { transform: none !important; }

【禁止】
- animation keyframes（流动条纹、呼吸灯等全部不做）
- 3D transform
- 改任何 .tsx

【验收】
- npm test 60/60
- 在 DevTools 里开启 "Emulate CSS prefers-reduced-motion: reduce"，hover 与按下全部无位移
- 375px 下连续点选三个策略卡，无卡顿

交付：CSS 改动行号 + reduced-motion 验证截图。
```

### 【用户操作】
1. 发提示词。
2. DevTools → Rendering → Emulate CSS media feature prefers-reduced-motion → reduce。
3. 鼠标悬停卡片，确认不再上浮。

### 【验收标准】
- 正常模式下 hover 有轻微上浮与阴影加深。
- 开启 reduced-motion 后所有位移消失（不只是变快）。
- `npm test` 60/60。

### 【失败处理】
若 reduced-motion 下仍有位移：说明用了 `!important` 或 `animation`，让 AI 改成普通 transition 并检查层叠顺序。

---

## 阶段 9：全量回归（1 小时）

### 目标
确认视觉改完，功能一条不少。

### 【复制给 AI 的提示词】

```text
你是 case_sim 回归 Agent。全程只读，不改代码。

【环境事实】
- 项目不是 git 仓库，git diff 不可用，用 mtime 审计。
- 后端 pytest 必须从项目根跑，收集数应为 184。

【任务】
1. cd frontend && npm test → 记录 pass/fail（应为 60/60，若阶段 5 调整过 Steps mock 仍是 60）
2. cd frontend && npx tsc -b → 错误数应为 0
3. cd frontend && npm run build → 记录成功与否、index chunk 大小（基线 663.14 kB，允许 ±30 kB）
4. cd 项目根 && .venv\Scripts\python.exe -m pytest -q → 应为 184 passed
5. 变更审计：cd frontend && find src tests -newermt "2026-10-20 21:00" -type f
6. 红线检查：确认 baselineFinance.ts 与 domain/financials.js 的 mtime 早于本次改造开始时间
7. 教师端零改动检查：find src/pages/teacher src/layouts/TeacherLayout.tsx -newermt "2026-10-20 21:00" -type f
   预期只有 TeacherStudentsPage.tsx（阶段 7 允许），如出现其他文件必须说明原因

【输出】
《游戏化改造验收报告》：
- 前端测试 X/Y、后端 184/184、tsc 错误数、build 结果与 chunk 体积
- 变更文件清单（按阶段归类）
- 红线文件检查结论
- 教师端是否被误改
- 遗留问题（若有）
- 是否建议上线：是/否 + 依据

禁止修改任何代码。
```

### 【用户操作】
1. 发提示词。
2. 自己再跑一遍这两条确认：
   ```bash
   cd "C:\Users\huang2006\Desktop\Work\upload2\case_sim-\frontend"
   npm test
   ```
   ```bash
   cd "C:\Users\huang2006\Desktop\Work\upload2\case_sim-"
   .venv\Scripts\python.exe -m pytest -q
   ```

### 【验收标准】
- 前端 60/60、后端 184/184。
- `tsc -b` 0 错误。
- 教师端只有 `TeacherStudentsPage.tsx` 一个文件被改。
- index chunk 增量 ≤ 30 kB。

### 【失败处理】
若后端测试数不是 184：先确认是不是在 `backend/` 目录跑的（会报 25 个 collection error）。

---

## 依赖关系与执行顺序

```
阶段 0（基线盘点）
   ↓
阶段 1（设计令牌）
   ↓
阶段 2（学生端换肤）
   ↓
   ├─→ 阶段 3（策略卡三色）   ┐
   ├─→ 阶段 4（财务卡图标）   ├─ 三者互不冲突，可并行，但都要在阶段 2 之后
   └─→ 阶段 5（关卡进度）     ┘
              ↓
        阶段 6（FAB 气泡）
              ↓
   ┌──────────┴──────────┐
   ↓                     ↓
阶段 7（教师 KPI）    阶段 8（微动效）
   └──────────┬──────────┘
              ↓
        阶段 9（全量回归）
```

**与并发修复的关系**：`StudentPlayPage.tsx` 会被两边同时改——并发 P1 改的是 `begin()` 的错误分支，游戏化改的是渲染层。两者不冲突但同文件，**建议先做完并发 P1 再开游戏化**，否则同一文件两处改动容易互相覆盖。

---

## 已评估但排除（决策记录，勿再讨论）

| 提案 | 排除理由 |
|---|---|
| 3D 翻牌动画（carden 风格） | `rotateY` 在低端安卓掉帧；且翻转过程中文字可读性下降，学生会误触 |
| 经营等级 / 勋章体系（skills-service） | 需要新增数据结构与后端字段，牵动 184 个后端测试；且与"商科严肃性"冲突 |
| 复盘页做成 Web OS 桌面（Aurora-OS） | 改动面覆盖整个复盘页与雷达图容器，收益与成本不匹配 |
| 进度条流动条纹动画 | `animation` 会被 reduced-motion 块整体禁用，实际效果在部分设备上看不到 |
| 数字滚动动画 | 滚动期间的中间值会让测试断言不稳定 |
| 教师端一起换成暖色 | 直接摧毁"教师端克制专业 / 学生端友好"的双语域设计 |

---

## 附录 A：设计令牌速查

| 变量 | 值 | 用途 |
|---|---|---|
| `--student-bg` | `#FFF8E7` | 学生端页面底色 |
| `--student-surface` | `#FFFFFF` | 卡片面 |
| `--student-radius-card` | `16px` | 卡片圆角 |
| `--student-radius-control` | `10px` | 输入框/按钮圆角 |
| `--student-shadow-card` | `0 4px 12px rgba(31,41,55,.08)` | 卡片默认阴影 |
| `--student-shadow-card-hover` | `0 8px 20px rgba(31,41,55,.12)` | 悬停阴影 |
| `--student-text` | `#1f2937` | 主文字（对比度 ≥ 12:1） |
| `--student-text-muted` | `#4b5563` | 次要文字（对比度 ≈ 7:1） |
| `--option-a-border/bg` | `#3b82f6` / `#eff6ff` | A 选项（蓝色，中性区分色） |
| `--option-b-border/bg` | `#8b5cf6` / `#f5f3ff` | B 选项（紫色，中性区分色） |
| `--option-c-border/bg` | `#06b6d4` / `#ecfeff` | C 选项（青色，中性区分色） |

> 对比度说明：原次要文字 `rgba(0,0,0,.45)` 在 `#FFF8E7` 上约 3.9:1，低于 WCAG AA 的 4.5:1；改为 `#4b5563` 后约 7:1，这是**有意为之的可读性提升**，不是"配色偏好"。
>
> 配色说明：策略卡 A/B/C 用蓝/紫/青而非绿/橙/红，是因为后端未下发 `risk_level`，用语义色（绿=保守/橙=稳健/红=激进）会误导学生以为颜色代表风险等级。中性区分色只做视觉区分，不带任何风险暗示。

---

## 附录 B：验收命令合集

```bash
cd "C:\Users\huang2006\Desktop\Work\upload2\case_sim-\frontend"
npm test
npx tsc -b
npm run build

cd "C:\Users\huang2006\Desktop\Work\upload2\case_sim-"
.venv\Scripts\python.exe -m pytest -q

# 变更审计（无 git）
cd "C:\Users\huang2006\Desktop\Work\upload2\case_sim-\frontend"
find src tests -newermt "2026-10-20 21:00" -type f
```

---

## 附录 C：一键启动提示词（第一次开对话时用）

```text
你是一个自主前端改造 Agent，负责 case_sim 学生端"暖色经营风"改造。

项目根：C:\Users\huang2006\Desktop\Work\upload2\case_sim-\
前端目录：C:\Users\huang2006\Desktop\Work\upload2\case_sim-\frontend

请先读这份清单并严格按阶段执行：
C:\Users\huang2006\Desktop\Work\upload2\case_sim-前端游戏化执行清单.md

执行前必须确认的三条：
1. 路径别名"配而未用"，所有 import 用相对路径。
2. 教师端零改动（阶段 7 除外）。
3. 前端测试 60/60 是硬指标，只许改断言不许删用例。

每次完成后报告：改动文件 + 行号 + npm test 结果 + tsc 结果 + 截图路径。
遇到需要改后端或改契约的地方，停下来问我，不要自己决定。
```
