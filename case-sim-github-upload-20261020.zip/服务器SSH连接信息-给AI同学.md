# 服务器 SSH 连接信息（给负责 AI 的同学）

> ⚠️ **这份文档请私聊发送，不要发在群里。** 群里有其他成员，服务器账号密码属于敏感信息。
> 密码一栏我留了空位 —— **请你自己填上后再发给他**，不要贴在群里。

---

## 一、连接信息

| 项目 | 值 |
|---|---|
| 服务器地址（IP） | `8.155.128.75` |
| 端口 | `22`（默认） |
| 登录用户 | `root` |
| 登录密码 | **【请你自己填在这里】** |
| 系统 | Ubuntu 22.04.5 LTS |
| 项目根目录 | `/opt/case-sim` |

**连接命令（他本机 Windows「终端」或 PowerShell 里执行）：**

```bash
ssh root@8.155.128.75
```

提示 `root@8.155.128.75's password:` 后输入密码即可（**输入时屏幕不显示字符，是正常的**，输完直接回车）。

> ✅ 说明：22 端口是通的 —— 你之前多次从自己电脑成功 `ssh` 进去过，说明阿里云安全组已放行。

---

## 二、登录后先确认「你确实在服务器上」

```bash
whoami
```
→ 应输出 `root`。若输出 `huang2006` 之类，说明还在本机，没连上。

```bash
hostname
```
→ 应输出 `iZf8z9bvr1gihktc8xflstZ`。

**看提示符更直观**：本机是 `huang2006@LAPTOP-4SPC8DVG`，服务器是 `root@iZf8z9bvr1gihktc8xflstZ:~#`。

---

## 三、项目在这台机器上的布局

| 路径 | 说明 |
|---|---|
| `/opt/case-sim` | **项目根**（所有代码在这） |
| `/opt/case-sim/backend` | 后端（FastAPI） |
| `/opt/case-sim/frontend` | 前端（React + Vite），`dist/` 是构建产物 |
| `/opt/case-sim/ai_component` | **AI 组件（就是你要负责的部分）** |
| `/opt/case-sim/docs` | 商科规则、标杆案例等数据 |
| `/opt/case-sim/.venv` | Python 虚拟环境（**别删**） |
| `/opt/case-sim/backend/.env` | 环境配置，含**真实 API Key** 与教师口令（**别外传、别删**） |
| `/opt/case-sim/backend/data/app.db` | SQLite 数据库，**线上全部数据**（案例、学生账号、作答记录） |
| `/opt/case-sim/deploy/` | Nginx 与 systemd 配置模板 |

---

## 四、日常操作常用命令

**查看服务状态 / 日志**
```bash
systemctl status case-sim
```
```bash
journalctl -u case-sim -n 100 --no-pager
```
（实时看日志：`journalctl -u case-sim -f`，按 `Ctrl+C` 退出）

**重启服务（**改完后端代码后必须做**）**
```bash
systemctl restart case-sim
```

**健康检查**
```bash
curl -s http://127.0.0.1:8100/api/health
```
→ 应输出 `{"status":"ok"}`

**跑测试**
```bash
cd /opt/case-sim && ./.venv/bin/python -m pytest backend/tests ai_component/tests -q
```

---

## 五、改了代码之后怎么让改动生效

| 改了什么 | 需要做什么 |
|---|---|
| 后端 `.py` / `ai_component` / `docs` 数据 | `systemctl restart case-sim` |
| 前端 `frontend/src` | `cd /opt/case-sim/frontend && npm ci && npm run build`（**不用重启后端**） |
| `deploy/nginx/case-sim.conf` | 需复制到 `/etc/nginx/` 后 `nginx -t && systemctl reload nginx` |

> ⚠️ 前端构建产物 `dist/` **不在版本库里**，所以每次改前端源码都必须在服务器上重新构建，否则页面还是旧的。

---

## 六、⚠️ 危险操作（请务必避开）

| 不要做 | 为什么 |
|---|---|
| 删除或覆盖 `/opt/case-sim/backend/.env` | 里面有真实 API Key 和教师登录口令，删了要重配 |
| 删除 `/opt/case-sim/backend/data/app.db` | 这是**全部线上数据**，删了案例和学生记录全没 |
| 删除 `/opt/case-sim/.venv` | 重建要重新联网装依赖 |
| 修改 `/etc/systemd/system/case-sim.service` 里的 `--workers 1` | **必须保持 1**。调大后会同时引发 3 个故障（令牌失效被踢、学生试跑失效、AI 任务重复调度导致**双倍消耗模型额度**） |
| 在服务器上直接改代码后忘记重启 | 改动不会生效 |

**改动前先备份，是个好习惯：**
```bash
cp -a /opt/case-sim/backend/data/app.db /root/appdb-bak-$(date +%F-%H%M) && echo "已备份"
```

---

## 七、更安全的选择（强烈建议，二选一）

直接把 `root` 账号密码给出去 = 对方拥有服务器**最高权限**（能读走 API Key、能删掉所有数据）。如果方便，建议改用下面任意一种方式，用完后随时可以收回：

### 方式 A：建一个专用账号（推荐，操作简单）

在服务器上执行一次：

```bash
adduser --disabled-password --gecos "" caseteam
```
```bash
usermod -aG sudo caseteam
```
```bash
mkdir -p /home/caseteam/.ssh && chmod 700 /home/caseteam/.ssh
```
```bash
echo 'caseteam:在这里换成一个新密码' | chpasswd
```

然后给他：用户名 `caseteam` + 上面设的密码。他要改项目文件时用 `sudo`（如 `sudo systemctl restart case-sim`）。

**合作结束后收回：**
```bash
deluser --remove-home caseteam
```

### 方式 B：用密钥登录（更安全，但要他生成一次密钥）

他本机执行 `ssh-keygen -t ed25519` 生成密钥，把公钥（`~/.ssh/id_ed25519.pub` 的内容）发给你，你在服务器执行：

```bash
mkdir -p ~/.ssh && chmod 700 ~/.ssh
```
```bash
echo "他发来的公钥内容" >> ~/.ssh/authorized_keys && chmod 600 ~/.ssh/authorized_keys
```

之后他就能免密登录，你不用把密码给任何人。

**无论选哪种**：合作结束后，建议把 root 密码改一次（`passwd`）。

---

## 八、给他的第一条消息（可直接复制）

> 服务器可以直连，信息我私聊发你：地址 `8.155.128.75`、用户 `root`、端口 22（默认）。
> 项目在 `/opt/case-sim`，AI 那部分代码在 `/opt/case-sim/ai_component`。
> 登录后先跑 `whoami` 确认是 `root` 再动手；改完后端代码记得 `systemctl restart case-sim`。
> 详细说明和常用命令我整理成一份文档一起发你了，里面有「危险操作清单」，动手前先扫一眼。
