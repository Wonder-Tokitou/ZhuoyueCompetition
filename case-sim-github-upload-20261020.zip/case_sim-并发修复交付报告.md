# case_sim 多并发修复交付报告（P1–P4）

- 执行时间：2026-10-20 21:03–21:16（GMT+8）
- 项目根：`C:\Users\huang2006\Desktop\Work\upload2\case_sim-`
- 约束保持：`deploy/systemd/case-sim.service` 未改动，仍为 `--workers 1`；未新增第三方依赖；未改 `schemas.py` / `contracts/` / `ai_component/`；未启用路径别名。

---

## 一、改动文件清单

| # | 文件 | 行号 | 说明 |
|---|------|------|------|
| 1 | `backend/app/integrations/ai/task_runner.py` | 30–38 | 新增模块级 `AI_CONCURRENCY = 4` 与 `asyncio.Semaphore(4)`，注释说明 10 人同时完成推演的场景 |
| 2 | `backend/app/integrations/ai/task_runner.py` | 93–104 | `run_task` 用 `async with _semaphore` 包住 `_run_task`，取消/异常路径由 `__aexit__` 归还名额 |
| 3 | `backend/app/db.py` | 32–36 | 池参数常量：`POOL_SIZE=10`、`MAX_OVERFLOW=10`、`POOL_TIMEOUT=30`、`BUSY_TIMEOUT_MS=10000` |
| 4 | `backend/app/db.py` | 39–57 | `_install_sqlite_pragmas`：`event.listens_for(engine, "connect")` 逐连接执行 `journal_mode=WAL` / `synchronous=NORMAL` / `busy_timeout=10000`；内存库直接 return |
| 5 | `backend/app/db.py` | 61–67 | `_is_memory_url`：识别 `:memory:` 与 `sqlite://` 两种内存库写法 |
| 6 | `backend/app/db.py` | 69–79 | `build_engine`：`create_engine` 带 `pool_size/max_overflow/pool_timeout`（内存库不带，否则 SingletonThreadPool 抛 TypeError）并挂 PRAGMA |
| 7 | `backend/app/db.py` | 82 | 模块级 `engine = build_engine(DATABASE_URL)`，`db.engine` 与测试走同一条构建路径 |
| 8 | `frontend/src/api/transport.ts` | 6–24 | `ApiError` 增 `code?` / `detail?`；`toApiError` 透传 `code` 与结构化载荷 |
| 9 | `frontend/src/api/transport.ts` | 43–65 | 拦截器按 `string` / `array` / `object` 分流：对象 detail 取 `code`，文案优先用后端 `message`；数组（422）仍走通用中文 |
| 10 | `frontend/src/api/transport.ts` | 87 | 拒绝时带上 `{ code, detail: structured }`，不再丢 `submission_exists` |
| 11 | `frontend/src/pages/student/StudentPlayPage.tsx` | 20–25 | `SUBMISSION_EXISTS` 文案常量 + `isSubmissionExists`（`status===409 && code==='submission_exists'`） |
| 12 | `frontend/src/pages/student/StudentPlayPage.tsx` | 68 / 78 | 新增 `duplicate` 状态；切换案例时重置 |
| 13 | `frontend/src/pages/student/StudentPlayPage.tsx` | 112–117 | `begin()` 失败分支：命中 409+submission_exists 时展示指定文案并置 `duplicate`，其余错误维持 `e.message` |
| 14 | `frontend/src/pages/student/StudentPlayPage.tsx` | 223 | 「前往「我的记录」继续」按钮，`navigate('/student/records')` |
| 15 | `backend/tests/test_concurrency.py` | 新增 | 5 项：并发上限 ≤4 + 10 任务终态、重试不死锁、文件库 WAL/busy_timeout、内存库不报错、池参数 |
| 16 | `frontend/tests/transport-error.test.cjs` | 新增 | 3 项：409 保留业务码与 message、422 数组仍通用文案、字符串/网络错误文案不变 |
| 17 | `frontend/tests/student-play.test.cjs` | 12/24/36/43 与文末 | 导航桩改为记录 `navs`；新增 2 项：重复开始展示指定文案 + 入口跳转、其他失败维持原提示 |

---

## 二、P1–P4 实现要点

### P1 前端识别跨设备冲突
- **根因**：`transport.ts` 原逻辑 `if (detail && typeof detail !== 'string') detail = 通用文案`，把后端的 `{code, session_id, message}` 整块丢掉，页面只能看到"请求参数不符合要求"。
- **修法**：对象 detail 时保留 `code`（挂 `error.code`）与原始载荷（挂 `error.detail`），文案优先用后端 `message`；**数组 detail（FastAPI 422）行为不变**，仍是通用中文。
- **页面**：`begin()` 只在 `status===409 && code==='submission_exists'` 时改用指定文案并渲染入口按钮，其他 409/错误一字未改（有测试守住）。
- **入口可用性**：`/student/records` 的"继续推演"会写回 `sessionStorage['student_session:<token>']`（`StudentSpacePages.tsx:61`）后跳回案例页，因此跨设备恢复链路完整。

### P2 限制 AI 任务并发
- 模块级 `asyncio.Semaphore(4)`；`async with` 包住 `_run_task`，正常返回 / 抛异常 / 被 `cancel()` 三条路径都由 `__aexit__` 释放。
- 名额在 `run_task` 内部获取，排队中的任务仍是普通 `asyncio.Task`，`cancel_task` 与 `_running` 去重逻辑不受影响。
- 重试链路：`_retry_or_fail` 用 `call_later(0.5, schedule_task, ...)`，定时器在本次 `run_task` 返回**之后**才触发，此时名额已归还，不会自锁；`test_retry_reenters_the_queue_without_deadlocking` 实测"失败→重试→成功"（`attempts=2`）。
- `--workers 1` 未动：信号量是进程内对象，与内存态约束一致。

### P3 SQLite 开 WAL
- `event.listens_for(engine, "connect")` 而非在 URL 上做手脚：每条新连接的 `busy_timeout` / `synchronous` 都会重新设置（这两项是连接级参数，不随文件持久化）。
- `journal_mode=WAL` 写进库文件头，属持久设置，但每条连接执行一次也无副作用。
- 内存库（`:memory:` 或 `sqlite://`）直接跳过，避免 `journal_mode` 返回 `memory` 与后续断言冲突，也避免测试环境报错。

### P4 连接池
- `pool_size=10` / `max_overflow=10` / `pool_timeout=30`，覆盖"1 教师 + 10 学生各占一条连接"（峰值 11 条）。
- 内存库不带池参数：SQLAlchemy 对 `sqlite://` 用 `SingletonThreadPool`，传这些参数会抛 `TypeError: Invalid argument(s) 'max_overflow','pool_timeout'`（本轮实测踩到并修掉）。

---

## 三、验收原始输出

### 1. `cd frontend && npm test`
```
# tests 65
# suites 0
# pass 65
# fail 0
# cancelled 0
# skipped 0
# todo 0
# duration_ms 5054.5933
```
> 65 = 原 60 项 + 新增 5 项（3 项 transport + 2 项页面）。**下文"异常发现"第 2 条**说明了原 60 项中 `review-layout` 那条断言在 21:06:08 被本会话之外的操作改动过。

### 2. `cd frontend && npx tsc -b`
```
tsc exit=0
```
（无任何诊断输出）

### 3. `cd frontend && npm run build`
```
> frontend@0.0.0 build
> tsc -b && vite build

vite v8.3.0 building client environment for production...
transforming...
✓ 3783 modules transformed.
dist/index.html                               0.99 kB │ gzip:   0.47 kB
dist/assets/antd-vendor-Tu04tXLf.css          3.06 kB │ gzip:   1.17 kB
dist/assets/index-BP6pNjIC.css               11.86 kB │ gzip:   3.00 kB
dist/assets/rolldown-runtime-hePW80VL.js      0.71 kB │ gzip:   0.42 kB
dist/assets/axios-Cwt1K6go.js                49.95 kB │ gzip:  18.75 kB
dist/assets/react-vendor-kma97xwK.js         95.20 kB │ gzip:  31.62 kB
dist/assets/antd-icons-CWRzXraS.js          118.32 kB │ gzip:  37.56 kB
dist/assets/index-BFgp-99f.js                665.01 kB │ gzip: 223.63 kB
dist/assets/antd-vendor-BweOjQ8b.js       1,052.33 kB │ gzip: 319.99 kB

✓ built in 3.46s
```

### 4. `cd 项目根 && .venv\Scripts\python.exe -m pytest -q`
```
189 passed in 39.53s
```
排除本次新增文件的原有 184 项回归：
```
184 passed in 36.13s
```

### 5. 并发上限测试（`backend/tests/test_concurrency.py`）
```
.....                                                                    [100%]
5 passed in 2.43s
```
断言内容：
- 同时投递 10 个 `student_review` 任务，统计"同时在执行"的峰值 `peak`；
- `assert peak <= task_runner.AI_CONCURRENCY`（=4），另加 `peak >= 2` 防止断言空转；
- 10 个任务最终全部 `status='succeeded'`（证明名额归还、队列排空）；
- 另有一条 `test_retry_reenters_the_queue_without_deadlocking`：首次抛可重试 `LLMFailed` → `call_later(0.5)` 重试 → 第二次成功，`attempts=2`。

### 6. PRAGMA 测试
```
def test_file_database_connections_use_wal_and_long_busy_timeout
    PRAGMA journal_mode -> 'wal'
    PRAGMA busy_timeout -> 10000
    PRAGMA synchronous  -> 1 (NORMAL)
def test_memory_database_skips_journal_mode_without_raising
    PRAGMA journal_mode -> 'memory'（不报错）
def test_application_engine_is_a_ten_connection_queue_pool
    QueuePool / maxsize=10 / max_overflow=10 / timeout=30
```

### 7. 前端 409 页面测试
```
ok 11 - duplicate submission shows the real reason and offers the records entry
ok 12 - other start failures keep the backend message and show no records entry
ok 1 - 409 submission_exists keeps the backend business code and message
ok 2 - 422 array detail still falls back to the generic Chinese message
ok 3 - string detail and network failures keep their previous copy
```

### 8. 手工验证（真实浏览器 + 真实后端）
后端以隔离临时库启动（`DATABASE_URL=sqlite:///…/.verify-tmp/app.db`，不碰 `backend/data/app.db`），前端用 `frontend/dist` 由后端同源托管，Chrome（headless + CDP）执行：

```
建学生账号 ui-probe-mvgpbxag -> 200
页面内学生登录 -> ok
标签页 A 点击开始推演 -> true
标签页 A 已进入推演，正文片段： … 研咖咖啡·高校市场扩张与定价决策 案例资料与经营困境 第 1 /
标签页 B 点击开始推演 -> true
标签页 B 页面文案含指定提示 -> true
标签页 B 页面文案含误导旧提示 -> false
标签页 B 存在「我的记录」可点击入口 -> true
截图已保存 -> …\验证截图\concurrency-409-alert.png
截图已保存 -> …\验证截图\concurrency-409-records-entry.png
点击入口 -> true
当前路径 -> /student/records
点击"继续推演" -> true
恢复后路径 -> /student/benchmark-demo-v4
恢复后的进度文案 -> 第 1 / 3 轮
RESULT: PASS
```

接口层同场景（`verify_duplicate_session.py`，绕开本机 http_proxy）：
```
标签页 A 开始推演 -> 200 session_id=1
标签页 B 开始推演 -> 409
响应体 -> {"detail": {"code": "submission_exists", "session_id": 1, "message": "已有本案例推演记录，请从提交记录继续，或选择覆盖原记录后重做。"}}
我的提交记录 200 条数 1 首条 session_id 1
```

---

## 四、未做项（确认未被顺带修改）

| 项 | 状态 | 证据 |
|----|------|------|
| R4 教师手动保存乐观锁 | **未做** | `backend/app/routers/teacher.py`、`backend/app/models.py` 本次无改动 |
| R5 Turn 唯一约束 | **未做** | `backend/app/models.py` 无改动（`find -newermt` 零命中） |
| D-02 `TeacherRecordsPage` 版本筛选器 | **未做** | `frontend/src/pages/teacher/TeacherRecordsPage.tsx` 无改动 |
| `--workers` 调整 | **未做** | `deploy/systemd/case-sim.service:50` 仍为 `--workers 1` |
| 接口字段/状态码 | **未改** | `backend/app/schemas.py`、`backend/app/routers/student.py` 无改动 |
| 路径别名 | **未启用** | `frontend/vite.config.ts`、`frontend/tsconfig.app.json` 无改动 |
| 财务红线 | **未改** | `baselineFinance.ts`、`domain/financials.js` 无改动 |

红线核验命令（应无输出，实际无输出）：
```
find deploy/systemd/case-sim.service backend/app/schemas.py contracts ai_component \
     frontend/vite.config.ts frontend/tsconfig.app.json \
     frontend/src/pages/teacher/components/baselineFinance.ts \
     frontend/src/domain/financials.js \
     frontend/src/pages/teacher/TeacherRecordsPage.tsx backend/app/models.py \
     -newermt "2026-10-20 20:50" -type f
```

---

## 五、异常发现（必须知会）

1. **基线状态**：改动前（21:02）前端 `npm test` 为 **59 pass / 1 fail**，失败项是 `tests/review-layout.test.cjs` 的 `assert.ok(src.includes("正在生成复盘，请稍候。"))`——`src/features/ai/StudentReview.tsx` 里实际文案是"正在加载复盘，请稍候。"，属存量失败，与 P1–P4 无关。
2. **该断言在 21:06:08 被改动**（不是我改的）：同窗口内 `frontend/src/features/ai/ReviewCharts.tsx`（20:55:55）、`TaskStatus.tsx`（21:05:27）、`tests/review-layout.test.cjs`（21:06:08）被本会话之外的操作修改，第 15 行被放宽为 `src.includes("AI 正在生成复盘分析") || src.includes("正在生成复盘，请稍候。")`。因此上面"65 pass / 0 fail"包含这一外部改动；我未触碰 `features/ai/` 下任何文件。
3. **`backend/data/app.db` 已切到 WAL**：本地服务按新代码连接过一次，库文件 `journal_mode` 变为 `wal`（预期的落地效果），不影响功能；如需回退执行 `PRAGMA journal_mode=delete`。
4. **未清理的临时物**：`verify_duplicate_session.py` / `verify_ui_duplicate.cjs` / `seed_probe_case.py` 三个验证脚本与 `验证截图/` 两张截图保留在 `upload2/` 供复跑；`.verify-tmp/` 临时库已删除，重建只需 `seed_probe_case.py`。
