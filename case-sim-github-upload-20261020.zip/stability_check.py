# -*- coding: utf-8 -*-
"""网站稳定性双跑检查：构建 -> 启动 -> 页面 -> 核心功能 -> 日志 -> 停止，共两轮。"""
import os, sys, json, time, signal, shutil, subprocess, threading, concurrent.futures
from pathlib import Path
import httpx

ROOT = Path(r"C:\Users\huang2006\Desktop\Work\upload2\case_sim-")
PY = str(ROOT / ".venv" / "Scripts" / "python.exe")
BASE = "http://127.0.0.1:8110"
CHROME = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
TEST_DB = ROOT / "backend" / "data" / "stability_check.db"
TEST_ART = ROOT / "backend" / "data" / ".stability_artifacts"
REPORT_JSON = ROOT.parent / "stability_result.json"

env = os.environ.copy()
env["PATH"] = r"C:\Program Files\nodejs;C:\Windows\System32;C:\Windows;" + env.get("PATH", "")
env["DATABASE_URL"] = "sqlite:///./backend/data/stability_check.db"
env["ARTIFACT_ROOT"] = str(TEST_ART)
env["PYTHONIOENCODING"] = "utf-8"
env["TEACHER_PASSWORD"] = "test123"

def log(*a):
    print(*a, flush=True)

def port_free():
    import socket
    s = socket.socket()
    s.settimeout(0.5)
    try:
        return s.connect_ex(("127.0.0.1", 8110)) != 0
    finally:
        s.close()

def pids_on_port(port=8110):
    try:
        out = subprocess.run(["netstat", "-ano"], capture_output=True, text=True, encoding="utf-8", errors="replace").stdout
    except Exception:
        return set()
    pids = set()
    for line in out.splitlines():
        parts = line.split()
        if len(parts) >= 5 and parts[0].upper().startswith("TCP") and f":{port}" in parts[1] and parts[3].upper() == "LISTENING":
            pids.add(parts[4])
    return pids

def kill_listeners(port=8110):
    for pid in pids_on_port(port):
        subprocess.run(["taskkill", "/F", "/PID", pid], capture_output=True)
    return pids_on_port(port)

def wait_port_free(timeout=60):
    t0 = time.time()
    while time.time() - t0 < timeout:
        if port_free() and not pids_on_port(8110):
            return True
        time.sleep(0.5)
    return False

def reset_state():
    for p in [TEST_DB, Path(str(TEST_DB) + "-wal"), Path(str(TEST_DB) + "-shm")]:
        if p.exists():
            p.unlink()
    if TEST_ART.exists():
        shutil.rmtree(TEST_ART, ignore_errors=True)

def frontend_digest():
    import hashlib
    h = hashlib.sha256()
    for base, dirs, files in os.walk(ROOT / "frontend"):
        dirs[:] = sorted(d for d in dirs if d not in {"node_modules", "dist", ".git"})
        for name in sorted(files):
            p = Path(base) / name
            if p.suffix == ".tsbuildinfo":
                continue
            h.update(p.relative_to(ROOT).as_posix().encode()); h.update(p.read_bytes())
    return h.hexdigest()

def build():
    t0 = time.time()
    npm = r"C:\Program Files\nodejs\npm.cmd"
    p = subprocess.run([npm, "run", "build"], cwd=ROOT / "frontend", env=env,
                       capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=1800)
    out = (p.stdout or "") + (p.stderr or "")
    dist = ROOT / "frontend" / "dist"
    assets = sorted(x.name for x in (dist / "assets").glob("*")) if (dist / "assets").exists() else []
    # 与 bootstrap.py 一致地写入构建戳，避免后续 local 启动误触发 npm ci
    try:
        (dist / "source.sha256").write_text(frontend_digest())
    except Exception:
        pass
    return {
        "rc": p.returncode,
        "seconds": round(time.time() - t0, 1),
        "built": "built in" in out,
        "modules": (lambda m: m.group(1) if m else None)(__import__("re").search(r"(\d+) modules transformed", out)),
        "dist_index": (dist / "index.html").exists(),
        "assets": assets,
        "tail": out[-1200:],
    }

def start_server(run_no):
    out_path = ROOT / "logs" / f"stability-run{run_no}.out.log"
    f = open(out_path, "w", encoding="utf-8", errors="replace")
    flags = subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_NO_WINDOW
    p = subprocess.Popen([PY, "scripts/bootstrap.py", "local"], cwd=ROOT, env=env,
                         stdout=f, stderr=subprocess.STDOUT, creationflags=flags)
    t0 = time.time()
    ready = False
    err = None
    while time.time() - t0 < 90:
        if p.poll() is not None:
            err = f"进程提前退出 rc={p.returncode}"
            break
        try:
            r = httpx.get(BASE + "/api/health", timeout=1.5)
            if r.status_code == 200:
                ready = True
                break
        except Exception:
            pass
        time.sleep(0.5)
    return {"proc": p, "ready": ready, "seconds": round(time.time() - t0, 1), "error": err,
            "out_log": str(out_path), "log_handle": f}

def stop_server(srv):
    p = srv["proc"]
    # bootstrap 会再 spawn 一个 run_server 子进程；在 Windows 上必须按进程树/端口清理
    try:
        p.send_signal(signal.CTRL_BREAK_EVENT)
    except Exception:
        pass
    try:
        p.wait(timeout=10)
    except Exception:
        subprocess.run(["taskkill", "/F", "/T", "/PID", str(p.pid)], capture_output=True)
        try:
            p.wait(timeout=10)
        except Exception:
            p.kill(); p.wait()
    kill_listeners(8110)
    try:
        srv["log_handle"].close()
    except Exception:
        pass
    return wait_port_free(60)

def hit(client, name, method, path, expect, **kw):
    t0 = time.perf_counter()
    try:
        r = client.request(method, path, **kw)
        body = r.text
        rec = {"name": name, "method": method, "path": path, "expect": expect, "status": r.status_code,
               "ms": round((time.perf_counter() - t0) * 1000, 1), "len": len(r.content)}
        rec["ok"] = (r.status_code == expect)
        rec["sample"] = body[:180].replace("\n", " ")
        return rec, r
    except Exception as e:
        return {"name": name, "method": method, "path": path, "expect": expect, "status": None,
                "ms": round((time.perf_counter() - t0) * 1000, 1), "len": 0, "ok": False,
                "sample": repr(e)}, None

def chrome_markers(path, markers):
    try:
        p = subprocess.run([CHROME, "--headless=new", "--disable-gpu", "--no-sandbox",
                            "--virtual-time-budget=6000", "--dump-dom", BASE + path],
                           capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=60)
        dom = p.stdout or ""
        found = {m: (m in dom) for m in markers}
        return {"path": path, "rc": p.returncode, "len": len(dom), "markers": found,
                "ok": p.returncode == 0 and all(found.values())}
    except Exception as e:
        return {"path": path, "rc": None, "len": 0, "markers": {}, "ok": False, "error": repr(e)}

def newest_runtime_log(since_ts):
    logs = sorted((ROOT / "logs").glob("runtime-*.log"), key=lambda x: x.stat().st_mtime, reverse=True)
    for f in logs:
        if f.stat().st_mtime >= since_ts - 5:
            return f
    return logs[0] if logs else None

def analyze_log(path):
    if not path or not path.exists():
        return {"path": None, "errors": 0, "warnings": 0, "tracebacks": 0, "http5xx": 0, "samples": []}
    text = path.read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()
    errs = [l for l in lines if (" ERROR " in l or " CRITICAL " in l)]
    warns = [l for l in lines if " WARNING " in l]
    tbs = [l for l in lines if "Traceback" in l]
    h5 = [l for l in lines if '"status": 5' in l]
    return {"path": str(path), "errors": len(errs), "warnings": len(warns),
            "tracebacks": len(tbs), "http5xx": len(h5),
            "samples": (errs + warns + tbs)[:5]}

def source_snapshot():
    import hashlib
    h = hashlib.sha256()
    targets = ["backend", "ai_component", "contracts", "frontend/src", "scripts",
               "frontend/vite.config.ts", "frontend/package.json"]
    for rel in targets:
        p = ROOT / rel
        if p.is_file():
            h.update(rel.encode()); h.update(p.read_bytes()); continue
        if not p.exists():
            continue
        for base, dirs, files in os.walk(p):
            dirs[:] = sorted(d for d in dirs if d not in {"__pycache__", "data", "static", "node_modules", "dist", ".pytest_cache"})
            for name in sorted(files):
                fp = Path(base) / name
                if fp.suffix in {".pyc", ".log"}:
                    continue
                h.update(fp.relative_to(ROOT).as_posix().encode()); h.update(fp.read_bytes())
    return h.hexdigest()

def run_once(run_no):
    log(f"\n===== RUN {run_no} =====")
    if not wait_port_free(20):
        log("      清理残留监听进程:", kill_listeners(8110))
        if not wait_port_free(20):
            raise SystemExit("8110 端口仍被占用，无法开始")
    snap0 = source_snapshot()
    log(f"      源码快照 {snap0[:12]}")
    reset_state()
    log("[1/5] 测试库已重置，开始构建（tsc -b + vite build）")
    b = build()
    log(f"      构建 rc={b['rc']} {b['seconds']}s modules={b['modules']} assets={len(b['assets'])}")
    if b["rc"] != 0:
        return {"run": run_no, "build": b, "start": {"ready": False, "error": "构建失败"}, "checks": [],
                "pages": [], "chrome": [], "log": {}, "stable": False}

    log("[2/5] 启动服务")
    srv = start_server(run_no)
    log(f"      启动 ready={srv['ready']} {srv['seconds']}s err={srv['error']}")
    started_at = time.time()
    checks, pages, chrome, concurrency = [], [], [], {}
    lg = {"path": None, "errors": 0, "warnings": 0, "tracebacks": 0, "http5xx": 0, "samples": []}
    try:
        if not srv["ready"]:
            return {"run": run_no, "build": b, "start": {k: v for k, v in srv.items() if k not in ("proc", "log_handle")},
                    "checks": [], "pages": [], "chrome": [], "log": {}, "stable": False}
        with httpx.Client(base_url=BASE, timeout=20, follow_redirects=False,
                          headers={"Connection": "close"}) as c:
            log("[3/5] 页面访问（每页重复 3 次）")
            for path in ["/", "/teacher/login", "/student", "/favicon.svg"]:
                statuses = []
                for _ in range(3):
                    rec, _r = hit(c, path, "GET", path, 200)
                    statuses.append(rec["status"])
                    if _ == 0:
                        pages.append(rec)
                    time.sleep(0.05)
                if len(set(statuses)) != 1:
                    pages[-1]["ok"] = False
                    pages[-1]["sample"] = f"重复3次状态不一致: {statuses}"
            # 静态资源
            html = c.get("/teacher/login").text
            import re as _re
            for a in _re.findall(r'/assets/[^"\']+', html):
                rec, _r = hit(c, a, "GET", a, 200)
                pages.append(rec)

            log("[4/5] 核心功能链路")
            rec, r = hit(c, "health", "GET", "/api/health", 200); checks.append(rec)
            rec, r = hit(c, "teacher_login_wrong", "POST", "/api/teacher/login",
                        401, json={"password": "wrong-password"}); checks.append(rec)
            rec, r = hit(c, "teacher_login_ok", "POST", "/api/teacher/login",
                         200, json={"password": "test123"}); checks.append(rec)
            ttok = r.json().get("teacher_token") if r is not None and r.status_code == 200 else None
            rec, r = hit(c, "teacher_students", "GET", "/api/teacher/students",
                         200, params={"token": ttok}); checks.append(rec)
            base_students = len(r.json()) if r is not None and r.status_code == 200 else None

            uname = f"stab_r{run_no}_u"
            rec, r = hit(c, "teacher_create_student", "POST", "/api/teacher/students",
                         200, params={"token": ttok},
                         json={"username": uname, "password": "Passw0rd!23", "real_name": f"稳定性测试{run_no}"})
            checks.append(rec)

            rec, r = hit(c, "student_login", "POST", "/api/student/login",
                         200, json={"username": uname, "password": "Passw0rd!23"}); checks.append(rec)
            stok = r.json().get("access_token") if r is not None and r.status_code == 200 else None
            hdr = {"Authorization": f"Bearer {stok}"} if stok else {}

            rec, r = hit(c, "student_me", "GET", "/api/student/me", 200, headers=hdr); checks.append(rec)
            rec, r = hit(c, "student_cases", "GET", "/api/student/cases", 200, headers=hdr); checks.append(rec)
            cases = r.json() if r is not None and r.status_code == 200 else []
            case_tok = cases[0]["student_token"] if cases else None
            case_count = len(cases)

            rec, r = hit(c, "play_open", "GET", f"/api/play/{case_tok}", 200, headers=hdr); checks.append(rec)
            play = r.json() if r is not None and r.status_code == 200 else {}
            nodes = play.get("nodes") or []
            node_count = len(nodes)
            first = nodes[0] if nodes else None

            rec, r = hit(c, "session_start", "POST", f"/api/play/{case_tok}/sessions", 200, headers=hdr,
                         json={"student_name": f"稳定性测试{run_no}"}); checks.append(rec)
            sess = r.json() if r is not None and r.status_code == 200 else {}
            sid = sess.get("session_id")

            decide_ok = False
            next_node = None
            if first and sid:
                body = {"student_name": f"稳定性测试{run_no}", "session_id": sid,
                        "node_id": first["id"], "option_key": first["options"][0]["key"],
                        "duration_ms": 1200}
                rec, r = hit(c, "decide_first", "POST", f"/api/play/{case_tok}/decide", 200,
                             headers=hdr, json=body); checks.append(rec)
                if r is not None and r.status_code == 200:
                    decide_ok = True
                    next_node = r.json().get("next_node_id")

            rec, r = hit(c, "session_state", "GET", f"/api/play/{case_tok}/sessions/{sid}", 200,
                         headers=hdr); checks.append(rec)
            turns = len(r.json().get("turns", [])) if r is not None and r.status_code == 200 else None

            rec, r = hit(c, "student_records", "GET", "/api/student/records", 200, headers=hdr)
            checks.append(rec)
            record_count = len(r.json()) if r is not None and r.status_code == 200 else None

            rec, r = hit(c, "student_logout", "POST", "/api/student/logout", 200, headers=hdr)
            checks.append(rec)
            rec, r = hit(c, "student_me_after_logout", "GET", "/api/student/me", 401, headers=hdr)
            checks.append(rec)

            log("[5/5] 并发健康检查（20 并发）")
            def one(_):
                try:
                    return httpx.get(BASE + "/api/health", timeout=5).status_code
                except Exception:
                    return None
            with concurrent.futures.ThreadPoolExecutor(max_workers=20) as ex:
                res = list(ex.map(one, range(20)))
            concurrency = {"total": len(res), "ok": sum(1 for x in res if x == 200),
                           "failed": [x for x in res if x != 200]}

        chrome = [chrome_markers("/teacher/login", ["访问密码", "教师登录"]),
                  chrome_markers("/student", ["登录个人空间"])]
        log("[*] 采集日志")
        lg = analyze_log(newest_runtime_log(started_at))
    finally:
        stopped = stop_server(srv)
    snap1 = source_snapshot()
    source_changed = snap0 != snap1
    all_ok = (b["rc"] == 0 and srv["ready"] and all(x["ok"] for x in checks)
              and all(x["ok"] for x in pages) and all(x["ok"] for x in chrome)
              and concurrency.get("ok") == concurrency.get("total") and lg["errors"] == 0 and lg["http5xx"] == 0
              and not source_changed)
    return {
        "run": run_no, "build": b,
        "start": {"ready": srv["ready"], "seconds": srv["seconds"], "error": srv["error"], "stopped": stopped},
        "source": {"before": snap0, "after": snap1, "changed_during_run": source_changed},
        "pages": pages, "checks": checks, "chrome": chrome, "concurrency": concurrency,
        "log": lg, "metrics": {"base_students": base_students, "case_count": case_count,
                               "node_count": node_count, "decide_ok": decide_ok, "next_node": next_node,
                               "turns": turns, "record_count": record_count},
        "stable": all_ok,
    }

def main():
    results = []
    snap_start = source_snapshot()
    log(f"测试开始源码快照: {snap_start}")
    for i in (1, 2):
        results.append(run_once(i))
    snap_end = source_snapshot()
    REPORT_JSON.write_text(json.dumps({"source_start": snap_start, "source_end": snap_end, "runs": results},
                                      ensure_ascii=False, indent=2), encoding="utf-8")
    log("\n===== 汇总 =====")
    log(f"源码整体快照: start={snap_start[:12]} end={snap_end[:12]} 全程未变={snap_start == snap_end}")
    for r in results:
        ck = {x["name"]: x["status"] for x in r.get("checks", [])}
        log(f"RUN{r['run']}: build_rc={r['build']['rc']} build_s={r['build']['seconds']} "
            f"start_ready={r['start'].get('ready')} start_s={r['start'].get('seconds')} "
            f"pages_ok={sum(1 for x in r.get('pages',[]) if x['ok'])}/{len(r.get('pages',[]))} "
            f"api_ok={sum(1 for x in r.get('checks',[]) if x['ok'])}/{len(r.get('checks',[]))} "
            f"errors={r['log'].get('errors')} 5xx={r['log'].get('http5xx')} stable={r['stable']}")
        log("   ", ck, r.get("metrics"))
    log("JSON ->", REPORT_JSON)

if __name__ == "__main__":
    main()
