import react from '@vitejs/plugin-react'
import { defineConfig, loadEnv } from 'vite'
import { fileURLToPath, URL } from 'node:url'

// 开发端口和后端代理端口通过 VITE_DEV_PORT / VITE_BACKEND_PORT 配置，
// 默认开发页面 5174，后端 8110，与 backend/.env.example 保持一致。
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '')
  const backendPort = env.VITE_BACKEND_PORT || '8110'
  const frontendPort = Number(env.VITE_DEV_PORT || '5174')

  return {
    plugins: [react()],
    resolve: {
      alias: {
        '@': fileURLToPath(new URL('./src', import.meta.url)),
        '@components': fileURLToPath(new URL('./src/components', import.meta.url)),
        '@features': fileURLToPath(new URL('./src/features', import.meta.url)),
        '@api': fileURLToPath(new URL('./src/api', import.meta.url)),
        '@pages': fileURLToPath(new URL('./src/pages', import.meta.url)),
        '@layouts': fileURLToPath(new URL('./src/layouts', import.meta.url)),
        '@domain': fileURLToPath(new URL('./src/domain', import.meta.url)),
      },
    },
    build: {
      // antd 单厂商包约 1 MB，属库本身体量；拆出后作为长期缓存块，调高阈值避免误报
      chunkSizeWarningLimit: 1100,
      rollupOptions: {
        output: {
          // 按厂商拆包，避免单文件超 500 kB 警告；antd 单独成包便于长期缓存
          manualChunks(id: string) {
            if (id.includes('node_modules/react') || id.includes('node_modules/react-dom') ||
                id.includes('node_modules/react-router')) {
              return 'react-vendor'
            }
            if (id.includes('node_modules/antd') && !id.includes('node_modules/@ant-design')) {
              return 'antd-vendor'
            }
            if (id.includes('node_modules/@ant-design')) {
              return 'antd-icons'
            }
            if (id.includes('node_modules/axios')) {
              return 'axios'
            }
          },
        },
      },
    },
    server: {
      host: true,
      port: frontendPort,
      proxy: {
        '/api': {
          target: `http://127.0.0.1:${backendPort}`,
          changeOrigin: false,
        },
        '/media': {
          target: `http://127.0.0.1:${backendPort}`,
          changeOrigin: false,
        },
      },
    },
  }
})
