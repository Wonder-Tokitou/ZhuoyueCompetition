﻿import ReviewEditor from '../../features/ai/ReviewEditor'
import { useEffect, useMemo, useState } from 'react'
import { Alert, Button, Card, Drawer, Input, Select, Space, Table, Tag, Typography } from 'antd'
import { getRecords, listCases } from '../../api/client'
import type { CaseListItem, StudentRecord } from '../../api/types'
import { useTeacherToken } from '../../context/TeacherTokenContext'
import { formatDuration, formatTime } from './teacherConstants'
import MetricComparison from '../../components/MetricComparison'
import { filterRecords, recordFinished, recordKey, summarizeRecords } from '../../domain/recordSummary'
import './teacher.css'

export default function TeacherRecordsPage() {
  const token = useTeacherToken()
  const [cases, setCases] = useState<CaseListItem[]>([]), [caseId, setCaseId] = useState<number | null>(null)
  const [records, setRecords] = useState<StudentRecord[]>([]), [error, setError] = useState('')
  const [loading, setLoading] = useState(false), [refresh, setRefresh] = useState(0)
  const [name, setName] = useState(''), [status, setStatus] = useState('all'), [version, setVersion] = useState('all')
  const [opened, setOpened] = useState<string | null>(null)
  useEffect(() => { let active = true; listCases(token).then(rows => { if (active) { setCases(rows); setCaseId(v => v ?? rows[0]?.id ?? null) } }).catch(e => { if (active) setError(e.message) }); return () => { active = false } }, [token])
  useEffect(() => {
    let active = true
    setRecords([]); setError('')
    if (caseId === null) return
    setLoading(true)
    getRecords(caseId, token).then(rows => { if (active) setRecords(rows) }).catch(e => { if (active) setError(e.message) }).finally(() => { if (active) setLoading(false) })
    return () => { active = false }
  }, [caseId, token, refresh])
  const filtered = useMemo(() => filterRecords(records, name, status, version), [records, name, status, version])
  const summary = summarizeRecords(filtered)
  const selected = records.find(r => recordKey(r) === opened)
  const versions = [...new Set(records.map(r => String(r.case_version ?? 'unknown')))]
  const reviewStatus = (r: StudentRecord) => r.review_status === 'succeeded' ? '已生成' : r.review_status === 'failed' ? '生成失败' : !r.review_status || r.review_status === 'not_started' ? '尚未生成' : '生成中'
  return <Space direction="vertical" size={20} style={{ width: '100%' }}>
    <div><Typography.Title level={3}>学生作答记录</Typography.Title><Typography.Text type="secondary">先找到需要关注的作答，再查看策略、理由与复盘。</Typography.Text></div>
    <Space wrap className="record-filters">
      <Select aria-label="选择案例" style={{ width: 280, maxWidth: '100%' }} value={caseId} options={cases.map(r => ({ value: r.id, label: r.title }))} onChange={id => { setOpened(null); setVersion('all'); setCaseId(id) }} />
      <Input.Search aria-label="搜索学生" placeholder="搜索学生姓名" allowClear value={name} onChange={e => setName(e.target.value)} style={{ width: 220 }} />
      <Select aria-label="完成状态" value={status} onChange={setStatus} style={{ width: 140 }} options={[{ value: 'all', label: '全部状态' }, { value: 'finished', label: '已完成' }, { value: 'unfinished', label: '未完成' }]} />
      <Select aria-label="案例版本" value={version} onChange={setVersion} style={{ width: 150 }} options={[{ value: 'all', label: '全部版本' }, ...versions.map(v => ({ value: v, label: v === 'unknown' ? '历史版本未知' : `版本 ${v}` }))]} />
      <Button onClick={() => setRefresh(v => v + 1)} loading={loading}>刷新记录</Button>
    </Space>
    {error && <Alert type="error" message={error} />}
    <div className="record-summary" aria-label="当前筛选统计">
      <Card size="small" title="参与人数">{summary.participants}</Card><Card size="small" title="完成人数">{summary.completed}</Card>
      {summary.rounds.map((count, i) => <Card size="small" key={i} title={`第 ${i + 1} 轮已提交`}>{count} 人</Card>)}
    </div>
    <Typography.Text type="secondary">统计仅覆盖当前筛选的已有记录，按学生账号去重；任一次完成即计入完成人数。历史匿名记录按姓名归并，不表示全班应到人数或在线状态。</Typography.Text>
    <Table<StudentRecord> rowKey={recordKey} dataSource={filtered} loading={loading} scroll={{ x: 720 }} pagination={{ pageSize: 10, showSizeChanger: false, hideOnSinglePage: true }} locale={{ emptyText: error ? '记录未加载，请重试' : '没有匹配的作答记录' }} columns={[
      { title: '学生', dataIndex: 'student_name', render: (text, r) => <><strong>{text}</strong><div>{r.student_id ? `账号 #${r.student_id}` : '历史匿名记录'}</div></> },
      { title: '推演次数', render: (_, r) => `第 ${r.attempt_no ?? 1} 次` },
      { title: '版本', render: (_, r) => r.case_version ?? '未记录' },
      { title: '进度', render: (_, r) => <Tag color={recordFinished(r) ? 'green' : 'default'}>{recordFinished(r) ? '已完成' : '未完成'} · {r.turns.length}/3</Tag> },
      { title: '复盘', render: (_, r) => reviewStatus(r) },
      { title: '操作', render: (_, r) => <Button onClick={() => setOpened(recordKey(r))}>查看作答</Button> },
    ]} />
    <Drawer title={selected ? `${selected.student_name} · 第 ${selected.attempt_no ?? 1} 次推演` : '作答详情'} width={720} open={opened !== null} onClose={() => setOpened(null)}>
      {selected ? <Space direction="vertical" size={16} style={{ width: '100%' }}>
        <Typography.Text>案例版本 {selected.case_version ?? '未记录'} · {reviewStatus(selected)}</Typography.Text>
        {selected.turns.map(t => <Card key={t.id} size="small" title={`第 ${t.idx} 轮`}><p><strong>已选策略：</strong>{t.chosen_label || '历史策略文字未记录'}</p><p>理由：{t.input_text || '未填写'}</p><p>{t.result_json.summary}</p><MetricComparison before={t.before_metrics} after={t.after_metrics ?? t.result_json.metrics} /><p>{formatTime(t.created_at)} · 作答耗时 {formatDuration(t.duration_ms)}</p></Card>)}
        <Typography.Title level={5}>AI 复盘 · {reviewStatus(selected)}</Typography.Title>
        {selected.review && <ReviewEditor key={`${selected.review_id}-${refresh}`} record={selected} token={token} onSaved={() => setRefresh(v => v + 1)} />}
      </Space> : <Typography.Text>{loading ? '正在更新记录…' : '该记录已不可用，请关闭后刷新列表。'}</Typography.Text>}
    </Drawer>
  </Space>
}
