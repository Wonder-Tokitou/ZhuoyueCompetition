import { useEffect, useState } from 'react'
import { Alert, Button, Card, Col, Form, Input, Modal, Row, Space, Statistic, Table, Tag, Typography } from 'antd'
import { api } from '../../api/client'
import { useTeacherToken } from '../../context/TeacherTokenContext'
import type { StudentAccount } from '../../context/StudentAccountContext'
import { OptionDistributionChart, RecentActivityChart } from './components/OptionDistributionChart'

export default function TeacherStudentsPage() {
  const token = useTeacherToken()
  const [rows, setRows] = useState<StudentAccount[]>([]), [error, setError] = useState('')
  const [editing, setEditing] = useState<StudentAccount | null>(null), [busy, setBusy] = useState(false)
  const [form] = Form.useForm(), [editForm] = Form.useForm()
  async function load() { try { setRows((await api.get('/teacher/students', { params: { token } })).data) } catch (e) { setError(e instanceof Error ? e.message : '加载失败') } }
  useEffect(() => { void load() }, [token])
  async function save(id: number, values: object) {
    await api.patch('/teacher/students/' + id, values, { params: { token } }); await load()
  }
  return <Space direction="vertical" style={{ width: '100%' }}>
    {error && <Alert type="error" message={error} closable onClose={() => setError('')} />}
    <Card title="班级仪表盘">
      <Typography.Text type="secondary">以下 KPI 与图表当前为占位数据（mock），用于验证布局与图表渲染；真实统计待后端补充聚合接口后接入。</Typography.Text>
      {/* KPI 卡片行：4 个 Statistic，窄屏自动换行（xs 单列 → sm 双列 → lg 四列） */}
      <Row gutter={[16, 16]} style={{ marginTop: 12 }}>
        <Col xs={24} sm={12} lg={6}>
          {/* TODO: 待后端补充聚合接口——已完成人数取自学生推演提交状态，当前 mock 12；总人数取真实学生列表 */}
          <Card size="small"><Statistic title="已完成人数 / 总人数" value={12} suffix={`/ ${rows.length}`} /></Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          {/* TODO: 待后端补充聚合接口——卡在节点 2 的学生人数，当前 mock 3 */}
          <Card size="small"><Statistic title="卡在节点 2 的人数" value={3} /></Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          {/* TODO: 待后端补充聚合接口——人均营收（万元），当前 mock 86 万 */}
          <Card size="small"><Statistic title="人均营收" value={86} suffix="万" /></Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          {/* TODO: 待后端补充聚合接口——平均推演时长（分钟），当前 mock 22 分钟 */}
          <Card size="small"><Statistic title="平均时长" value={22} suffix="分钟" /></Card>
        </Col>
      </Row>
      <Row gutter={[16, 16]} style={{ marginTop: 16 }}>
        <Col xs={24} lg={12}>
          {/* TODO: 待后端补充聚合接口——选项分布（A/B/C），当前 mock：A=30%、B=50%、C=20% */}
          <Card size="small" title="选项分布（最近一次推演）"><OptionDistributionChart /></Card>
        </Col>
        <Col xs={24} lg={12}>
          {/* TODO: 待后端补充聚合接口——最近活跃趋势（近 7 次推演人数），当前 mock：[12, 19, 15, 22, 28, 24, 30] */}
          <Card size="small" title="最近活跃趋势（近 7 次推演）"><RecentActivityChart /></Card>
        </Col>
      </Row>
    </Card>
    <Card title="学生账号（学生可自行注册，也可在此添加）">
      <Form form={form} layout="inline" onFinish={async (values) => { setBusy(true); setError(''); try { await api.post('/teacher/students', values, { params: { token } }); form.resetFields(); await load() } catch (e) { setError(e instanceof Error ? e.message : '创建失败') } finally { setBusy(false) } }}>
        <Form.Item name="username" label="账号" rules={[{ required: true, pattern: /^[A-Za-z0-9_.-]{1,64}$/, message: '使用英文、数字、点、短横线或下划线' }]}><Input autoComplete="off" /></Form.Item>
        <Form.Item name="real_name" label="真实姓名" rules={[{ required: true, whitespace: true, max: 64 }]}><Input /></Form.Item>
        <Form.Item name="password" label="初始密码" rules={[{ required: true, min: 8, max: 128 }]}><Input.Password autoComplete="new-password" /></Form.Item>
        <Button htmlType="submit" type="primary" loading={busy}>创建账号</Button>
      </Form>
      <p>将账号与初始密码单独发给学生。密码不在列表展示；停用或重置密码将撤销现有登录。</p>
    </Card>
    <Table rowKey="id" dataSource={rows} columns={[
      { title: '账号', dataIndex: 'username' }, { title: '真实姓名', dataIndex: 'real_name' },
      { title: '状态', render: (_, r) => <Tag color={r.status === 'active' ? 'green' : 'red'}>{r.status === 'active' ? '正常' : '已停用'}</Tag> },
      { title: '管理', render: (_, r) => <Space><Button onClick={() => { setEditing(r); editForm.setFieldsValue({ real_name: r.real_name, password: '' }) }}>修改 / 重置密码</Button><Button danger={r.status === 'active'} onClick={() => Modal.confirm({ title: `${r.status === 'active' ? '停用' : '启用'} ${r.real_name}？`, onOk: async () => { await save(r.id, { status: r.status === 'active' ? 'disabled' : 'active' }) } })}>{r.status === 'active' ? '停用' : '启用'}</Button></Space> },
    ]} />
    <Modal title={`管理 ${editing?.username || ''}`} open={!!editing} onCancel={() => setEditing(null)} onOk={() => editForm.submit()} confirmLoading={busy}>
      <Form form={editForm} layout="vertical" onFinish={async (values) => { if (!editing) return; setBusy(true); try { await save(editing.id, { real_name: values.real_name, ...(values.password ? { password: values.password } : {}) }); setEditing(null) } catch (e) { setError(e instanceof Error ? e.message : '保存失败') } finally { setBusy(false) } }}>
        <Form.Item name="real_name" label="真实姓名" rules={[{ required: true, whitespace: true, max: 64 }]}><Input /></Form.Item>
        <Form.Item name="password" label="重置密码（留空则不变）" rules={[{ min: 8, max: 128 }]}><Input.Password autoComplete="new-password" /></Form.Item>
      </Form>
    </Modal>
  </Space>
}
