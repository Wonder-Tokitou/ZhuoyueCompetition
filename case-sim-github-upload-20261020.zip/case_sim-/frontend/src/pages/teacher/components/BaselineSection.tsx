import type { Dispatch, SetStateAction } from 'react'
import { Alert, Button, Card, Input, InputNumber, Select, Space, Tag, Typography } from 'antd'
import { linkedBaseline } from './baselineFinance'
import { metricAnnotation } from './metricAnnotation'
import type { MetricsDraft } from '../hooks/useCalibrationState'
import { METRIC_FIELDS, CASH_FLOW_TEXTAREA_STYLE } from '../teacherConstants'
import { calculateNetProfit } from '../../../domain/financials.js'
import TaskStatus from '../../../features/ai/TaskStatus'
import type { AiTaskResponse, GetCaseResponse } from '../../../api/types'

const { TextArea } = Input

interface BaselineSectionProps {
  detail: GetCaseResponse
  title: string
  setTitle: (value: string) => void
  background: string
  setBackground: (value: string) => void
  dilemma: string
  setDilemma: (value: string) => void
  metrics: MetricsDraft
  setMetrics: Dispatch<SetStateAction<MetricsDraft>>
  operatingCost: number | null
  setOperatingCost: (value: number | null) => void
  operatingExpense: number | null
  setOperatingExpense: (value: number | null) => void
  netProfit: number | null
  setNetProfit: (value: number | null) => void
  revenueLink: 'margin' | 'cost'
  setRevenueLink: (value: 'margin' | 'cost') => void
  baselineDirty: boolean
  savingCase: boolean
  onSaveCase: () => void
  nodesCount: number
  generatingNodes: boolean
  nodeError: string
  setNodeError: (value: string) => void
  nodeProgressError: string
  setNodeProgressError: (value: string) => void
  nodeTask: AiTaskResponse | null
  onGenerateNodes: () => void
}

/** stage=1 财务基准与案例信息：受控表单 + 营收/毛利率/成本联动（100% 走 linkedBaseline） */
export default function BaselineSection({
  detail, title, setTitle, background, setBackground, dilemma, setDilemma,
  metrics, setMetrics, operatingCost, setOperatingCost, operatingExpense, setOperatingExpense,
  netProfit, setNetProfit, revenueLink, setRevenueLink, baselineDirty, savingCase, onSaveCase,
  nodesCount, generatingNodes, nodeError, setNodeError, nodeProgressError, setNodeProgressError,
  nodeTask, onGenerateNodes,
}: BaselineSectionProps) {
  return (
    <>
      <Card size="small" type="inner" title="案例信息与财务基准" extra={<Tag color={baselineDirty ? 'orange' : 'default'}>{baselineDirty ? '未保存' : '已载入 / 已保存'}</Tag>}>
        <Space direction="vertical" size={12} style={{ width: '100%' }}>
          <Input
            addonBefore="案例标题"
            value={title}
            maxLength={200}
            onChange={(event) => setTitle(event.target.value)}
          />
          <TextArea rows={3} value={background} onChange={(event) => setBackground(event.target.value)} placeholder="企业背景" />
          <TextArea rows={3} value={dilemma} onChange={(event) => setDilemma(event.target.value)} placeholder="核心经营困境" />
          <div className="metrics-grid">
            {METRIC_FIELDS.map((field) =>
              field.numeric ? (
                <InputNumber
                  key={field.key}
                  min={0}
                  step={0.1}
                  value={metrics.revenue}
                  placeholder={field.label}
                  addonBefore={field.label}
                  style={{ width: 240 }}
                  onChange={(value) => {
                    const revenue = value ?? null
                    const linked = linkedBaseline(revenue, metrics.gross_margin, operatingCost, revenueLink)
                    setMetrics((prev) => ({ ...prev, revenue, gross_margin: linked?.margin ?? prev.gross_margin }))
                    if (linked) setOperatingCost(linked.cost)
                    setNetProfit(calculateNetProfit(revenue, linked?.cost ?? operatingCost, operatingExpense))
                  }}
                />
              ) : field.key === 'cash_flow' ? (
                <TextArea key={field.key} rows={5} autoSize={{ minRows: 5, maxRows: 12 }} style={CASH_FLOW_TEXTAREA_STYLE}
                  value={String(metrics.cash_flow ?? '')} placeholder={field.label}
                  onChange={(event) => setMetrics((prev) => ({ ...prev, cash_flow: event.target.value }))} />
              ) : (
                <div key={field.key} style={{ width: 240 }}>
                  <Input
                    value={metricAnnotation(String(metrics[field.key] ?? '')).value}
                    placeholder={field.label}
                    addonBefore={field.label}
                    style={{ width: 240 }}
                    onChange={(event) => {
                      const note = metricAnnotation(String(metrics[field.key] ?? '')).note || metricAnnotation(String(detail.case.base_metrics?.[field.key] ?? '')).note
                      const value = event.target.value + (note ? ` ${note}` : '')
                      setMetrics((prev) => ({ ...prev, [field.key]: value }))
                      if (field.key === 'gross_margin') {
                        const linked = linkedBaseline(metrics.revenue, value, operatingCost, 'margin')
                        if (linked) { setOperatingCost(linked.cost); setNetProfit(calculateNetProfit(metrics.revenue, linked.cost, operatingExpense)) }
                      }
                    }}
                  />
                  <Typography.Text type="secondary" style={{ display: 'block', fontSize: 12, lineHeight: 1.5, marginTop: 4 }}>{(metricAnnotation(String(metrics[field.key] ?? '')).note || metricAnnotation(String(detail.case.base_metrics?.[field.key] ?? '')).note) && `注：${metricAnnotation(String(metrics[field.key] ?? '')).note || metricAnnotation(String(detail.case.base_metrics?.[field.key] ?? '')).note}`}</Typography.Text>
                </div>
              ),
            )}
            <InputNumber min={0} step={0.1} value={operatingCost} placeholder="营业成本（万元）" addonBefore="营业成本"
              style={{ width: 240 }} onChange={(value) => {
                setOperatingCost(value)
                const linked = linkedBaseline(metrics.revenue, metrics.gross_margin, value, 'cost')
                if (linked) setMetrics(prev => ({ ...prev, gross_margin: linked.margin }))
                setNetProfit(calculateNetProfit(metrics.revenue, value, operatingExpense))
              }} />
            <InputNumber min={0} step={0.1} value={operatingExpense} placeholder="运营费用（万元）" addonBefore="运营费用"
              style={{ width: 240 }} onChange={(value) => { setOperatingExpense(value); setNetProfit(calculateNetProfit(metrics.revenue, operatingCost, value)) }} />
            <InputNumber precision={2} value={netProfit} readOnly placeholder="净利润（万元）" addonBefore="净利润 · 自动计算" style={{ width: 260 }} />
          </div>
          <div className="node-actions">
            <Typography.Text type="secondary">
              修改营收时：<Select aria-label="营收联动方式" value={revenueLink} style={{ width: 180 }} options={[{ value: 'margin', label: '保持毛利率，计算成本' }, { value: 'cost', label: '保持成本，计算毛利率' }]} onChange={setRevenueLink} />。直接修改毛利率会计算成本；直接修改成本会反算毛利率。净利润同步计算。营收为零时无法反算毛利率。
            </Typography.Text>
            <Button type="primary" loading={savingCase} onClick={() => void onSaveCase()}>
              保存案例信息
            </Button>
          </div>
          <Typography.Paragraph type="secondary" style={{ margin: 0, fontSize: 12 }}>
            企业背景：{detail.case.background || '（空）'}
            <br />
            核心经营困境：{detail.case.dilemma || '（空）'}
            <br />
            这两项是学生端首屏题面。编辑后请保存；重新发布后用于新推演，已有推演保持原快照。
          </Typography.Paragraph>
        </Space>
      </Card>
      {nodeError && <Alert showIcon type="error" message="决策节点生成失败" description={nodeError} closable onClose={() => setNodeError('')} />}
      {nodeProgressError && <Alert showIcon type="warning" message={nodeProgressError} closable onClose={() => setNodeProgressError('')} />}
      {nodesCount === 0 && <Button type="primary" loading={generatingNodes} disabled={savingCase || operatingCost === null || operatingExpense === null || !detail.case.base_metrics} onClick={() => void onGenerateNodes()}>确认财务基准并生成决策节点</Button>}
      {nodeTask && <TaskStatus task={nodeTask} busy={generatingNodes} />}
    </>
  )
}
