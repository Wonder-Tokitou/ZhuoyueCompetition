/**
 * 班级仪表盘图表：选项分布柱状图（A/B/C）+ 最近活跃趋势折线图。
 * ECharts 按需引入：只注册用到的图表、组件与 Canvas 渲染器，禁止 `import * as echarts from 'echarts'` 全量引入。
 * 说明：未使用 echarts-for-react——其 3.0.6 ESM 入口为 `import * as echarts from 'echarts'`（全量），
 * 与按需引入约束冲突；此处改为自写轻量封装（init / setOption / resize / dispose）。
 * 数据来源：均为 mock 占位数据，仅供视觉验证；真实统计待后端补充聚合接口（见组件内 TODO 注释）。
 */
import { useEffect, useRef } from 'react'
import * as echarts from 'echarts/core'
import { BarChart, LineChart, RadarChart } from 'echarts/charts'
import { GridComponent, TooltipComponent, LegendComponent, TitleComponent } from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'
import type { EChartsOption } from 'echarts'

echarts.use([BarChart, LineChart, RadarChart, GridComponent, TooltipComponent, LegendComponent, TitleComponent, CanvasRenderer])

/** 柱条主色序列，与教师端主色 #1a3a5c 同一色系（深蓝 → 中蓝 → 浅蓝）。 */
const BARS = ['#1a3a5c', '#2f5f8f', '#6d96ba']

// TODO: 待后端补充聚合接口（如 GET /teacher/dashboard/option-distribution），以下为 mock 占位数据。
export const OPTION_DISTRIBUTION_MOCK = [
  { name: 'A', value: 30 },
  { name: 'B', value: 50 },
  { name: 'C', value: 20 },
]

// TODO: 待后端补充聚合接口（如 GET /teacher/dashboard/recent-activity），以下为 mock 占位数据。
export const RECENT_ACTIVITY_MOCK = [12, 19, 15, 22, 28, 24, 30]

/** 轻量 ECharts React 封装：挂载时 init，option 变化时 setOption，卸载时 dispose，窗口 resize 时自适应。 */
function EChart({ option, height }: { option: EChartsOption; height: number }) {
  const elRef = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const el = elRef.current
    if (!el) return
    const chart = echarts.init(el)
    chart.setOption(option)
    const onResize = () => chart.resize()
    window.addEventListener('resize', onResize)
    return () => {
      window.removeEventListener('resize', onResize)
      chart.dispose()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- 仅在挂载时 init 一次
  }, [])
  useEffect(() => {
    const el = elRef.current
    if (!el) return
    const chart = echarts.getInstanceByDom(el)
    if (chart) chart.setOption(option)
  }, [option])
  return <div ref={elRef} style={{ height, width: '100%' }} />
}

export interface OptionDistributionChartProps {
  data?: { name: string; value: number }[]
  height?: number
  maxWidth?: number | string
}

/** 选项分布柱状图（对应参考 HmcOptionsStats 的分布统计；option 参照 ECharts 官方 bar-simple 示例）。 */
export function OptionDistributionChart({ data = OPTION_DISTRIBUTION_MOCK, height = 240, maxWidth = '100%' }: OptionDistributionChartProps) {
  const option: EChartsOption = {
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    grid: { left: 8, right: 8, top: 8, bottom: 8, containLabel: true },
    xAxis: { type: 'category', data: data.map((d) => d.name), axisTick: { alignWithLabel: true } },
    yAxis: {
      type: 'value',
      max: 100,
      axisLabel: { formatter: '{value}%' },
      splitLine: { lineStyle: { color: '#eef2f6' } },
    },
    series: [
      {
        name: '选项占比',
        type: 'bar',
        barWidth: '50%',
        data: data.map((d, i) => ({ value: d.value, itemStyle: { color: BARS[i % BARS.length], borderRadius: [4, 4, 0, 0] } })),
      },
    ],
  }
  return (
    <div style={{ width: '100%', maxWidth }}>
      <EChart option={option} height={height} />
    </div>
  )
}

export interface RecentActivityChartProps {
  data?: number[]
  height?: number
  maxWidth?: number | string
}

/** 最近活跃趋势折线图（复用已注册的 LineChart，x 轴为近 7 次推演活动序号）。 */
export function RecentActivityChart({ data = RECENT_ACTIVITY_MOCK, height = 180, maxWidth = '100%' }: RecentActivityChartProps) {
  const option: EChartsOption = {
    tooltip: { trigger: 'axis' },
    grid: { left: 8, right: 8, top: 8, bottom: 8, containLabel: true },
    xAxis: { type: 'category', boundaryGap: false, data: data.map((_, i) => `第${i + 1}次`) },
    yAxis: { type: 'value', minInterval: 1, splitLine: { lineStyle: { color: '#eef2f6' } } },
    series: [
      {
        name: '活跃人数',
        type: 'line',
        smooth: true,
        symbol: 'circle',
        symbolSize: 6,
        data,
        lineStyle: { color: '#1a3a5c', width: 2 },
        itemStyle: { color: '#1a3a5c' },
        areaStyle: { color: 'rgba(26, 58, 92, 0.12)' },
      },
    ],
  }
  return (
    <div style={{ width: '100%', maxWidth }}>
      <EChart option={option} height={height} />
    </div>
  )
}

export default OptionDistributionChart
