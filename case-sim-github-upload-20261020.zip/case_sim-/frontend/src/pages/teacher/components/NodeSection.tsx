import type { ReactNode } from 'react'
import { Button, Card, Collapse, Input, InputNumber, Select, Space, Table, Tabs, Tag, Typography } from 'antd'
import type { TableColumnsType } from 'antd'
import ProgressivePanel from './ProgressivePanel'
import type { MetricsDraft, NodeDraft, OptionDraft } from '../hooks/useCalibrationState'
import { METRIC_FIELDS, RISK_META, RISK_OPTIONS } from '../teacherConstants'
import { calculateNetProfit } from '../../../domain/financials.js'
import type { GetCaseResponse, RiskLevel } from '../../../api/types'

const { TextArea } = Input

interface NodeSectionProps {
  token: string
  detail: GetCaseResponse
  nodes: NodeDraft[]
  dirtyNodes: NodeDraft[]
  activeNode: string | undefined
  setActiveNode: (key: string) => void
  savingCase: boolean
  savingNodeId: number | null
  prerequisitesDirty: boolean
  onDirtyChange: (dirty: boolean) => void
  onSaveNode: (node: NodeDraft) => void
  onSummariesSaved: (summaries: Record<string, string>) => void
  updateNode: (nodeId: number, patch: Partial<NodeDraft>) => void
  updateOption: (nodeId: number, optionKey: string, patch: Partial<OptionDraft>) => void
  updateOptionMetric: (nodeId: number, optionKey: string, field: keyof MetricsDraft, value: string | number | null) => void
}

function buildColumns(
  node: NodeDraft,
  renderImpact: (id: string) => ReactNode,
  updateOption: (nodeId: number, optionKey: string, patch: Partial<OptionDraft>) => void,
  updateOptionMetric: (nodeId: number, optionKey: string, field: keyof MetricsDraft, value: string | number | null) => void,
): TableColumnsType<OptionDraft> {
  return [
    {
      title: '选项键',
      dataIndex: 'key',
      width: '6%',
      render: (value: string) => <Tag>{value}</Tag>,
    },
    {
      title: '风险等级',
      dataIndex: 'risk_level',
      width: '10%',
      render: (_: RiskLevel, record: OptionDraft) => (
        <Select
          value={record.risk_level}
          options={RISK_OPTIONS}
          size="small"
          style={{ width: '100%', minWidth: 0 }}
          labelRender={() => (
            <Tag color={RISK_META[record.risk_level].color}>{record.risk_level}</Tag>
          )}
          onChange={(value: RiskLevel) => updateOption(node.id, record.key, { risk_level: value })}
        />
      ),
    },
    {
      title: '策略内容',
      dataIndex: 'label',
      width: '18%',
      render: (_: string, record: OptionDraft) => (
        <TextArea
          value={record.label}
          autoSize={{ minRows: 8, maxRows: 16 }}
          onChange={(event) => updateOption(node.id, record.key, { label: event.target.value })}
        />
      ),
    },
    {
      title: '结果摘要',
      dataIndex: 'summary',
      width: '18%',
      render: (_: string, record: OptionDraft) => (
        <TextArea
          value={record.summary}
          autoSize={{ minRows: 8, maxRows: 16 }}
          onChange={(event) => updateOption(node.id, record.key, { summary: event.target.value })}
        />
      ),
    },
    {
      title: '现金流说明',
      dataIndex: 'metrics',
      width: '18%',
      render: (_: MetricsDraft, record: OptionDraft) => (
        <div className="metrics-grid">
          {METRIC_FIELDS.filter(field => field.key === 'cash_flow').map((field) =>
            field.numeric ? (
              <InputNumber
                key={field.key}
                size="small"
                min={0}
                step={0.1}
                value={record.metrics.revenue}
                placeholder={field.label}
                addonBefore={field.label}
                onChange={(value) =>
                  updateOptionMetric(node.id, record.key, 'revenue', value ?? null)
                }
              />
            ) : field.key === 'cash_flow' ? (
              <TextArea key={field.key} aria-label="现金流说明" autoSize={{ minRows: 8, maxRows: 16 }} style={{ width: '100%', minWidth: 0 }}
                value={String(record.metrics.cash_flow ?? '')} placeholder={field.label}
                onChange={(event) => updateOptionMetric(node.id, record.key, field.key, event.target.value)} />
            ) : (
              <Input
                key={field.key}
                size="small"
                value={String(record.metrics[field.key] ?? '')}
                placeholder={field.label}
                addonBefore={field.label}
                onChange={(event) =>
                  updateOptionMetric(node.id, record.key, field.key, event.target.value)
                }
              />
            ),
          )}
        </div>
      ),
    },
    { title: '递进影响（每轮基于上一轮结果）', key: 'impact', width: '30%', render: (_: unknown, record: OptionDraft) => renderImpact(`${node.id}:${record.key}`) },
  ]
}

/** stage=2 节点与递进规则：Tabs + 6 列选项表 + 指标依据 Collapse，由 ProgressivePanel 注入递进影响列 */
export default function NodeSection({
  token, detail, nodes, dirtyNodes, activeNode, setActiveNode, savingCase, savingNodeId,
  prerequisitesDirty, onDirtyChange, onSaveNode, onSummariesSaved,
  updateNode, updateOption, updateOptionMetric,
}: NodeSectionProps) {
  if (nodes.length === 0) {
    return (
      <Typography.Text type="secondary">
        基准指标校准并确认后，系统才生成决策节点。请先完成基准数据、营业成本与运营费用，然后启动节点生成。
      </Typography.Text>
    )
  }
  return (
    <ProgressivePanel detail={detail} token={token} onDirtyChange={onDirtyChange} prerequisitesDirty={prerequisitesDirty} onSummariesSaved={onSummariesSaved}>
      {renderImpact => <Tabs
        key={detail.case.id}
        activeKey={activeNode ?? String(nodes[0]?.id)}
        onChange={setActiveNode}
        destroyInactiveTabPane={false}
        items={nodes.map((node) => ({
          key: String(node.id),
          label: (
            <Space size={8} wrap>
              <Tag color="blue">{node.node_role}</Tag>
              <Typography.Text strong>第 {node.idx} 个节点</Typography.Text>
              {dirtyNodes.some(n => n.id === node.id) && <Tag color="orange">未保存</Tag>}
            </Space>
          ),
          children: (
            <Space direction="vertical" size={12} style={{ width: '100%' }}>
              <Input
                addonBefore="节点标题"
                value={node.title}
                onChange={(event) => updateNode(node.id, { title: event.target.value })}
              />
              <TextArea
                rows={3}
                value={node.background}
                placeholder="节点背景说明（学生端在节点内展示）"
                onChange={(event) => updateNode(node.id, { background: event.target.value })}
              />
              <Table<OptionDraft>
                size="small"
                rowKey="key"
                columns={buildColumns(node, renderImpact, updateOption, updateOptionMetric)}
                dataSource={node.options}
                pagination={false}
                tableLayout="fixed"
                onRow={() => ({ style: { verticalAlign: 'top' } })}
                scroll={{ x: 1000 }}
              />
              <Collapse size="small" items={[{ key: 'basis', label: '指标计算 / 推测依据（教师核对）', children: <Space direction="vertical" style={{ width: '100%' }}>
                <Typography.Text type="secondary">营收、毛利率、市场份额、现金流：{node.options[0]?.financial_basis?.source || '由AI按案例素材和行业/传导规则提出，属于情境推测；非确定性财报事实。'}</Typography.Text>
                {node.options.map((option) => <Card key={option.key} size="small" title={`选项 ${option.key} · ${option.risk_level}`}>
                  {Object.values(option.financial_basis?.indicators || {}).map((indicator, i) => <Typography.Paragraph key={`${option.key}-${i}`} style={{ marginBottom: 4 }}>
                    <b>{indicator.label}：</b>{indicator.formula ? `${indicator.formula}；` : ''}{indicator.before !== undefined ? `基准 ${indicator.before} → ` : ''}{indicator.after ?? '未计算'}；{indicator.method}
                    {indicator.inputs && <>；输入 {JSON.stringify(indicator.inputs)}</>}
                  </Typography.Paragraph>)}
                  <Typography.Text type="secondary">净利润暂按教师校准的教学估算假设计算：营收 − 营业成本 − 运营费用 = {(option.calculated_net_profit ?? calculateNetProfit(Number(option.metrics.revenue || 0), Number(option.financial_assumptions?.operating_cost || 0), Number(option.financial_assumptions?.operating_expense || 0)))?.toFixed(2)} 万元。请核对输入假设是否符合案例材料。</Typography.Text>
                </Card>)}
              </Space> }]}/>
              <div className="node-actions">
                <Typography.Text type="secondary">
                  保存当前节点文案后，再保存递进规则并发布；已有推演保持原版本。
                </Typography.Text>
                <Button
                  type="primary"
                  loading={savingNodeId === node.id}
                  disabled={savingNodeId !== null || savingCase}
                  onClick={() => void onSaveNode(node)}
                >
                  保存节点
                </Button>
              </div>
            </Space>
          ),
        }))}
      />}
    </ProgressivePanel>
  )
}
