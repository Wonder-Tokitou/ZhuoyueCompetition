import { useLocation, useNavigate } from 'react-router-dom'
import { useStudentToken } from '../../context/StudentTokenContext'
import StudentReview from '../../features/ai/StudentReview'
import { useEffect, useRef, useState } from 'react'
import { Alert } from 'antd'
import { resetStudentSubmission } from '../../api/client'

export default function StudentReviewPage() {
  const token = useStudentToken()
  const location = useLocation()
  const navigate = useNavigate()
  const sessionId = Number(new URLSearchParams(location.search).get('session') || sessionStorage.getItem(`student_session:${token}`))
  const [busy, setBusy] = useState(false), [error, setError] = useState('')
  const scope = useRef({ active: true, busy: false })
  useEffect(() => { const current = { active: true, busy: false }; scope.current = current; setBusy(false); setError(''); return () => { current.active = false } }, [token, sessionId])
  async function restart() {
    const current = scope.current
    if (current.busy || !sessionId) return
    current.busy = true; setBusy(true); setError('')
    try {
      const saved = await resetStudentSubmission(token, sessionId)
      if (!current.active) return
      sessionStorage.setItem(`student_session:${token}`, String(saved.session_id))
      window.dispatchEvent(new Event('student-session-updated'))
      navigate(`/student/${token}`)
    } catch {
      if (current.active) setError('无法确认覆盖结果，请返回推演核对服务器进度后再操作，不要连续重复覆盖。')
      // Lock retries after an uncertain reset; viewing the session reconciles its state.
    } finally { if (current.active) setBusy(false) }
  }
  return <>{error && <Alert type="warning" message={error} />}<StudentReview key={token + ':' + sessionId} token={token} sid={sessionId} restarting={busy || !!error}
    onBack={() => navigate(`/student/${token}`)} onRestart={restart} /></>
}
