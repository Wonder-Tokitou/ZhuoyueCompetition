import { useEffect, useRef, useState } from 'react'
import { Alert, Button, Card, Input, Popconfirm, Space, Spin, Steps, Typography } from 'antd'
import MetricComparison from '../../components/MetricComparison'
import { useNavigate } from 'react-router-dom'
import { decide, playGet, restoreStudent, rollbackStudentSubmission, startStudent } from '../../api/client'
import type { Metrics, OptionDetail, PlayResponse, RiskLevel, SessionState } from '../../api/types'
import { useStudentToken } from '../../context/StudentTokenContext'
import { useStudentAccount } from '../../context/StudentAccountContext'

/** 风险等级 → 边框/填充色：保守绿、稳健黄、激进红（任务指定色值）。 */
const RISK_META: Record<RiskLevel, { border: string; fill: string }> = {
  保守: { border: '#16a34a', fill: '#16a34a' },
  稳健: { border: '#ca8a04', fill: '#ca8a04' },
  激进: { border: '#dc2626', fill: '#dc2626' },
}
/** 无 risk_level 数据时的中性占位（学生端 OptionBrief 不含风险字段，防剧透）。 */
const RISK_PLACEHOLDER = { border: '#d1d5db', fill: '#1a3a5c' }

/** 同账号在另一设备/标签页已开始过本案例：后端返回 409 + detail.code=submission_exists。 */
const SUBMISSION_EXISTS = '已有本案例推演记录，请从「我的记录」继续'

function isSubmissionExists(error: unknown): boolean {
  const failure = error as { status?: number; code?: string } | null
  return failure?.status === 409 && failure?.code === 'submission_exists'
}

/** 趋势箭头：增=绿（#16a34a）、降=红（#dc2626）；无对比基准时返回 null 不显示。 */
function TrendArrow({ dir }: { dir: 'up' | 'down' }) {
  return <span className="metric-trend" style={{ color: dir === 'up' ? '#16a34a' : '#dc2626' }} aria-label={dir === 'up' ? '较上轮上升' : '较上轮下降'}>{dir === 'up' ? '↑' : '↓'}</span>
}

/** 2×2 财务指标卡：营收大数字、毛利率/份额百分比+趋势箭头、现金流文字；net_profit 额外一行。 */
export function MetricsBar({ metrics, before }: { metrics: (Metrics & { net_profit?: number; cash_flow_amount?: number }) | null; before?: (Metrics & { net_profit?: number }) | null }) {
  if (!metrics) return null
  const trend = (current: string | undefined, previous: string | undefined): 'up' | 'down' | null => {
    if (current === undefined || previous === undefined) return null
    const c = parseFloat(current), p = parseFloat(previous)
    if (Number.isNaN(c) || Number.isNaN(p) || c === p) return null
    return c > p ? 'up' : 'down'
  }
  const marginTrend = trend(metrics.gross_margin, before?.gross_margin)
  const shareTrend = trend(metrics.market_share, before?.market_share)
  return <div className="student-metrics">
    <div className="metric-card metric-revenue"><span className="metric-label">营收</span><span className="metric-value">{metrics.revenue} 万元</span></div>
    <div className="metric-card"><span className="metric-label">毛利率</span><span className="metric-value">{metrics.gross_margin}{marginTrend && <TrendArrow dir={marginTrend} />}</span></div>
    <div className="metric-card"><span className="metric-label">市场份额</span><span className="metric-value">{metrics.market_share}{shareTrend && <TrendArrow dir={shareTrend} />}</span></div>
    <div className="metric-card"><span className="metric-label">现金流</span><span className="metric-value">{metrics.cash_flow}</span>{typeof metrics.cash_flow_amount === 'number' && <span className="metric-note">本期现金净流量 {metrics.cash_flow_amount.toFixed(2)} 万元</span>}</div>
    {typeof metrics.net_profit === 'number' && <div className="metric-card"><span className="metric-label">净利润 </span><span className="metric-value">{metrics.net_profit.toFixed(2)} 万元</span></div>}
  </div>
}

export default function StudentPlayPage() {
  const token = useStudentToken(), navigate = useNavigate()
  const account = useStudentAccount()
  const [data, setData] = useState<PlayResponse | null>(null)
  const [state, setState] = useState<SessionState | null>(null)
  const [name, setName] = useState(account.real_name)
  const [reason, setReason] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const [loading, setLoading] = useState(true)
  const [at, setAt] = useState(Date.now())
  const [loadedToken, setLoadedToken] = useState('')
  const [selected, setSelected] = useState<string | null>(null)
  const [showResult, setShowResult] = useState(false)
  const [uncertain, setUncertain] = useState(false)
  // 跨设备/跨标签页重复开始时为 true：页面提示已有记录，并给出"我的记录"入口。
  const [duplicate, setDuplicate] = useState(false)
  const page = useRef({ token, active: false, busy: false, nodeId: null as number | null, uncertain: false })
  const node = data?.nodes.find((n) => n.id === state?.next_node_id)
  const last = state?.turns.at(-1)

  useEffect(() => {
    let cancelled = false
    const current = { token, active: true, busy: false, nodeId: null as number | null, uncertain: false }
    page.current = current
    setLoading(true); setError(''); setState(null); setData(null)
    setReason(''); setBusy(false); setName(account.real_name)
    setSelected(null); setShowResult(false); setUncertain(false); setDuplicate(false)
    async function load() {
      try {
        const session = Number(sessionStorage.getItem('student_session:' + token))
        if (session) {
          const saved = await restoreStudent(token, session)
          if (!cancelled) { setState(saved); setData(saved.play); setName(saved.student_name); current.nodeId = saved.next_node_id }
        } else {
          const play = await playGet(token)
          if (!cancelled) setData(play)
        }
      } catch (e) { if (!cancelled) setError(e instanceof Error ? e.message : '案例暂不可用') }
      finally { if (!cancelled) { setLoadedToken(token); setLoading(false); setAt(Date.now()) } }
    }
    void load()
    return () => { cancelled = true; current.active = false }
  }, [token])

  async function begin() {
    const current = page.current
    if (!name.trim() || !current.active || current.token !== token || current.busy) return
    current.busy = true
    setBusy(true); setError(''); setDuplicate(false)
    try {
      const next = await startStudent(token, name.trim())
      if (!current.active) return
      setState(next); setData(next.play); setAt(Date.now())
      current.nodeId = next.next_node_id
      sessionStorage.setItem('student_session:' + token, String(next.session_id))
      sessionStorage.setItem('student_name:' + token, next.student_name)
      window.dispatchEvent(new Event('student-session-updated'))
    } catch (e) {
      if (!current.active) return
      // 换设备/新标签页时本地 sessionStorage 里没有 session_id，只能重新建会话；
      // 该学生已有本案例记录 → 409 submission_exists，此时要引导回"我的记录"恢复进度，
      // 而不是显示"参数不符合要求"这类误导文案。
      if (isSubmissionExists(e)) { setDuplicate(true); setError(SUBMISSION_EXISTS); return }
      setError(e instanceof Error ? e.message : '开始失败')
    } finally { current.busy = false; if (current.active) setBusy(false) }
  }

  function acceptSaved(saved: SessionState, submittedNode: number, key: string) {
    const accepted = saved.turns.find(turn => turn.node_id === submittedNode)
    setState(saved); setData(saved.play)
    page.current.nodeId = saved.next_node_id
    page.current.uncertain = false; setUncertain(false)
    if (accepted) {
      setSelected(null); setReason(''); setShowResult(true)
      setError(accepted.chosen_option === key ? '' : '此回合已由另一页面提交，下面显示服务器实际保存的策略，请核对。')
      window.dispatchEvent(new Event('student-session-updated'))
    } else {
      setError('本回合尚未保存，请核对所选策略后重新确认提交。')
    }
  }

  async function reconcile() {
    const current = page.current
    if (!state || !node || !selected || current.busy || !current.active || current.token !== token) return
    current.busy = true; setBusy(true)
    try {
      const saved = await restoreStudent(token, state.session_id)
      if (current.active) acceptSaved(saved, node.id, selected)
    } catch { if (current.active) setError('仍无法核对服务器进度，请稍后重试；不会重复提交或自动选择其他策略。') }
    finally { current.busy = false; if (current.active) setBusy(false) }
  }

  async function submit() {
    const current = page.current
    if (!node || !state || !selected || !node.options.some(o => o.key === selected) || showResult ||
        !current.active || current.token !== token || current.busy || current.uncertain || current.nodeId !== node.id) return
    const key = selected
    current.busy = true
    setBusy(true); setError('')
    try {
      await decide(token, { student_name: state.student_name, session_id: state.session_id,
        node_id: node.id, option_key: key, input_text: reason.trim() || undefined,
        duration_ms: Math.max(0, Date.now() - at) })
      if (!current.active) return
      const saved = await restoreStudent(token, state.session_id)
      if (!current.active) return
      acceptSaved(saved, node.id, key)
    } catch {
      if (!current.active) return
      // A lost response does not prove that the POST failed. Reconcile first;
      // never blindly retry a decision which may already have been committed.
      try {
        const saved = await restoreStudent(token, state.session_id)
        if (current.active) acceptSaved(saved, node.id, key)
      } catch {
        if (current.active) {
          current.uncertain = true; setUncertain(true)
          setError('提交状态待确认，请点击“核对已保存进度”。核对前不会再次提交，以免重复作答。')
        }
      }
    }
    finally { current.busy = false; if (current.active) setBusy(false) }
  }

  if (loading || loadedToken !== token) return <Spin />
  const selectedIndex = node?.options.findIndex(o => o.key === selected) ?? -1
  const selectedOption = node?.options[selectedIndex]
  const lastNode = data?.nodes.find(n => n.id === last?.node_id)
  const lastIndex = lastNode?.options.findIndex(o => o.key === last?.chosen_option) ?? -1
  const lastLabel = last?.chosen_label || lastNode?.options[lastIndex]?.label || '历史策略内容不可用'
  const lastDisplay = last?.display_option || (lastIndex >= 0 ? String.fromCharCode(65 + lastIndex) : '')
  const beforeLast = state && state.turns.length > 1 ? state.turns[state.turns.length - 2].after_metrics : data?.base_metrics
  const roundNodes = [...(data?.nodes ?? [])].sort((a, b) => a.idx - b.idx)
  const roundSteps = [1, 2, 3].map((i) => ({ title: `第 ${i} 轮：${roundNodes.find((n) => n.idx === i)?.title ?? '…'}` }))
  async function rollback(nodeId: number, idx: number) {
    const current = page.current
    if (!state || current.busy || current.uncertain || !current.active) return
    current.busy = true; setBusy(true)
    try {
      const updated = await rollbackStudentSubmission(token, state.session_id, data?.nodes.find(n => n.id === nodeId)?.idx || idx)
      if (!current.active) return
      setState(updated); setData(updated.play); setSelected(null); setReason(''); setShowResult(false); setError('已回退到该决策点，后续节点记录和旧复盘已移除，可以重新选择。')
      current.nodeId = updated.next_node_id; setAt(Date.now())
      window.dispatchEvent(new Event('student-session-updated'))
    } catch {
      if (!current.active) return
      // A lost reset response may already have changed the server: restore before allowing another action.
      try {
        const saved = await restoreStudent(token, state.session_id)
        if (!current.active) return
        setState(saved); setData(saved.play); current.nodeId = saved.next_node_id
        setSelected(null); setReason(''); setShowResult(false); setError('已核对服务器进度，请检查当前回合后继续。')
        window.dispatchEvent(new Event('student-session-updated'))
      } catch { if (current.active) { setError('暂时无法确认回退结果，请重新载入案例以核对进度。'); setData(null) } }
    } finally { current.busy = false; if (current.active) setBusy(false) }
  }
  return <Space direction="vertical" size={16} style={{ width: '100%' }}>
    {error && <Alert type="warning" showIcon message={error} />}
    {!data && <Button block onClick={() => { sessionStorage.removeItem('student_session:' + token); window.location.reload() }}>重新载入案例</Button>}
    {data && <Card title={data.case_title} size="small">
      <details open={!state}><summary>案例资料与经营困境</summary><Typography.Paragraph>{data.background}</Typography.Paragraph><Typography.Paragraph>{data.dilemma}</Typography.Paragraph></details>
      {state && <><Typography.Text strong>{state.finished ? '三轮推演已完成' : `第 ${node?.idx ?? state.turns.length + 1} / 3 轮`} · 已提交 {state.turns.length} 轮</Typography.Text>
        <Steps size="small" current={Math.min(state.turns.length, 3)} items={roundSteps} aria-label="推演进度" /></>}
      <MetricsBar metrics={state?.current_metrics || data.base_metrics} before={beforeLast} />
      {state?.financial_state && <p>净利润 {state.financial_state.net_profit.toFixed(2)} 万元 · 本期现金净流量 {state.financial_state.cash_flow_amount.toFixed(2)} 万元（按前轮结果递进计算）</p>}
      {state && <Typography.Text type="secondary">教师版本 {state.case_version} · 已提交进度已保存，刷新可继续；未提交的理由与选择仅保留在本页。</Typography.Text>}
    </Card>}
    {data && !state && <Card title="开始推演" size="small">
      <Typography.Paragraph>实名作答：{account.real_name}</Typography.Paragraph>
      <Button block type="primary" loading={busy} disabled={!name.trim()} onClick={() => void begin()}>开始推演</Button>
      {duplicate && <Button block style={{ marginTop: 12 }} onClick={() => navigate('/student/records')}>前往「我的记录」继续</Button>}
    </Card>}
    {last && (showResult || state?.finished) && <Alert type="success" message="本轮结果" description={<><p>你提交的策略 {lastDisplay}：{lastLabel}</p><p>{last.summary}</p><MetricComparison before={beforeLast} after={last.after_metrics} /><p>现金净流量是本期流入与流出的差额，不是账户余额；负值绝对值扩大代表净流出扩大。</p><p>班级均值（TODO: 待后端聚合接口）：营收 150 万元 · 毛利率 58% · 市场份额 18%</p><p>标杆路径（TODO: 待后端聚合接口）：第 1 轮稳健扩张 → 第 2 轮收缩成本 → 第 3 轮聚焦现金流</p></>} />}
    {state && state.turns.length > 0 && <details className="decision-history"><summary>查看此前决策（{state.turns.length} 轮）与修改入口</summary>{state.turns.map((turn, index) => <Card key={`history-${turn.node_id}`} size="small" title={`此前决策 ${index + 1}：${data?.nodes.find(n => n.id === turn.node_id)?.title || ''}`}>
      <Typography.Paragraph>{data?.nodes.find(n => n.id === turn.node_id)?.background}</Typography.Paragraph>
      <Typography.Paragraph>已选 {turn.display_option || ''}：{turn.chosen_label || turn.chosen_option}</Typography.Paragraph>
      <Typography.Paragraph>决策理由：{turn.input_text || '未填写'}</Typography.Paragraph>
      <Typography.Paragraph>{turn.summary}</Typography.Paragraph>
      <MetricComparison before={index ? state.turns[index - 1].after_metrics : data?.base_metrics} after={turn.after_metrics} />
      {data && <Popconfirm title={`回退到第 ${index + 1} 轮？`} description="此轮及后续作答、旧复盘将被清除，教师端记录同步改变，无法撤销。" okText="确认回退" cancelText="保留记录" onConfirm={() => rollback(turn.node_id, index + 1)}><Button disabled={busy || uncertain}>修改此决策及后续节点</Button></Popconfirm>}
    </Card>)}</details>}
    {showResult && node && <Button block type="primary" onClick={() => { setShowResult(false); setSelected(null); setAt(Date.now()) }}>继续下一回合</Button>}
    {node && !showResult && <Card size="small" title={'第 ' + node.idx + ' 回合 · ' + node.node_role}>
      <Typography.Title level={4}>{node.title}</Typography.Title>
      <Typography.Paragraph>{node.background}</Typography.Paragraph>
      <Space direction="vertical" style={{ width: '100%', marginTop: 12 }}>
        {node.options.map((o, index) => {
          // TODO: 待后端在 S1 选项接口下发 risk_level / description（当前 OptionBrief 仅 key+label，防剧透）。
          // 下发后 RISK_META 映射自动生效：保守绿/稳健黄/激进红边框，选中填充对应色。
          const risk = (o as Partial<OptionDetail>).risk_level
          const meta = risk ? RISK_META[risk] : RISK_PLACEHOLDER
          const letter = String.fromCharCode(65 + index)
          const isSelected = selected === o.key
          return <div key={`${node.id}:${o.key}`} className="strategy-option-card" style={{ borderColor: meta.border, ...(isSelected ? { background: meta.fill, borderColor: meta.fill } : {}) }}>
            <Button className="strategy-option" block
              type={isSelected ? 'primary' : 'default'} aria-pressed={isSelected}
              disabled={busy || uncertain} style={isSelected ? { background: meta.fill, borderColor: meta.fill, color: '#fff' } : {}}
              onClick={() => {
                if (!page.current.busy && !page.current.uncertain && page.current.nodeId === node.id) setSelected(o.key)
              }}>
              <span className="strategy-letter">{letter}</span>
              <span className="strategy-body">
                <span className="strategy-name">{o.label}</span>
                <span className="strategy-desc">策略详情待后端下发（TODO）</span>
                <span className="strategy-risk" style={isSelected ? { color: '#fff' } : { color: meta.border }}>{risk ?? '风险待评估'}{isSelected ? '（已选择）' : ''}</span>
              </span>
            </Button>
          </div>
        })}
      </Space>
      <label htmlFor="decision-reason" className="decision-reason-label">我的理由（选填）</label>
      <Input.TextArea id="decision-reason" rows={3} maxLength={4000} showCount disabled={busy || uncertain} value={reason} onChange={(e) => setReason(e.target.value)} placeholder="至少 20 字：这项策略如何回应当前经营问题？未提交内容仅保留在本页。" />
      <div className="decision-submit">
      {selectedOption && <Typography.Paragraph role="status" style={{ marginTop: 12 }}>
        {busy ? '正在保存' : '已选择'} {String.fromCharCode(65 + selectedIndex)}：{selectedOption.label}
      </Typography.Paragraph>}
      {uncertain ? <Button block loading={busy} onClick={() => void reconcile()}>核对已保存进度</Button> :
        <Button block type="primary" loading={busy} disabled={!selectedOption || busy} onClick={() => void submit()}>确认提交本回合</Button>}
      </div>
      <Typography.Paragraph type="secondary">先选择一项，再确认提交；提交前可以修改选择。A/B/C 仅为本次展示顺序，记录以策略内容为准。</Typography.Paragraph>
      <Typography.Paragraph type="secondary" style={{ marginTop: 12 }}>策略及结果来自教师确认版本；本阶段不调用 AI。</Typography.Paragraph>
    </Card>}
    {state?.finished && <Button type="primary" block onClick={() => navigate('/student/' + token + '/review?session=' + state.session_id)}>推演完成 · 查看 AI 复盘</Button>}
  </Space>
}
