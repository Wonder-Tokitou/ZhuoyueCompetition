import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { createBrowserRouter, RouterProvider, useLocation } from 'react-router-dom'
import { App as AntdApp, ConfigProvider } from 'antd'
import zhCN from 'antd/locale/zh_CN'
import 'antd/dist/reset.css'
import './index.css'
import App from './App'
import FeedbackBridge from './components/FeedbackBridge'

/**
 * 按路由段切换 antd 主色：
 *   /teacher/* → 深蓝 #1a3a5c（教师端桌面优先）
 *   /student/* → 品红 #db2777（学生端移动优先）
 *   其他路径不覆盖，走 antd 默认主色。
 * 暗色模式不在这里切换，保持 D2 默认否。
 */
function ThemedApp() {
  const { pathname } = useLocation()
  const colorPrimary = pathname.startsWith('/teacher')
    ? '#1a3a5c'
    : pathname.startsWith('/student')
      ? '#db2777'
      : undefined

  return (
    <ConfigProvider
      locale={zhCN}
      theme={colorPrimary ? { token: { colorPrimary } } : undefined}
    >
      <AntdApp>
        {/* 把 antd 的 message 实例注册给 axios 拦截器，保证请求失败一定有中文提示 */}
        <FeedbackBridge />
        <App />
      </AntdApp>
    </ConfigProvider>
  )
}

const router = createBrowserRouter([{ path: '*', element: <ThemedApp /> }])

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <RouterProvider router={router} />
  </StrictMode>,
)
