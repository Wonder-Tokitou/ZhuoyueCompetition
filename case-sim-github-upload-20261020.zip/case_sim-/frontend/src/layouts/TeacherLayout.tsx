import { AppstoreOutlined, LogoutOutlined, ProfileOutlined } from '@ant-design/icons'
import { Alert, Button, Layout, Menu, Modal } from 'antd'
import type { MenuProps } from 'antd'
import { Outlet, useBlocker, useLocation, useNavigate, useParams } from 'react-router-dom'
import { logoutTeacher } from '../api/client'
import { useIsNarrow } from '../hooks/useIsNarrow'
import './TeacherLayout.css'
import { useEffect, useRef, useState } from 'react'
import { TeacherDraftContext } from '../context/TeacherDraftContext'

const { Sider, Content } = Layout

const MENU_ITEMS: MenuProps['items'] = [
  { key: 'workbench', icon: <AppstoreOutlined />, label: '工作台' },
  { key: 'records', icon: <ProfileOutlined />, label: '案例记录' },
  { key: 'students', icon: <ProfileOutlined />, label: '学生管理' },
]

/**
 * 老师端布局（桌面优先）：左侧固定 Menu + 右侧内容区，内容区最小宽度 1000px。
 * 窄于 768px 时顶部出提示条，侧边栏收成图标条，保证记录页在手机上仍可操作。
 */
export default function TeacherLayout() {
  const [hasDraft, setHasDraft] = useState(false)
  const loggingOut = useRef(false)
  const blocker = useBlocker(({ currentLocation, nextLocation }) => hasDraft && !loggingOut.current && currentLocation.pathname !== nextLocation.pathname)
  useEffect(() => {
    if (blocker.state !== 'blocked') return
    const confirmation = Modal.confirm({ title: '离开未保存的编辑？', content: '未保存的草稿将丢失。已受理的后台任务仍会继续。', okText: '放弃编辑并离开', cancelText: '继续编辑', onOk: () => blocker.proceed(), onCancel: () => blocker.reset() })
    return () => confirmation.destroy()
  }, [blocker])
  const mayLeave = () => !hasDraft || window.confirm('还有未保存的编辑或正在执行的操作。离开会丢弃本页未保存内容，是否离开？')
  const isNarrow = useIsNarrow(768)
  const { teacherToken = '' } = useParams<{ teacherToken: string }>()
  const navigate = useNavigate()
  const { pathname } = useLocation()

  const basePath = `/teacher/${teacherToken}`
  const activeKey = pathname.replace(/\/+$/, '').endsWith('/students') ? 'students' : pathname.replace(/\/+$/, '').endsWith('/records') ? 'records' : 'workbench'

  const onMenuClick: MenuProps['onClick'] = ({ key }) => {
    navigate(key === 'workbench' ? basePath : `${basePath}/${key}`)
  }

  /** 退出：先请服务端吊销令牌，再清本地副本；网络失败也要完成本地登出。 */
  async function handleLogout() {
    if (!mayLeave()) return
    loggingOut.current = true
    const token = sessionStorage.getItem('teacher_token') || teacherToken
    try {
      if (token) await logoutTeacher(token)
    } catch { /* 服务端不可达时仍允许本地登出 */ }
    finally {
      sessionStorage.removeItem('teacher_token')
      sessionStorage.removeItem('teacher_selected_case')
      navigate('/teacher/login', { replace: true })
    }
  }

  return (
    <Layout className="teacher-shell" hasSider>
      <Sider
        className="teacher-sider"
        theme="light"
        width={200}
        collapsedWidth={64}
        collapsed={isNarrow}
        trigger={null}
      >
        <div className="teacher-brand">{isNarrow ? '教师' : '案例推演 · 教师端'}</div>
        <Menu
          mode="inline"
          selectedKeys={[activeKey]}
          items={MENU_ITEMS}
          onClick={onMenuClick}
        />
        <Button
          className="teacher-logout"
          type="text"
          icon={<LogoutOutlined />}
          block
          onClick={() => void handleLogout()}
        >
          {isNarrow ? null : '退出登录'}
        </Button>
      </Sider>

      <Layout className="teacher-main">
        {isNarrow && (
          <Alert
            className="teacher-narrow-alert"
            type="warning"
            showIcon
            banner
            message="建议在电脑上操作"
            description="当前为手机宽度：侧边栏已收成图标条，案例记录页可左右滑动查看完整表格。"
          />
        )}
        <Content className="teacher-content-scroll">
          <div className="teacher-content">
            <TeacherDraftContext.Provider value={setHasDraft}><Outlet /></TeacherDraftContext.Provider>
          </div>
        </Content>
      </Layout>
    </Layout>
  )
}
