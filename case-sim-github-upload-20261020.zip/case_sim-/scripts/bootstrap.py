"""Shared setup/launch; never accesses production servers."""
import argparse, hashlib, os, shutil, subprocess, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]

def run(args, cwd=ROOT):
    subprocess.run([str(x) for x in args], cwd=cwd, check=True)

def run_npm_ci(workdir):
    """执行 npm ci；被运行环境文件保护拦截（safe-delete）时给出可操作提示。"""
    npm = shutil.which('npm.cmd' if os.name == 'nt' else 'npm')
    p = subprocess.run([npm, 'ci', '--ignore-scripts', '--no-audit', '--no-fund'],
                       cwd=workdir, capture_output=True, text=True)
    if p.returncode != 0:
        err = (p.stderr or '') + (p.stdout or '')
        if 'SAFE_DELETE' in err or 'safe-delete' in err:
            raise SystemExit(
                'npm ci 的整目录清理被当前运行环境的文件保护拦截（SAFE_DELETE_BULK_CONFIRM_REQUIRED）。\n'
                '请改用以下任一方式：\n'
                '  1) 在普通终端（无此保护）执行 python scripts/bootstrap.py setup --rebuild；\n'
                '  2) 先手工移走 frontend/node_modules 再执行 --rebuild；\n'
                '  3) 自动化环境改用 npm install（增量修复依赖树）后执行 npm run build。')
        raise SystemExit(err[-800:] or f'npm ci 失败 rc={p.returncode}')

def app_port():
    """读取 backend/.env 的 APP_PORT；环境变量 APP_PORT 优先。"""
    port = 8100
    env_path = ROOT / 'backend/.env'
    if env_path.exists():
        for line in env_path.read_text(encoding='utf-8', errors='ignore').splitlines():
            line = line.strip()
            if line.startswith('APP_PORT='):
                try:
                    port = int(line.split('=', 1)[1].strip())
                except ValueError:
                    pass
    try:
        return int(os.getenv('APP_PORT', port))
    except ValueError:
        return port

def ensure_port_free(port):
    """启动前预检端口；被占用时给出可操作清理提示（避免裸抛 EADDRINUSE）。"""
    import socket
    s = socket.socket()
    s.settimeout(0.5)
    try:
        busy = s.connect_ex(('127.0.0.1', port)) == 0
    finally:
        s.close()
    if busy:
        raise SystemExit(
            f'端口 {port} 已被占用，无法启动。\n'
            f'若为残留的旧服务进程（含强杀启动脚本后遗留的 uvicorn 子进程），请先清理：\n'
            f'  netstat -ano | findstr :{port}\n'
            f'  taskkill /F /PID <上方输出最后一列的 PID>\n'
            f'然后重新运行启动命令。')

def frontend_digest():
    h=hashlib.sha256()
    for base, dirs, files in os.walk(ROOT/'frontend'):
        dirs[:]=sorted(d for d in dirs if d not in {'node_modules','dist','.git'})
        for name in sorted(files):
            p=Path(base)/name
            if p.suffix=='.tsbuildinfo': continue
            h.update(p.relative_to(ROOT).as_posix().encode()); h.update(p.read_bytes())
    return h.hexdigest()

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('mode', choices=['setup','local','public'])
    parser.add_argument('--rebuild', action='store_true')
    parser.add_argument('--local-only', action='store_true')
    args=parser.parse_args()
    if sys.version_info[:2]!=(3,13): raise SystemExit('Use Python 3.13 (tested runtime).')
    config=ROOT/'backend/.env'
    if not config.exists(): shutil.copy2(ROOT/'backend/.env.example',config)
    python=ROOT/'.venv'/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
    if not python.exists(): run([sys.executable,'-m','venv',ROOT/'.venv'])
    requirements=ROOT/'backend/requirements.txt'
    marker=ROOT/'.venv/requirements.sha256'
    expected=hashlib.sha256(requirements.read_bytes()).hexdigest()
    if not marker.exists() or marker.read_text()!=expected:
        run([python,'-m','pip','install','-r',requirements]); marker.write_text(expected)
    frontend=ROOT/'frontend'; stamp=frontend/'dist/source.sha256'; wanted=frontend_digest()
    if args.rebuild or not (frontend/'dist/index.html').exists() or not stamp.exists() or stamp.read_text()!=wanted:
        npm=shutil.which('npm.cmd' if os.name=='nt' else 'npm')
        if not npm: raise SystemExit('Install Node.js 24 with npm; first startup builds frontend.')
        run_npm_ci(frontend)
        run([npm,'run','build'],frontend); stamp.write_text(wanted)
    if args.mode=='setup': return
    if args.mode=='public':
        if not args.local_only and not (ROOT/'tools/cloudflared.exe').exists():
            raise SystemExit('Install tools/cloudflared.exe or use --local-only. See README.md.')
        run([python,'scripts/run_public.py']+(['--local-only'] if args.local_only else []))
    else:
        ensure_port_free(app_port())
        run([python,'-c','from backend.app import models; from backend.app.db import Base,engine; Base.metadata.create_all(engine); from backend.app.migrations import migrate; migrate(); from backend.app.seed import main; main()'])
        run([python,'scripts/run_server.py','--no-log-window'])

if __name__=='__main__':
    try: main()
    except (subprocess.CalledProcessError,KeyboardInterrupt) as exc:
        raise SystemExit(getattr(exc,'returncode',130))
