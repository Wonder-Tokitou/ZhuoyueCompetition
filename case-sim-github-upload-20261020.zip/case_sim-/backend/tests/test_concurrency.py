"""并发能力验证：AI 任务并发上限 + SQLite 连接 PRAGMA / 连接池。

两条断言对应本次改动：
1. task_runner 的模块级 Semaphore(4)：10 个任务同时入队时，真正同时在跑的 ≤ 4，
   且最终全部落到终态（说明名额被正确归还，没有卡死队列）。
2. db.build_engine：文件库连接拿到 WAL + busy_timeout=10000，:memory: 库不报错。
"""
import asyncio
from datetime import datetime
from uuid import uuid4

from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import QueuePool

from backend.app import db as db_module
from backend.app import models
from backend.app.integrations.ai import artifacts
from backend.app.integrations.ai import task_runner
from contracts.errors import LLMFailed


def _file_factory(tmp_path, name="concurrency.db"):
    """独立文件库：内存库用 StaticPool 共用一个连接，测不出并发。"""
    engine = create_engine(
        "sqlite:///" + (tmp_path / name).as_posix(),
        connect_args={"check_same_thread": False},
    )
    models.Base.metadata.create_all(engine)
    return engine, sessionmaker(bind=engine, autoflush=False)


def test_ai_worker_caps_concurrent_tasks_and_drains_the_queue(tmp_path, monkeypatch):
    engine, factory = _file_factory(tmp_path)
    monkeypatch.setattr(task_runner, "SessionLocal", factory)
    monkeypatch.setattr(artifacts, "ARTIFACT_ROOT", tmp_path / "artifacts")

    running = 0
    peak = 0
    started = []

    async def fake_review(db, task):
        """替身：只模拟"占着一个名额在做模型调用"的耗时，不碰外部服务。"""
        nonlocal running, peak
        running += 1
        peak = max(peak, running)
        try:
            started.append(task.task_id)
            for _ in range(5):
                await asyncio.sleep(0)
        finally:
            running -= 1
        task.status, task.stage, task.finished_at = "succeeded", "completed", datetime.now()
        db.commit()

    monkeypatch.setattr(task_runner, "_run_student_review", fake_review)

    prefix = "cap-" + uuid4().hex[:8]
    with factory() as session:
        for index in range(10):
            session.add(models.AiTask(
                task_id="%s-%02d" % (prefix, index),
                kind="student_review",
                status="queued",
                stage="queued",
                input_json={},
            ))
        session.commit()
        task_ids = [row.task_id for row in session.scalars(select(models.AiTask)).all()]

    async def scenario():
        for task_id in task_ids:
            task_runner.schedule_task(task_id)
        pending = list(task_runner._running.values())
        assert len(pending) == 10, "10 个任务都应已入队"
        await asyncio.gather(*pending)

    assert task_runner.AI_CONCURRENCY == 4
    asyncio.run(scenario())

    assert peak <= task_runner.AI_CONCURRENCY, "同时在跑的任务数不得超过 4（实际峰值 %d）" % peak
    assert peak >= 2, "任务必须真的重叠执行，否则这条断言没有意义（实际峰值 %d）" % peak
    with factory() as session:
        statuses = [row.status for row in session.scalars(select(models.AiTask)).all()]
    assert sorted(statuses) == ["succeeded"] * 10, "名额必须归还，10 个任务都要进入终态"
    assert sorted(started) == sorted(task_ids)
    engine.dispose()


def test_retry_reenters_the_queue_without_deadlocking(tmp_path, monkeypatch):
    """可重试失败后名额必须归还，0.5s 后的重试要能重新拿到名额。"""
    engine, factory = _file_factory(tmp_path, "retry.db")
    monkeypatch.setattr(task_runner, "SessionLocal", factory)
    monkeypatch.setattr(artifacts, "ARTIFACT_ROOT", tmp_path / "artifacts")

    attempts = []

    async def flaky_review(db, task):
        attempts.append(task.attempts)
        if len(attempts) == 1:
            raise LLMFailed("模型临时不可用")
        task.status, task.stage, task.finished_at = "succeeded", "completed", datetime.now()
        db.commit()

    monkeypatch.setattr(task_runner, "_run_student_review", flaky_review)

    task_id = "retry-" + uuid4().hex[:8]
    with factory() as session:
        session.add(models.AiTask(task_id=task_id, kind="student_review", status="queued",
                                 stage="queued", input_json={}, max_attempts=3))
        session.commit()

    async def scenario():
        task_runner.schedule_task(task_id)
        # _retry_or_fail 用 call_later(0.5) 重新入队，这里等到重试真正跑完。
        for _ in range(30):
            await asyncio.sleep(0.1)
            with factory() as session:
                row = session.scalar(select(models.AiTask).where(models.AiTask.task_id == task_id))
                if row.status in ("succeeded", "failed", "cancelled"):
                    return
        raise AssertionError("重试任务没有重新进入队列（可能被信号量卡死）")

    asyncio.run(scenario())

    assert len(attempts) == 2, "第一次失败后应重试一次（实际尝试 %d 次）" % len(attempts)
    with factory() as session:
        row = session.scalar(select(models.AiTask).where(models.AiTask.task_id == task_id))
        assert row.status == "succeeded"
        assert row.attempts == 2
    engine.dispose()


def test_file_database_connections_use_wal_and_long_busy_timeout(tmp_path):
    engine = db_module.build_engine("sqlite:///" + (tmp_path / "pragmas.db").as_posix())
    try:
        with engine.connect() as connection:
            assert connection.exec_driver_sql("PRAGMA journal_mode").scalar() == "wal"
            assert connection.exec_driver_sql("PRAGMA busy_timeout").scalar() == 10000
            # synchronous=NORMAL(1)：WAL 下的推荐值，仍然崩溃安全。
            assert connection.exec_driver_sql("PRAGMA synchronous").scalar() == 1
        # 第二条连接也必须是 WAL：PRAGMA 挂在 connect 事件上，而不只是首条连接。
        with engine.connect() as connection:
            assert connection.exec_driver_sql("PRAGMA journal_mode").scalar() == "wal"
    finally:
        engine.dispose()


def test_memory_database_skips_journal_mode_without_raising():
    engine = db_module.build_engine("sqlite://")
    try:
        with engine.connect() as connection:
            assert connection.exec_driver_sql("PRAGMA journal_mode").scalar() == "memory"
    finally:
        engine.dispose()


def test_application_engine_is_a_ten_connection_queue_pool():
    if db_module._is_memory_url(db_module.DATABASE_URL):
        return  # 内存库用 SingletonThreadPool，不适用 P4 的池参数
    pool = db_module.engine.pool
    assert isinstance(pool, QueuePool)
    assert pool._pool.maxsize == 10, "pool_size 应为 10"
    assert pool._max_overflow == 10, "max_overflow 应为 10"
    assert pool._timeout == 30, "pool_timeout 应为 30 秒"
