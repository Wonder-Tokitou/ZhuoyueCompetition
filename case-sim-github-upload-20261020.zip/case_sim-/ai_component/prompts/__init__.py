"""ai_component/prompts."""
