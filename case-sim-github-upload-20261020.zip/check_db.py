import sqlite3
conn = sqlite3.connect(r'C:\Users\huang2006\Desktop\Work\upload2\case_sim-\backend\data\app.db')
c = conn.cursor()

c.execute('SELECT id, title, status, version FROM "case"')
rows = c.fetchall()
print("Case count:", len(rows))
for r in rows:
    print(r)
