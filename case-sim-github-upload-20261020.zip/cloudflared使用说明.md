# cloudflared.exe 使用说明（给负责 AI 的同学）

你要的 `tools/cloudflared.exe` 已随本压缩包一起发给你。以下是它的信息与用法。

---

## 一、文件信息（可核对）

| 项 | 值 |
|---|---|
| 文件名 | `cloudflared.exe` |
| 版本 | **2026.9.3**（构建于 2026-09-24） |
| 大小 | **55,366,080 字节**（约 52 MB） |
| SHA256 | `f096265ec2fcbe9bb6e2d64268db167ced3fcbb83d894bdb9e2fcdb26f2ea7e2` |
| 平台 | Windows amd64 |

**核对方法**（Windows PowerShell）：

```powershell
Get-FileHash .\cloudflared.exe -Algorithm SHA256
```

输出的哈希值应与上表一致。**核对版本**：

```powershell
.\cloudflared.exe --version
```
→ 应输出 `cloudflared version 2026.9.3 (built 2026-09-24T08:31 UTC)`

---

## 二、它是什么、用来干什么

这是 Cloudflare 官方的 **Tunnel 客户端**（命令行工具，不是安装程序）。本项目用它把**你本机启动的服务**临时映射到一个公网网址，方便别人用手机/外网访问，用于公网联调测试。

> 注意：它是**开发测试用的临时隧道**，不是正式托管 —— 关掉窗口网址就失效，且每次启动网址会变。
> 正式的常驻服务现在跑在阿里云服务器上（`http://8.155.128.75`），不依赖这个 exe。

---

## 三、放到哪里

把 `cloudflared.exe` 放到项目的这个位置（**目录名必须是 `tools`，文件名必须一字不差**）：

```
<项目根>/
└── tools/
    └── cloudflared.exe      ← 放这里
```

**原因**：启动脚本是按这个固定路径找它的 ——

```python
# scripts/run_public.py:126
executable = ROOT / "tools" / "cloudflared.exe"
```

放过位置会报：`Missing tools/cloudflared.exe; see docs/公网测试使用说明.md`

---

## 四、怎么用

**方式一（推荐，一键）**：在项目根目录双击

```
start-public.bat
```

脚本会自动：装依赖（缺的话）→ 构建前端 → 启动本地服务 → 用 cloudflared 开一条公网隧道 → 在窗口里打印 Teacher / Student 两条公网网址。关掉窗口即停止。

**方式二（手动）**：先启动服务，再单独开隧道

```powershell
# 终端 1：启动本地服务（默认监听 8200）
powershell -ExecutionPolicy Bypass -File scripts/run_public.ps1
```

---

## 五、如果这个文件丢了

官方下载地址（选 **Windows / amd64** 版本）：

```
https://github.com/cloudflare/cloudflared/releases
```

下载后改名 `cloudflared.exe` 放进 `tools/` 即可。项目文档里也记了这一条：`docs/公网测试使用说明.md` 第 50 行。

---

## 六、备注

- **它是 Windows 专用的**，Linux 云服务器上不能用（也没有必要用）。
- 它不是 Python / npm 依赖，**不需要** `pip install` 或 `npm install`。
- 本项目交付包默认**不包含**这个文件（52 MB，体积太大），所以需要单独发给你。
