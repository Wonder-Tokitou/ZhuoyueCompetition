# 改动清单（交接给负责 AI 部分的同学）

> 变更时间：2026-09-28 20:43 – 23:26
> 工程根：`case_sim-/`
> 本次共改动 **25 个源文件**，测试 **136 passed**
> 本次目标：接入云服务器 + 修复 4 个线上缺陷

---

## 一、你（AI 部分）最需要看的一处

### ⭐ `ai_component/prompts/case_generation.py` —— 统一金额口径为「单店月营收」

**问题**：线上案例的决策节点生成**反复失败**，被领域校验器（`backend/app/domain/validator.py` 的 V3/V4）拦下。

**根因**：提示词里只写了 `"revenue": 数值(万元)`，**没有标明口径**。而 `_rules_block()` 给出的行业基准是「**单店**月营收 8–20 万」。于是模型在 `base_metrics` 里填了 **5 家店合计 60 万**，在节点选项里却填了**单店 12–15 万** —— 同一份输出里混用两种口径：

| 项 | 模型原先填的 | 后果 |
|---|---|---|
| `base_metrics.revenue` | `60`（5 店合计） | V3：60 不在「单店 8–20 万」区间内 → 不通过 |
| 节点选项 `metrics.revenue` | `12 / 14.5 / 15`（单店） | V4：拿 12 和 60 相减 → 判成「营收暴跌 80%」→ 不通过 |

**权威口径依据**（三条硬证据，均指向「单店」）：
1. `docs/商科规则.json` → `industry_baseline`：`校园餐饮/零售：营收规模 单店月营收8万—20万元`
2. `docs/标杆案例.json` → `base_metrics`：`store_count:5, monthly_revenue_per_store:12, monthly_opex_per_store:4.4`
3. `backend/app/seed.py:39`：`"revenue": raw_base["monthly_revenue_per_store"]` —— 运行时 `revenue` 直接取**单店值**

数值自洽：`12 − 4.6 − 4.4 = 3.0` ＝ 标杆案例给出的单店月净利 `3.0`。

**改动内容（3 处）**：

| 位置 | 改法 |
|---|---|
| `_output_block()` 的 metrics 串 | `"revenue": 数值(万元)` → **`"revenue": 单店月营收数值(万元)`** |
| `_output_block()` 的 constraints | 第 7 条后**新增第 8 条**：`【金额口径统一】所有 revenue / operating_cost / operating_expense 一律按「单店、每月、万元」填写…公司整体规模只能写进企业背景文字` |
| `_rules_block()` 的 baseline_lines | `营收规模 %s` → **`营收规模 %s（单店月营收口径，所有 revenue 均按此口径填写）`** |

**配套改动**：
- `backend/app/schemas.py:108`：`Metrics.revenue` 的 description `营收，单位万元` → **`单店月营收，单位万元`**
- `ai_component/tests/test_public_interface.py`：**新增回归测试**，断言 `build_messages()` 产出的 system 段同时含 `单店月营收` 与 `金额口径统一` 两个字符串

**验证方式**：
```bash
python -m pytest backend/tests ai_component/tests -q      # 应 136 passed
grep -c "单店月营收数值" ai_component/prompts/case_generation.py   # 应 = 1
grep -c "金额口径统一"   ai_component/prompts/case_generation.py   # 应 = 1
```
**线上效果**：改前后同一案例重生成 —— 任务从 `failed` 变 `succeeded`（首次尝试即通过，16 秒），9 个选项营收全部落在 `10.5–15.0`（基准 12.0，同口径可比）。

> ⚠️ **如果你要调整口径判断，请注意**：`backend/app/domain/validator.py` 的 V4 是把**每个节点的每个选项**都与**案例级 `base_metrics`** 比（不是与前一节点结果比）。所以所有选项的 revenue 都必须与 base 同口径、且方向符合 `transmission_rules`，否则一定被拦。

---

## 二、其余改动（按模块）

### A. 教师令牌持久化 —— 修复「登录后约 2 秒被踢回登录页」

**根因**：`backend/app/routers/teacher.py` 里 `TEACHER_TOKENS: set[str]` 是**进程内存**。线上 gunicorn 多 worker 时，登录落在 worker A、后续请求轮到 worker B → 403「令牌无效」→ 前端 `transport.ts` 清 sessionStorage 并跳回登录页。

| 文件 | 改动 |
|---|---|
| `backend/app/models.py` | **新增 `TeacherSession` 表**（`token` 主键 / `created_at` / `expires_at`） |
| `backend/app/routers/teacher.py` | 新增 `is_valid_teacher_token(db, token)`（先查内存缓存、未命中回查表）与 `issue_teacher_token(db)`（签发落库 + 顺带清过期行）；`teacher_login` 增加 `db` 依赖；**9 处**校验点改为调 helper |
| `backend/app/routers/accounts.py` | `require_teacher` 增加 `db` 依赖，改用同一 helper（原先是 `from ...teacher import TEACHER_TOKENS` 的耦合） |
| `backend/app/main.py` | lifespan 增加**启动自检日志**（打印令牌存储模式与单 worker 约束） |

**设计取舍**：保留 `TEACHER_TOKENS` 作为**进程内缓存快路径**，权威来源改为数据库 —— 这样既有 15+ 处直接操作该集合的既有测试无需改动，又多 worker 下不会失效。
**过期治理**：签发时 `DELETE` 过期行（对齐 `StudentLogin` 的做法）。

**新增测试**（`backend/tests/test_accounts.py`，3 个）：
- `test_teacher_token_survives_process_memory_loss` —— 清空内存缓存后仍能鉴权（**模拟「另一个 worker」**）
- `test_teacher_token_expiry_revokes_access` —— 过期令牌被拒 + 登录时清理过期行
- `test_teacher_logout_revokes_token` —— 登出后立即失效、且幂等

### B. 教师登出功能

| 文件 | 改动 |
|---|---|
| `backend/app/routers/teacher.py` | 新增 `POST /api/teacher/logout`：内存缓存 + 数据库双清，**幂等** |
| `frontend/src/api/client.ts` | 新增 `logoutTeacher(token)` |
| `frontend/src/layouts/TeacherLayout.tsx` / `.css` | 侧栏底部新增「退出登录」按钮（`LogoutOutlined`） |

> 令牌现在有 12 小时有效期，必须有主动吊销入口，否则「退出」只是前端删本地副本。

### C. 二维码可达性（线上 nginx 未反代 `/media`）

**背景**：线上 nginx 实际是 `root …/frontend/dist` + `try_files $uri $uri/ /index.html` 且**只反代 `/api/`**，导致 `/media/qrcode/*.png` 被它兜底成 `index.html`（返回 200 但内容是网页）。仓库里的 `deploy/nginx/case-sim.conf`（全量反代）**从未真正部署**。

| 文件 | 改动 |
|---|---|
| `backend/app/main.py` | 新增 `GET /api/media/{path:path}`：从 `ASSETS_DIR` 取文件，`is_relative_to` 挡目录穿越，缺失返回 **404**；`ASSETS_DIR` 改为复用 `teacher.STATIC_DIR`；启动时 `mkdir` 后再**无条件** `app.mount("/media", …)`（原先 `if is_dir()` 会静默跳过） |
| `backend/app/routers/teacher.py` | `_qr_code_url` 返回值 `/media/qrcode/x.png` → **`/api/media/qrcode/x.png`** |
| `backend/tests/test_publish_qrcode.py` | 更新期望值 + 新增三条断言（能取到真 PNG / 缺失 404 / 目录穿越 404） |
| `frontend/.../PublishPanel.tsx` | 仅更新注释 |

> 二维码**图片里编码的是学生端网址**（`/student/<token>`），不是图片自身地址，因此换前缀**不影响扫码**。
> 已实测：解码结果 = `http://8.155.128.75/student/207ea49c…`，与预期逐字符一致。

### D. 单 worker 约束声明（不改逻辑，只加注释）

`backend/app/routers/student.py`（`TRY_STORE`）与 `backend/app/integrations/ai/task_runner.py`（`_running`）仍是进程内存状态 —— 前者按 `SPEC.md:706` 属「刻意不落库」，后者是 `asyncio.Task` 无法序列化。均补上「必须保持 `--workers 1`」的注释。
`deploy/systemd/case-sim.service` 注释同步改写：教师令牌已持久化、不再受 worker 数影响；剩余内存态收敛为上述两处。

### E. 测试改造（不改产品行为）

- **新增** `backend/tests/teacher_helpers.py`：`login_teacher(client, monkeypatch)`，通过 HTTP 登录拿真实令牌
- **8 个测试文件**原先直接 `TEACHER_TOKENS.add(...)`（约 30 处），全部改为走 HTTP 登录：
  `test_mvp_smoke` / `test_architecture_seams` / `test_presentation_and_background` / `test_student_workflow` / `test_teacher_calibration` / `test_v4_state` / `test_review_contract_regression` / `test_choice_receipts`
- `test_v4_state.py` 适配 `teacher_login` 新签名（用一次性内存库隔离）
- `test_accounts.py` 中 2 个缓存未命中回归测试改用 `monkeypatch.setattr(teacher, 'TEACHER_TOKENS', set())`，测试结束自动还原，不污染全局

---

## 三、验证状态

| 项 | 结果 |
|---|---|
| 语法编译 | ✅ `python -m compileall backend ai_component` 退出码 0 |
| 全量测试 | ✅ **`136 passed`**（backend 130 + ai_component 6） |
| 线上教师端并发 | ✅ 5 轮 × 30 次 = **150/150 全 200**，零 403 |
| 线上登出闭环 | ✅ 登录 200 → 用令牌 200 → 登出 200 → **再用同令牌 403** |
| 线上案例 1 | ✅ `published`、`nodes=3`、`revenue=12.0`（单店口径） |
| 线上二维码 | ✅ `200 image/png 850B`，解码内容正确、链接可访问 |
| 学生端 | ✅ `me` / `cases` / `records` / `play` 全 200 |

---

## 四、交接注意事项

1. **本包不含 `backend/.env`**（里面有真实 `LLM_API_KEY`）。首次运行请复制 `backend/.env.example` 为 `backend/.env` 并按需填写。
2. **本包不含 `frontend/dist` 与 `node_modules`**。跑前端先 `cd frontend && npm ci && npm run build`。
3. **`docs/商科规则.json` 与 `docs/标杆案例.json` 是运行时必需**（`backend/app/domain/rules.py` 在 import 时加载，缺失会直接崩）。已在包内，勿删。
4. **`tools/cloudflared.exe` 已排除**（54 MB 的 Windows 二进制，云服务器用不到）。
5. **Nginx 配置仍未真正部署**（`deploy/nginx/case-sim.conf`）。当前功能已用 `/api/media` 绕开，但治本仍建议替换线上配置。
6. 若你（AI 部分）要改**案例生成/校验**相关逻辑，请同时看：
   - 生成：`ai_component/prompts/case_generation.py`、`ai_component/agents/generator.py`、`backend/app/integrations/ai/workflow.py`
   - 校验：`backend/app/domain/validator.py`（V1–V6 六项）、`docs/商科规则.json`（行业基准与传导规则表）
