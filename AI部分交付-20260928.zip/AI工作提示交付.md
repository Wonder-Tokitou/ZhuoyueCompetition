# AI 工作提示与代码交付清单

本文是交给搭档及后续 Codex/AI 编程助手的项目地图和协作约束。每次开启新会话，请先让 AI 从项目根目录阅读本文件、`README.md`、`CONTEXT.md`、相关 `docs/` 和目标代码/测试，再开始修改。本文不代替源码与测试；出现冲突时按“权威信息顺序”处理。

## 1. 项目边界与权威信息

### 系统形态

- 一个仓库、一个平台后端进程。`ai_component/` 与 `backend/` 是维护区分离，不是两套单独运行的服务。
- AI 侧由 `backend/app/integrations/ai/` 调用，并通过 `contracts/` 交换稳定数据结构。AI 侧不导入 `backend`，平台也不把 AI 逻辑复制进业务路由。
- 代码路径必须可搬迁：从源码位置/项目根目录推导，或通过环境变量显式配置。Windows 脚本以 `%~dp0` 或 `$PSScriptRoot` 定位根目录。禁止硬编码开发者盘符、用户名、工作区、局域网 IP。
- 交付时不得把 `.env`、`.venv`、`node_modules`、运行数据库、学生记录、公网密钥和日志一并拷给他人。

### 权威信息顺序

遇到描述冲突时，不按聊天片段猜测。依次检查：

1. 当前源码和当前数据结构；
2. `contracts/` 的对外接口及 `backend/app/domain/` 的规则；
3. `CONTEXT.md`、`SPEC.md`、当前相关 ADR（`docs/adr/`）；
4. `docs/架构分工与交接.md`、商科规则、验收文件及现有测试；
5. 用户本轮明确的新指令；
6. 旧聊天、历史运行日志仅作线索，不作为当前行为的唯一依据。

如果新指令与既有不可变约束冲突，应先报告冲突和影响。业务规则、教师/学生权限、真实数据删除、迁移、模型成本、对公网暴露等会改变结果或产生外部影响的问题，必须先问清楚；不能以“AI 自己判断”替代产品决策。低风险且可逆的实现细节，可采用项目既有模式并记录假设。

## 2. 目录地图（交付副本）

### 项目根目录

| 目录/文件 | 用途与维护说明 |
| --- | --- |
| `ai_component/` | AI 专属维护区，模型供应商协议、Agent、提示词和 AI 纯单元测试。 |
| `backend/` | FastAPI 平台后端、确定性业务规则、数据库模型与迁移、任务/文件适配器、接口和后端集成测试。 |
| `frontend/` | React/TypeScript 教师端、学生端、同源 API 封装和前端测试。 |
| `contracts/` | AI 与平台共享的公开数据合同、错误、日志和输出规范。任何跨区结构改动都要同步双方及测试。 |
| `docs/` | 架构/商科规则/验收/部署/竞赛材料。规则变更要同步结构化 JSON、说明文档和测试。 |
| `scripts/` | 服务启动、停服、进程树管理、公网空间代理、日志和验收工具。路径均相对项目根。 |
| `tools/` | 随包提供的 `cloudflared.exe`，公网 Quick Tunnel 启动器使用；不是 Python/npm 依赖。 |
| `start.bat` | 本地开发启动：创建 `.env`/`.venv`、安装依赖、构建、迁移/seed，再启动本地服务。 |
| `start-public.bat` | 公网测试启动：独立准备缺失的依赖、构建并启动五个隔离空间；不 seed 本地演示数据。 |
| `stop-public.bat` | 停止本项目公网网关、隧道及其子进程；保留密钥和记录。 |
| `README.md` | 项目安装、环境变量、API 与测试总览。 |
| `CONTEXT.md` | 精简项目目标、重要背景和当前架构约束。新会话优先阅读。 |
| `SPEC.md` | 较完整产品/系统规范；改业务前先查对应条款。 |
| `.gitignore` | 排除 `.env`、依赖目录、运行 DB/日志、二维码、公网私有文件和测试缓存。 |
| `backend/requirements*.txt` | Python 运行/开发依赖列表。 |
| `frontend/package.json` / `package-lock.json` | Node 依赖声明与精确锁定版本；安装优先 `npm ci`。 |
| `测试案例素材.txt` | 非敏感、可重复使用的案例生成/调试素材，不是运行时数据库或学生数据。 |

运行后才会出现的内容：`.venv/`、`frontend/node_modules/`、`frontend/dist/`、`backend/.env`、`backend/data/`、`backend/app/static/qrcode/`、`private/public-test/`、`logs/`、`__pycache__/`、`.pytest*`、`.test-tmp/`。这些不属于源码分区；按 `.gitignore` 管理。不要把它们误认为新的 AI 架构目录。

### `ai_component/`：AI 维护区

| 子目录/文件 | 职责 |
| --- | --- |
| `agents/` | Agent 与工作流编排：`case_workflow.py`/`generator.py` 做案例生成与有限修复，`student_agent.py` 做学生复盘，`tutor_agent.py` 做受限助教，`teacher_advice.py` 做教师建议。只接收平台提供的能力和证据，不自行访问数据库或文件系统。 |
| `prompts/` | `case_generation.py` 等可复用提示词构造。提示词与输出合同需同时维护测试。 |
| `providers/` | 模型提供商协议层；`llm.py` 负责 OpenAI 兼容接口、超时/重试/结构化输出等。模型 URL、Key、名称取自运行配置，禁止硬编码 Key/模型名。 |
| `tests/` | Mock 模型和纯数据测试，不产生模型费用，不导入 FastAPI/SQLAlchemy。 |
| `README.md` | AI 区边界、调用入口、局部测试方法。 |

### `backend/`：整体平台后端

| 子目录/文件 | 职责 |
| --- | --- |
| `app/main.py` | FastAPI 应用装配、路由注册、生命周期和启动恢复入口。 |
| `app/db.py`、`models.py`、`migrations.py`、`schemas.py` | DB 会话、ORM 表、迁移和 HTTP 数据模型。表/数据结构变更须评估迁移与旧数据兼容。 |
| `app/paths.py` | 平台文件与数据根路径的统一推导点。新增文件存储路径优先复用此处/配置，不散落各自绝对路径。 |
| `app/seed.py` | 本地开发演示案例的幂等 seed；公网空间启动不调用该本地 seed。 |
| `app/observability.py` | 日志/请求追踪和敏感内容处理。不得记录 API Key、访问密钥、密码或完整学生敏感内容。 |
| `app/domain/` | 确定性领域逻辑：`financials.py` 财务公式、`decision_engine.py` 决策计算、`rules.py` 风险/商科规则、`student_choices.py` 与 `student_labels.py` 学生选项展示、`validator.py` 案例校验、`review_contract.py` 复盘合同校验。学生推演及教师规则结果在这里，不交给 LLM 自由发挥。 |
| `app/integrations/` | 外部/跨模块适配层；负责把平台能力转成 AI 侧可用的受限接口。 |
| `app/integrations/ai/` | AI 与平台的唯一主要接缝：`workflow.py` 案例编排适配、`task_runner.py` 调度/恢复、`evidence.py` 授权上下文证据、`artifacts.py` 元数据、`blob_storage.py` 文件存储抽象、`tutor.py` 助教工具访问、`web_search.py` 外部检索、`teacher_advice.py` 教师建议、`trial.py` 推演相关 AI 能力。涉及 DB、权限、文件授权时从这里处理，不让 AI Agent 直连平台内部。 |
| `app/routers/` | `teacher.py`、`student.py`、`accounts.py` 是 HTTP 边界及教师、学生、账号 API。保持校验/鉴权/序列化职责；复杂财务或 AI 编排下沉到 domain/integrations。 |
| `app/services/` | 通用平台用例：`extractors.py` 上传文档解析、`student_auth.py` 账号认证、`student_submissions.py` 提交保存、`case_recalibration.py` 校准后的指标重算。 |
| `app/static/qrcode/` | 启动/发布后生成的二维码静态产物；不要存放手工源码或作为案例唯一数据。 |
| `tests/` | 后端 API、数据库工作流、任务恢复/幂等、权限、AI Adapter、HTTP smoke 和公网网关测试。默认用 Mock 模型和临时 SQLite。 |
| `data/` | 运行时生成的 SQLite DB 与制品目录（默认路径）。数据不能提交/覆盖；要清理时先确认环境和备份。交付包不带此目录。 |
| `.env.example` | 无真实密钥的配置模板。可复制成被忽略的 `backend/.env`，接收方按环境填写。 |
| `.env` | 本地密钥/口令配置，不在交付副本中。严禁读取后输出或纳入版本库/压缩包。 |

### `frontend/`：教师端与学生端

| 子目录/文件 | 职责 |
| --- | --- |
| `src/main.tsx`、`App.tsx` | React 入口、全局路由/页面装配。 |
| `src/api/` | 同源 HTTP transport、业务 client、TypeScript API 类型。服务端路径变化优先在这里对齐，不在页面散写 URL。 |
| `src/components/` | 双端通用组件，如指标比较、相机扫码和反馈桥接。 |
| `src/context/` | 学生账号、学生令牌、教师令牌等会话状态。不得保存模型密钥或服务端访问密钥。 |
| `src/domain/` | 前端可复用的展示/交互规则；不得取代后端权威财务计算。 |
| `src/features/ai/` | AI 相关 API 和 UI 能力集中区：`GeneratePanel.tsx` 案例生成、`AiFixDrawer.tsx` AI 修复候选、`TaskStatus.tsx` 任务状态、`ReviewEditor.tsx` 教师复盘校准、`StudentReview.tsx` 学生复盘、`StudentTutorSidebar.tsx` 学生助教、`api.ts` AI API。不要把普通业务流程错误地归入 AI。 |
| `src/hooks/` | 可复用 React hooks。 |
| `src/layouts/` | 学生和教师页面框架、导航与布局样式。 |
| `src/pages/student/` | `StudentLandingPage.tsx` 学生入口/案例列表，`StudentLoginPage.tsx` 登录，`StudentPlayPage.tsx` 决策推演，`StudentReviewPage.tsx` 完成后复盘，`StudentSpacePages.tsx` 学习空间/记录等页面。 |
| `src/pages/teacher/` | `TeacherWorkbenchPage.tsx` 工作台/案例校准发布，`TeacherRecordsPage.tsx` 学生提交记录，`TeacherStudentsPage.tsx` 学生管理，`TeacherLoginPage.tsx` 登录；`components/` 放教师工作台分组件。教师人工保存优先。 |
| `src/utils/` | 通用 UI 辅助工具。 |
| `public/` | Vite 原样复制到构建结果的静态资源。 |
| `tests/` | Node 原生测试：财务显示、API 展示合同、学生流程、AI UI、教师任务等。 |
| `dist/` | 构建产物，由 `npm run build` 重建，不当成源码维护或手改。 |
| `node_modules/` | 本机依赖，不跨机器传递；用锁文件安装。 |
| `.env.example` | 前端开发端口/代理的无密钥样例。前端绝不能配置 DeepSeek Key。 |

### `contracts/`：跨区接口合同

- `ai.py`：平台可调用的 AI 能力输入/输出结构。
- `presentation.py`：对学生安全展示文本的结构/格式合同。
- `review.py`：学生复盘结构与完整性规则；维度/条目按当前合同动态保存，不擅自把教师要求的动态数量改成固定数量，但必须保证合同定义的基础字段完整。
- `tutor.py`：助教的证据/回答合同。
- `errors.py`：可预期的跨层错误类型。
- `telemetry.py`：不泄漏敏感值的跨层日志事件合同。
- `README.md`：调用方责任与合同说明。

改合同属于跨区变更：AI Agent、backend Adapter、API schema、前端显示和两侧测试都要核对。不要只改一方然后靠宽松解析掩盖不兼容。

### `docs/`：文档与领域资料

| 子目录/文件 | 职责 |
| --- | --- |
| `adr/` | 架构决策记录；先检查已有决策，架构边界变化需新增 ADR，而不是只在聊天里留结论。 |
| `source/` | 标杆案例/商科规则源文件（DOCX），是业务需求来源，不是测试缓存。 |
| `提交材料/` | 系统介绍、设计、流程、验收矩阵、图表、路演和赛事合规材料。产品行为变化后检查是否需要同步。 |
| `商科规则.md` / `商科规则.json` | 商科判断、风险梯度和结构化规则依据。商科规则冲突须找老师确认，不让模型猜。 |
| `标杆案例.json` | 当前案例结构/展示参考样例。不要把它当运行中的学生数据库。 |
| `架构分工与交接.md`、`架构拆分验收.md` | AI 区与平台区边界和联合验收要求。 |
| `公网测试使用说明.md`、`公网测试验收.md` | 隔离空间、公网访问密钥、链接、日志与停服说明。 |
| `运行日志.md` | 教师/学生动作、上传、AI 调用和故障日志指南。 |
| `学生空间架构与联调.md`、`学生端验收.md` | 学生账号、提交保存、教师读取路径和验收点。 |
| `商科待确认项.md` | 尚待业务方确认的问题；不能自行把待确认判断写成产品规则。 |
| `本地开发架构.md`、故障修复/优化/验收文档 | 本地环境和历史技术经验，改同一功能前阅读；日志中的旧路径/错误可能过时。 |
| `contract-v4.md` | 案例结构版本合同/字段说明。 |
| `build_docs.py` | 竞赛交付文档的本地生成辅助脚本；输出前检查目标路径，不能把生成物写到任意机器绝对路径。 |

### `scripts/` 与 `tools/`

| 文件 | 用途 |
| --- | --- |
| `scripts/run_server.py` | 本地单实例 FastAPI 启动及日志/端口配置。 |
| `scripts/run_public.py` | 公网测试生命周期：准备五个空间、启动隔离 worker、启动 Cloudflare 隧道、打印日志/链接、退出时回收子进程。 |
| `scripts/public_gateway.py` | 公网测试访问 key 校验、空间路由和访问边界；不是生产级身份系统。 |
| `scripts/public_links.py` | 原子更新 `private/public-test/links.json` 状态/入口。 |
| `scripts/run_public.ps1` | PowerShell 公网脚本包装器，参数和路径以自身位置推导。 |
| `scripts/stop_public.ps1` | 精确识别并结束本项目公网启动器及子进程，不应误杀普通本地服务。 |
| `scripts/process_group.py` | Windows 子进程组/job 生命周期管理。 |
| `scripts/watch_logs.py` | 多服务实时日志查看辅助。 |
| `scripts/check_public.py` | 使用已存在 key 做公网连通性只读检查；不要打印 key。 |
| `scripts/verify_http.py`、`backend/tests/*smoke*` | 以临时服务/Mock 检查端到端路由；不能误连生产/公网数据。 |
| `tools/cloudflared.exe` | 公网测试使用的 Cloudflare Tunnel Windows 可执行文件；不是 Linux 云主机可执行文件。Linux 生产应使用 Linux 版部署组件或 Nginx/Caddy 等正式反向代理方案。 |

公网运行数据统一位于 `private/public-test/`：`links.json` 为最新地址；`access-keys.json` 为五个隔离测试 key；`spaces/test-N/` 放各空间 DB、文件、日志；`tunnel.log` 放隧道日志。保留空间目录即保留 key 对应的历史记录。生产部署不要把整个 `private/` 打包或公开。

## 3. 不可破坏的业务与技术约束

1. **教师发布内容是推演真值。** 学生进入教师发布的快照进行确定性计算；学生提交后由后端规则计算结果。推演阶段不能因调用 AI、模型换版或 AI 复盘失败而更改选择含义或财务结果。
2. **教师人工编辑优先。** 校准字段、节点选项或已保存内容被教师确认/修改后，异步 AI 候选必须检查版本/时间戳；不允许晚到的 AI 结果覆盖人工保存内容。
3. **AI 是边界清晰的能力。** 案例生成、受限答疑、学生完成后的复盘可以调模型。工具只可读取本次授权的案例/节点/学生本人答案等证据；不允许任意文件路径、任意 SQL 或跨学生查询。
4. **确定性规则归平台。** 财务公式、指标区间、风险传导、有效选项、节点顺序、发布检查在 `backend/app/domain/`；不要把精确计算“优化”为 LLM 输出。
5. **动态复盘不强行固定条数。** 保留模型/教师定义的动态维度与数组长度；同时校验每个合同要求的基础字段、类型和内容完整性。缺项应明确失败/修复，不能静默丢弃或按固定长度误判。
6. **任务需可追踪。** AI 后台任务保留状态/阶段/重试/错误和关联制品，重启恢复、幂等键和教师可见日志要继续成立。
7. **数据和凭证隔离。** 不将 API Key、测试 key、学生姓名/答案或上传原文放进前端、Git、README、截图或普通日志；AI 测试用 Mock，不触发真实收费调用。
8. **一项需求一个最小变更面。** 不借小 UI/计算修复重写路由、数据库或 AI 协议。DB schema 变更必须有迁移和兼容测试。
9. **接口不随意兼容式扩张。** 对外 HTTP API 尽量保持既有路径/字段；变更合同需先列受影响端并补迁移/回归。
10. **目录清晰。** AI 新实现放 `ai_component/`，平台 API/DB/领域行为放 `backend/`，浏览器 UI 放 `frontend/`，跨区共识放 `contracts/`；不要建立第二套同名实现或散放提示词。

## 4. 接到模糊提示时的决策流程

使用下列流程，而不是直接猜代码：

1. **复述可验收结果。** 用一两句话说明用户要改变的可观察行为，以及明确不应改变的行为。
2. **定位层次。** 判定是 UI、HTTP/API、数据库/迁移、确定性业务规则、AI provider/Agent、文件/部署脚本或文档；说明拟改目录和不改目录。
3. **查证现状。** 读目标源码、相邻测试、合同、商科规则、ADR、启动脚本和最新日志（如用户要求看日志）。旧聊天内容不能覆盖当前源码证据。
4. **列假设和风险。** 例如“我假设是动态数组而非固定 5 项”；如果假设影响商科含义、数据归属/删除、凭证权限、费用或公网暴露，暂停并提出一个明确问题。
5. **先写失败测试或最小复现。** 复现当前行为后做最小实现；绝不以改测试期待值来伪装修复。
6. **执行对应验证。** 运行目标测试，再跑受影响层级测试；用户要求全量验收时跑全量。模型通过 Mock 测，不在无许可时用真实 Key。
7. **检查副作用。** 查看 diff、绝对路径、秘钥/个人信息、测试/数据库污染、构建产物、进程和日志；不要清理非本次明确授权的数据。
8. **交付证据。** 汇报原因、实际改动文件、测试命令/通过数量、未验证项和人工下一步。不能把“代码已改”说成“公网已生效”；部署中的进程需由有权限的人重启。

### 必须向用户确认的情况

- 商科指标定义、财务口径、选项风险梯度/正确性或规则来源互相冲突；
- 要新增/删除/迁移真实案例、账号、学生记录、日志或私有文件；
- 需要读取/公开真实模型 Key、教师口令、测试空间 key 或学生信息；
- 将服务绑定公网网卡、开放云安全组/端口、发信/部署/重启生产服务；
- 不确定保留旧 API/DB 兼容，且迁移会影响现有数据；
- 用户只要求诊断/只读时，不能顺便实施代码或外部写操作。

对低风险问题可按当前规范作最小、可撤销的实现，并把假设写在回答/注释里；不要因问题不够精确就把两个维护区合并或引入新框架。

## 5. 建议的 Codex/AI 会话提示词

开工前：

> 请先阅读项目根目录 `AI工作提示交付.md`、`CONTEXT.md`、`README.md`，再读与本任务有关的 ADR、商科规则、源码和测试。不要先改代码。先汇报当前实现、证据、任务涉及的目录、不可变约束及任何必须澄清的问题。仅在行为边界清晰后做最小修改。所有路径保持可搬迁；AI 只能经平台适配层使用授权数据；学生推演由教师发布快照和确定性规则决定；教师人工保存不可被 AI 覆盖。用 Mock 做 AI 测试，不泄漏或读取密钥值。完成后跑针对测试，检查 diff 与副作用并给出证据。

要求实施时追加：

> 仅修改本任务允许的目录/文件：`<列出范围>`。不改变对外 API、数据库结构、部署状态或其他业务规则；如发现确需扩大范围，先停止并说明原因。验收标准：`<可观察的通过条件>`。

需求不清楚时追加：

> 将不明确点分成“可逆实现细节”和“会影响产品/数据/安全的决定”。对前者按已有规范给出假设；对后者不要猜，先问我。不要把 AI 自由生成内容当成计算或教师决策依据。

## 6. 依赖、测试和运行注意

- Python 后端依赖：`backend/requirements.txt`；测试额外依赖：`backend/requirements-dev.txt`。
- 前端依赖：`frontend/package.json`；锁文件：`frontend/package-lock.json`。交付后用 `npm ci`，不提交 `node_modules/`。
- 后端/AI 测试从项目根运行：

  ```powershell
  .\.venv\Scripts\python.exe -m pytest backend/tests ai_component/tests -q -p no:cacheprovider
  ```

- 前端测试与构建：

  ```powershell
  cd frontend
  npm.cmd test
  npm.cmd run build
  ```

- 测试应使用临时 DB、临时制品目录、Mock LLM。测试失败时保留可复现证据，不把 `.pytest*`/`.test-tmp` 测试输出提交。
- 本机开发双击 `start.bat`；公网验收双击 `start-public.bat`；停止公网用 `stop-public.bat`。不能在处理 bug 时顺手重启用户仍在使用的服务。
- Quick Tunnel 地址每次启动可能变化；当前链接读 `private/public-test/links.json`。测试 key 读 `private/public-test/access-keys.json`；切勿把全量 key 发给测试群。
- `start-public.bat` 的默认本地网关端口是 `scripts/run_public.py` 的 `--port` 默认值 8200。阿里云生产部署应优先反代到 HTTPS 443；先配置反向代理/证书/防火墙/安全组和健康检查，再开放服务。不要把数据库或开发端口暴露到公网。

## 7. 交付前检查清单

- [ ] 修改只落在对应维护区，跨区改动有合同/接口和双方测试。
- [ ] 没有硬编码开发机盘符、用户目录、局域网 IP 或 `.venv` 解释器路径。
- [ ] 没有真实 `.env`、API Key、教师密码、测试密钥、学生数据、运行 DB、个人上传件或历史日志。
- [ ] 本机产物（`.venv`、`node_modules`、`dist`、缓存、日志、二维码、测试 DB）可在接收端重建。
- [ ] AI 调用可通过 Mock 测试；学生推演仍是确定性；教师修改不会被覆盖；复盘动态长度与基础完整性均受检验。
- [ ] DB/schema/API/环境变量/公网行为变化有迁移或使用说明及回滚考虑。
- [ ] 运行目标测试及受影响的全量测试；前端有变化则 `npm test` + build。
- [ ] `git diff --check`、路径扫描、密钥扫描结果可说明；不提交测试临时产物。
- [ ] 汇报精确改动、验证证据、未完成项/风险及需要搭档或老师确认的决定。
