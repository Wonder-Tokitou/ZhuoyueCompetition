import { useEffect, useState } from 'react'
import { Alert, Button, Card, Spin, Space, Typography } from 'antd'
import { review, retryStudentReview } from './api'
import type { ReviewResponse } from '../../api/types'

const POLL_MS = 2000

export default function StudentReview({ token, sid, onRestart, onBack }: { token: string; sid: number; onRestart: () => void; onBack: () => void }) {
  const [data, setData] = useState<ReviewResponse | null>(null)
  const [error, setError] = useState('')
  const [refresh, setRefresh] = useState(0)
  const [connection, setConnection] = useState('')

  useEffect(() => {
    let cancelled = false
    let timer: number | undefined
    let wake: (() => void) | undefined
    const controller = new AbortController()
    const wait = (ms: number) => new Promise<void>((resolve) => {
      wake = resolve
      timer = window.setTimeout(resolve, ms)
    })
    setError('')
    setConnection('')
    setData(null)
    async function load() {
      if (!sid) {
        setError('缺少推演会话')
        return
      }
      let failures = 0
      while (!cancelled) {
        try {
          const result = await review(token, sid, controller.signal)
          if (cancelled) return
          failures = 0
          setConnection('')
          setData(result)
          if (result.status !== 'pending' && result.status !== 'running') return
          await wait(POLL_MS)
        } catch (cause) {
          if (cancelled) return
          const status = (cause as { status?: number })?.status
          if (status && status >= 400 && status < 500 && status !== 408 && status !== 429) {
            setError(cause instanceof Error ? cause.message : '复盘暂不可用')
            return
          }
          failures += 1
          setConnection('暂时无法查询进度，正在自动重连；这不代表 AI 生成失败。')
          await wait(Math.min(30000, POLL_MS * 2 ** Math.min(failures, 4)))
        }
      }
    }
    void load()
    return () => { cancelled = true; controller.abort(); window.clearTimeout(timer); wake?.() }
  }, [token, sid, refresh])

  if (error) return <Space direction="vertical"><Alert type="warning" message="复盘暂不可用" description={error} /><Button onClick={() => setRefresh((x) => x + 1)}>重新查看</Button></Space>
  if (data?.status === 'failed') return <Space direction="vertical"><Alert type="error" message="AI 复盘生成失败，推演结果已保存" description={data.conclusion} /><Button onClick={async () => { try { await retryStudentReview(token, sid); setData(null); setRefresh((x) => x + 1) } catch (e) { setError(e instanceof Error ? e.message : '重试失败') } }}>重试 AI 复盘</Button></Space>
  if (!data || data.status === 'pending' || data.status === 'running') {
    return <Space direction="vertical"><Spin /><Typography.Text>推演已完成，AI 正在生成并校验复盘。阶段：{data?.stage || '排队中'}，尝试次数：{data?.attempts || 0}。生成和校验可能需要数分钟；离开页面不会取消任务。</Typography.Text>{connection && <Alert type="warning" message={connection} />}</Space>
  }
  return (
    <Space direction="vertical" style={{ width: '100%' }}>
      <Typography.Title level={3}>推演复盘</Typography.Title>
      <Typography.Text type="secondary">{data.framework_type}</Typography.Text>
      <Card title="分析维度">
        {data.dimensions.map((dimension, index) => (
          <Card size="small" key={`${dimension.name}-${index}`} title={dimension.name}>
            {dimension.content}
          </Card>
        ))}
      </Card>
      <Card title="综合结论">{data.conclusion}</Card>
      <Space direction="vertical" style={{ width: '100%' }}>
        <Button block onClick={onBack}>返回推演并修改决策</Button>
        <Button size="large" type="primary" block onClick={onRestart}>再试一次（覆盖原记录）</Button>
      </Space>
    </Space>
  )
}
