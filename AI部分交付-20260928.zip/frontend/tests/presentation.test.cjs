const { test } = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs'), path = require('node:path'), vm = require('node:vm'), ts = require('typescript')
const React = require('react'), { renderToStaticMarkup } = require('react-dom/server')

function load(file, mocks = {}) {
  const exports = {}
  const code = ts.transpileModule(fs.readFileSync(path.resolve(__dirname, file), 'utf8'), { compilerOptions: { module: ts.ModuleKind.CommonJS, jsx: ts.JsxEmit.ReactJSX, target: ts.ScriptTarget.ES2022 } }).outputText
  vm.runInNewContext(code, { exports, require: (id) => id in mocks ? mocks[id] : require(id) })
  return exports
}

test('metrics render as labelled before/after rows with zero preserved and missing values explicit', () => {
  const Component = load('../src/components/MetricComparison.tsx').default
  const html = renderToStaticMarkup(React.createElement(Component, { before: { revenue: 0, gross_margin: '0.0%', cash_flow: '收紧' }, after: { revenue: 12.2, gross_margin: '60.5%', cash_flow: '改善' } }))
  for (const text of ['<table', '决策前', '决策后', '营收（万元）', '毛利率', '现金流', '12.2', '>0<', '未记录']) assert.ok(html.includes(text), text)
  assert.ok(!html.includes('revenue') && !html.includes('gross_margin'))
})

test('assistant references collapse separately from answer and render plain safe text', () => {
  const { TutorMessage } = load('../src/features/ai/StudentTutorSidebar.tsx', { '../../api/transport': {}, './api': {}, 'react-router-dom': {} })
  const content = '现金流改善。[read_results]\n\n依据：\n[read_results] 教师版本 1\n营收：12 万元\n<script>alert(1)</script>'
  const html = renderToStaticMarkup(React.createElement(TutorMessage, { content }))
  assert.ok(html.includes('<details>') && !html.includes('<details open'))
  assert.ok(html.indexOf('现金流改善') < html.indexOf('<details>'))
  assert.ok(html.includes('营收：12 万元') && !html.includes('<script>'))
  assert.ok(!html.includes('read_results') && html.includes('【已提交结果】'))
  const userHtml = renderToStaticMarkup(React.createElement(TutorMessage, { content, assistant: false }))
  assert.ok(!userHtml.includes('<details>'))
  assert.ok(userHtml.includes('[read_results]'))
  const legacy = renderToStaticMarkup(React.createElement(TutorMessage, { content: '依据[read\\_result][read_node][read_rules][web_1]' }))
  assert.ok(!legacy.includes('read') && !legacy.includes('web_'))
  for (const label of ['已提交结果', '当前节点', '教学规则', '外部资料 1']) assert.ok(legacy.includes(label))
})
