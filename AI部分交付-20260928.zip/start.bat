@echo off
setlocal

REM Always work relative to this script, regardless of the current directory.
cd /d "%~dp0"

REM Prepare a private local configuration on first run. The file is git-ignored.
if not exist "backend\.env" (
    copy /Y "backend\.env.example" "backend\.env" >nul
    echo Created backend\.env from backend\.env.example.
    echo Edit it to add an LLM endpoint/key when you are ready to connect a real model.
)

REM Local ports are configured in backend\.env; these defaults keep this copy
REM separate from the baseline project that uses port 8000.
set "APP_HOST=0.0.0.0"
set "APP_PORT=8100"
for /f "usebackq tokens=1,* delims==" %%A in ("backend\.env") do (
    if /I "%%A"=="APP_HOST" set "APP_HOST=%%B"
    if /I "%%A"=="APP_PORT" set "APP_PORT=%%B"
)

REM A copied venv may keep an unusable launcher path. Test it before reuse.
if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" --version >nul 2>&1
    if errorlevel 1 (
        echo Existing .venv is not usable; moving it aside for recovery.
        ren ".venv" ".venv.invalid-%RANDOM%"
    )
)

REM Recreate the environment on each computer. --copies avoids launcher issues in non-ASCII paths.
if not exist ".venv\Scripts\python.exe" (
    echo Creating virtual environment...
    python -m venv --copies .venv
    if errorlevel 1 (
        echo Failed to create the virtual environment.
        exit /b 1
    )
)

call .venv\Scripts\activate.bat
if errorlevel 1 (
    echo Failed to activate the virtual environment.
    exit /b 1
)

REM Test PNG rendering too: importing qrcode alone misses its optional image backend.
REM Only install when the local environment is incomplete; normal starts are offline.
python -c "import fastapi, uvicorn, sqlalchemy, pydantic, httpx, multipart, pypdf, qrcode, PIL, dotenv; from io import BytesIO; qrcode.make('startup-check').save(BytesIO(), format='PNG')" >nul 2>&1
if errorlevel 1 (
    echo Installing backend dependencies...
    set "PIP_ARGS=--default-timeout=120 --retries=5 --prefer-binary"
    if defined PIP_INDEX_URL set "PIP_ARGS=%PIP_ARGS% --index-url %PIP_INDEX_URL%"
    python -m pip install %PIP_ARGS% -r backend\requirements.txt
    if errorlevel 1 (
        echo Backend dependency installation failed.
        echo If PyPI is unreachable, set PIP_INDEX_URL or install the requirements offline.
        exit /b 1
    )
) else (
    echo Backend dependencies already installed; skipping pip download.
)

REM Recheck the actual feature after installation; do not start a broken server.
python -c "import qrcode; from io import BytesIO; qrcode.make('startup-check').save(BytesIO(), format='PNG')"
if errorlevel 1 (
    echo QR PNG rendering check failed. Verify Pillow in the project virtual environment.
    exit /b 1
)

if not exist "frontend\node_modules\.bin\vite.cmd" (
    echo Installing frontend dependencies from package-lock.json...
    pushd frontend
    call npm.cmd ci
    if errorlevel 1 (
        echo Frontend dependency installation failed.
        popd
        exit /b 1
    )
    popd
) else (
    echo Frontend dependencies already installed; skipping npm download.
)

echo Building frontend...
pushd frontend
call npm.cmd run build
if errorlevel 1 (
    echo Frontend build failed.
    popd
    exit /b 1
)
popd

echo Running database migrations...
python -c "from backend.app.migrations import migrate; migrate()"
if errorlevel 1 (
    echo Database migration failed.
    exit /b 1
)

echo Loading seed data...
python -c "from backend.app.seed import main; main()"
if errorlevel 1 (
    echo Seed data loading failed.
    exit /b 1
)

echo.
echo ==========================================
echo   Case Sim System Starting...
echo ==========================================
echo.
echo Teacher Login: http://localhost:%APP_PORT%/teacher/login
echo.
echo Student Home: http://localhost:%APP_PORT%/student
echo.
echo Seed Student Case: http://localhost:%APP_PORT%/student/benchmark-demo-v4
echo.
echo For LAN access, open the same port via this computer's IPv4 address.
echo.
echo Press Ctrl+C to stop the server
echo ==========================================
echo.

set "PYTHONUTF8=1"
".venv\Scripts\python.exe" -u scripts\run_server.py
if errorlevel 1 echo Server failed. See the runtime log window and logs folder.
pause
