# case-sim · 高校商科 AI 案例推演平台

这是当前可独立运行的纯净源码目录。前后端、案例规则、演示数据与交付文档都在本目录内，不依赖搭档电脑上的局域网地址。

本目录是本地开发隔离副本，默认后端使用 `8100`、Vite 开发服务器使用 `5174`；原始 `case-sim` 目录保持 `8000` / `5173` 基线不变。端口可在 `backend/.env` 的 `APP_PORT`、`frontend/.env` 的 `VITE_DEV_PORT` 与 `VITE_BACKEND_PORT` 中调整。

项目的 AI / 平台分工、目录与交接步骤见 [架构分工与交接](docs/架构分工与交接.md)。

搭档交付入口：先读根目录 [交付说明.txt](交付说明.txt) 和 [AI工作提示交付.md](AI工作提示交付.md)。交付包不含本机 `.env`、虚拟环境、依赖安装目录、运行数据库、公网密钥或日志。

## 首次启动

在 Windows 命令行运行 `start.bat`。脚本会：

1. 首次运行时从 `backend/.env.example` 创建本地 `backend/.env`（该文件已被 git 忽略）；
2. 检查当前电脑的 `.venv` 是否可用；如果它来自另一台电脑，则移到旁边并在当前目录重新创建；
3. 安装前端依赖并构建 `frontend/dist`；
4. 执行幂等数据库迁移与内置演示案例 seed；
5. 在 `0.0.0.0:8100` 启动 FastAPI，并同时托管前端页面。

首次运行需要能访问 Python 与 npm 软件源。之后可直接再次运行脚本。

## 环境变量

- `TEACHER_PASSWORD`：教师登录密码；本地首次启动默认是 `local-dev-only`，建议修改。
- `DATABASE_URL`：可选，默认使用 `backend/data/app.db`。
- `LLM_PROVIDER` / `LLM_BASE_URL` / `LLM_API_KEY` / `LLM_MODEL`：OpenAI 兼容模型配置；未配置时 AI 功能返回明确错误，已发布案例的确定性推演仍可运行。
- `PUBLIC_BASE_URL`：可选。留空时根据当前请求地址生成二维码；跨设备演示时可填写 `http://本机局域网IP:8100`。

真实 AI 接入只需要编辑 `backend/.env`，不需要改前端代码：

```dotenv
LLM_PROVIDER=openai_compatible
LLM_BASE_URL=https://api.deepseek.com
LLM_API_KEY=你的密钥
LLM_MODEL=deepseek-flash
```

DeepSeek 地址填写根地址即可，调用层会统一发送 `POST {LLM_BASE_URL}/chat/completions`。模型也可以改为开放平台提供的其他名称，例如 `deepseek-v4-pro`。API Key 只保存在本机 `backend/.env`，不要提交到版本库。

当前调用层位于 `ai_component/providers/llm.py`。案例生成由数据库任务驱动，任务阶段和制品可通过以下教师接口查询：

- `GET /api/ai-tasks/{task_id}`：任务状态；
- `GET /api/ai-tasks/{task_id}/steps`：阶段记录；
- `GET /api/ai-tasks/{task_id}/artifacts`：原始素材、生成稿和校验报告；
- `GET /api/ai-tasks/{task_id}/output`：成功后的结构化输出。

任务记录在服务重启后会自动恢复；学生复盘接口在生成期间返回 `status=pending`，前端会自动轮询。

## 访问地址

启动时会额外打开教师端/学生端共用的实时日志窗口，日志同时保存到根目录
`logs`。上传、AI阶段、重试、决策输出及错误查看方式见 [运行日志说明](docs/运行日志.md)。

- 教师端：`http://localhost:8100/teacher/login`
- 内置演示案例：`http://localhost:8100/student/benchmark-demo-v4`
- 学生端常驻入口：`http://localhost:8100/student`；登录后直接显示教师已发布案例；令牌、链接与扫码作为可选入口保留。

## 测试

- 后端：先按需运行 `python -m pip install -r backend/requirements-dev.txt`，再运行 `python -m pytest backend/tests ai_component/tests -q`
- 前端：在 `frontend` 目录运行 `npm.cmd test` 和 `npm.cmd run build`

## 已知限制

- 案例生成、答疑和复盘使用外部模型；学生决策只使用教师发布并冻结的结果。
- 不再保留旧的自由决策 AI 估算/稳健降级入口，避免与教师发布结果冲突。
- `start.bat` 面向 Windows，首次安装依赖需要可访问 Python 与 npm 软件源。
- `.venv` 是每台电脑独立生成的运行环境，不要复制或提交；脚本会在当前项目目录中重新创建它。
- `backend/data/app.db`、`backend/app/static/qrcode/` 和 `frontend/dist/` 都是运行产物，不是源码配置；它们已被 git 忽略。
# 公网测试入口

双击 `start-public.bat` 启动五个密钥隔离的测试空间；原 `start.bat` 保持本地开发用途。
`start-public.bat` 可首次独立创建 `.venv`、安装缺失依赖并构建前端；不需要先运行会启动本地服务和加载 seed 的 `start.bat`。
参见 [公网测试使用说明](docs/公网测试使用说明.md) 与 [验收记录](docs/公网测试验收.md)。
长期密钥保存在本机 `private/public-test/access-keys.json`，不要提交或整份群发。
