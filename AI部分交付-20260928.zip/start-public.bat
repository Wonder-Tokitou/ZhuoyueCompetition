@echo off
setlocal
cd /d "%~dp0"
set "PYTHONUTF8=1"

REM Create a private local environment from the safe template on first run.
if not exist "backend\.env" (
    copy /Y "backend\.env.example" "backend\.env" >nul
    echo Created backend\.env from backend\.env.example.
    echo Edit it to configure DeepSeek before using AI features.
)

REM A virtual environment is computer-specific; recreate a copied/broken one.
if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" --version >nul 2>&1
    if errorlevel 1 (
        echo Existing .venv is not usable; moving it aside for recovery.
        ren ".venv" ".venv.invalid-%RANDOM%"
    )
)

if not exist ".venv\Scripts\python.exe" (
    echo Creating local Python environment...
    python -m venv --copies .venv
    if errorlevel 1 (
        echo Failed to create .venv. Install Python and retry.
        pause
        exit /b 1
    )
)

call .venv\Scripts\activate.bat
if errorlevel 1 (
    echo Failed to activate the project Python environment.
    pause
    exit /b 1
)

python -c "import fastapi, uvicorn, sqlalchemy, pydantic, httpx, multipart, pypdf, qrcode, PIL, dotenv; from io import BytesIO; qrcode.make('startup-check').save(BytesIO(), format='PNG')" >nul 2>&1
if errorlevel 1 (
    echo Installing backend dependencies...
    set "PIP_ARGS=--default-timeout=120 --retries=5 --prefer-binary"
    if defined PIP_INDEX_URL set "PIP_ARGS=%PIP_ARGS% --index-url %PIP_INDEX_URL%"
    python -m pip install %PIP_ARGS% -r backend\requirements.txt
    if errorlevel 1 (
        echo Backend dependency installation failed.
        echo If PyPI is unreachable, set PIP_INDEX_URL or install the requirements offline.
        pause
        exit /b 1
    )
)

python -c "import qrcode; from io import BytesIO; qrcode.make('startup-check').save(BytesIO(), format='PNG')"
if errorlevel 1 (
    echo QR image support is unavailable. Check Pillow in .venv.
    pause
    exit /b 1
)

if not exist "frontend\node_modules\.bin\vite.cmd" (
    echo Installing frontend dependencies from package-lock.json...
    pushd frontend
    call npm.cmd ci
    if errorlevel 1 (
        echo Frontend dependency installation failed. Install Node.js/npm and retry.
        popd
        pause
        exit /b 1
    )
    popd
)

echo Building frontend...
pushd frontend
call npm.cmd run build
if errorlevel 1 (
    echo Frontend build failed.
    popd
    pause
    exit /b 1
)
popd

echo Starting five isolated public spaces. No local demo cases are seeded.
echo Links: private\public-test\links.json
echo Access keys: private\public-test\access-keys.json
echo Each space keeps its own database under private\public-test\spaces\test-N.
echo Quick Tunnel URL changes after restart; the same space key still addresses retained records.
echo Press Ctrl+C to close the public service and its child processes.
echo.

".venv\Scripts\python.exe" -u scripts\run_public.py
if errorlevel 1 echo Public service failed. Inspect private\public-test\tunnel.log and spaces\test-N\process.log.
pause
