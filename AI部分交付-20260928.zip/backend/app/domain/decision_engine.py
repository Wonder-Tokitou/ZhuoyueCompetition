"""确定性指标校验与差值；学生决策不包含模型调用或模型降级。"""
import json, re
from typing import Any, Dict, List, Tuple
from backend.app.domain import rules
from backend.app.observability import log

KEYS = ("revenue", "gross_margin", "market_share", "cash_flow")

def _pct(v: Any) -> bool:
    return isinstance(v, str) and re.fullmatch(r"-?\d+(?:\.\d)?%", v) is not None

def validate_metrics(m: Any) -> Tuple[bool, str]:
    if not isinstance(m, dict) or set(m) != set(KEYS): return False, "指标必须恰好包含四键"
    if not isinstance(m["revenue"], (int, float)): return False, "revenue 必须为数值"
    if not _pct(m["gross_margin"]) or not _pct(m["market_share"]): return False, "百分比必须保留一位小数"
    if not isinstance(m["cash_flow"], str) or not m["cash_flow"].strip(): return False, "cash_flow 必须为非空字符串"
    return True, ""

def delta(before: Dict[str, Any], after: Dict[str, Any]) -> Dict[str, Any]:
    def p(v): return float(str(v).rstrip('%'))
    return {"revenue": float(after["revenue"])-float(before["revenue"]),
            "gross_margin": p(after["gross_margin"])-p(before["gross_margin"]),
            "market_share": p(after["market_share"])-p(before["market_share"]),
            "cash_flow": {"from": str(before["cash_flow"]), "to": str(after["cash_flow"])} }
