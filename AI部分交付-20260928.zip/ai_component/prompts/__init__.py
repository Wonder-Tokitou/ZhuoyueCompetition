"""ai_component/prompts."""
