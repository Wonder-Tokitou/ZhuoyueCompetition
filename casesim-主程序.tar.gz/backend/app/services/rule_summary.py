"""Deterministic teacher summaries; never invent a unique later-round outcome."""
import re
from backend.app.domain.progressive import apply_impact, baseline
from backend.app.domain.progressive import Impact
from backend.app.domain.process_metrics import inferred_impact

MARKER = '【递进指标同步】'

def summary_for_rule(original, impact, initial=None, case_type=None):
    # Replace old generated block, not append another copy on each save.
    prose = (original or '').split(MARKER)[0].split('较上一轮：')[0].strip()
    # Legacy AI summaries mix preset metrics into prose. Retain only complete
    # qualitative sentences without metric claims which could contradict rules.
    sentences = re.split(r'(?<=[。！？])', prose)
    prose = ''.join(s for s in sentences if not re.search(
        r'(营收|收入|毛利率|份额|现金流|现金净流|净利润|营业成本|运营费用).*(?:\d|上升|下降|增加|减少|改善|持平|维持|流出|流入|升至|降至)', s)).strip()
    def change(value, unit):
        return ('增加' if value > 0 else '减少' if value < 0 else '不变') + (f'{abs(value):g}{unit}' if value else '')
    professional = ''
    if case_type:
        rule = Impact.model_validate(impact)
        process = {**inferred_impact(case_type, rule), **({k:v for k,v in rule.process.model_dump().items() if v is not None} if rule.process else {})}
        labels = {
            '市场营销类': [('unit_sales_pct','单位销量','%'),('satisfaction_pp','客户满意度','分'),
                          ('channel_coverage_pp','渠道覆盖度','个百分点'),
                          ('pricing_tier_step','定价策略档位','档'),
                          ('product_mix_width_delta','产品组合宽度','个SKU')],
            '战略决策类': [('market_capacity_pct','目标市场容量','%'),('industry_growth_pp','行业增长率','个百分点'),
                          ('competition_intensity_pp','竞争强度','分'),('resource_match_pp','资源匹配度','分'),
                          ('risk_score_pp','风险等级','分'),('target_market_share_pp','预期市场占有率','个百分点')],
            '财务管理类': [('profitability_pp','盈利质量','分'),('liquidity_pp','现金流安全','分'),('solvency_pp','偿债能力','分'),('efficiency_pp','运营效率','分')],
        }.get(case_type, [])
        professional = '专业指标：' + '；'.join(f'{label}{change(process[key], unit)}' for key,label,unit in labels) + '。\n'
    text = professional + '较上一轮：' + '；'.join(f'{label}{change(impact[key], unit)}' for key,label,unit in [
        ('revenue_pct','营收','%'),('margin_pp','毛利率','个百分点'),
        ('expense_pct','运营费用','%'),('cash_pct','现金净流量','%'),('share_pp','市场份额','个百分点')]) + '。'
    if initial is not None:
        after = apply_impact(initial, impact, case_type)
        text += f'按当前基准计算：营收{after["revenue"]:.2f}万元，毛利率{after["gross_margin"]}，市场份额{after["market_share"]}，运营费用{after["operating_expense"]:.2f}万元，净利润{after["net_profit"]:.2f}万元，现金净流量{after["cash_flow_amount"]:.2f}万元。'
    else:
        text += '具体结果随前序选择而变化。'
    return (prose + '\n\n' if prose else '') + text

def sync_rule_summaries(case, config):
    case_type = getattr(case, 'case_type', None)
    initial = baseline(case.base_metrics_json, case.financial_assumptions_json, config['cash_flow_amount'], case_type)
    summaries = {}
    for node in case.nodes:
        for option in node.option_results:
            key = f'{node.id}:{option.option_key}'
            option.summary = summary_for_rule(option.summary, config['rules'][key], initial if node.idx == 1 else None, case_type)
            summaries[key] = option.summary
    return summaries
