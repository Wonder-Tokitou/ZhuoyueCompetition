"""Project an authorized teacher case/node into model evidence."""
from ai_component import suggest_fix as generate_suggestion


def advice_mode_hint(case_type: str) -> str:
    """按分析模式给出校准侧重（文档 2.6-3）；财务模式保持原有提示，返回空串。"""
    return {
        "市场营销类": "【校准重点】营销模式：优先核对营销 ROI 合理性与费用投入配比，并检查销量、市场份额、客户满意度、复购率是否自洽。",
        "战略决策类": "【校准重点】战略模式：优先核对风险与收益的匹配度、资源投入回收期，并检查风险指数与资源匹配度是否反向冲突。",
    }.get(case_type, "")


async def suggest_fix(case, node, question):
    context = [
        "【案例标题】" + (case.title or ""),
        "【企业背景】" + (case.background or ""),
        "【核心经营困境】" + (case.dilemma or ""),
        "【案例类型】" + case.case_type,
    ]
    # 按分析模式给出校准侧重（文档 2.6-3）；财务模式保持原有提示。
    mode_hint = advice_mode_hint(case.case_type)
    if mode_hint:
        context.append(mode_hint)
    if node is not None:
        lines = [
            "【节点序号】第 %d 个（%s）" % (node.idx, node.node_role),
            "【节点标题】" + node.title,
            "【节点背景】" + node.background,
        ]
        for option in sorted(node.option_results, key=lambda option: option.option_key):
            lines.append(
                "【选项%s】风险等级=%s；文案=%s；结果摘要=%s；指标=%s"
                % (option.option_key, option.risk_level, option.label,
                   option.summary, option.metrics_json)
            )
        context.append("\n".join(lines))

    return await generate_suggestion(context, question)
