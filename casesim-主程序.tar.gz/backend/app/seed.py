"""Idempotently seed the bundled benchmark case without calling external services."""
from datetime import datetime
from json import loads
from pathlib import Path
from typing import Any, Dict, List

from sqlalchemy import select
from sqlalchemy.orm import Session

from backend.app import models
from backend.app.domain import rules
from backend.app.db import SessionLocal
from backend.app.paths import PROJECT_ROOT

SEED_STUDENT_TOKEN = "benchmark-demo-v4"
SEED_TEACHER_TOKEN = "benchmark-seed-owner"

# 三套决策选项库（文档第 6 章）：每个案例 3 节点 × 3 选项，选项带五要素决策依据。
OPTION_LIBRARY_DIR = PROJECT_ROOT / "docs" / "决策选项库"
OPTION_LIBRARY_FILES = (
    "市场营销-花漾美妆新品上市.json",
    "战略决策-家电企业国际化.json",
    "财务管理-装备制造产能扩建.json",
)


def seed_demo_case(db: Session) -> models.Case:
    existing = db.scalar(select(models.Case).where(models.Case.student_token == SEED_STUDENT_TOKEN))
    if existing is not None:
        return existing

    source: dict[str, Any] = rules.SAMPLE_CASE
    framework = db.scalar(select(models.Framework).where(models.Framework.name == source["framework"]))
    if framework is None:
        framework = models.Framework(
            name=source["framework"], prompt_template="Bundled benchmark framework",
            output_schema=source["standard_review"], version="v1",
        )
        db.add(framework)
        db.flush()

    raw_base = source["base_metrics"]
    case = models.Case(
        title=source["title"], source_text=source["background"], status="published",
        framework_id=framework.id, teacher_token=SEED_TEACHER_TOKEN,
        student_token=SEED_STUDENT_TOKEN, published_at=datetime.now(),
        case_type=source["case_type"], source_kind="material", owner_type="teacher",
        background=source["background"], dilemma=source["dilemma"], version=1,
        base_metrics_json={
            "revenue": raw_base["monthly_revenue_per_store"],
            "gross_margin": raw_base["gross_margin"],
            "market_share": raw_base["market_share"],
            "cash_flow": "稳健",
        },
    )
    db.add(case)
    db.flush()
    results = {(item["node_index"], item["option_key"]): item for item in source["simulation_results"]}
    for index, raw_node in enumerate(source["nodes"], start=1):
        node = models.Node(
            case_id=case.id, idx=index, scenario=raw_node["background"],
            node_role=raw_node["node_role"], title=raw_node["title"],
            background=raw_node["background"], options_json=raw_node["options"],
        )
        db.add(node)
        db.flush()
        for raw_option in raw_node["options"]:
            result = results[(index, raw_option["option_key"])]
            db.add(models.OptionResult(
                node_id=node.id, option_key=raw_option["option_key"], label=raw_option["label"],
                risk_level=raw_option["risk_level"], metrics_json=result["metrics"],
                summary=result["summary"],
            ))
    db.commit()
    db.refresh(case)
    return case


def load_option_library() -> List[Dict[str, Any]]:
    """读取三套决策选项库；缺文件或 JSON 非法时直接抛错，不静默跳过。"""
    cases: List[Dict[str, Any]] = []
    for name in OPTION_LIBRARY_FILES:
        path: Path = OPTION_LIBRARY_DIR / name
        if not path.is_file():
            raise FileNotFoundError("决策选项库缺少文件：%s" % path)
        cases.append(loads(path.read_text(encoding="utf-8")))
    return cases


def seed_option_library(db: Session) -> List[models.Case]:
    """把三套决策选项库写入校案例库；按案例类型幂等，重复调用只补齐不重建。"""
    seeded: List[models.Case] = []
    for source in load_option_library():
        case_type = source["case_type"]
        mode = {"市场营销类": "marketing", "战略决策类": "strategy",
                "财务管理类": "finance"}[case_type]
        token = "option-library-%s" % mode
        case = db.scalar(select(models.Case).where(models.Case.student_token == token))
        if case is None:
            framework = db.scalar(select(models.Framework).where(
                models.Framework.name == source["framework"]))
            if framework is None:
                framework = models.Framework(
                    name=source["framework"], prompt_template="决策选项库配套分析框架",
                    output_schema={}, version="v1",
                )
                db.add(framework)
                db.flush()
            case = models.Case(
                title=source["title"], source_text=source["background"], status="published",
                framework_id=framework.id, teacher_token="option-library-owner-%s" % mode,
                student_token=token, published_at=datetime.now(),
                case_type=case_type, source_kind="material", owner_type="teacher",
                background=source["background"], dilemma=source["dilemma"], version=1,
                base_metrics_json=dict(source["base_metrics"]),
                financial_assumptions_json=dict(source["financial_assumptions"]),
                library_scope="school", mode=mode,
            )
            db.add(case)
            db.flush()
        for index, raw_node in enumerate(source["nodes"], start=1):
            node = db.scalar(select(models.Node).where(
                models.Node.case_id == case.id, models.Node.idx == index))
            if node is None:
                node = models.Node(
                    case_id=case.id, idx=index, scenario=raw_node["background"],
                    node_role=raw_node["node_role"], title=raw_node["title"],
                    background=raw_node["background"], options_json=raw_node["options"],
                )
                db.add(node)
                db.flush()
            for raw_option in raw_node["options"]:
                result = db.scalar(select(models.OptionResult).where(
                    models.OptionResult.node_id == node.id,
                    models.OptionResult.option_key == raw_option["option_key"]))
                if result is None:
                    db.add(models.OptionResult(
                        node_id=node.id, option_key=raw_option["option_key"],
                        label=raw_option["label"], risk_level=raw_option["risk_level"],
                        metrics_json=raw_option["metrics"], summary=raw_option["summary"],
                        detail_json=raw_option.get("detail"),
                    ))
        db.commit()
        db.refresh(case)
        seeded.append(case)
    return seeded


def main() -> None:
    with SessionLocal() as db:
        case = seed_demo_case(db)
        print(f"Seed ready: case_id={case.id}, student_token={case.student_token}")
        for item in seed_option_library(db):
            print(f"Option library ready: case_id={item.id}, case_type={item.case_type}")


if __name__ == "__main__":
    main()
