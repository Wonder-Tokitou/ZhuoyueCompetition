"""三套分析框架的专业过程指标层（叠加在共用财务引擎之上）。

市场营销、战略决策、财务管理三套框架各有自己的核心指标：
- 市场营销：单位销量、市场份额、客户满意度、渠道覆盖度、定价策略档位、产品组合宽度
- 战略决策：目标市场容量、行业增长率、竞争强度、资源匹配度（三档）、风险等级（三档）、预期市场占有率
- 财务管理：营业收入、营业成本与毛利率、运营费用、净利润、现金流（沿用共用财务引擎）

指标定义、基准、反推系数、合理区间与档位来自 docs/营销规则.json、docs/战略规则.json
（文档 2.3.1）；财务管理模式按文档要求保持原有逻辑，系数仍在本文件内。
"""
from __future__ import annotations

from typing import Any

from backend.app.domain import rules as _rules

MARKETING = "市场营销类"
STRATEGY = "战略决策类"

MARKETING_RULES = _rules.MARKETING_RULES
STRATEGY_RULES = _rules.STRATEGY_RULES

#: 营销：单轮市场份额变动建议区间（正负个百分点）
SHARE_PP_LIMIT = float(MARKETING_RULES["ranges"]["market_share_pp_limit"])
#: 营销：客户满意度合理区间
SATISFACTION_RANGE = (float(MARKETING_RULES["ranges"]["customer_satisfaction_min"]),
                      float(MARKETING_RULES["ranges"]["customer_satisfaction_max"]))
#: 战略：风险指数高位阈值与资源匹配度低位阈值
STRATEGY_RISK_HIGH = float(STRATEGY_RULES["ranges"]["risk_score_high"])
STRATEGY_MATCH_LOW = float(STRATEGY_RULES["ranges"]["resource_match_low"])

#: 三档指标：档位名 → 档位下界分值
TIERS = {
    "pricing_tier": MARKETING_RULES["tiers"]["pricing_tier"],
    "resource_match": STRATEGY_RULES["tiers"]["resource_match"],
    "risk_level": STRATEGY_RULES["tiers"]["risk_level"],
}


def clamp(value: float, low: float = 0.0, high: float = 100.0) -> float:
    return round(min(max(float(value), low), high), 2)


def _share_of(metrics: dict[str, Any]) -> float | None:
    """案例基准里的市场份额（百分数字符串或数值）；缺失返回 None。"""
    raw = metrics.get("market_share")
    if raw is None:
        return None
    try:
        return float(str(raw).rstrip("%") or 0)
    except ValueError:
        return None


def baseline(case_type: str, metrics: dict[str, Any],
             override: dict[str, Any] | None = None) -> dict[str, float]:
    """模式基准过程指标；override 来自案例的 process_baseline_json（教师可改）。

    市场份额类指标优先取案例基准（教师填的真实数字），取不到才回落到规则默认值，
    保证「教师改任一基准指标，全链路数据自动重算」。
    """
    share = _share_of(metrics)
    if case_type == MARKETING:
        result = {key: float(value) for key, value in MARKETING_RULES["baseline"].items()}
    elif case_type == STRATEGY:
        result = {key: float(value) for key, value in STRATEGY_RULES["baseline"].items()}
        if share is not None:
            result["target_market_share"] = share
    else:
        result = {"profitability": 60.0, "liquidity": 70.0,
                  "solvency": 70.0, "operating_efficiency": 65.0}
    for key, value in (override or {}).items():
        if key in result and value is not None:
            try:
                result[key] = float(value)
            except (TypeError, ValueError):
                continue
    return result


def inferred_impact(case_type: str, impact: Any) -> dict[str, float]:
    """由财务影响反推过程指标的单轮变化量。"""
    revenue, margin = float(impact.revenue_pct), float(impact.margin_pp)
    expense, cash, share = float(impact.expense_pct), float(impact.cash_pct), float(impact.share_pp)
    if case_type == MARKETING:
        co = MARKETING_RULES["impact_coefficients"]
        return {
            "unit_sales_pct": round(revenue * float(co["unit_sales_pct_per_revenue_pct"]), 2),
            "satisfaction_pp": round(margin * float(co["satisfaction_pp_per_margin_pp"]), 2),
            "channel_coverage_pp": round(expense * float(co["channel_coverage_pp_per_expense_pct"]), 2),
            "pricing_tier_step": round(margin * float(co["pricing_tier_step_per_margin_pp"]), 2),
            "product_mix_width_delta": round(revenue * float(co["product_mix_width_per_revenue_pct"]), 2),
        }
    if case_type == STRATEGY:
        co = STRATEGY_RULES["impact_coefficients"]
        return {
            "market_capacity_pct": round(revenue * float(co["market_capacity_pct_per_revenue_pct"]), 2),
            "industry_growth_pp": round(revenue * float(co["industry_growth_pp_per_revenue_pct"]), 2),
            "competition_intensity_pp": round(share * float(co["competition_intensity_pp_per_share_pp"]), 2),
            "resource_match_pp": round((revenue - expense) * float(co["resource_match_pp_per_gap"]), 2),
            "risk_score_pp": round((expense - cash) * float(co["risk_score_pp_per_gap"]), 2),
            "target_market_share_pp": round(share * float(co["target_market_share_pp_per_share_pp"]), 2),
        }
    return {"profitability_pp": round(margin + revenue * 0.1, 2),
            "liquidity_pp": round(cash * 0.1, 2), "solvency_pp": round(-expense * 0.1, 2),
            "efficiency_pp": round((revenue - expense) * 0.1, 2)}


def delta_for(case_type: str, impact: Any) -> dict[str, float]:
    """合并「由财务影响反推的过程指标变化」与「教师显式填写的过程指标变化」。"""
    supplied = impact.process.model_dump() if impact.process is not None else {}
    return {**inferred_impact(case_type, impact), **{k: v for k, v in supplied.items() if v is not None}}


def apply(before: dict[str, Any], case_type: str, impact: Any) -> dict[str, float]:
    delta = delta_for(case_type, impact)
    if case_type == MARKETING:
        r = MARKETING_RULES["ranges"]
        return {
            "unit_sales": round(float(before.get("unit_sales", 100))
                                * (1 + delta["unit_sales_pct"] / 100), 2),
            "customer_satisfaction": clamp(float(before.get("customer_satisfaction", 70))
                                           + delta["satisfaction_pp"], *SATISFACTION_RANGE),
            "channel_coverage": clamp(float(before.get("channel_coverage", 45))
                                      + delta["channel_coverage_pp"],
                                      float(r["channel_coverage_min"]), float(r["channel_coverage_max"])),
            "pricing_tier": float(min(max(round(float(before.get("pricing_tier", 2))
                                                + delta["pricing_tier_step"]),
                                          int(float(r["pricing_tier_min"]))),
                                      int(float(r["pricing_tier_max"])))),
            "product_mix_width": clamp(float(before.get("product_mix_width", 6))
                                       + delta["product_mix_width_delta"],
                                       float(r["product_mix_width_min"]), float(r["product_mix_width_max"])),
        }
    if case_type == STRATEGY:
        r = STRATEGY_RULES["ranges"]
        return {
            "market_capacity": round(float(before.get("market_capacity", 100))
                                     * (1 + delta["market_capacity_pct"] / 100), 2),
            "industry_growth": clamp(float(before.get("industry_growth", 8)) + delta["industry_growth_pp"],
                                     float(r["industry_growth_min"]), float(r["industry_growth_max"])),
            "competition_intensity": clamp(float(before.get("competition_intensity", 55))
                                           + delta["competition_intensity_pp"],
                                           float(r["competition_intensity_min"]),
                                           float(r["competition_intensity_max"])),
            "resource_match": clamp(float(before.get("resource_match", 70)) + delta["resource_match_pp"]),
            "risk_score": clamp(float(before.get("risk_score", 35)) + delta["risk_score_pp"]),
            "target_market_share": clamp(float(before.get("target_market_share", 12))
                                           + delta["target_market_share_pp"],
                                           float(r["target_market_share_min"]),
                                           float(r["target_market_share_max"])),
        }
    return {
        "profitability": clamp(float(before.get("profitability", 60)) + delta["profitability_pp"]),
        "liquidity": clamp(float(before.get("liquidity", 70)) + delta["liquidity_pp"]),
        "solvency": clamp(float(before.get("solvency", 70)) + delta["solvency_pp"]),
        "operating_efficiency": clamp(float(before.get("operating_efficiency", 65)) + delta["efficiency_pp"]),
    }


def tier_of(key: str, value: float | None) -> str | None:
    """把三档指标的分值换算成档位名（定价策略 / 资源匹配度 / 风险等级）。

    阈值为档位下界，取「不超过当前分值的最大下界」对应的档位。
    """
    tiers = TIERS.get(key)
    if not tiers or value is None:
        return None
    current = None
    for name, low in sorted(tiers.items(), key=lambda item: float(item[1])):
        if float(value) >= float(low):
            current = name
    return current


def _as_impact(impact: Any) -> Any:
    """接受已校验的 Impact，或快照里未经校验的 dict（延迟导入避免循环依赖）。"""
    if isinstance(impact, dict):
        from backend.app.domain.progressive import Impact
        return Impact.model_validate(impact)
    return impact


def warnings(before: dict[str, Any], case_type: str, impact: Any, after: dict[str, Any]) -> list[dict[str, str]]:
    """按模式给出本轮的过程指标提示，不改变任何计算结果。

    warning = 超出建议区间（前端黄色提示）；danger = 组合难以支撑（前端红色预警）。
    """
    impact = _as_impact(impact)
    delta = delta_for(case_type, impact)
    found: list[dict[str, str]] = []
    if case_type == MARKETING:
        share_pp = float(getattr(impact, "share_pp", 0) or 0)
        if abs(share_pp) > SHARE_PP_LIMIT:
            found.append({"level": "warning",
                          "message": "本轮市场份额变动 %+.1f 个百分点，超出 ±%g 个百分点建议区间"
                                     % (share_pp, SHARE_PP_LIMIT)})
        raw = float(before.get("customer_satisfaction", 70)) + float(delta.get("satisfaction_pp", 0))
        low, high = SATISFACTION_RANGE
        if raw < low or raw > high:
            found.append({"level": "warning",
                          "message": "客户满意度推演值 %.1f%% 超出 %g%%—%g%% 合理区间，已按边界截断"
                                     % (raw, low, high)})
    if case_type == STRATEGY:
        risk = float(after.get("risk_score", 0))
        match = float(after.get("resource_match", 100))
        if risk >= STRATEGY_RISK_HIGH and match <= STRATEGY_MATCH_LOW:
            found.append({"level": "danger",
                          "message": "风险等级%s（%.0f 分）而资源匹配度%s（%.0f 分）：该组合难以支撑，请调整方案"
                                     % (tier_of("risk_level", risk), risk,
                                        tier_of("resource_match", match), match)})
    return found
