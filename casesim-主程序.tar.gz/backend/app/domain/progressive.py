"""Version 1 progressive simulation. Pure arithmetic, no model or database calls.

Amounts are 万元 per case accounting period. Rates are percent; margin/share
changes are percentage points. Cash is a signed period cash-flow amount, not
the cash balance. Negative cash × a positive growth rate becomes more negative.
"""
from decimal import Decimal, ROUND_HALF_UP
from itertools import product
import math
from typing import Any, Literal
from pydantic import BaseModel, ConfigDict, Field
from backend.app.domain.decision_engine import percentage
from backend.app.domain import process_metrics


class ProcessImpact(BaseModel):
    """过程指标的**单轮变化量**。

    字段按三套分析框架的指标定义命名（市场营销 / 战略决策 / 财务管理），
    与 docs/营销规则.json、docs/战略规则.json 的 process_metrics 一一对应。
    """
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)
    # 市场营销：单位销量、市场份额、客户满意度、渠道覆盖度、定价档位、产品组合宽度
    unit_sales_pct: float | None = Field(default=None, ge=-100, le=1000)
    satisfaction_pp: float | None = Field(default=None, ge=-100, le=100)
    channel_coverage_pp: float | None = Field(default=None, ge=-100, le=100)
    pricing_tier_step: float | None = Field(default=None, ge=-3, le=3)
    product_mix_width_delta: float | None = Field(default=None, ge=-30, le=30)
    # 战略决策：目标市场容量、行业增长率、竞争强度、资源匹配度、风险等级、预期市占率
    market_capacity_pct: float | None = Field(default=None, ge=-100, le=1000)
    industry_growth_pp: float | None = Field(default=None, ge=-100, le=100)
    competition_intensity_pp: float | None = Field(default=None, ge=-100, le=100)
    resource_match_pp: float | None = Field(default=None, ge=-100, le=100)
    risk_score_pp: float | None = Field(default=None, ge=-100, le=100)
    target_market_share_pp: float | None = Field(default=None, ge=-100, le=100)
    # 财务管理：盈利质量、现金流安全、偿债能力、运营效率
    profitability_pp: float | None = Field(default=None, ge=-100, le=100)
    liquidity_pp: float | None = Field(default=None, ge=-100, le=100)
    solvency_pp: float | None = Field(default=None, ge=-100, le=100)
    efficiency_pp: float | None = Field(default=None, ge=-100, le=100)


class Impact(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)
    revenue_pct: float = Field(ge=-100, le=1000)
    margin_pp: float = Field(ge=-100, le=100)
    expense_pct: float = Field(ge=-100, le=1000)
    cash_pct: float = Field(ge=-100, le=1000)
    share_pp: float = Field(ge=-100, le=100)
    process: ProcessImpact | None = None


class ReferencePath(BaseModel):
    model_config = ConfigDict(extra="forbid")
    path: str = Field(pattern=r'^[ABC]→[ABC]→[ABC]$')
    kind: Literal['recommended', 'historical'] = 'recommended'


class Configuration(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)
    enabled: bool = True
    cash_flow_amount: float
    rules: dict[str, Impact]
    reasoning: dict[str, dict] = Field(default_factory=dict)
    reference_path: ReferencePath | None = None


def money(value):
    if not math.isfinite(float(value)) or abs(float(value)) > 1e12:
        raise ValueError("财务金额超出可计算范围")
    return float(Decimal(str(value)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


#: 财务指标键：过程指标一律不得覆盖它们，否则下一轮按百分比解析会失败。
FINANCIAL_KEYS = frozenset({"revenue", "gross_margin", "market_share", "operating_cost",
                            "operating_expense", "net_profit", "cash_flow_amount", "cash_flow"})


def _merge_process(result: dict, process_values: dict) -> dict:
    """把过程指标并入结果，但绝不覆盖财务指标（键名冲突时丢弃过程指标）。"""
    for key, value in process_values.items():
        if key not in FINANCIAL_KEYS:
            result[key] = value
    return result


def baseline(metrics, assumptions, cash, case_type: str | None = None, process_baseline=None):
    revenue = money(metrics["revenue"])
    margin = percentage(metrics["gross_margin"])
    share = percentage(metrics["market_share"])
    expense = money(assumptions["operating_expense"])
    cost = money(revenue * (1 - margin / 100))
    if revenue < 0 or expense < 0 or not 0 <= margin <= 100 or not 0 <= share <= 100:
        raise ValueError("基准营收/费用须非负，毛利率/市场份额须在0—100%内")
    if abs(cost - float(assumptions["operating_cost"])) > 0.02:
        raise ValueError("基准营业成本与营收×(1−毛利率)不一致，请先核对保存")
    result = {**metrics, "revenue": revenue, "gross_margin": f"{margin:.1f}%",
            "market_share": f"{share:.1f}%", "operating_cost": cost,
            "operating_expense": expense, "net_profit": money(revenue-cost-expense),
            "cash_flow_amount": money(cash)}
    if case_type:
        result = _merge_process(result, process_metrics.baseline(case_type, metrics, process_baseline))
    return result


def apply_impact(before, impact, case_type: str | None = None):
    rule = Impact.model_validate(impact)
    revenue = money(before["revenue"] * (1 + rule.revenue_pct / 100))
    margin = round(percentage(before["gross_margin"]) + rule.margin_pp, 1)
    share = round(percentage(before["market_share"]) + rule.share_pp, 1)
    if not 0 <= margin <= 100 or not 0 <= share <= 100:
        raise ValueError("递进结果的毛利率或市场份额超出0—100%，请调整影响规则")
    cost = money(revenue * (1 - margin / 100))
    expense = money(before["operating_expense"] * (1 + rule.expense_pct / 100))
    cash = money(before["cash_flow_amount"] * (1 + rule.cash_pct / 100))
    result = {"revenue": revenue, "gross_margin": f"{margin:.1f}%",
            "market_share": f"{share:.1f}%", "operating_cost": cost,
            "operating_expense": expense, "net_profit": money(revenue-cost-expense),
            "cash_flow_amount": cash,
            "cash_flow": f"本期现金净流量 {cash:.2f} 万元"}
    if case_type:
        result = _merge_process(result, process_metrics.apply(before, case_type, rule))
    return result


def preview(snapshot, configuration, assumptions):
    config = Configuration.model_validate(configuration)
    nodes = sorted(snapshot["nodes"], key=lambda n: n["idx"])
    if [n["idx"] for n in nodes] != [1, 2, 3] or any(
        {o["key"] for o in n["options"]} != {"A", "B", "C"} or len(n["options"]) != 3 for n in nodes
    ):
        raise ValueError("递进模式需要完整的3节点×3选项")
    expected = {f'{n["id"]}:{o["key"]}' for n in nodes for o in n["options"]}
    if set(config.rules) != expected:
        raise ValueError("影响规则需与当前9个选项一一对应；重新生成节点后请重新确认规则")
    case_type = str(snapshot.get("case_type") or "")
    for node in nodes:
        seen = {}
        for option in node["options"]:
            rule_key = f'{node["id"]}:{option["key"]}'
            values = config.rules[rule_key].model_dump()
            financial_vector = tuple(float(values[name]) for name in (
                "revenue_pct", "margin_pp", "expense_pct", "cash_pct", "share_pp"
            ))
            process_values = values.get("process") or {}
            process_vector = tuple(float(value) for key, value in sorted(process_values.items()) if value is not None)
            vector = financial_vector + process_vector
            if all(value == 0 for value in vector):
                raise ValueError(
                    f'第{node["idx"]}轮选项{option["key"]}的影响规则不能全部为0；'
                    "否则学生选择不会改变任何经营结果"
                )
            duplicate = seen.get(vector)
            if duplicate is not None:
                raise ValueError(
                    f'第{node["idx"]}轮选项{duplicate}与{option["key"]}的影响规则不能相同；'
                    "不同方案必须产生可区分的经营结果"
                )
            seen[vector] = option["key"]
    initial = baseline(snapshot["base_metrics"], assumptions, config.cash_flow_amount, case_type,
                       snapshot.get("process_baseline"))
    paths = []
    alerts: list[dict[str, Any]] = []
    for choices in product("ABC", repeat=3):
        state = initial
        steps = []
        for node, key in zip(nodes, choices):
            rule = config.rules[f'{node["id"]}:{key}']
            before_step = state
            try:
                state = apply_impact(before_step, rule, case_type)
            except ValueError as exc:
                raise ValueError(f'路径 {"→".join(choices)} 第{node["idx"]}轮：{exc}') from exc
            for item in process_metrics.warnings(before_step, case_type, rule, state):
                alerts.append({**item, "round": node["idx"], "path": "→".join(choices)})
            steps.append(state)
        paths.append({"path": "→".join(choices), "steps": steps, "final": state})
    # 同一条提示在 27 条路径里会重复出现，按文案去重并保留首次命中的轮次与路径。
    unique: dict[str, dict[str, Any]] = {}
    for item in alerts:
        unique.setdefault(item["message"], item)
    return {"baseline": initial, "paths": paths, "warnings": list(unique.values())}
