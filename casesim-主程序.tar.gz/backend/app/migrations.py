"""幂等 SQLite 增量迁移。只追加列，不删除或重建业务数据。"""
import re
import shutil
from pathlib import Path
from sqlalchemy import inspect, text
from backend.app.observability import event
from backend.app.db import engine


def _quote_identifier(name: str) -> str:
    return '"%s"' % name.replace('"', '""')


def _retarget_create_table(sql: str, old_name: str, new_name: str) -> str:
    """Rename only the CREATE TABLE target and repair the broken session FK."""
    name = re.escape(old_name)
    pattern = rf'(?is)^(\s*CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?)(?:"{name}"|`{name}`|\[{name}\]|{name})(?=\s|\()'
    rewritten, count = re.subn(
        pattern,
        lambda match: match.group(1) + _quote_identifier(new_name),
        sql,
        count=1,
    )
    if count != 1:
        raise RuntimeError(f'无法解析 SQLite 建表语句：{old_name}')
    return rewritten.replace('"session_legacy"', '"session"').replace('session_legacy', 'session')


def _repair_broken_session_references(cur) -> None:
    """Repair child tables retargeted by the previously deployed rename migration.

    SQLite rewrites child foreign keys when a parent table is renamed.  The old
    migration renamed ``session`` to ``session_legacy`` and later dropped it, so
    inserts into turn/review/message/ai tables failed with HTTP 500.  Rebuild
    only affected child tables, preserving rows plus their explicit indexes and
    triggers. ``legacy_alter_table`` keeps grandchildren pointed at the stable
    public table name while each repaired table is swapped in.
    """
    affected = cur.execute(
        "SELECT name, sql FROM sqlite_master "
        "WHERE type='table' AND sql LIKE '%session_legacy%' ORDER BY name"
    ).fetchall()
    for table, create_sql in affected:
        temp = f'__repair_{table}_session_fk'
        if cur.execute(
            "SELECT 1 FROM sqlite_master WHERE name=?", (temp,)
        ).fetchone():
            raise RuntimeError(f'检测到未完成的迁移临时表：{temp}')
        columns = [row[1] for row in cur.execute(
            f'PRAGMA table_info({_quote_identifier(table)})'
        ).fetchall()]
        objects = cur.execute(
            "SELECT type, name, sql FROM sqlite_master "
            "WHERE tbl_name=? AND type IN ('index','trigger') AND sql IS NOT NULL",
            (table,),
        ).fetchall()
        cur.execute(_retarget_create_table(create_sql, table, temp))
        names = ', '.join(_quote_identifier(column) for column in columns)
        cur.execute(
            f'INSERT INTO {_quote_identifier(temp)} ({names}) '
            f'SELECT {names} FROM {_quote_identifier(table)}'
        )
        cur.execute(f'DROP TABLE {_quote_identifier(table)}')
        cur.execute(
            f'ALTER TABLE {_quote_identifier(temp)} RENAME TO {_quote_identifier(table)}'
        )
        for _kind, _name, object_sql in objects:
            cur.execute(
                object_sql.replace('"session_legacy"', '"session"').replace(
                    'session_legacy', 'session'
                )
            )
        event('已修复迁移遗留的 session 外键', table=table)

def migrate() -> None:
    # Back up the database actually being migrated, never the default production
    # path when a test or deployment supplied DATABASE_URL.
    if engine.dialect.name == "sqlite" and engine.url.database not in (None, "", ":memory:"):
        db_path = Path(engine.url.database).resolve()
        backup = Path(str(db_path) + ".bak-v5")
        if db_path.exists() and not backup.exists():
            shutil.copy2(db_path, backup)
    insp = inspect(engine)
    additions = {
        "case": {"version": "INTEGER NOT NULL DEFAULT 1", "input_filename": "VARCHAR(255)", "input_mime": "VARCHAR(128)", "input_size": "INTEGER", "base_net_profit": "FLOAT", "financial_assumptions_json": "JSON", "story_json": "JSON", "play_locked": "BOOLEAN NOT NULL DEFAULT 0", "teacher_id": "INTEGER REFERENCES teacher_account(id)", "library_scope": "VARCHAR(16) NOT NULL DEFAULT 'school'", "mode": "VARCHAR(16)", "process_baseline_json": "JSON", "deleted_at": "DATETIME"},
        "option_result": {"net_profit": "FLOAT", "financial_basis_json": "JSON", "detail_json": "JSON"},
        "session": {"student_id": "INTEGER REFERENCES student_account(id)", "case_version": "INTEGER NOT NULL DEFAULT 1", "case_snapshot_json": "JSON NOT NULL DEFAULT '{}'", "current_metrics_json": "JSON NOT NULL DEFAULT '{}'", "kind": "VARCHAR(16) NOT NULL DEFAULT 'formal'"},
        "student_account": {"class_name": "VARCHAR(64) NOT NULL DEFAULT ''"},
        "teacher_session": {"teacher_id": "INTEGER REFERENCES teacher_account(id)"},
        "turn": {"before_metrics_json": "JSON", "after_metrics_json": "JSON", "delta_metrics_json": "JSON", "result_source": "VARCHAR(32)"},
    }
    with engine.begin() as conn:
        for table, cols in additions.items():
            if not insp.has_table(table):
                continue
            existing = {c["name"] for c in inspect(conn).get_columns(table)}
            for name, ddl in cols.items():
                if name not in existing:
                    conn.execute(text('ALTER TABLE "%s" ADD COLUMN "%s" %s' % (table, name, ddl)))
        if insp.has_table("case"):
            conn.execute(text('UPDATE "case" SET version=1 WHERE version IS NULL'))
            # mode 只是 case_type 的语义别名（finance / marketing / strategy），
            # 历史案例按案例类型回填，case_type 本身不动。
            conn.execute(text(
                'UPDATE "case" SET mode = CASE "case_type" '
                "WHEN '财务管理类' THEN 'finance' "
                "WHEN '市场营销类' THEN 'marketing' "
                "WHEN '战略决策类' THEN 'strategy' END "
                'WHERE mode IS NULL'))
        if insp.has_table("session"):
            conn.execute(text('UPDATE "session" SET case_version=1 WHERE case_version IS NULL'))
            conn.execute(text("UPDATE \"session\" SET case_snapshot_json='{}' WHERE case_snapshot_json IS NULL"))
            conn.execute(text("UPDATE \"session\" SET current_metrics_json='{}' WHERE current_metrics_json IS NULL"))
            conn.execute(text("UPDATE \"session\" SET kind='formal' WHERE kind IS NULL"))
            # Keep legacy submissions intact. Add a DB-level one-run constraint
            # only when existing logged-in records are already unambiguous.
            duplicates = conn.execute(text(
                'SELECT COUNT(*) FROM (SELECT case_id, student_id FROM "session" '
                'WHERE student_id IS NOT NULL GROUP BY case_id, student_id HAVING COUNT(*) > 1)'
            )).scalar_one()
            if not duplicates:
                conn.execute(text('DROP INDEX IF EXISTS uq_session_case_student'))
            else:
                event("未创建学生案例唯一索引：保留了历史重复提交，需由学生或教师确认清理",
                      level=30, duplicate_groups=int(duplicates))
        # ── 班级成员关系：把 student_account.class_name 的历史数据转成多对多成员 ──
        # create_all 先于 migrate() 执行，所以 class_group / class_membership 此时已存在。
        if insp.has_table("class_group") and insp.has_table("student_account"):
            import hashlib
            legacy = conn.execute(text(
                "SELECT DISTINCT class_name FROM student_account WHERE class_name <> ''"
            )).fetchall()
            for (name,) in legacy:
                gid = conn.execute(text("SELECT id FROM class_group WHERE name = :n"), {"n": name}).scalar()
                if gid is None:
                    join_code = "class-" + hashlib.sha1(name.encode()).hexdigest()[:12]
                    conn.execute(text(
                        "INSERT INTO class_group (name, join_code, created_at) VALUES (:n, :c, CURRENT_TIMESTAMP)"),
                        {"n": name, "c": join_code})
                    gid = conn.execute(text("SELECT id FROM class_group WHERE name = :n"), {"n": name}).scalar()
                conn.execute(text(
                    "INSERT OR IGNORE INTO class_membership (class_id, student_id, joined_at) "
                    "SELECT :g, id, CURRENT_TIMESTAMP FROM student_account WHERE class_name = :n"),
                    {"g": gid, "n": name})
            if legacy:
                event("班级成员关系迁移完成", legacy_classes=len(legacy))
    # ── P0：practice 模式 ──────────────────────────────────────────────
    # 旧模型的 UniqueConstraint(case_id, student_id) 在 SQLite 里是表级 UNIQUE
    # （sqlite_autoindex_session_1），命名索引 DROP 删不掉它，practice 行会撞它。
    # SQLite 不支持删表级约束，只能重建表：拷数据 → 换新结构（无表级 UNIQUE）→ 建 3 元组唯一索引。
    with engine.raw_connection() as raw:
        raw.commit()
        cur = raw.cursor()
        foreign_keys = int(cur.execute("PRAGMA foreign_keys").fetchone()[0])
        legacy_alter_table = int(cur.execute("PRAGMA legacy_alter_table").fetchone()[0])
        cur.execute("PRAGMA foreign_keys=OFF")
        cur.execute("PRAGMA legacy_alter_table=ON")
        try:
            has_session = cur.execute(
                "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='session'"
            ).fetchone()[0]
            if has_session:
                sql = cur.execute(
                    "SELECT sql FROM sqlite_master WHERE type='table' AND name='session'"
                ).fetchone()[0] or ""
                # 只重建带有表级 UNIQUE(case_id, student_id[, kind]) 的旧表；
                # 已去掉该约束的新结构跳过。
                if re.search(r"UNIQUE\s*\(\s*case_id\s*,\s*student_id\s*(?:,\s*kind\s*)?\)", sql):
                    temp = '__session_without_pair_unique'
                    if cur.execute(
                        "SELECT 1 FROM sqlite_master WHERE name=?", (temp,)
                    ).fetchone():
                        raise RuntimeError(f'检测到未完成的迁移临时表：{temp}')
                    cur.execute('''
                        CREATE TABLE "__session_without_pair_unique" (
                            id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                            case_id INTEGER NOT NULL REFERENCES "case"(id),
                            kind VARCHAR(16) NOT NULL DEFAULT 'formal',
                            student_name VARCHAR(64) NOT NULL,
                            student_id INTEGER REFERENCES student_account(id),
                            created_at DATETIME NOT NULL,
                            finished_at DATETIME,
                            attempt_no INTEGER NOT NULL DEFAULT 1,
                            case_version INTEGER NOT NULL DEFAULT 1,
                            case_snapshot_json JSON NOT NULL,
                            current_metrics_json JSON NOT NULL
                        )''')
                    cols = ("id, case_id, kind, student_name, student_id, created_at, finished_at, "
                            "attempt_no, case_version, case_snapshot_json, current_metrics_json")
                    cur.execute(
                        f'INSERT INTO "{temp}" ({cols}) SELECT {cols} FROM "session"')
                    cur.execute('DROP TABLE "session"')
                    cur.execute(f'ALTER TABLE "{temp}" RENAME TO "session"')
                    event("session 表已重建：移除表级唯一约束，允许多次推演独立记录（practice 模式）")
                duplicate_groups = cur.execute(
                    'SELECT COUNT(*) FROM (SELECT case_id, student_id, kind FROM "session" '
                    'WHERE student_id IS NOT NULL GROUP BY case_id, student_id, kind HAVING COUNT(*) > 1)'
                ).fetchone()[0]
                if duplicate_groups:
                    event("历史数据中存在同一学生同一案例的多次推演，已按多条记录保留",
                          level=30, duplicate_groups=int(duplicate_groups))
                # 4.1 多次推演独立记录：同一学生同一案例允许多次推演，
                # 因此去掉 (case_id, student_id, kind) 的唯一索引，改为普通索引。
                cur.execute('DROP INDEX IF EXISTS uq_session_case_student_kind')
                cur.execute(
                    'CREATE INDEX IF NOT EXISTS ix_session_case_student '
                    'ON "session" (case_id, student_id)')
                cur.execute(
                    'CREATE INDEX IF NOT EXISTS ix_session_student_id ON "session" (student_id)')

            # Self-heal databases already processed by the broken rename-based
            # migration before this fix was deployed.
            _repair_broken_session_references(cur)
            leftovers = cur.execute(
                "SELECT name FROM sqlite_master WHERE sql LIKE '%session_legacy%'"
            ).fetchall()
            if leftovers:
                raise RuntimeError(f'仍有对象引用 session_legacy：{leftovers}')
            raw.commit()
        except Exception:
            raw.rollback()
            raise
        finally:
            cur.execute(f"PRAGMA legacy_alter_table={legacy_alter_table}")
            cur.execute(f"PRAGMA foreign_keys={foreign_keys}")

    # ── P0 迁移结束 ──────────────────────────────────────────────────────
