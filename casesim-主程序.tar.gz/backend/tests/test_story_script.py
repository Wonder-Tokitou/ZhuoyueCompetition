from ai_component.prompts.case_generation import build_messages
from backend.app import models
from backend.app.integrations.ai.evidence import teaching_policy
from backend.app.services.simulation import live_snapshot


def test_case_generation_requires_separate_story_script():
    messages = build_messages(
        "一家企业正在决定下一阶段经营方向。" * 20,
        "material",
        "战略决策类",
        "",
        policy=teaching_policy(),
    )
    prompt = messages[0]["content"]
    assert '"story"' in prompt
    assert "剧情台词不得替代或改写专业术语" in prompt
    assert "正常模式" in prompt and "剧情模式" in prompt
    assert "不得另造可点击方案" in prompt
    assert '"reason_phrases"' not in prompt


def test_story_script_is_part_of_the_frozen_case_snapshot(tmp_path):
    from backend.tests.test_mvp_smoke import temporary_db
    from backend.app.seed import seed_demo_case

    _, factory = temporary_db(tmp_path)
    story = {
        "cast": {"manager": "负责人", "finance": "财务负责人", "marketing": "市场负责人"},
        "opening": [{"speaker": "负责人", "text": "先看清局面，再作决定。"}],
        "rounds": [],
        "ending": [{"speaker": "负责人", "text": "复盘这三轮的取舍。"}],
    }
    with factory() as db:
        case = seed_demo_case(db)
        case.story_json = story
        db.commit()
        snap = live_snapshot(db.get(models.Case, case.id))
    assert snap["story"] == story
