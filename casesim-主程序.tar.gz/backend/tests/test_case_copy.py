"""共享校案例库：查看他人已发布案例，并深拷贝到个人库。"""
import secrets

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker

from backend.app import models
from backend.app.db import Base, get_db
from backend.app.main import app
from backend.app.routers import teacher


@pytest.fixture()
def env(tmp_path, monkeypatch):
    engine = create_engine(f"sqlite:///{tmp_path / 'share.db'}", connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine)
    factory = sessionmaker(bind=engine, autoflush=False, autocommit=False)

    def override_db():
        with factory() as db:
            yield db

    app.dependency_overrides[get_db] = override_db
    monkeypatch.setenv("TEACHER_PASSWORD", "admin-secret")
    monkeypatch.setattr(teacher, "schedule_task", lambda _: None)
    monkeypatch.setattr(teacher, "QRCODE_DIR", tmp_path / "qrcode")
    client = TestClient(app)
    yield client, factory
    app.dependency_overrides.clear()
    client.close()
    engine.dispose()


def _register(client, username, real_name):
    response = client.post("/api/teacher/register", json={
        "username": username, "real_name": real_name,
        "password": "teacher-pass", "admin_password": "admin-secret"})
    assert response.status_code in (200, 409), response.text


def _token(client, username):
    response = client.post("/api/teacher/login",
                           json={"username": username, "password": "teacher-pass"})
    assert response.status_code == 200, response.text
    return response.json()["teacher_token"]


def _teacher_id(factory, username):
    with factory() as db:
        return db.scalar(select(models.TeacherAccount.id).where(
            models.TeacherAccount.username == username))


def _make_case(factory, teacher_id, *, status="published", scope="school", version=3):
    with factory() as db:
        case = models.Case(
            title="花漾美妆·新品上市", source_text="素材", status=status,
            teacher_token=secrets.token_hex(16), student_token=secrets.token_hex(16),
            case_type="市场营销类", source_kind="material", owner_type="teacher",
            background="背景", dilemma="困境", version=version, teacher_id=teacher_id,
            library_scope=scope,
            base_metrics_json={"revenue": 200000, "gross_margin": "60.0%",
                               "market_share": "3.5%", "cash_flow": "稳健"},
            financial_assumptions_json={"operating_cost": 80000, "operating_expense": 24000})
        db.add(case)
        db.flush()
        rules = {}
        node_ids = []
        for idx in (1, 2, 3):
            node = models.Node(case_id=case.id, idx=idx, scenario="场景",
                               options_json=[{"key": key, "label": f"方案{key}"} for key in "ABC"],
                               node_role="核心策略", title=f"第{idx}轮", background="背景")
            db.add(node)
            db.flush()
            node_ids.append(node.id)
            for key, risk in zip("ABC", ("保守", "稳健", "激进")):
                db.add(models.OptionResult(
                    node_id=node.id, option_key=key, label=f"方案{key}",
                    metrics_json={"revenue": 200000, "gross_margin": "60.0%",
                                  "market_share": "3.5%", "cash_flow": "稳健"},
                    risk_level=risk, summary="摘要",
                    detail_json={"positioning": "定位", "actions": "动作", "investment": "投入",
                                 "expected_return": "预期", "tradeoff": "代价"}))
                rules["%d:%s" % (node.id, key)] = {
                    "revenue_pct": 2, "margin_pp": 0, "expense_pct": 0, "cash_pct": 0, "share_pp": 1}
        db.add(models.SimulationConfig(case_id=case.id, published_snapshot_json={"nodes": []},
                                       draft_json={"enabled": True, "cash_flow_amount": 10.0,
                                                   "rules": rules,
                                                   "reasoning": {key: {"basis": "依据"} for key in rules}}))
        db.commit()
        return case.id, node_ids


def test_shared_library_lists_only_others_published_school_cases(env):
    client, factory = env
    _register(client, "teacher_a", "张老师")
    _register(client, "teacher_b", "李老师")
    owner_id = _teacher_id(factory, "teacher_a")
    shared_id, _ = _make_case(factory, owner_id)
    _make_case(factory, owner_id, scope="personal")
    _make_case(factory, owner_id, status="draft")

    items = client.get("/api/teacher/library/shared", params={"token": _token(client, "teacher_b")}).json()
    assert [item["id"] for item in items] == [shared_id]
    assert items[0]["teacher_name"] == "张老师"
    assert items[0]["node_count"] == 3

    own = client.get("/api/teacher/library/shared", params={"token": _token(client, "teacher_a")}).json()
    assert own == []


def test_copy_deep_copies_nodes_options_and_remaps_rule_keys(env):
    client, factory = env
    _register(client, "teacher_a", "张老师")
    _register(client, "teacher_b", "李老师")
    owner_id = _teacher_id(factory, "teacher_a")
    reader_id = _teacher_id(factory, "teacher_b")
    source_id, source_nodes = _make_case(factory, owner_id)

    response = client.post(f"/api/teacher/cases/{source_id}/copy",
                           params={"token": _token(client, "teacher_b")})
    assert response.status_code == 200, response.text
    body = response.json()
    new_id = body["case"]["id"]
    assert new_id != source_id
    assert body["case"]["teacher_id"] == reader_id
    assert body["case"]["library_scope"] == "personal"
    assert body["case"]["status"] == "draft"
    assert body["case"]["version"] == 1
    assert len(body["nodes"]) == 3
    assert sum(len(node["options"]) for node in body["nodes"]) == 9

    with factory() as db:
        new_nodes = db.scalars(select(models.Node).where(models.Node.case_id == new_id)).all()
        new_node_ids = {node.id for node in new_nodes}
        assert new_node_ids.isdisjoint(set(source_nodes)), "副本必须使用新节点 ID"
        config = db.get(models.SimulationConfig, new_id)
        assert config is not None, "递进规则必须随复制带走"
        assert config.published_snapshot_json is None
        rule_heads = {int(key.split(":")[0]) for key in config.draft_json["rules"]}
        assert rule_heads == new_node_ids, "规则键必须重映射到副本节点"
        assert len(config.draft_json["rules"]) == 9
        assert {int(key.split(":")[0]) for key in config.draft_json["reasoning"]} == new_node_ids

        options = db.scalars(select(models.OptionResult).where(
            models.OptionResult.node_id.in_(new_node_ids))).all()
        assert len(options) == 9
        assert all(option.detail_json for option in options)


def test_copy_leaves_source_case_untouched(env):
    client, factory = env
    _register(client, "teacher_a", "张老师")
    _register(client, "teacher_b", "李老师")
    owner_id = _teacher_id(factory, "teacher_a")
    source_id, source_nodes = _make_case(factory, owner_id)

    client.post(f"/api/teacher/cases/{source_id}/copy", params={"token": _token(client, "teacher_b")})

    with factory() as db:
        source = db.get(models.Case, source_id)
        assert source.library_scope == "school"
        assert source.status == "published"
        assert source.version == 3
        assert source.teacher_id == owner_id
        assert {node.id for node in db.scalars(
            select(models.Node).where(models.Node.case_id == source_id))} == set(source_nodes)
        config = db.get(models.SimulationConfig, source_id)
        assert config.published_snapshot_json == {"nodes": []}


def test_copy_rejects_case_outside_shared_library(env):
    client, factory = env
    _register(client, "teacher_a", "张老师")
    _register(client, "teacher_b", "李老师")
    owner_id = _teacher_id(factory, "teacher_a")
    draft_id, _ = _make_case(factory, owner_id, status="draft")
    token = _token(client, "teacher_b")
    assert client.post(f"/api/teacher/cases/{draft_id}/copy", params={"token": token}).status_code == 404
