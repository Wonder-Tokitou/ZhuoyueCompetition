"""AI 三处按分析模式分化：生成提示词 / 复盘提示词 / 校准助手。"""
from ai_component.agents.student_agent import review_mode_focus
from ai_component.prompts.case_generation import build_messages
from backend.app.integrations.ai.teacher_advice import advice_mode_hint

from backend.tests.test_confirmed_baseline_scope import teaching_policy

MODES = ["战略决策类", "市场营销类", "财务管理类"]


def _system(case_type: str) -> str:
    return build_messages("素材", "material", case_type, "", policy=teaching_policy())[0]["content"]


def test_generation_prompt_injects_mode_indicators():
    marketing = _system("市场营销类")
    strategy = _system("战略决策类")
    assert "基准销量" in marketing and "客户满意度" in marketing
    assert "风险背景" in strategy and "资源状况" in strategy
    assert marketing != strategy


def test_generation_prompt_financial_mode_has_no_mode_branch():
    assert "本案例为财务管理模式" in _system("财务管理类")


def test_review_focus_differs_by_mode():
    assert "4P" in review_mode_focus("市场营销类")
    assert "SWOT" in review_mode_focus("战略决策类")
    assert review_mode_focus("财务管理类") == ""


def test_advice_hint_differs_by_mode():
    assert "ROI" in advice_mode_hint("市场营销类")
    assert "回收期" in advice_mode_hint("战略决策类")
    assert advice_mode_hint("财务管理类") == ""


def test_three_mode_prompts_are_distinct():
    systems = {mode: _system(mode) for mode in MODES}
    assert len(set(systems.values())) == 3
