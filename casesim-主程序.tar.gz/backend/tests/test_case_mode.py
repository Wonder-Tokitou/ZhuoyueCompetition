"""Case.mode 别名列与 process_baseline_json 的迁移与兼容性。

mode 只是 case_type 的语义别名（finance / marketing / strategy），
case_type 仍是权威枚举：rules._self_check、27 条路径快照都引用它。
所以迁移只能「新增列 + 回填」，历史案例的过程指标数值必须逐条不变。
"""
from sqlalchemy import create_engine, inspect, text
from sqlalchemy.orm import sessionmaker

from backend.app import migrations
from backend.app import models
from backend.app.db import Base
from backend.app.seed import seed_demo_case
from backend.app.services.simulation import prepare
from backend.tests.test_progressive import setup_case
from backend.tests.test_student_workflow import env  # noqa: F401 (env 是 fixture)


def _file_engine(path):
    return create_engine('sqlite:///' + path.as_posix())


def _insert_case(db, title, case_type, mode=None):
    """按 ORM 默认值插入一条案例，避免逐列补齐 NOT NULL 约束。"""
    db.add(models.Case(title=title, case_type=case_type, background=title,
                       dilemma=title, source_text=title, source_kind='text',
                       teacher_token=title, student_token=title, mode=mode))
    db.commit()


def test_migration_backfills_mode_for_existing_cases(tmp_path, monkeypatch):
    engine = _file_engine(tmp_path / 'mode.db')
    Base.metadata.create_all(engine)
    factory = sessionmaker(bind=engine, autoflush=False)
    with factory() as db:
        _insert_case(db, '旧财务案例', '财务管理类')
        _insert_case(db, '旧营销案例', '市场营销类')
        _insert_case(db, '旧战略案例', '战略决策类')

    monkeypatch.setattr(migrations, 'engine', engine)
    migrations.migrate()

    with engine.connect() as conn:
        rows = dict(conn.execute(text('SELECT "case_type", mode FROM "case"')).all())
        assert rows == {'财务管理类': 'finance',
                        '市场营销类': 'marketing',
                        '战略决策类': 'strategy'}
        # case_type 本身不动：它是过程指标、路径快照、规则自校验的权威枚举
        assert set(rows) == {'财务管理类', '市场营销类', '战略决策类'}
    assert 'process_baseline_json' in {c['name'] for c in inspect(engine).get_columns('case')}
    engine.dispose()


def test_migration_is_idempotent_and_keeps_manual_mode(tmp_path, monkeypatch):
    engine = _file_engine(tmp_path / 'mode2.db')
    Base.metadata.create_all(engine)
    factory = sessionmaker(bind=engine, autoflush=False)
    with factory() as db:
        _insert_case(db, '手工案例', '财务管理类', mode='marketing')

    monkeypatch.setattr(migrations, 'engine', engine)
    migrations.migrate()
    migrations.migrate()

    with engine.connect() as conn:
        assert conn.execute(text('SELECT mode FROM "case"')).scalar() == 'marketing'
    engine.dispose()


def test_history_case_paths_unchanged_after_migration(tmp_path, monkeypatch):
    """验收项 6：历史案例不受影响 —— 迁移后 27 条路径 final 指标逐条不变。"""
    engine = _file_engine(tmp_path / 'legacy.db')
    Base.metadata.create_all(engine)
    factory = sessionmaker(bind=engine, autoflush=False)
    with factory() as db:
        seed_demo_case(db)

    _, config, before = setup_case(factory)
    assert len(before['paths']) == 27

    with factory() as db:
        db.execute(text('UPDATE "case" SET mode = NULL'))
        db.commit()

    monkeypatch.setattr(migrations, 'engine', engine)
    migrations.migrate()

    with factory() as db:
        case = db.scalar(text('SELECT id FROM "case"'))
        row = db.get(models.Case, case)
        assert row.mode is not None
        assert row.process_baseline_json is None
        _, after = prepare(row, config)

    assert len(after['paths']) == 27
    assert [p['final'] for p in after['paths']] == [p['final'] for p in before['paths']]
    engine.dispose()


def test_process_baseline_override_only_affects_process_metrics(env):
    """教师自定义基准只改过程指标，财务四指标不受影响。"""
    _, factory = env
    _, config, plain = setup_case(factory)
    with factory() as db:
        case = db.scalar(text('SELECT id FROM "case"'))
        row = db.get(models.Case, case)
        row.process_baseline_json = {'market_share': 50.0, 'satisfaction': 4.0}
        db.commit()
        _, overridden = prepare(row, config)

    for a, b in zip(plain['paths'], overridden['paths']):
        assert b['final']['net_profit'] == a['final']['net_profit']
        assert b['final']['revenue'] == a['final']['revenue']
        assert b['final']['cash_flow_amount'] == a['final']['cash_flow_amount']
        assert b['final']['market_share'] >= a['final']['market_share']
