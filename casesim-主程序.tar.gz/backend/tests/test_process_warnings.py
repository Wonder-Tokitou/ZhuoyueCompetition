"""过程指标区间校验与战略预警。"""
from backend.app.domain import process_metrics, progressive


def _impact(**extra):
    base = {"revenue_pct": 0, "margin_pp": 0, "expense_pct": 0, "cash_pct": 0, "share_pp": 0}
    base.update(extra)
    return progressive.Impact(**base)


def test_marketing_share_beyond_five_points_is_flagged():
    alerts = process_metrics.warnings({"customer_satisfaction": 70}, process_metrics.MARKETING,
                                      _impact(share_pp=6), {})
    assert any(item["level"] == "warning" and "±5" in item["message"] for item in alerts)


def test_marketing_satisfaction_out_of_range_is_flagged():
    impact = _impact(process=progressive.ProcessImpact(satisfaction_pp=40))
    alerts = process_metrics.warnings({"customer_satisfaction": 70}, process_metrics.MARKETING, impact, {})
    assert any(item["level"] == "warning" and "合理区间" in item["message"] for item in alerts)


def test_strategy_high_risk_with_low_resource_is_danger():
    alerts = process_metrics.warnings({}, process_metrics.STRATEGY, _impact(),
                                      {"risk_score": 80, "resource_match": 30})
    assert len(alerts) == 1
    assert alerts[0]["level"] == "danger"


def test_within_range_produces_no_alert():
    influence = _impact(share_pp=3)
    assert process_metrics.warnings({"customer_satisfaction": 70}, process_metrics.MARKETING, influence, {}) == []
    assert process_metrics.warnings({}, process_metrics.STRATEGY, _impact(),
                                    {"risk_score": 50, "resource_match": 60}) == []


def _snapshot():
    return {
        "case_type": process_metrics.MARKETING,
        "base_metrics": {"revenue": 100.0, "gross_margin": "60.0%",
                         "market_share": "30.0%", "cash_flow": "稳健"},
        "nodes": [{"id": i, "idx": i, "options": [{"key": key} for key in "ABC"]} for i in (1, 2, 3)],
    }


def _configuration():
    rules = {}
    for i in (1, 2, 3):
        for key, share in zip("ABC", (6.0, 1.0, -2.0)):
            rules["%d:%s" % (i, key)] = {"revenue_pct": 2, "margin_pp": 0, "expense_pct": 0,
                                         "cash_pct": 0, "share_pp": share}
    return {"enabled": True, "cash_flow_amount": 10.0, "rules": rules}


def test_preview_returns_deduplicated_warnings():
    result = progressive.preview(_snapshot(), _configuration(),
                                 {"operating_cost": 40.0, "operating_expense": 20.0})
    assert "warnings" in result
    assert len(result["paths"]) == 27
    messages = [item["message"] for item in result["warnings"]]
    assert len(messages) == len(set(messages)), "同一提示不应在 27 条路径里重复出现"
    assert any("±5" in message for message in messages)
    assert result["warnings"][0]["round"] >= 1


def test_accepts_unvalidated_rule_dict_from_snapshot():
    """学生提交时规则来自快照 JSON，是 dict 而不是已校验的 Impact。"""
    rule = {"revenue_pct": 2, "margin_pp": 0, "expense_pct": 0, "cash_pct": 0, "share_pp": 6}
    alerts = process_metrics.warnings({"customer_satisfaction": 70}, process_metrics.MARKETING, rule, {})
    assert any("±5" in item["message"] for item in alerts)
