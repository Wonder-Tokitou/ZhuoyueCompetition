"""三套分析框架的指标体系是否符合文档定义。

文档口径：
- 市场营销：单位销量、市场份额（由共用财务引擎给出）、客户满意度、渠道覆盖度、定价策略档位、产品组合宽度
- 战略决策：目标市场容量、行业增长率、竞争强度、资源匹配度（三档）、风险等级（三档）、预期市场占有率
- 财务管理：营业收入、营业成本与毛利率、运营费用、净利润、现金流
"""
from backend.app.domain import process_metrics as pm
from backend.app.domain.progressive import FINANCIAL_KEYS
from backend.app.domain.progressive import ProcessImpact
from backend.tests.test_progressive import setup_case
from backend.tests.test_student_workflow import env  # noqa: F401 (env 是 fixture)


def test_marketing_metric_set_matches_the_document():
    """产品组合、定价策略、渠道投入、客户满意度、单位销量五项齐备。"""
    assert set(pm.MARKETING_RULES["process_metrics"]) == {
        "unit_sales", "customer_satisfaction", "channel_coverage", "pricing_tier", "product_mix_width"}
    # 定价策略三档：低价渗透 / 市场跟随 / 高价撇脂
    assert pm.TIERS["pricing_tier"] == {"低价渗透": 1.0, "市场跟随": 2.0, "高价撇脂": 3.0}


def test_strategy_metric_set_matches_the_document():
    """市场机会三子项 + 资源匹配度 + 风险等级 + 预期市占率。"""
    assert set(pm.STRATEGY_RULES["process_metrics"]) == {
        "market_capacity", "industry_growth", "competition_intensity",
        "resource_match", "risk_score", "target_market_share"}
    # 资源匹配度与风险等级各三档
    assert pm.TIERS["resource_match"] == {"不足": 0.0, "基本匹配": 40.0, "充足": 70.0}
    assert pm.TIERS["risk_level"] == {"低": 0.0, "中": 34.0, "高": 67.0}


def test_three_tier_conversion_boundaries():
    assert pm.tier_of("resource_match", 20) == "不足"
    assert pm.tier_of("resource_match", 40) == "基本匹配"
    assert pm.tier_of("resource_match", 69.9) == "基本匹配"
    assert pm.tier_of("resource_match", 70) == "充足"
    assert pm.tier_of("risk_level", 0) == "低"
    assert pm.tier_of("risk_level", 33.9) == "低"
    assert pm.tier_of("risk_level", 34) == "中"
    assert pm.tier_of("risk_level", 66.9) == "中"
    assert pm.tier_of("risk_level", 67) == "高"
    assert pm.tier_of("pricing_tier", 1) == "低价渗透"
    assert pm.tier_of("pricing_tier", 3) == "高价撇脂"
    assert pm.tier_of("unknown_key", 5) is None


def test_process_keys_never_collide_with_financial_keys():
    """过程指标不得叫财务指标同名，否则下一轮按百分比解析会失败。"""
    for rules in (pm.MARKETING_RULES, pm.STRATEGY_RULES):
        for key in rules["process_metrics"]:
            assert key not in FINANCIAL_KEYS, key
    finance = pm.baseline("财务管理类", {})
    assert set(finance) <= {"profitability", "liquidity", "solvency", "operating_efficiency"}


def test_process_impact_fields_cover_both_frameworks():
    fields = set(ProcessImpact.model_fields)
    assert {"unit_sales_pct", "satisfaction_pp", "channel_coverage_pp",
            "pricing_tier_step", "product_mix_width_delta"} <= fields
    assert {"market_capacity_pct", "industry_growth_pp", "competition_intensity_pp",
            "resource_match_pp", "risk_score_pp", "target_market_share_pp"} <= fields


def test_baseline_takes_case_market_share_for_strategy():
    """教师改基准份额后，战略的预期市占率起点随之改变（全链路重算的前提）。"""
    low = pm.baseline("战略决策类", {"market_share": "12.0%"})
    high = pm.baseline("战略决策类", {"market_share": "30.0%"})
    assert low["target_market_share"] == 12.0
    assert high["target_market_share"] == 30.0
    assert pm.baseline("战略决策类", {})["target_market_share"] == 12.0  # 缺省回落


def test_process_metrics_do_not_change_financial_finals(env):
    """过程指标只做叠加展示，财务 final 一字不变。"""
    _, factory = env
    _, config, preview = setup_case(factory)
    with factory() as db:
        from sqlalchemy import text as _text
        case_id = db.scalar(_text('SELECT id FROM "case"'))
        from backend.app import models
        case = db.get(models.Case, case_id)
        case.case_type = "战略决策类"
        db.commit()
        from backend.app.services.simulation import prepare
        _, after = prepare(case, config)
    assert [p["final"]["net_profit"] for p in after["paths"]] == [
        p["final"]["net_profit"] for p in preview["paths"]]
    assert [p["final"]["revenue"] for p in after["paths"]] == [
        p["final"]["revenue"] for p in preview["paths"]]
    # 战略模式下过程指标确实带上了新键
    assert "risk_score" in after["paths"][0]["final"]
    assert "market_capacity" in after["paths"][0]["final"]
