"""V7 选项五要素校验。"""
from backend.app.domain import validator


def _detail(**over):
    base = {
        "positioning": "以线下渠道为核心，小范围试水",
        "actions": "优先进驻核心城市 120 家标杆门店",
        "investment": "新增营销费用约 5000 万元",
        "expected_return": "销量增速 3%-5%，份额提升 0.2-0.5 个百分点",
        "tradeoff": "起量慢，可能错过赛道窗口期",
    }
    base.update(over)
    return base


def _payload(detail):
    option = {"key": "A"}
    if detail is not None:
        option["detail"] = detail
    return {"nodes": [{"options": [option]}]}


def test_complete_five_elements_pass():
    assert validator._v7_option_detail(_payload(_detail(theory=["4P 渠道策略"]))) == []


def test_missing_element_is_reported():
    detail = _detail()
    detail.pop("investment")
    errors = validator._v7_option_detail(_payload(detail))
    assert any("缺「investment」" in error for error in errors)


def test_theory_must_bind_one_or_two_concepts():
    errors = validator._v7_option_detail(_payload(_detail(theory=["a", "b", "c"])))
    assert any("1—2 个" in error for error in errors)


def test_option_without_detail_is_not_an_error():
    assert validator._v7_option_detail(_payload(None)) == []


def test_validate_case_surfaces_option_detail_errors():
    ok, errors = validator.validate_case(_payload({"positioning": "", "actions": "",
                                                   "investment": "", "expected_return": "",
                                                   "tradeoff": ""}))
    assert not ok
    assert any(error.startswith("V7") for error in errors)


def test_live_snapshot_carries_option_detail():
    from types import SimpleNamespace

    from backend.app.services import simulation

    option = SimpleNamespace(option_key="A", label="方案 A", risk_level="稳健",
                             summary="结果摘要", metrics_json={"revenue": 12},
                             detail_json={"positioning": "以线下渠道为核心"})
    node = SimpleNamespace(id=1, idx=1, node_role="核心战略", title="标题",
                           background="背景", option_results=[option])
    case = SimpleNamespace(source_text="素材", version=1, title="案例", case_type="市场营销类",
                           background="背景", dilemma="困境", base_metrics_json={},
                           story_json=None, nodes=[node])

    snapshot = simulation.live_snapshot(case)
    assert snapshot["nodes"][0]["options"][0]["detail"] == {"positioning": "以线下渠道为核心"}
