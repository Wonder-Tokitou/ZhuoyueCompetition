"""三套决策选项库（文档第 6 章）入库。

文档每个案例只给了 1 个决策节点（3 选项），系统强制 3 节点 × 3 选项，
因此另外 2 个节点由本库补齐：文案与五要素格式沿用第 6 章口径。
"""
from sqlalchemy import select

from backend.app import models
from backend.app.domain.validator import OPTION_DETAIL_KEYS
from backend.app.domain.validator import _v7_option_detail
from backend.app.seed import OPTION_LIBRARY_FILES
from backend.app.seed import load_option_library
from backend.app.seed import seed_option_library
from backend.tests.test_student_workflow import env  # noqa: F401 (env 是 fixture)


# 文档第 6 章逐字给出的 9 个选项（每个案例的第 1 个决策节点）。
DOCUMENTED_OPTIONS = {
    '市场营销类': [
        '深耕线下渠道，小范围稳步试水',
        '全渠道协同布局，达人种草带动销售',
        '全网流量驱动，低价冲量抢占市场',
    ],
    '战略决策类': [
        '巩固国内市场，聚焦产品升级',
        '东南亚建厂，渐进式区域扩张',
        '欧美全线布局，并购本土品牌',
    ],
    '财务管理类': [
        '自有资金小幅扩产，零新增负债',
        '长期贷款配套自有资金，中等规模扩产',
        '股权加债权混合融资，大规模新建产能',
    ],
}


def test_library_covers_three_modes():
    library = load_option_library()
    assert len(library) == len(OPTION_LIBRARY_FILES) == 3
    assert [item['case_type'] for item in library] == ['市场营销类', '战略决策类', '财务管理类']
    for item in library:
        assert item['title'] and item['background'] and item['dilemma']
        assert set(item['base_metrics']) >= {'revenue', 'gross_margin', 'market_share', 'cash_flow'}
        assert set(item['financial_assumptions']) >= {'operating_cost', 'operating_expense'}


def test_every_case_has_three_nodes_and_three_options():
    for item in load_option_library():
        where = item['case_type']
        assert len(item['nodes']) == 3, where
        for index, node in enumerate(item['nodes'], start=1):
            assert node['node_role'] and node['title'] and node['background'], where
            assert len(node['options']) == 3, '%s 节点%d' % (where, index)
            assert [o['option_key'] for o in node['options']] == ['A', 'B', 'C']
            # 每个节点内风险等级必须齐全，且与选项序号对应（A 保守 / B 稳健 / C 激进）
            assert [o['risk_level'] for o in node['options']] == ['保守', '稳健', '激进']
            for option in node['options']:
                assert option['label'] and option['summary'], option['option_key']
                assert set(option['metrics']) >= {'revenue', 'gross_margin', 'market_share', 'cash_flow'}


def test_every_option_carries_five_elements_and_theory():
    """验收项 3 的内容侧：每个选项都有可展开的五要素决策依据。"""
    for item in load_option_library():
        for index, node in enumerate(item['nodes'], start=1):
            for option in node['options']:
                where = '%s 节点%d 选项%s' % (item['case_type'], index, option['option_key'])
                detail = option.get('detail')
                assert isinstance(detail, dict), where
                for key in OPTION_DETAIL_KEYS:
                    assert str(detail.get(key) or '').strip(), '%s 缺「%s」' % (where, key)
                assert 1 <= len(detail.get('theory') or []) <= 2, where
                assert all(str(t).strip() for t in detail['theory']), where


def test_option_detail_passes_v7_validator():
    """复用发布链路的同一条校验，确保入库内容也能通过教师端发布。"""
    for item in load_option_library():
        payload = {'nodes': [
            {'options': [{'key': o['option_key'], 'detail': o['detail']} for o in node['options']]}
            for node in item['nodes']]}
        assert _v7_option_detail(payload) == [], item['case_type']


def test_documented_first_node_matches_the_document():
    """第 6 章逐字给出的 9 个选项必须原样出现在每个案例的第 1 个决策节点。"""
    for item in load_option_library():
        labels = [o['label'] for o in item['nodes'][0]['options']]
        assert labels == DOCUMENTED_OPTIONS[item['case_type']], item['case_type']


def test_option_detail_never_leaks_other_options():
    """detail 只描述本方案自身，不得透露风险等级、指标数值或推荐答案。"""
    forbidden = ('选项A', '选项B', '选项C', '推荐答案', '标准答案', '标准路径')
    for item in load_option_library():
        for node in item['nodes']:
            for option in node['options']:
                text = ''.join(str(v) for v in option['detail'].values())
                for word in forbidden:
                    assert word not in text, '%s / %s 含「%s」' % (
                        item['case_type'], option['option_key'], word)


def test_seed_writes_three_cases(env):
    _, factory = env
    with factory() as db:
        seeded = seed_option_library(db)
        assert [c.case_type for c in seeded] == ['市场营销类', '战略决策类', '财务管理类']
        for case in seeded:
            nodes = db.scalars(select(models.Node).where(
                models.Node.case_id == case.id).order_by(models.Node.idx)).all()
            assert len(nodes) == 3
            assert case.library_scope == 'school'
            assert case.mode == {'市场营销类': 'marketing', '战略决策类': 'strategy',
                                 '财务管理类': 'finance'}[case.case_type]
            for node in nodes:
                options = db.scalars(select(models.OptionResult).where(
                    models.OptionResult.node_id == node.id)).all()
                assert len(options) == 3
                for option in options:
                    assert option.detail_json is not None
                    assert option.metrics_json and option.summary


def test_seed_is_idempotent(env):
    _, factory = env
    with factory() as db:
        first = [c.id for c in seed_option_library(db)]
    with factory() as db:
        second = [c.id for c in seed_option_library(db)]
        assert first == second
        case_ids = set(first)
        nodes = db.scalars(select(models.Node).where(
            models.Node.case_id.in_(case_ids))).all()
        assert len(nodes) == 9
        options = db.scalars(select(models.OptionResult).where(
            models.OptionResult.node_id.in_([n.id for n in nodes]))).all()
        assert len(options) == 27
