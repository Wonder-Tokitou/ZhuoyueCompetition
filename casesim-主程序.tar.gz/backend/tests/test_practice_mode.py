"""课后空间 practice 模式的后端契约测试（P0-B4）。

覆盖四条判据：
1. 同一学生对同一案例可同时存在 formal + practice 两行；
2. 教师端 records / 统计 / 趋势都不含 practice 行；
3. reset practice 不影响 formal 行的 turns；
4. POST sessions {mode:'practice'} 幂等（两次同一 session_id）。
"""
from sqlalchemy import func, select

from backend.app import models
from backend.tests.teacher_helpers import login_teacher
from backend.tests.test_student_workflow import URL, begin, complete, env  # noqa: F401 (env 是 fixture)


def _teacher_token(client, monkeypatch):
    return login_teacher(client, monkeypatch)


def _first_case_id(client, token):
    return client.get('/api/cases', params={'token': token}).json()[0]['id']


def _practice_begin(client):
    r = client.post(URL + '/sessions', json={'student_name': 'student', 'mode': 'practice'})
    assert r.status_code == 200, r.text
    return r.json()


def test_practice_is_idempotent(env):
    """B2 判据：mode=practice 连调两次，返回同一个 session_id 且 mode='practice'。"""
    client, _ = env
    first = _practice_begin(client)
    second = _practice_begin(client)
    assert first['mode'] == 'practice'
    assert second['session_id'] == first['session_id']


def test_formal_and_practice_coexist(env):
    """B1 判据：同一学生同一案例可同时存在 formal + practice；两行 formal 仍被拒绝。"""
    client, _ = env
    formal = begin(client)
    practice = _practice_begin(client)
    assert formal['session_id'] != practice['session_id']
    assert formal['mode'] == 'formal'
    assert practice['mode'] == 'practice'
    # 第二个 formal 仍 409
    dup = client.post(URL + '/sessions', json={'student_name': 'student'})
    assert dup.status_code == 409, dup.text
    # 第二个 practice 幂等复用
    again = _practice_begin(client)
    assert again['session_id'] == practice['session_id']


def test_teacher_never_sees_practice(env, monkeypatch):
    """B3 判据：教师端 records / 排行榜 / 选项分布都不含 practice 行。"""
    client, _ = env
    complete(client, begin(client))          # formal 走完 3 轮
    _practice_begin(client)                   # practice 创建（未走完也占一行）
    token = _teacher_token(client, monkeypatch)
    case_id = _first_case_id(client, token)

    records = client.get('/api/cases/%s/records' % case_id, params={'token': token})
    assert records.status_code == 200, records.text
    assert len(records.json()) == 1, records.text  # 只有 formal 一条

    board = client.get('/api/cases/%s/leaderboard' % case_id, params={'token': token})
    assert board.status_code == 200, board.text
    board_data = board.json()
    board_items = board_data.get('items', board_data) if isinstance(board_data, dict) else board_data
    assert len(board_items) == 1, board.text

    dist = client.get('/api/teacher/dashboard/option-distribution', params={'token': token, 'case_id': case_id})
    assert dist.status_code == 200, dist.text
    total = sum(o['count'] for o in dist.json()['options'])
    assert total == 3, dist.text  # 仅 formal 3 轮


def test_teacher_can_query_practice_records_explicitly(env, monkeypatch):
    """P3 判据：records 带 kind=practice 时返回练习局明细（教师可查但不进默认统计）。"""
    client, _ = env
    complete(client, begin(client))          # formal 3 轮
    pstate = _practice_begin(client)
    node = pstate['play']['nodes'][0]
    r = client.post(URL + '/decide', json={'session_id': pstate['session_id'], 'student_name': 'student',
        'node_id': node['id'], 'option_key': node['options'][0]['key'], 'duration_ms': 5})
    assert r.status_code == 200, r.text
    token = _teacher_token(client, monkeypatch)
    case_id = _first_case_id(client, token)

    formal = client.get('/api/cases/%s/records' % case_id, params={'token': token, 'kind': 'formal'})
    assert formal.status_code == 200, formal.text
    assert len(formal.json()) == 1, formal.text  # 只有 formal 一条

    practice = client.get('/api/cases/%s/records' % case_id, params={'token': token, 'kind': 'practice'})
    assert practice.status_code == 200, practice.text
    assert len(practice.json()) == 1, practice.text  # 练习局一条（含 1 轮 turn）
    assert practice.json()[0]['session_id'] == pstate['session_id'], practice.text


def test_reset_practice_keeps_formal_turns(env):
    """B3 判据：reset practice 不影响 formal 行的 turns。"""
    client, _ = env
    sid = complete(client, begin(client))     # formal 3 轮
    pstate = _practice_begin(client)
    node = pstate['play']['nodes'][0]
    r = client.post(URL + '/decide', json={'session_id': pstate['session_id'], 'student_name': 'student',
        'node_id': node['id'], 'option_key': node['options'][0]['key'], 'duration_ms': 5})
    assert r.status_code == 200, r.text
    # 重置 practice = 新建一次记录；原 practice 记录保留（多次推演独立）
    reset = client.post(URL + '/sessions/%s/reset' % pstate['session_id'])
    assert reset.status_code == 200, reset.text
    assert reset.json()['session_id'] != pstate['session_id'], reset.text
    # formal 的 turns 原样
    formal = client.get(URL + '/sessions/%s' % sid)
    assert formal.status_code == 200, formal.text
    assert len(formal.json()['turns']) == 3, formal.text
    # 原 practice 记录不被清空
    p2 = client.get(URL + '/sessions/%s' % pstate['session_id'])
    assert p2.status_code == 200, p2.text
    assert len(p2.json()['turns']) == 1, p2.text
    # 新建的那次是空的
    assert len(reset.json()['turns']) == 0, reset.text


def test_practice_completion_creates_no_review_task(env):
    """P0-fix 判据：练习局走完全部轮次后，ai_task 表中该 session 记录数为 0（不烧 LLM）。"""
    client, factory = env
    pstate = _practice_begin(client)
    psid = pstate['session_id']
    # 走完 practice 全部节点（最后一轮应触发 _enqueue_review_task，但被 kind 判断短路）
    for node in pstate['play']['nodes']:
        r = client.post(URL + '/decide', json={'session_id': psid, 'student_name': 'student',
            'node_id': node['id'], 'option_key': node['options'][0]['key'],
            'input_text': '练习选择', 'duration_ms': 5})
        assert r.status_code == 200, r.text
    with factory() as db:
        n = db.scalar(select(func.count()).select_from(models.AiTask).where(models.AiTask.session_id == psid))
        assert n == 0, "练习局不得生成 ai_task：%r" % db.scalars(
            select(models.AiTask).where(models.AiTask.session_id == psid)).all()


def test_formal_completion_still_enqueues_review_task(env):
    """P0-fix 回归：正式局走完全部轮次仍生成 student_review 复盘任务。"""
    client, factory = env
    fsid = complete(client, begin(client))
    with factory() as db:
        task = db.scalar(select(models.AiTask).where(
            models.AiTask.session_id == fsid,
            models.AiTask.kind == 'student_review',
        ))
        assert task is not None, "正式局必须生成 student_review 复盘任务"
