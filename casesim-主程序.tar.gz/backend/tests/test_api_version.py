"""接口契约版本号（响应头 X-API-Version）。

前端打包版本落后于后端时，可据此提示用户刷新页面，避免「字段对不上却静默出错」。
"""
from backend.app import API_VERSION
from backend.app import main as app_module
from backend.tests.test_student_workflow import URL, env  # noqa: F401 (env 是 fixture)


def test_every_api_response_carries_version_header(env):
    client, _ = env
    for path in ('/api/health', URL):
        response = client.get(path)
        assert response.status_code == 200, response.text
        assert response.headers.get('X-API-Version') == API_VERSION, path


def test_version_is_present_even_on_errors(env):
    """错误响应同样要带版本号：客户端需要区分「接口不存在」和「版本不匹配」。 """
    client, _ = env
    response = client.get('/api/not-a-real-endpoint')
    assert response.status_code == 404
    assert response.headers.get('X-API-Version') == API_VERSION


def test_version_constant_matches_middleware_source():
    """避免有人在 main.py 里另写一个字面量，与 API_VERSION 漂移。"""
    assert API_VERSION == '2'
    source = open(app_module.__file__, encoding='utf-8').read()
    assert 'response.headers["X-API-Version"] = API_VERSION' in source
