import type { CaseStatus, CaseType, FrameworkType, Metrics, RiskLevel } from '../api/types'

/** 案例类型下拉（value 与 docs/商科规则.json 的 case_types 一致，界面显示为「模式」） */
export const CASE_TYPE_OPTIONS: { value: CaseType; label: string }[] = [
  { value: '战略决策类', label: '战略决策模式' },
  { value: '市场营销类', label: '市场营销模式' },
  { value: '财务管理类', label: '财务管理模式' },
]

/** 案例类型 → 界面显示名。枚举值本身不变，只改展示文案。 */
export const CASE_TYPE_LABELS: Record<CaseType, string> = {
  战略决策类: '战略决策模式',
  市场营销类: '市场营销模式',
  财务管理类: '财务管理模式',
}

/** 后端返回的是原始枚举值，展示前统一走这里，避免页面出现「××类」。 */
export function caseTypeLabel(value: string): string {
  return CASE_TYPE_LABELS[value as CaseType] ?? value
}

/** 各模式在生成页的说明：过程指标 + 复盘框架 */
export const CASE_MODE_HINTS: Record<CaseType, string> = {
  战略决策类: '战略决策模式将包含风险等级、资源匹配度、市场机会、海外收入占比等过程指标，采用 SWOT 分析模型复盘。综合经营与财务结果仍会全程保留。',
  市场营销类: '市场营销模式将包含销量、市场份额、客户满意度、复购率、营销 ROI 等过程指标，采用 4P 营销理论复盘。综合经营与财务结果仍会全程保留。',
  财务管理类: '财务管理模式以盈利质量、现金流安全、偿债能力、运营效率等指标为核心，采用盈亏平衡分析复盘。综合经营与财务结果仍会全程保留。',
}

/** 商科规则 §4.5：案例类型与核心分析框架一一对应，用于界面提示 */
export const FRAMEWORK_BY_CASE_TYPE: Record<CaseType, FrameworkType> = {
  战略决策类: 'SWOT分析模型',
  市场营销类: '4P营销理论',
  财务管理类: '盈亏平衡分析',
}

/** 风险等级 Tag 配色：保守=灰、稳健=蓝、激进=红 */
export const RISK_META: Record<RiskLevel, { color: string }> = {
  保守: { color: 'default' },
  稳健: { color: 'blue' },
  激进: { color: 'red' },
}

export const RISK_LEVELS: RiskLevel[] = ['保守', '稳健', '激进']

export const RISK_OPTIONS = RISK_LEVELS.map((level) => ({ value: level, label: level }))

/** case.status 四态展示 */
export const STATUS_META: Record<CaseStatus, { text: string; color: string }> = {
  draft: { text: '草稿（待完善）', color: 'default' },
  generating: { text: '正在准备', color: 'gold' },
  ready: { text: '已就绪（可核对）', color: 'green' },
  published: { text: '已发布', color: 'purple' },
}

/** 四项指标的键与中文名（顺序固定） */
export const METRIC_FIELDS: { key: keyof Metrics; label: string; numeric: boolean }[] = [
  { key: 'revenue', label: '营收（万元）', numeric: true },
  { key: 'gross_margin', label: '毛利率', numeric: false },
  { key: 'market_share', label: '市场份额', numeric: false },
  { key: 'cash_flow', label: '现金流', numeric: false },
]

export const CASH_FLOW_TEXTAREA_STYLE = { width: '100%', minHeight: 140, resize: 'vertical' as const }

/** 过程指标面板字段（键与 docs/营销规则.json、docs/战略规则.json 的 baseline 键一致） */
export interface ProcessBaselineField {
  key: string
  label: string
  unit?: string
  /** 编辑时的取值范围提示（来自规则文件 ranges） */
  min?: number
  max?: number
  step?: number
  hint?: string
  /** 三档下拉：教师从离散档位中选择，存储档位代表分值 */
  options?: { label: string; value: number }[]
}

export const PROCESS_BASELINE_FIELDS: Record<string, ProcessBaselineField[]> = {
  marketing: [
    { key: 'unit_sales', label: '单位销量', unit: '万件', min: 0, step: 1, hint: '4P 营销理论：销量基数' },
    { key: 'customer_satisfaction', label: '客户满意度', unit: '分', min: 30, max: 90, step: 1, hint: '规则区间 30–90 分' },
    { key: 'channel_coverage', label: '渠道覆盖率', unit: '%', min: 0, max: 100, step: 1, hint: '渠道铺货广度' },
    { key: 'pricing_tier', label: '定价档位', unit: '档', min: 1, max: 3, step: 1, hint: '1=低价渗透 2=市场跟随 3=高价撇脂', options: [
      { label: '低价渗透', value: 1 },
      { label: '市场跟随', value: 2 },
      { label: '高价撇脂', value: 3 },
    ] },
    { key: 'product_mix_width', label: '产品线宽度', unit: '个', min: 1, max: 30, step: 1, hint: 'SKU 宽度基线' },
  ],
  strategy: [
    { key: 'market_capacity', label: '市场容量', unit: '指数', min: 0, step: 1, hint: '目标市场容量指数' },
    { key: 'industry_growth', label: '行业增速', unit: '%', min: -50, max: 100, step: 0.5, hint: '行业年增长率' },
    { key: 'competition_intensity', label: '竞争强度', unit: '分', min: 0, max: 100, step: 1, hint: '竞争激烈程度（越高越激烈）' },
    { key: 'resource_match', label: '资源匹配度', unit: '档', min: 0, max: 100, step: 1, hint: '不足 < 40；基本匹配 40–70；充足 ≥ 70', options: [
      { label: '不足', value: 0 },
      { label: '基本匹配', value: 40 },
      { label: '充足', value: 70 },
    ] },
    { key: 'risk_score', label: '风险等级', unit: '档', min: 0, max: 100, step: 1, hint: '低 < 34；中 34–67；高 ≥ 67', options: [
      { label: '低', value: 0 },
      { label: '中', value: 34 },
      { label: '高', value: 67 },
    ] },
    { key: 'target_market_share', label: '预期市占率', unit: '%', min: 0, max: 100, step: 0.5, hint: '进入后的预期份额' },
  ],
}

/** 规则文件默认基线（process_baseline 为空时展示并作为兜底） */
export const PROCESS_BASELINE_DEFAULTS: Record<string, Record<string, number>> = {
  marketing: {
    unit_sales: 100,
    customer_satisfaction: 70,
    channel_coverage: 45,
    pricing_tier: 2,
    product_mix_width: 6,
  },
  strategy: {
    market_capacity: 100,
    industry_growth: 8,
    competition_intensity: 55,
    resource_match: 70,
    risk_score: 35,
    target_market_share: 12,
  },
}

/** 模式中文名（教师端/学生端共用） */
export const MODE_LABELS: Record<string, string> = {
  finance: '财务管理模式',
  marketing: '市场营销模式',
  strategy: '战略决策模式',
}

/** 由 case.mode 或 case_type 推导模式，保证旧案例兼容 */
export function resolveMode(mode?: string | null, caseType?: string): 'finance' | 'marketing' | 'strategy' {
  if (mode === 'finance' || mode === 'marketing' || mode === 'strategy') return mode
  if (caseType === '市场营销类') return 'marketing'
  if (caseType === '战略决策类') return 'strategy'
  return 'finance'
}

/** 时间显示：后端给 ISO 8601，界面只到分钟 */
export function formatTime(iso: string): string {
  if (!iso) return '-'
  return iso.replace('T', ' ').slice(0, 16)
}

/** 决策耗时（毫秒 → 秒） */
export function formatDuration(ms: number): string {
  if (typeof ms !== 'number' || Number.isNaN(ms)) return '-'
  return `${(ms / 1000).toFixed(1)} 秒`
}
