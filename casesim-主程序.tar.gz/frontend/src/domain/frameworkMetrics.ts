import type { CaseType } from '../api/types'

export type ProcessKey =
  // 市场营销：单位销量、市场份额、客户满意度、渠道覆盖度、定价策略档位、产品组合宽度
  | 'unit_sales_pct' | 'satisfaction_pp' | 'channel_coverage_pp'
  | 'pricing_tier_step' | 'product_mix_width_delta'
  // 战略决策：目标市场容量、行业增长率、竞争强度、资源匹配度、风险等级、预期市场占有率
  | 'market_capacity_pct' | 'industry_growth_pp' | 'competition_intensity_pp'
  | 'resource_match_pp' | 'risk_score_pp' | 'target_market_share_pp'
  // 财务管理：盈利质量、现金流安全、偿债能力、运营效率
  | 'profitability_pp' | 'liquidity_pp' | 'solvency_pp' | 'efficiency_pp'

export type ProcessImpact = Partial<Record<ProcessKey, number | null>>
export type FinancialImpact = { revenue_pct: number; margin_pp: number; expense_pct: number; cash_pct: number; share_pp: number }
export type LayeredImpact = FinancialImpact & { process?: ProcessImpact | null }

/** kind: number = 数值输入框；tier = 三档下拉（存档位代表分值） */
type MetricField = { key: ProcessKey; label: string; unit: string; kind?: 'number' | 'tier'; tier?: string }

export const PROCESS_FIELDS: Record<CaseType, MetricField[]> = {
  市场营销类: [
    { key: 'unit_sales_pct', label: '单位销量变化', unit: '%' },
    { key: 'satisfaction_pp', label: '客户满意度变化', unit: '分' },
    { key: 'channel_coverage_pp', label: '渠道覆盖度变化', unit: '个百分点' },
    { key: 'pricing_tier_step', label: '定价策略档位变化', unit: '档', kind: 'tier', tier: 'pricing_tier' },
    { key: 'product_mix_width_delta', label: '产品组合宽度变化', unit: '个 SKU' },
  ],
  战略决策类: [
    { key: 'market_capacity_pct', label: '目标市场容量变化', unit: '%' },
    { key: 'industry_growth_pp', label: '行业增长率变化', unit: '个百分点' },
    { key: 'competition_intensity_pp', label: '竞争强度变化', unit: '分' },
    { key: 'resource_match_pp', label: '资源匹配度变化', unit: '分' },
    { key: 'risk_score_pp', label: '风险等级变化', unit: '分' },
    { key: 'target_market_share_pp', label: '预期市场占有率变化', unit: '个百分点' },
  ],
  财务管理类: [
    { key: 'profitability_pp', label: '盈利质量变化', unit: '分' },
    { key: 'liquidity_pp', label: '现金流安全变化', unit: '分' },
    { key: 'solvency_pp', label: '偿债能力变化', unit: '分' },
    { key: 'efficiency_pp', label: '运营效率变化', unit: '分' },
  ],
}

export const PROCESS_TITLES: Record<CaseType, string> = {
  市场营销类: '市场营销指标',
  战略决策类: '战略决策指标',
  财务管理类: '财务管理指标',
}

/** 三档指标的档位名与代表分值（与 docs/营销规则.json、docs/战略规则.json 的 tiers 一致） */
export const PROCESS_TIERS: Record<string, { label: string; value: number }[]> = {
  pricing_tier: [
    { label: '低价渗透', value: 1 },
    { label: '市场跟随', value: 2 },
    { label: '高价撇脂', value: 3 },
  ],
  resource_match: [
    { label: '不足', value: 0 },
    { label: '基本匹配', value: 40 },
    { label: '充足', value: 70 },
  ],
  risk_level: [
    { label: '低', value: 0 },
    { label: '中', value: 34 },
    { label: '高', value: 67 },
  ],
}

/** 分值 → 档位名（取不超过该分值的最大下界） */
export function tierOf(key: string, value?: number | null): string | null {
  const tiers = PROCESS_TIERS[key]
  if (!tiers || value == null) return null
  let hit: string | null = null
  for (const item of [...tiers].sort((a, b) => a.value - b.value)) {
    if (Number(value) >= item.value) hit = item.label
  }
  return hit
}

export function inferProcess(caseType: CaseType, impact: FinancialImpact): ProcessImpact {
  if (caseType === '市场营销类') return {
    unit_sales_pct: impact.revenue_pct,
    satisfaction_pp: Number((impact.margin_pp * 2).toFixed(2)),
    channel_coverage_pp: Number((impact.expense_pct * 0.5).toFixed(2)),
    pricing_tier_step: Number((impact.margin_pp * 0.1).toFixed(2)),
    product_mix_width_delta: Number((impact.revenue_pct * 0.05).toFixed(2)),
  }
  if (caseType === '战略决策类') return {
    market_capacity_pct: Number((impact.revenue_pct * 0.2).toFixed(2)),
    industry_growth_pp: Number((impact.revenue_pct * 0.05).toFixed(2)),
    competition_intensity_pp: Number((impact.share_pp * 1.5).toFixed(2)),
    resource_match_pp: Number(((impact.revenue_pct - impact.expense_pct) * 0.15).toFixed(2)),
    risk_score_pp: Number(((impact.expense_pct - impact.cash_pct) * 0.12).toFixed(2)),
    target_market_share_pp: Number(impact.share_pp.toFixed(2)),
  }
  return {
    profitability_pp: Number((impact.margin_pp + impact.revenue_pct * 0.1).toFixed(2)),
    liquidity_pp: Number((impact.cash_pct * 0.1).toFixed(2)),
    solvency_pp: Number((-impact.expense_pct * 0.1).toFixed(2)),
    efficiency_pp: Number(((impact.revenue_pct - impact.expense_pct) * 0.1).toFixed(2)),
  }
}

export function normalizeImpact(caseType: CaseType, impact?: LayeredImpact | null): LayeredImpact {
  const base: FinancialImpact = impact ?? { revenue_pct: 0, margin_pp: 0, expense_pct: 0, cash_pct: 0, share_pp: 0 }
  return { ...base, process: { ...inferProcess(caseType, base), ...(impact?.process ?? {}) } }
}

/** Recalculate the shared financial transmission coefficients after a professional metric is edited. */
export function syncFinancial(caseType: CaseType, impact: LayeredImpact): LayeredImpact {
  const p = impact.process ?? {}
  if (caseType === '市场营销类') return {
    ...impact,
    revenue_pct: Number((p.unit_sales_pct ?? 0).toFixed(2)),
    margin_pp: Number(((p.satisfaction_pp ?? 0) * 0.5).toFixed(2)),
    expense_pct: Number(((p.channel_coverage_pp ?? 0) * 2).toFixed(2)),
    cash_pct: Number((-((p.channel_coverage_pp ?? 0) + (p.product_mix_width_delta ?? 0) * 2)).toFixed(2)),
  }
  if (caseType === '战略决策类') return {
    ...impact,
    revenue_pct: Number(((p.market_capacity_pct ?? 0) * 5).toFixed(2)),
    margin_pp: Number(((p.competition_intensity_pp ?? 0) * -0.5).toFixed(2)),
    expense_pct: Number((((p.risk_score_pp ?? 0) * 5) + 0).toFixed(2)),
    cash_pct: Number((-(p.risk_score_pp ?? 0) * 3).toFixed(2)),
    share_pp: Number((p.target_market_share_pp ?? 0).toFixed(2)),
  }
  return {
    ...impact,
    revenue_pct: Number(((p.efficiency_pp ?? 0) * 0.8 + (p.profitability_pp ?? 0) * 0.2).toFixed(2)),
    margin_pp: Number(((p.profitability_pp ?? 0) * 0.5).toFixed(2)),
    expense_pct: Number((-(p.solvency_pp ?? 0) * 0.5).toFixed(2)),
    cash_pct: Number(((p.liquidity_pp ?? 0) * 5).toFixed(2)),
  }
}
