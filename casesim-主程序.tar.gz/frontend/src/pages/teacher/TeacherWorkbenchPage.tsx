import { listCaseAiTasks } from '../../features/ai/api'
import TaskStatus, { pendingTask } from '../../features/ai/TaskStatus'
import type { AiTaskResponse } from '../../api/types'
import { useContext, useEffect, useRef, useState } from 'react'
import { TeacherDraftContext } from '../../context/TeacherDraftContext'
import { Alert, App as AntdApp, Button, Card, Popconfirm, Input, Steps, Space, Spin, Tag, Typography } from 'antd'
import { createCase, copySharedCase, deleteCase, getCase, listCases, listSharedCases } from '../../api/client'
import type { CaseListItem, CreateCasePayload, GetCaseResponse, PublishResponse, SharedCaseItem } from '../../api/types'
import { caseTypeLabel } from '../../domain/caseConstants'
import { useTeacherToken } from '../../context/TeacherTokenContext'
import AiFixDrawer from '../../features/ai/AiFixDrawer'
import CalibratePanel from './components/CalibratePanel'
import GeneratePanel from '../../features/ai/GeneratePanel'
import PublishPanel from './components/PublishPanel'
import { STATUS_META } from './teacherConstants'
import './teacher.css'

const SELECTION_KEY = 'teacher_selected_case'
export default function TeacherWorkbenchPage() {
  const teacherToken = useTeacherToken()
  const { message } = AntdApp.useApp()
  const registerDraft = useContext(TeacherDraftContext)
  const [stage, setStage] = useState(1)
  const [creating, setCreating] = useState(false)
  const [search, setSearch] = useState('')
  const [dirtyParts, setDirtyParts] = useState<string[]>([])
  const [sourceDirty, setSourceDirty] = useState(false)
  const hasDraft = dirtyParts.length > 0 || sourceDirty
  const dirtyRef = useRef(false)
  dirtyRef.current = hasDraft
  useEffect(() => { registerDraft(hasDraft); return () => registerDraft(false) }, [hasDraft, registerDraft])
  useEffect(() => {
    const warn = (e: BeforeUnloadEvent) => { if (dirtyRef.current) { e.preventDefault(); e.returnValue = '' } }
    window.addEventListener('beforeunload', warn)
    return () => window.removeEventListener('beforeunload', warn)
  }, [])
  function mayDiscard() { return !hasDraft || window.confirm('还有未保存的编辑或正在执行的操作。切换案例会丢弃未保存内容，是否继续？') }
  function chooseCase(id: number) {
    if (id === caseId && !creating) return
    if (!mayDiscard()) return
    setDirtyParts([]); setSourceDirty(false); setCreating(false); setCaseId(id); setStage(1); setGenErrors([])
  }
  const [caseList, setCaseList] = useState<CaseListItem[]>([])
  const [listLoading, setListLoading] = useState(true)
  const [caseId, setCaseId] = useState<number | null>(null)
  const [detail, setDetail] = useState<GetCaseResponse | null>(null)
  const [task, setTask] = useState<AiTaskResponse | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const [connectionError, setConnectionError] = useState('')
  const [listError, setListError] = useState('')
  const [genErrors, setGenErrors] = useState<string[]>([])
  const [publishResult, setPublishResult] = useState<PublishResponse | null>(null)
  const [refresh, setRefresh] = useState(0), [listRefresh, setListRefresh] = useState(0)
  const [shared, setShared] = useState<SharedCaseItem[]>([])
  const [sharedLoading, setSharedLoading] = useState(true)
  const [copyingId, setCopyingId] = useState<number | null>(null)
  const [draftRevision, setDraftRevision] = useState(0)
  const [resetRevision, setResetRevision] = useState(0)
  const saveRead = useRef(0)
  const currentDetailId = useRef<number | null>(null)
  const currentScope = useRef({ caseId, teacherToken })
  currentScope.current = { caseId, teacherToken }
  const mounted = useRef(false), uploadLock = useRef(false)
  useEffect(() => { mounted.current = true; return () => { mounted.current = false } }, [])

  useEffect(() => {
    let active = true, timer: number | undefined
    async function pollList() {
      let retry = true
      try {
        const rows = await listCases(teacherToken)
        if (!active) return
        setCaseList(rows)
        setListError('')
        setCaseId((current) => {
          if (current !== null) return current
          let saved = 0
          try { saved = Number(sessionStorage.getItem(SELECTION_KEY)) } catch { /* optional */ }
          return rows.find((row) => row.id === saved)?.id ?? rows.find((row) => row.status === 'generating')?.id ?? rows[0]?.id ?? null
        })
      } catch (e) {
        if (!active) return
        const status = (e as { status?: number }).status
        retry = status !== 401 && status !== 403
        setListError('案例列表暂不可用；已受理的任务仍由后台执行。')
      } finally {
        if (active) { setListLoading(false); if (retry) timer = window.setTimeout(() => void pollList(), 5000) }
      }
    }
    void pollList()
    return () => { active = false; window.clearTimeout(timer) }
  }, [teacherToken, listRefresh])

  // 共享校案例库：其他教师已发布的案例，可一键复制到个人库后修改。
  useEffect(() => {
    let active = true
    setSharedLoading(true)
    listSharedCases(teacherToken)
      .then((rows) => { if (active) setShared(rows) })
      .catch(() => { if (active) setShared([]) })
      .finally(() => { if (active) setSharedLoading(false) })
    return () => { active = false }
  }, [teacherToken, listRefresh])

  async function handleCopyShared(id: number) {
    setCopyingId(id)
    try {
      const created = await copySharedCase(id, teacherToken)
      message.success('已复制到个人案例库，可修改后重新发布。')
      setListRefresh((n) => n + 1)
      setRefresh((n) => n + 1)
      chooseCase(created.case.id)
    } finally {
      setCopyingId(null)
    }
  }

  useEffect(() => {
    let active = true, timer: number | undefined, failures = 0
    setConnectionError('')
    if (currentDetailId.current !== caseId) { setDetail(null); setTask(null); setPublishResult(null); currentDetailId.current = caseId }
    if (caseId === null) return
    try { sessionStorage.setItem(SELECTION_KEY, String(caseId)) } catch { /* optional */ }
    async function poll() {
      let again = false
      try {
        const [response, tasks] = await Promise.all([getCase(caseId!, teacherToken), listCaseAiTasks(caseId!, teacherToken)])
        if (!active) return
        const latest = tasks[0] ?? null
        setDetail(response); setDraftRevision(n => n + 1); setTask(latest); setConnectionError(''); failures = 0
        setCaseList((rows) => rows.map((row) => row.id === response.case.id ? { ...row, status: response.case.status } : row))
        again = response.case.status === 'generating' || pendingTask(latest)
      } catch (e) {
        if (!active) return
        failures++
        const status = (e as { status?: number }).status
        again = ![401, 403, 404].includes(status ?? 0)
        setConnectionError(again ? '进度连接暂时中断，正在自动重连；不会取消后台任务。' : '无法读取案例，请重新登录或选择其他案例。')
      } finally {
        if (active && again) timer = window.setTimeout(() => void poll(), Math.min(15000, 2000 * (1 + failures)))
      }
    }
    void poll()
    return () => { active = false; window.clearTimeout(timer) }
  }, [caseId, teacherToken, refresh])

  // Saving is a metadata synchronization, not a navigation/generation refresh.
  // Keep the editor mounted and leave all unsaved drafts untouched.
  async function syncAfterSave() {
    if (caseId === null) return
    const request = ++saveRead.current
    try {
      const response = await getCase(caseId, teacherToken)
      if (!mounted.current || request !== saveRead.current || currentScope.current.caseId !== caseId || currentScope.current.teacherToken !== teacherToken) return
      setDetail(response)
      setPublishResult(null)
      setCaseList(rows => rows.map(row => row.id === response.case.id ? { ...row, title: response.case.title, status: response.case.status } : row))
    } catch {
      if (mounted.current && currentScope.current.caseId === caseId && currentScope.current.teacherToken === teacherToken) message.warning('保存已完成，但最新状态同步失败；当前编辑内容已保留。')
    }
  }

  async function handleGenerate(payload: CreateCasePayload): Promise<boolean> {
    if (uploadLock.current) return false
    uploadLock.current = true; setSubmitting(true); setGenErrors([])
    try {
      // 多账号：创建时把令牌带给后端，案例归属到当前登录教师
      const created = await createCase({ ...payload, token: teacherToken })
      try { sessionStorage.setItem(SELECTION_KEY, String(created.case_id)) } catch { /* optional */ }
      if (mounted.current) {
        setCreating(false); setStage(1); setSourceDirty(false); setDirtyParts([]); setCaseId(created.case_id); setRefresh((n) => n + 1); setListRefresh((n) => n + 1)
        if (created.warning) setGenErrors(created.errors ?? [created.warning])
        else message.success('素材已受理，任务已保存到后台；可以切换页面，稍后回来查看。')
      }
      return true
    } catch {
      if (mounted.current) setGenErrors(['上传或受理未确认，请刷新案例列表确认是否已创建，再决定是否重试。'])
      return false
    } finally {
      uploadLock.current = false
      if (mounted.current) setSubmitting(false)
    }
  }

  async function handleDeleteSelectedCase() {
    if (caseId === null) return
    const deletingId = caseId
    setSubmitting(true)
    try {
      await deleteCase(deletingId, teacherToken)
      try { sessionStorage.removeItem(SELECTION_KEY) } catch { /* optional */ }
      setDirtyParts([])
      setSourceDirty(false)
      setTask(null)
      setCaseId(null)
      setDetail(null)
      setCaseList((rows) => rows.filter((row) => row.id !== deletingId))
      setListRefresh((n) => n + 1)
      message.success('已移入回收站。可在「案例回收站」恢复或彻底删除。')
    } catch (e) {
      const detail = (e as { detail?: string }).detail
      message.error(detail || '删除失败；若案例仍有后台任务，请等待任务结束后重试。')
    } finally {
      setSubmitting(false)
    }
  }

  function handleResetSelectedCase() {
    if (caseId === null || !selected) return
    if (!hasDraft) { message.info('当前没有需要恢复的修改。'); return }
    if (busy || dirtyParts.some((part) => part.includes('进行中'))) {
      message.warning('当前操作尚未完成，请稍后再恢复。')
      return
    }
    if (!window.confirm('放弃尚未保存的修改，并恢复到最近一次保存的内容？')) return
    setDirtyParts([])
    setSourceDirty(false)
    setResetRevision((value) => value + 1)
    message.success('已恢复到最近一次保存的内容。')
  }

  const selected = detail?.case.id === caseId ? detail : null
  const selectedTask = selected ? task : null
  const busy = selected?.case.status === 'generating' || pendingTask(selectedTask)
  const statusMeta = selected ? STATUS_META[selected.case.status] : null
  const running = caseList.filter((row) => row.status === 'generating')
  // 案例库折叠：默认展开；折叠后左栏收成一条窄栏，选择记忆在本标签页内（sessionStorage）
  const [libraryCollapsed, setLibraryCollapsed] = useState(() => {
    try { return sessionStorage.getItem('teacher_case_library_collapsed') === '1' } catch { return false }
  })
  // 案例库范围筛选：all=全部 / personal=个人案例库 / school=校案例库
  const [scopeFilter, setScopeFilter] = useState<'all' | 'personal' | 'school'>('all')
  function toggleLibrary() {
    setLibraryCollapsed((v) => {
      const next = !v
      try { sessionStorage.setItem('teacher_case_library_collapsed', next ? '1' : '0') } catch { /* 可选持久化，失败不影响功能 */ }
      return next
    })
  }
  const filteredCases = caseList.filter((row) =>
    row.title.toLowerCase().includes(search.trim().toLowerCase()) &&
    (scopeFilter === 'all' || (row.library_scope ?? 'school') === scopeFilter))
  return <div className="teacher-workspace">
    <div className="teacher-page-head"><div><Typography.Title level={3} style={{ margin: 0 }}>案例工作区</Typography.Title><Typography.Text type="secondary">按教学任务准备案例。草稿保存与发布分开，已有推演保持原版本。</Typography.Text></div>
      <Button type="primary" disabled={submitting} onClick={() => { if (mayDiscard()) { setCreating(true); setStage(0); setDirtyParts([]); setSourceDirty(false) } }}>新建案例</Button>
    </div>
    <div className="case-workspace-grid" style={libraryCollapsed ? { gridTemplateColumns: '64px minmax(0, 1fr)' } : undefined}>
    <aside className={libraryCollapsed ? 'case-library is-collapsed' : 'case-library'} aria-label="案例库">
      {libraryCollapsed ? <Button block className="case-library-rail" aria-label="展开案例库" aria-expanded={false} title="展开案例库" onClick={toggleLibrary}>案例库 »</Button>
      : <><Card size="small">
      <div className="case-library-head"><strong>案例库</strong><Button type="text" size="small" aria-label="折叠案例库" aria-expanded title="折叠案例库" onClick={toggleLibrary}>«</Button></div>
      <Input.Search aria-label="搜索案例" placeholder="搜索案例标题" value={search} onChange={e => setSearch(e.target.value)} />
      <div className="case-library-scope">
        {([['all', '全部'], ['personal', '个人库'], ['school', '校库']] as const).map(([key, label]) =>
          <Button key={key} size="small" type={scopeFilter === key ? 'primary' : 'default'} onClick={() => setScopeFilter(key)}>{label}</Button>)}
      </div>
      {listLoading && <Spin />}
      <div className="case-library-list">{filteredCases.map(row => <Button key={row.id} data-case-id={row.id} block type={!creating && row.id === caseId ? 'primary' : 'text'} onClick={() => chooseCase(row.id)}>
        <span>{row.title}<Tag color={STATUS_META[row.status].color}>{STATUS_META[row.status].text}</Tag><Tag color={(row.library_scope ?? 'school') === 'school' ? 'blue' : 'purple'}>{(row.library_scope ?? 'school') === 'school' ? '校库' : '个人库'}</Tag></span>
      </Button>)}</div>
      {!listLoading && !filteredCases.length && <p>{caseList.length ? '当前筛选下没有案例' : '还没有案例，点击“新建案例”开始。'}</p>}
      {!!search && !filteredCases.some(r => r.title.toLowerCase().includes(search.trim().toLowerCase())) && <p>没有匹配案例</p>}
    </Card>
      <Card size="small" title="共享案例库" style={{ marginTop: 12 }}>
        {sharedLoading && <Spin />}
        <div className="case-library-list">
          {shared.map((item) => <div key={item.id} className="case-library-shared">
            <div><strong>{item.title}</strong></div>
            <div>
              <Tag color="blue">{item.case_type ? caseTypeLabel(item.case_type) : '未分类'}</Tag>
              <Tag>{item.teacher_name}</Tag>
              <Tag>v{item.version}</Tag>
            </div>
            <Button size="small" block loading={copyingId === item.id} disabled={copyingId !== null}
              onClick={() => void handleCopyShared(item.id)}>复制到我的案例库</Button>
          </div>)}
        </div>
        {!sharedLoading && !shared.length && <p>暂无可复制的共享案例。</p>}
      </Card></>}
    </aside>
    <section className="case-editor" aria-label="案例编辑">
    {listError && <Alert showIcon type="warning" message={listError} />}
    {connectionError && <Alert showIcon type="warning" message={connectionError} />}
    <Steps size="small" current={creating ? 0 : stage} onChange={next => setStage(next)} items={[
      { title: '素材与生成', disabled: creating }, { title: '经营基准', disabled: creating || !selected },
      { title: '节点与规则', disabled: creating || !selected?.nodes.length }, { title: '检查与发布', disabled: creating || !selected },
    ]} />
    {creating ? <GeneratePanel generating={submitting} statusText="正在接收素材，请稍候" errors={genErrors} onGenerate={handleGenerate} onDirtyChange={setSourceDirty} /> : <>
      {selected && <div className="editor-status"><Space wrap><Typography.Text strong>{selected.case.title}</Typography.Text>{statusMeta && <Tag color={statusMeta.color}>{statusMeta.text}</Tag>}<Tag>草稿版本 {selected.case.version}</Tag></Space>
        <Space wrap><Button onClick={() => { setRefresh(n => n + 1); setListRefresh(n => n + 1) }}>刷新状态</Button><Button disabled={!!busy || dirtyParts.some((part) => part.includes('进行中')) || !hasDraft} onClick={handleResetSelectedCase}>重置</Button><Popconfirm title="移入回收站？" description="尚未保存的修改也会放弃；案例从当前列表中隐藏，可在回收站恢复。" okText="移入回收站" cancelText="取消" okButtonProps={{ danger: true }} onConfirm={() => void handleDeleteSelectedCase()}><Button danger disabled={!!busy}>删除</Button></Popconfirm></Space>
      </div>}
      <div role="status" className="draft-status">{dirtyParts.length ? `待处理：${dirtyParts.join('、')}。切换阶段会保留编辑，离开页面前请保存。` : '当前无未保存编辑。保存草稿后仍需发布，新推演才会使用修改。'}</div>
      {selectedTask && <TaskStatus task={selectedTask} busy={!!busy} />}
      {stage === 0 && <Card title="素材与生成"><p>当前案例已受理。原始素材用于教师核对，创建另一案例请使用“新建案例”。</p><details><summary>查看原始素材</summary><Typography.Paragraph style={{ whiteSpace: 'pre-wrap' }}>{selected?.case.source_text || '暂无可展示素材'}</Typography.Paragraph></details><Button onClick={() => setStage(1)} disabled={!selected}>进入经营基准</Button></Card>}
      {selected ? <>
        <div hidden={stage !== 1 && stage !== 2}><CalibratePanel key={`${selected.case.id}-${resetRevision}`} stage={stage} onDirtyChange={setDirtyParts} teacherToken={teacherToken} detail={selected} draftRevision={draftRevision} onSaveRefresh={syncAfterSave} onRefresh={async () => { setRefresh(n => n + 1) }} /></div>
        <div hidden={stage !== 3}><PublishPanel teacherToken={teacherToken} detail={selected} publishResult={publishResult} onPublished={setPublishResult} blocked={dirtyParts} onEdit={setStage} /></div>
        <AiFixDrawer key={selected.case.id} teacherToken={teacherToken} caseId={caseId} nodes={selected.nodes} />
        <Space wrap className="stage-actions"><Button disabled={stage === 0} onClick={() => setStage(s => Math.max(0, s - 1))}>上一阶段</Button><Button disabled={stage >= 3 || (stage === 1 && !selected.nodes.length)} onClick={() => setStage(s => Math.min(3, s + 1))}>下一阶段</Button>{stage === 1 && !selected.nodes.length && <Typography.Text type="secondary">确认经营基准并生成节点后，进入下一阶段。</Typography.Text>}</Space>
      </> : <Card>{busy || caseId !== null ? <Spin /> : <Typography.Text>选择已有案例，或新建案例开始备课。</Typography.Text>}</Card>}
    </>}
    {running.length > 0 && <Typography.Text type="secondary">后台有 {running.length} 个案例生成中，可从案例库查看。</Typography.Text>}
    </section></div>
  </div>
}
