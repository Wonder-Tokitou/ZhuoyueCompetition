import { useEffect, useRef, useState } from 'react'
import type { ReactNode } from 'react'
import { Alert, App, Button, Card, Checkbox, InputNumber, Select, Space, Table, Typography } from 'antd'
import { api } from '../../../api/client'
import type { GetCaseResponse } from '../../../api/types'
import { PROCESS_FIELDS, PROCESS_TITLES, normalizeImpact, syncFinancial } from '../../../domain/frameworkMetrics'
import type { FinancialImpact, LayeredImpact, ProcessKey } from '../../../domain/frameworkMetrics'

type Impact = LayeredImpact
type Basis = { basis: string; is_assumption: boolean; caveat: string; teacher_edited?: boolean }
type ReferencePath = { path: string; kind: 'recommended' | 'historical' }
type Configuration = { enabled: boolean; cash_flow_amount: number; rules: Record<string, Impact>; reasoning?: Record<string, Basis>; reference_path?: ReferencePath | null }
type Task = { task_id: string; status: string; error?: string }
type Path = { path: string; final: Record<string, number | string>; steps: Record<string, number | string>[] }
/** 过程指标区间提示：warning=黄色提示，danger=红色预警 */
type SimulationWarning = { level: 'warning' | 'danger'; message: string; round: number; path: string }
const fields: [keyof FinancialImpact, string][] = [['revenue_pct', '营收变化 %'], ['margin_pp', '毛利率变化 百分点'], ['expense_pct', '运营费用变化 %'], ['cash_pct', '现金流变化 %'], ['share_pp', '市场份额变化 百分点']]

export default function ProgressivePanel({ detail, token, children, onSummariesSaved, onDirtyChange, prerequisitesDirty = false }: { detail: GetCaseResponse; token: string; children?: (renderImpact: (id: string) => ReactNode) => ReactNode; onSummariesSaved?: (summaries: Record<string, string>) => void; onDirtyChange?: (dirty: boolean) => void; prerequisitesDirty?: boolean }) {
  const { message } = App.useApp()
  const [rules, setRules] = useState<Record<string, Impact>>({})
  const [reference, setReference] = useState<ReferencePath | null>(null)
  const [referenceKind, setReferenceKind] = useState<'recommended' | 'historical'>('recommended')
  const [cash, setCash] = useState<number | null>(null)
  const [confirmed, setConfirmed] = useState(false)
  const [busy, setBusy] = useState(false)
  const [loaded, setLoaded] = useState(false)
  const [published, setPublished] = useState(false)
  const [paths, setPaths] = useState<Path[]>([])
  const [warnings, setWarnings] = useState<SimulationWarning[]>([])
  const [reasoning, setReasoning] = useState<Record<string, Basis>>({})
  const [aiStatus, setAiStatus] = useState('')
  const [retryNo, setRetryNo] = useState(0)
  const [generating, setGenerating] = useState(false)
  const [savedRules, setSavedRules] = useState('')
  const [reviewRequired, setReviewRequired] = useState(false)
  const snapshot = JSON.stringify({ rules, cash })
  const dirty = loaded && (snapshot !== savedRules || reviewRequired)
  useEffect(() => { onDirtyChange?.(dirty || busy || generating || !loaded) }, [dirty, busy, generating, loaded, onDirtyChange])
  const touched = useRef(false)
  const url = `/cases/${detail.case.id}/simulation`
  useEffect(() => {
    let active = true
    let timer: ReturnType<typeof setTimeout> | undefined
    touched.current = false
    setLoaded(false); setPaths([]); setConfirmed(false)
    setAiStatus(''); setGenerating(false); setReasoning({})
    async function poll(task: Task) {
      if (!active) return
      if (task.status === 'succeeded') {
        const { data } = await api.get<{ rules: Record<string, Impact>; reasoning: Record<string, Basis> }>(`/ai-tasks/${task.task_id}/output`, { params: { token } })
        const saved = await api.get<{ draft: Configuration | null }>(url, { params: { token } })
        if (!active) return
        setGenerating(false)
        if (saved.data.draft) { setAiStatus('已保存的教师规则保持不变。请刷新后载入最新版本。'); return }
        if (touched.current) { setAiStatus('当前表格已有修改，参考规则没有覆盖这些内容。'); return }
        setRules(Object.fromEntries(Object.entries(data.rules).map(([id, rule]) => [id, normalizeImpact(detail.case.case_type, rule)]))); setReasoning(data.reasoning); setConfirmed(false)
        setAiStatus('参考规则已填入。请结合案例材料核对各项影响，再预览确认。')
        return
      }
      if (['failed', 'cancelled'].includes(task.status)) {
        setGenerating(false); setAiStatus(`参考规则暂时未能生成：${task.error || '请重试'}`); return
      }
      setGenerating(true); setAiStatus('正在准备9条影响规则并校验全部路径，刷新页面不会中断。')
      timer = setTimeout(async () => {
        try {
          const { data } = await api.get<Task>(`/ai-tasks/${task.task_id}`, { params: { token } })
          await poll(data)
        } catch {
          if (active) { setGenerating(false); setAiStatus('进度读取失败，请点击恢复查看；后台任务不会因此重复创建。') }
        }
      }, 2500)
    }
    api.get<{ draft: Configuration | null; published: boolean }>(url, { params: { token } }).then(({ data }) => {
      if (!active) return
      const normalizedRules = Object.fromEntries(Object.entries(data.draft?.rules || {}).map(([id, rule]) => [id, normalizeImpact(detail.case.case_type, rule)]))
      setRules(normalizedRules); setCash(data.draft?.cash_flow_amount ?? null)
      setSavedRules(data.draft ? JSON.stringify({ rules: normalizedRules, cash: data.draft.cash_flow_amount }) : '')
      setReference(data.draft?.reference_path ?? null)
      setReferenceKind(data.draft?.reference_path?.kind ?? 'recommended')
      setReasoning(data.draft?.reasoning || {})
      setPublished(data.published); setLoaded(true)
      if (data.draft) { setAiStatus('已载入上次保存的规则。'); return }
      setGenerating(true)
      api.post<{ protected: boolean; task: Task | null }>(`${url}/suggest`, null, { params: { token, retry: retryNo > 0 } }).then(async ({ data: result }) => {
        if (!active) return
        if (result.protected || !result.task) { setGenerating(false); setAiStatus('教师规则已在其他页面保存，请刷新载入。'); return }
        await poll(result.task)
      }).catch(() => { if (active) { setGenerating(false); setAiStatus('参考规则暂时无法读取，可重试或手动填写。') } })
    }).catch(() => { if (active) setLoaded(false) })
    return () => { active = false; if (timer) clearTimeout(timer) }
  }, [url, token, retryNo])
  // Saving node text/baseline increments the case version, but must not reload
  // persisted rules over the teacher's current unsaved input.
  const previousVersion = useRef({ url, token, version: detail.case.version })
  useEffect(() => {
    const previous = previousVersion.current
    previousVersion.current = { url, token, version: detail.case.version }
    if (previous.url === url && previous.token === token && previous.version !== detail.case.version) {
      touched.current = true // The pending suggestion may have used the previous node text.
      setReviewRequired(true)
      setPaths([])
      setConfirmed(false)
    }
  }, [url, token, detail.case.version])
  const rows = detail.nodes.flatMap(n => n.options.map(o => ({ id: `${n.id}:${o.key}`, title: `第${n.idx}轮 ${o.key}：${o.label}` })))
  function change(id: string, key: keyof FinancialImpact, value: number | null) {
    touched.current = true
    setRules(prev => ({ ...prev, [id]: { ...(prev[id] || { revenue_pct: 0, margin_pp: 0, expense_pct: 0, cash_pct: 0, share_pp: 0 }), [key]: value ?? 0 } }))
    setPaths([]); setConfirmed(false)
    setReasoning(prev => prev[id] ? { ...prev, [id]: { ...prev[id], teacher_edited: true } } : prev)
  }
  function changeProcess(id: string, key: ProcessKey, value: number | null) {
    touched.current = true
    setRules(prev => {
      const current = normalizeImpact(detail.case.case_type, prev[id])
      return { ...prev, [id]: syncFinancial(detail.case.case_type, { ...current, process: { ...current.process, [key]: value ?? 0 } }) }
    })
    setPaths([]); setConfirmed(false)
    setReasoning(prev => prev[id] ? { ...prev, [id]: { ...prev[id], teacher_edited: true } } : prev)
  }
  async function submit(save: boolean) {
    if (busy || prerequisitesDirty) { message.warning('请先保存财务基准与节点文案，再核对递进规则。'); return }
    if (cash === null) { message.warning('请填写有依据的本期现金净流量金额，不从描述自动推断'); return }
    if (save && !confirmed) { message.warning('请先确认9个选项规则'); return }
    if (generating) { message.warning('请等待参考规则准备完成，避免把暂定的0保存为规则'); return }
    const config: Configuration = { enabled: true, cash_flow_amount: cash, reasoning, reference_path: reference, rules: Object.fromEntries(rows.map(r => [r.id, normalizeImpact(detail.case.case_type, rules[r.id])])) }
    setBusy(true)
    try {
      const { data } = await api.post<{ paths: Path[]; warnings?: SimulationWarning[] }>(`${url}/preview`, config, { params: { token } })
      setPaths(data.paths)
      setWarnings(data.warnings ?? [])
      if (save) {
        const saved = await api.put<{ summaries?: Record<string, string> }>(url, config, { params: { token } })
        setSavedRules(snapshot)
        setReviewRequired(false)
        onSummariesSaved?.(saved.data.summaries || {})
        message.success('规则已保存。请点击下方“发布案例”，发布后新推演才使用新规则。')
      }
    } finally { setBusy(false) }
  }
  function renderImpact(id: string) {
    return <Space direction="vertical" style={{ width: '100%' }}>
      <Typography.Text strong>{PROCESS_TITLES[detail.case.case_type]}</Typography.Text>
      {PROCESS_FIELDS[detail.case.case_type].map(({ key, label, unit, kind }) => <InputNumber key={key} aria-label={`${id} ${label}`} addonBefore={label} addonAfter={unit} style={{ width: '100%' }} value={normalizeImpact(detail.case.case_type, rules[id]).process?.[key] ?? 0} precision={kind === 'tier' ? 0 : 2} step={kind === 'tier' ? 1 : undefined} min={kind === 'tier' ? -2 : -1000} max={kind === 'tier' ? 2 : 1000} disabled={!loaded || busy} onChange={value => changeProcess(id, key, value == null ? null : Number(value))} />)}
      <details><summary>查看财务传导指标</summary>
        <Space direction="vertical" style={{ width: '100%', marginTop: 8 }}>
          {fields.map(([key, label]) => <InputNumber key={key} aria-label={`${id} ${label}`} addonBefore={label} style={{ width: '100%' }} value={rules[id]?.[key] ?? 0} precision={key.endsWith('_pp') ? 1 : 2} min={-100} max={key.endsWith('_pp') ? 100 : 1000} disabled={!loaded || busy} onChange={value => change(id, key, value == null ? null : Number(value))} />)}
        </Space>
      </details>
      <details><summary>查看测算依据</summary>{reasoning[id] ? <><p>{reasoning[id].teacher_edited ? '当前数值已由教师调整。' : ''}{reasoning[id].is_assumption ? '教学假设：' : '材料依据：'}{reasoning[id].basis}</p><p>适用范围：{reasoning[id].caveat}</p></> : '请结合案例材料核对。'}</details>
    </Space>
  }
  async function saveReference(next: ReferencePath | null) {
    if (busy || !loaded || dirty || prerequisitesDirty) { message.warning('请先保存文案和递进规则，再选择参考路径。'); return }
    setBusy(true)
    try {
      await api.put(`${url}/reference`, { reference_path: next, rules, cash_flow_amount: cash }, { params: { token } })
      setReference(next)
      if (next) setReferenceKind(next.kind)
      message.success(next ? '标准路径及推演结果已自动保存；请重新发布案例，新推演即可使用。' : '标准路径已取消，请重新发布生效。')
    } catch { /* transport displays the error; keep last saved selection */ }
    finally { setBusy(false) }
  }
  // 红字要求「预览区域不折叠」：加载完已保存规则后自动预览一次，进入界面即展示全部路径。
  const autoPreviewed = useRef(false)
  useEffect(() => {
    if (!loaded || generating || busy || prerequisitesDirty) return
    if (cash === null || Object.keys(rules).length !== 9 || paths.length > 0 || autoPreviewed.current) return
    autoPreviewed.current = true
    void submit(false).catch(() => { /* transport 已提示错误，保持界面可重试 */ })
  }, [loaded, generating, busy, prerequisitesDirty, cash, rules, paths])
  return <Card title="决策校准：选项与递进影响规则" size="small">
    <Space direction="vertical" style={{ width: '100%' }}>
      <Alert type="info" showIcon message={published ? '当前案例已发布；保存修改后需要重新发布。' : '当前案例尚未发布。'} description={`${PROCESS_TITLES[detail.case.case_type]}用于呈现本课程的决策变化，财务结果由同一套公式同步计算。请先保存基准与选项文案，再核对规则并预览全部路径。`} />
      <Typography.Text>本期现金净流量（万元，与营收使用同一期间及企业范围）</Typography.Text>
      <Typography.Text role="status">{!loaded ? '正在载入规则…' : reviewRequired ? '案例内容已改变，请重新预览并保存' : dirty ? '当前修改尚未保存' : '规则已保存，重新发布后生效'}</Typography.Text>
      {prerequisitesDirty && <Alert type="warning" showIcon message="基准或节点文案尚未保存，请先保存，再预览和保存规则。" />}
      {aiStatus && <Alert type={aiStatus.includes('失败') ? 'warning' : 'info'} message={aiStatus} />}
      {!generating && !touched.current && (aiStatus.includes('未能') || aiStatus.includes('重试') || aiStatus.includes('恢复') || aiStatus.includes('无法')) && <Button onClick={() => setRetryNo(n => n + 1)}>重新准备参考规则</Button>}
      <InputNumber aria-label="本期现金净流量（万元）" value={cash} precision={2} onChange={v => { touched.current = true; setCash(v); setConfirmed(false); setPaths([]) }} disabled={!loaded || busy} />
      <Typography.Text type="secondary">现金流允许为负值；例如 −10 × (1+20%) = −12，表示净流出扩大。净利润由营收、成本和费用统一计算，不单独填写比例。</Typography.Text>
      {children ? children(renderImpact) : <Table rowKey="id" dataSource={rows} pagination={false} expandable={{ expandedRowRender: row => reasoning[row.id] ? <Space direction="vertical"><Typography.Text>{reasoning[row.id].is_assumption ? '教学假设' : '材料/规范依据'}{reasoning[row.id].teacher_edited ? '（教师已调整系数，以下保留初始测算依据）' : ''}</Typography.Text><Typography.Text>{reasoning[row.id].basis}</Typography.Text><Typography.Text type="secondary">适用范围：{reasoning[row.id].caveat}</Typography.Text></Space> : <Typography.Text>暂无测算依据，请结合案例材料核对。</Typography.Text> }} scroll={{ x: 1100 }} columns={[
        { title: '决策选项', dataIndex: 'title', width: 330 },
        ...fields.map(([key, title]) => ({ title, key, render: (_: unknown, row: typeof rows[number]) => <InputNumber aria-label={`${row.title} ${title}`} value={rules[row.id]?.[key] ?? 0} precision={key.endsWith('_pp') ? 1 : 2} min={-100} max={key.endsWith('_pp') ? 100 : 1000} disabled={!loaded || busy} onChange={v => change(row.id, key, v)} /> }))
      ]} />}
      <Checkbox className="review-confirm" checked={confirmed} disabled={!loaded || busy || generating} onChange={e => setConfirmed(e.target.checked)}>已核对基准及9个选项影响规则（含无影响的0值）</Checkbox>
      <Space wrap>
        <Typography.Text>参考路径类型</Typography.Text>
        <Select aria-label="参考路径类型" disabled={!loaded || busy || generating} value={referenceKind} options={[{value:'recommended',label:'教师推荐方案'},{value:'historical',label:'案例实际采用路径'}]} onChange={kind => { if (reference) void saveReference({...reference,kind}); else setReferenceKind(kind) }} />
        <Typography.Text>{reference ? `已选：${reference.path}` : '未设置参考路径（可选）'}</Typography.Text>
        <Button disabled={!reference || busy} onClick={() => void saveReference(null)}>取消参考路径</Button>
      </Space>
      <Typography.Text type="secondary">先保存递进规则，再选择标准路径。选中后自动保存路径及推演结果，提示成功后重新发布，新推演完成三轮即可查看。参考方案不是唯一正确答案，金额为教学模拟。</Typography.Text>
      <Space><Button disabled={!loaded || generating || rows.length !== 9} loading={busy} onClick={() => void submit(false)}>预览27条路径</Button><Button type="primary" disabled={!loaded || generating || rows.length !== 9 || !confirmed} loading={busy} onClick={() => void submit(true)}>保存递进规则（待发布）</Button></Space>
      {warnings.length > 0 && <Space direction="vertical" style={{ width: '100%' }}>
        {warnings.map((item) => <Alert key={item.message} showIcon
          type={item.level === 'danger' ? 'error' : 'warning'}
          message={item.message}
          description={`首次出现在第 ${item.round} 轮 · 路径 ${item.path}`} />)}
      </Space>}
      {paths.length >= 0 && <Table size="small" rowKey="path" dataSource={paths} pagination={false} expandable={{ defaultExpandAllRows: true, expandedRowRender: row => <div>{row.steps.map((s, i) => <p key={i}>第{i + 1}轮：营收 {s.revenue}，毛利率 {s.gross_margin}，成本 {s.operating_cost}，费用 {s.operating_expense}，净利润 {Number(s.net_profit).toFixed(2)}，现金净流量 {Number(s.cash_flow_amount).toFixed(2)}（金额单位：万元）</p>)}</div> }} columns={[
        { title: '设为参考', key: 'reference', render: (_: unknown, row: Path) => <Checkbox aria-label={`选择参考路径 ${row.path}`} checked={reference?.path === row.path} disabled={busy || !loaded} onChange={e => void saveReference(e.target.checked ? {path:row.path,kind:referenceKind} : null)} /> },
        { title: '路径（教师选项）', dataIndex: 'path', render: (value: string) => <div>{value}<div>{value.split('→').map((key,i) => { const node=[...detail.nodes].sort((a,b)=>a.idx-b.idx)[i]; return <p key={i}>第{i+1}轮：{node?.options.find(o=>o.key===key)?.label}</p> })}</div></div> },
        ...[['revenue', '末轮营收'], ['gross_margin', '末轮毛利率'], ['net_profit', '末轮净利润'], ['cash_flow_amount', '末轮现金净流量']].map(([key, title]) => ({ title, key, render: (_: unknown, row: Path) => typeof row.final[key] === 'number' ? Number(row.final[key]).toFixed(2) : row.final[key] }))
      ]} />}
    </Space>
  </Card>
}
