/**
 * 班级仪表盘图表：选项分布柱状图（A/B/C）。
 * ECharts 按需引入：只注册用到的图表、组件与 Canvas 渲染器，禁止 `import * as echarts from 'echarts'` 全量引入。
 * 说明：未使用 echarts-for-react——其 3.0.6 ESM 入口为 `import * as echarts from 'echarts'`（全量），
 * 与按需引入约束冲突；此处改为自写轻量封装（init / setOption / resize / dispose）。
 * 数据来源：TeacherStudentsPage 从 GET /teacher/dashboard/option-distribution 与
 * /teacher/dashboard/recent-activity 拉取真实统计后传入；无数据时显示空态提示，不展示占位假数据。
 */
import { useEffect, useRef } from 'react'
import * as echarts from 'echarts/core'
import { BarChart } from 'echarts/charts'
import { GridComponent, TooltipComponent, LegendComponent, TitleComponent } from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'
import type { EChartsOption } from 'echarts'

echarts.use([BarChart, GridComponent, TooltipComponent, LegendComponent, TitleComponent, CanvasRenderer])

/** 柱条主色序列，与教师端主色 #1a3a5c 同一色系（深蓝 → 中蓝 → 浅蓝）。 */
const BARS = ['#1a3a5c', '#2f5f8f', '#6d96ba']

/** 轻量 ECharts React 封装：挂载时 init，option 变化时 setOption，卸载时 dispose，窗口 resize 时自适应。 */
function EChart({ option, height }: { option: EChartsOption; height: number }) {
  const elRef = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const el = elRef.current
    if (!el) return
    const chart = echarts.init(el)
    chart.setOption(option)
    const onResize = () => chart.resize()
    window.addEventListener('resize', onResize)
    return () => {
      window.removeEventListener('resize', onResize)
      chart.dispose()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- 仅在挂载时 init 一次
  }, [])
  useEffect(() => {
    const el = elRef.current
    if (!el) return
    const chart = echarts.getInstanceByDom(el)
    if (chart) chart.setOption(option)
  }, [option])
  return <div ref={elRef} style={{ height, width: '100%' }} />
}

/** 无真实数据时的空态提示（不渲染图表，不展示 mock 假数据）。 */
function EmptyChart({ height }: { height: number }) {
  return (
    <div style={{ height, width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#8c8c8c', fontSize: 13 }}>
      暂无作答数据
    </div>
  )
}

export interface OptionDistributionChartProps {
  data?: { name: string; value: number }[]
  height?: number
  maxWidth?: number | string
}

/** 选项分布柱状图（对应参考 HmcOptionsStats 的分布统计；option 参照 ECharts 官方 bar-simple 示例）。 */
export function OptionDistributionChart({ data = [], height = 240, maxWidth = '100%' }: OptionDistributionChartProps) {
  if (!data.length) return <div style={{ width: '100%', maxWidth }}><EmptyChart height={height} /></div>
  const total = data.reduce((sum, d) => sum + d.value, 0) || 1
  const option: EChartsOption = {
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'shadow' },
      formatter: (params) => {
        const p = Array.isArray(params) ? params[0] : params
        const item = data.find((d) => d.name === p?.name)
        if (!item || typeof item.value !== 'number') return ''
        const pct = Math.round((item.value / total) * 100)
        return `${item.name}：${item.value} 人次（${pct}%）`
      },
    },
    grid: { left: 8, right: 8, top: 8, bottom: 8, containLabel: true },
    xAxis: { type: 'category', data: data.map((d) => d.name), axisTick: { alignWithLabel: true } },
    yAxis: {
      type: 'value',
      axisLabel: { formatter: '{value}' },
      splitLine: { lineStyle: { color: '#eef2f6' } },
    },
    series: [
      {
        name: '选项人次',
        type: 'bar',
        barWidth: '50%',
        data: data.map((d, i) => ({ value: d.value, itemStyle: { color: BARS[i % BARS.length], borderRadius: [4, 4, 0, 0] } })),
      },
    ],
  }
  return (
    <div style={{ width: '100%', maxWidth }}>
      <EChart option={option} height={height} />
    </div>
  )
}

export default OptionDistributionChart
