import { Card, Space, Tag, Typography } from 'antd'
import type { GetCaseResponse } from '../../../api/types'
import { STATUS_META } from '../teacherConstants'
import { useCalibrationState } from '../hooks/useCalibrationState'
import BaselineSection from './BaselineSection'
import NodeSection from './NodeSection'

interface CalibratePanelProps {
  stage?: number
  onDirtyChange?: (parts: string[]) => void
  teacherToken: string
  /** 未载入案例时为 null，此时只渲染空态 */
  detail: GetCaseResponse | null
  onRefresh: () => Promise<void>
  onSaveRefresh?: () => Promise<void>
  draftRevision?: number
}

/**
 * 校准区：stage=1 财务基准与案例信息（BaselineSection）、stage=2 节点与递进规则（NodeSection）。
 * 全部草稿状态与联动逻辑收敛在 useCalibrationState；向导仍由父组件 TeacherWorkbenchPage 的 Steps 驱动。
 */
export default function CalibratePanel({ teacherToken, detail, onRefresh, onSaveRefresh, draftRevision, stage = 1, onDirtyChange }: CalibratePanelProps) {
  const state = useCalibrationState({ teacherToken, detail, onRefresh, onSaveRefresh, draftRevision, onDirtyChange })
  const statusMeta = detail ? STATUS_META[detail.case.status] : null
  return (
    <Card
      title={stage === 1 ? '经营基准与案例信息' : '节点与递进规则'}
      extra={statusMeta ? <Tag color={statusMeta.color}>{statusMeta.text}</Tag> : undefined}
    >
      {!detail ? (
        <Typography.Text type="secondary">
          还没有载入案例。生成或选择一个案例后，可核对经营基准、三个决策节点、课程指标及其财务结果。
        </Typography.Text>
      ) : (
        <Space direction="vertical" size={16} style={{ width: '100%' }}>
          <div hidden={stage !== 1}>
            <BaselineSection
              detail={detail}
              title={state.title}
              setTitle={state.setTitle}
              background={state.background}
              setBackground={state.setBackground}
              dilemma={state.dilemma}
              setDilemma={state.setDilemma}
              metrics={state.metrics}
              setMetrics={state.setMetrics}
              operatingCost={state.operatingCost}
              setOperatingCost={state.setOperatingCost}
              operatingExpense={state.operatingExpense}
              setOperatingExpense={state.setOperatingExpense}
              netProfit={state.netProfit}
              setNetProfit={state.setNetProfit}
              revenueLink={state.revenueLink}
              setRevenueLink={state.setRevenueLink}
              baselineDirty={state.baselineDirty}
              savingCase={state.savingCase}
              onSaveCase={state.onSaveCase}
              nodesCount={state.nodes.length}
              generatingNodes={state.generatingNodes}
              nodeError={state.nodeError}
              setNodeError={state.setNodeError}
              nodeProgressError={state.nodeProgressError}
              setNodeProgressError={state.setNodeProgressError}
              nodeTask={state.nodeTask}
              onGenerateNodes={state.onGenerateNodes}
              mode={state.mode}
              processBaseline={state.processBaseline}
              setProcessBaseline={state.setProcessBaseline}
            />
          </div>
          <div hidden={stage !== 2}>
            <NodeSection
              token={teacherToken}
              detail={detail}
              nodes={state.nodes}
              dirtyNodes={state.dirtyNodes}
              activeNode={state.activeNode}
              setActiveNode={state.setActiveNode}
              savingCase={state.savingCase}
              savingNodeId={state.savingNodeId}
              prerequisitesDirty={state.baselineDirty || state.dirtyNodes.length > 0 || state.savingCase || state.savingNodeId !== null}
              onDirtyChange={state.setRulesDirty}
              onSaveNode={state.onSaveNode}
              onSummariesSaved={state.onSummariesSaved}
              updateNode={state.updateNode}
              updateOption={state.updateOption}
              updateOptionMetric={state.updateOptionMetric}
            />
          </div>
        </Space>
      )}
    </Card>
  )
}
