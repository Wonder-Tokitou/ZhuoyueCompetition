import { useEffect, useRef, useState } from 'react'
import { App as AntdApp } from 'antd'
import { generateCaseNodes, patchCase, patchNode } from '../../../api/client'
import { getAiTask, listCaseAiTasks } from '../../../features/ai/api'
import { pendingTask } from '../../../features/ai/TaskStatus'
import { stableIdempotencyKey } from '../../../domain/idempotency.js'
import { calculateNetProfit } from '../../../domain/financials.js'
import { baselineError } from '../components/baselineFinance'
import type { AiTaskResponse, GetCaseResponse, Metrics, OptionDetail, RiskLevel, TeacherNode } from '../../../api/types'
import { METRIC_FIELDS } from '../teacherConstants'
import { PROCESS_BASELINE_DEFAULTS, resolveMode } from '../../../domain/caseConstants'

/** 指标编辑态：营收允许为空（未填时用 null），其余三项是字符串 */
export type MetricsDraft = {
  revenue: number | null
  gross_margin: string
  market_share: string
  cash_flow: string
}

export type OptionDraft = Omit<OptionDetail, 'metrics' | 'financial_assumptions'> & {
  metrics: MetricsDraft
  financial_assumptions: { operating_cost: number | null; operating_expense: number | null }
}
export type NodeDraft = Omit<TeacherNode, 'options'> & { options: OptionDraft[] }

export const EMPTY_METRICS: MetricsDraft = {
  revenue: null,
  gross_margin: '',
  market_share: '',
  cash_flow: '',
}

export function toDraftMetrics(metrics: Metrics | null | undefined): MetricsDraft {
  if (!metrics) return { ...EMPTY_METRICS }
  return {
    revenue: typeof metrics.revenue === 'number' ? metrics.revenue : null,
    gross_margin: metrics.gross_margin ?? '',
    market_share: metrics.market_share ?? '',
    cash_flow: metrics.cash_flow ?? '',
  }
}

export function toDraftNodes(nodes: TeacherNode[]): NodeDraft[] {
  return nodes.map((node) => ({
    ...node,
    options: node.options.map((option) => ({
      ...option,
      metrics: toDraftMetrics(option.metrics),
      financial_assumptions: {
        operating_cost: option.financial_assumptions?.operating_cost ?? null,
        operating_expense: option.financial_assumptions?.operating_expense ?? null,
      },
    })),
  }))
}

export interface UseCalibrationStateArgs {
  teacherToken: string
  detail: GetCaseResponse | null
  onRefresh: () => Promise<void>
  onSaveRefresh?: () => Promise<void>
  draftRevision?: number
  onDirtyChange?: (parts: string[]) => void
}

/**
 * 校准区全部草稿状态与联动逻辑：
 * 表单（title/background/dilemma/metrics/nodes/联动/净利润）本地受控，
 * 点保存才写库；detail 变化仅显式重载/生成/导航时重置草稿，保存同步不覆盖。
 */
export function useCalibrationState({ teacherToken, detail, onRefresh, onSaveRefresh, draftRevision, onDirtyChange }: UseCalibrationStateArgs) {
  const { message } = AntdApp.useApp()
  const [title, setTitle] = useState(detail?.case.title ?? '')
  const [background, setBackground] = useState(detail?.case.background ?? '')
  const [dilemma, setDilemma] = useState(detail?.case.dilemma ?? '')
  const [metrics, setMetrics] = useState<MetricsDraft>(toDraftMetrics(detail?.case.base_metrics))
  const [nodes, setNodes] = useState<NodeDraft[]>(detail ? toDraftNodes(detail.nodes) : [])
  const [savingCase, setSavingCase] = useState(false)
  const [revenueLink, setRevenueLink] = useState<'margin' | 'cost'>('margin')
  const [savingNodeId, setSavingNodeId] = useState<number | null>(null)
  const [netProfit, setNetProfit] = useState<number | null>(detail?.case.base_net_profit ?? null)
  const [operatingCost, setOperatingCost] = useState<number | null>(detail?.case.financial_assumptions?.operating_cost ?? null)
  const [operatingExpense, setOperatingExpense] = useState<number | null>(detail?.case.financial_assumptions?.operating_expense ?? null)
  const [generatingNodes, setGeneratingNodes] = useState(false)
  const [nodeTask, setNodeTask] = useState<AiTaskResponse | null>(null)
  const [nodeError, setNodeError] = useState('')
  const [nodeProgressError, setNodeProgressError] = useState('')
  const [nodeGenerationAttempt, setNodeGenerationAttempt] = useState(0)
  const [activeNode, setActiveNode] = useState<string>()
  const [rulesDirty, setRulesDirty] = useState(false)
  const [processBaseline, setProcessBaseline] = useState<Record<string, number> | null>(() => {
    const mode = resolveMode(detail?.case.mode, detail?.case.case_type)
    const saved = detail?.case.process_baseline
    return saved && Object.keys(saved).length > 0 ? { ...saved } : { ...(PROCESS_BASELINE_DEFAULTS[mode] ?? {}) }
  })
  const baselineSnapshot = JSON.stringify({ title, background, dilemma, metrics, operatingCost, operatingExpense, netProfit, processBaseline })
  const [savedBaseline, setSavedBaseline] = useState(baselineSnapshot)
  const [savedNodes, setSavedNodes] = useState<Record<number, string>>(() => Object.fromEntries(nodes.map(n => [n.id, JSON.stringify(n)])))
  const baselineDirty = baselineSnapshot !== savedBaseline
  const dirtyNodes = nodes.filter(n => JSON.stringify(n) !== savedNodes[n.id])
  const dirtyKey = [baselineDirty ? '财务基准与案例信息' : '', ...dirtyNodes.map(n => `第${n.idx}轮文案`), rulesDirty ? '递进规则' : '', savingCase || savingNodeId !== null || generatingNodes ? '保存或生成进行中' : ''].filter(Boolean).join('、')
  useEffect(() => { onDirtyChange?.(dirtyKey ? dirtyKey.split('、') : []) }, [dirtyKey, onDirtyChange])
  const refreshRef = useRef(onRefresh)
  useEffect(() => { refreshRef.current = onRefresh }, [onRefresh])

  // 陈旧闭包修复：同步 effect 体内读取 baselineDirty / savedNodes / dirtyNodes 均未列入依赖数组。
  // 若直接补进依赖，filter/对象引用每次渲染都变，effect 会随每次渲染重跑（行为改变）。
  // 改为 latest-ref：渲染期直接赋值（纯赋值，无副作用），触发时机保持原样（仅 detail.id / draftRevision 变化），体内读取最新值。
  const syncRef = useRef({ baselineDirty, savedNodes, dirtyNodes })
  syncRef.current = { baselineDirty, savedNodes, dirtyNodes }

  // Only explicit reload/generation/navigation resets drafts, never save sync.
  useEffect(() => {
    const { baselineDirty, savedNodes, dirtyNodes } = syncRef.current
    if (!baselineDirty) {
      setTitle(detail?.case.title ?? '')
      setBackground(detail?.case.background ?? '')
      setDilemma(detail?.case.dilemma ?? '')
      setMetrics(toDraftMetrics(detail?.case.base_metrics))
      const nextMode = resolveMode(detail?.case.mode, detail?.case.case_type)
      const savedPb = detail?.case.process_baseline
      setProcessBaseline(savedPb && Object.keys(savedPb).length > 0 ? { ...savedPb } : { ...(PROCESS_BASELINE_DEFAULTS[nextMode] ?? {}) })
      setSavedBaseline(JSON.stringify({ title: detail?.case.title ?? '', background: detail?.case.background ?? '', dilemma: detail?.case.dilemma ?? '', metrics: toDraftMetrics(detail?.case.base_metrics),
        operatingCost: detail?.case.financial_assumptions?.operating_cost ?? null, operatingExpense: detail?.case.financial_assumptions?.operating_expense ?? null, netProfit: detail?.case.base_net_profit ?? null,
        processBaseline: savedPb && Object.keys(savedPb).length > 0 ? { ...savedPb } : { ...(PROCESS_BASELINE_DEFAULTS[nextMode] ?? {}) } }))
    }
    const incoming = detail ? toDraftNodes(detail.nodes) : []
    setNodes(current => incoming.map(n => current.find(old => old.id === n.id && JSON.stringify(old) !== savedNodes[old.id]) ?? n))
    setSavedNodes(current => Object.fromEntries(incoming.map(n => [n.id, dirtyNodes.some(old => old.id === n.id) ? current[n.id] : JSON.stringify(n)])))
    if (detail?.nodes.length) { setNodeTask(null); setGeneratingNodes(false) }
    if (!baselineDirty) {
      setNetProfit(detail?.case.base_net_profit ?? null)
      setOperatingCost(detail?.case.financial_assumptions?.operating_cost ?? null)
      setOperatingExpense(detail?.case.financial_assumptions?.operating_expense ?? null)
    }
  }, [detail?.case.id, draftRevision === undefined ? detail : draftRevision])

  // A page refresh or navigation back to this case must rediscover its persisted
  // node-generation task instead of showing a fresh button over a running job.
  useEffect(() => {
    if (!detail) return
    let active = true
    void listCaseAiTasks(detail.case.id, teacherToken).then((tasks) => {
      if (!active || nodeTask) return
      const latest = tasks.find((task) => task.kind === 'case_nodes')
      if (latest) {
        setNodeTask(latest)
        setGeneratingNodes(pendingTask(latest))
      }
    }).catch(() => {
      if (active) setNodeProgressError('无法恢复决策节点任务状态；可刷新页面重试，后台任务不会因此取消。')
    })
    return () => { active = false }
  }, [detail?.case.id, teacherToken])

  // Poll the database-backed task. Errors reconnect without resubmitting it;
  // terminal task errors are surfaced, and successful tasks refresh case data.
  useEffect(() => {
    if (!nodeTask || !pendingTask(nodeTask)) return
    let active = true
    let timer: number | undefined
    const poll = async () => {
      try {
        const latest = await getAiTask(nodeTask.task_id, teacherToken)
        if (!active) return
        setNodeTask(latest)
        setNodeProgressError('')
        if (pendingTask(latest)) {
          timer = window.setTimeout(() => void poll(), 2000)
        } else {
          setGeneratingNodes(false)
          if (latest.status === 'failed') {
            const failure = latest.error || '决策节点生成失败，请查看任务详情后重试。'
            setNodeError(failure)
            message.error(failure)
            setNodeGenerationAttempt((attempt) => attempt + 1)
          } else if (latest.status === 'succeeded') {
            setNodeError('')
            message.success('决策节点生成完成，已加载最新结果。')
            await refreshRef.current()
          }
        }
      } catch {
        if (active) {
          setNodeProgressError('任务进度暂不可用，正在重连；不会重新提交或取消后台任务。')
          timer = window.setTimeout(() => void poll(), 5000)
        }
      }
    }
    timer = window.setTimeout(() => void poll(), 1000)
    return () => { active = false; if (timer !== undefined) window.clearTimeout(timer) }
  }, [nodeTask?.task_id, nodeTask?.status, teacherToken])

  function updateNode(nodeId: number, patch: Partial<NodeDraft>) {
    setNodes((prev) => prev.map((node) => (node.id === nodeId ? { ...node, ...patch } : node)))
  }

  function updateOption(nodeId: number, optionKey: string, patch: Partial<OptionDraft>) {
    setNodes((prev) =>
      prev.map((node) =>
        node.id === nodeId
          ? {
              ...node,
              options: node.options.map((option) =>
                option.key === optionKey ? { ...option, ...patch } : option,
              ),
            }
          : node,
      ),
    )
  }

  function updateOptionMetric(
    nodeId: number,
    optionKey: string,
    field: keyof MetricsDraft,
    value: string | number | null,
  ) {
    setNodes((prev) =>
      prev.map((node) =>
        node.id === nodeId
          ? {
              ...node,
              options: node.options.map((option) =>
                option.key === optionKey
                  ? // 计算键写入，字段名与类型由 MetricsDraft 保证
                    ({ ...option, metrics: { ...option.metrics, [field]: value } as MetricsDraft })
                  : option,
              ),
            }
          : node,
      ),
    )
  }

  function validateMetrics(draft: MetricsDraft, prefix: string): Metrics | null {
    if (typeof draft.revenue !== 'number' || Number.isNaN(draft.revenue)) {
      message.warning(`${prefix}：营收要填数字`)
      return null
    }
    const missing = METRIC_FIELDS.filter(
      (field) => !field.numeric && !String(draft[field.key] ?? '').trim(),
    )
    if (missing.length > 0) {
      message.warning(`${prefix}：${missing.map((field) => field.label).join('、')}不能为空`)
      return null
    }
    return {
      revenue: draft.revenue,
      gross_margin: draft.gross_margin.trim(),
      market_share: draft.market_share.trim(),
      cash_flow: draft.cash_flow.trim(),
    }
  }

  function validateOptions(node: NodeDraft): OptionDetail[] | null {
    const prefix = `第 ${node.idx} 个节点`
    if (node.options.length !== 3 || new Set(node.options.map((o) => o.risk_level)).size !== 3) {
      message.warning(`${prefix}：三个选项的风险等级必须是保守 / 稳健 / 激进各一个`)
      return null
    }
    const options: OptionDetail[] = []
    for (const option of node.options) {
      if (!option.label.trim() || !option.summary.trim()) {
        message.warning(`${prefix}：选项 ${option.key} 的策略内容与结果摘要都要填写`)
        return null
      }
      const optionMetrics = validateMetrics(option.metrics, `${prefix} 选项 ${option.key}`)
      if (!optionMetrics) return null
      const assumptions = option.financial_assumptions
      if (assumptions.operating_cost === null || assumptions.operating_expense === null) {
        message.warning(`${prefix} 选项 ${option.key}：请填写营业成本和运营费用，系统才能可靠计算净利润`)
        return null
      }
      const completeAssumptions = {
        operating_cost: assumptions.operating_cost,
        operating_expense: assumptions.operating_expense,
      }
      options.push({
        key: option.key,
        label: option.label.trim(),
        risk_level: option.risk_level,
        metrics: optionMetrics,
        financial_assumptions: completeAssumptions,
        financial_basis: option.financial_basis,
        net_profit: Number(option.metrics.revenue || 0) - completeAssumptions.operating_cost - completeAssumptions.operating_expense,
        summary: option.summary.trim(),
        detail: option.detail ?? null,
      })
    }
    return options
  }

  async function handleSaveCase() {
    if (!detail) {
      message.warning('请先选择或生成一个案例')
      return
    }
    if (!title.trim()) {
      message.warning('案例标题不能为空')
      return
    }
    const caseMetrics = validateMetrics(metrics, '案例基准数据')
    if (!caseMetrics) return
    const inconsistency = baselineError(metrics.revenue, metrics.gross_margin, operatingCost)
    if (inconsistency) { message.warning(inconsistency); return }

    setSavingCase(true)
    try {
      if (operatingCost === null || operatingExpense === null) { message.warning('请填写营业成本和运营费用教学假设，以便确定性计算净利润'); return }
      const computedProfit = calculateNetProfit(caseMetrics.revenue, operatingCost, operatingExpense)
      if (computedProfit === null) { message.warning('请填写有效的营收、营业成本和运营费用'); return }
      if (netProfit !== null && Math.abs(netProfit - computedProfit) > 0.01) { message.warning('净利润与公式计算不一致，请核对成本、费用或营收'); return }
      await patchCase(detail.case.id, teacherToken, {
        title: title.trim(),
        background: background.trim(),
        dilemma: dilemma.trim(),
        base_metrics: caseMetrics,
        net_profit: computedProfit,
        financial_assumptions: { operating_cost: operatingCost, operating_expense: operatingExpense },
        process_baseline: processBaseline && Object.keys(processBaseline).length > 0 ? { ...processBaseline } : {},
      })
      message.success('案例级信息已保存')
      setSavedBaseline(baselineSnapshot)
      await (onSaveRefresh ?? onRefresh)()
    } catch {
      // 失败提示由 axios 拦截器统一走 message.error
    } finally {
      setSavingCase(false)
    }
  }

  async function handleSaveNode(node: NodeDraft) {
    if (!detail) {
      message.warning('请先选择或生成一个案例')
      return
    }
    if (!node.title.trim()) {
      message.warning(`第 ${node.idx} 个节点：节点标题不能为空`)
      return
    }
    const options = validateOptions(node)
    if (!options) return

    setSavingNodeId(node.id)
    try {
      await patchNode(detail.case.id, node.id, teacherToken, {
        title: node.title.trim(),
        background: node.background,
        options,
      })
      message.success(`第 ${node.idx} 个节点已保存`)
      setSavedNodes(current => ({ ...current, [node.id]: JSON.stringify(node) }))
      await (onSaveRefresh ?? onRefresh)()
    } catch {
      // 失败提示由 axios 拦截器统一走 message.error
    } finally {
      setSavingNodeId(null)
    }
  }

  function handleSummariesSaved(summaries: Record<string, string>) {
    setNodes(current => current.map(node => JSON.stringify(node) !== savedNodes[node.id] ? node : ({ ...node, options: node.options.map(option => ({ ...option, summary: summaries[`${node.id}:${option.key}`] ?? option.summary })) })))
    setSavedNodes(current => Object.fromEntries(Object.entries(current).map(([id, raw]) => {
      const node = JSON.parse(raw) as NodeDraft
      return [id, JSON.stringify({ ...node, options: node.options.map(option => ({ ...option, summary: summaries[`${node.id}:${option.key}`] ?? option.summary })) })]
    })))
  }

  async function handleGenerateNodes() {
    if (!detail) return
    setGeneratingNodes(true)
    setNodeError('')
    setNodeProgressError('')
    let taskAccepted = false
    try {
      const base = validateMetrics(metrics, '确认基准指标')
      if (!base || operatingCost === null || operatingExpense === null) return
      const profit = base.revenue - operatingCost - operatingExpense
      const payload = { base_metrics: base, net_profit: profit,
        financial_assumptions: { operating_cost: operatingCost, operating_expense: operatingExpense } }
      const task = await generateCaseNodes(detail.case.id, teacherToken, { base_metrics: base, net_profit: profit,
        financial_assumptions: { operating_cost: operatingCost, operating_expense: operatingExpense },
        idempotency_key: stableIdempotencyKey(`nodes-case-${detail.case.id}-v${detail.case.version}-a${nodeGenerationAttempt}`, payload) })
      setNodeTask(task)
      setSavedBaseline(baselineSnapshot)
      taskAccepted = true
      setGeneratingNodes(pendingTask(task))
      message.success('已确认基准指标，决策节点开始后台生成')
      await onRefresh()
    } catch (error) {
      const detailMessage = error instanceof Error ? error.message : '请求未能提交，请检查网络与服务日志后重试。'
      setNodeError(detailMessage)
      message.error(detailMessage)
    } finally {
      if (!taskAccepted) setGeneratingNodes(false)
    }
  }

  return {
    title, setTitle, background, setBackground, dilemma, setDilemma,
    metrics, setMetrics, nodes, setNodes,
    revenueLink, setRevenueLink,
    netProfit, setNetProfit, operatingCost, setOperatingCost, operatingExpense, setOperatingExpense,
    processBaseline, setProcessBaseline, mode: resolveMode(detail?.case.mode, detail?.case.case_type),
    savingCase, savingNodeId, generatingNodes, nodeTask, nodeError, setNodeError,
    nodeProgressError, setNodeProgressError, activeNode, setActiveNode, rulesDirty, setRulesDirty,
    baselineDirty, dirtyNodes,
    updateNode, updateOption, updateOptionMetric,
    onSaveCase: handleSaveCase,
    onSaveNode: handleSaveNode,
    onSummariesSaved: handleSummariesSaved,
    onGenerateNodes: handleGenerateNodes,
  }
}
