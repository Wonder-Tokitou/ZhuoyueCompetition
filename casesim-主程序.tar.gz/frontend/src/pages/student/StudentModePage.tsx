import { useEffect, useState } from 'react'
import { ArrowRightOutlined, BarChartOutlined, PlayCircleOutlined } from '@ant-design/icons'
import { Alert, Button, Spin, Tag, Typography } from 'antd'
import { useNavigate } from 'react-router-dom'
import { api, playGet } from '../../api/client'
import type { PlayResponse, StudentSubmission } from '../../api/types'
import { useStudentToken } from '../../context/StudentTokenContext'
import { caseTypeLabel } from '../../domain/caseConstants'

type Experience = 'normal' | 'story'

export default function StudentModePage() {
  const token = useStudentToken()
  const navigate = useNavigate()
  const [data, setData] = useState<PlayResponse | null>(null)
  const [error, setError] = useState('')
  const [roundsDone, setRoundsDone] = useState(0)

  useEffect(() => {
    let active = true
    playGet(token)
      .then((play) => { if (active) setData(play) })
      .catch((failure) => { if (active) setError(failure instanceof Error ? failure.message : '案例暂时无法打开') })
    return () => { active = false }
  }, [token])

  // 剧情模式解锁门槛：完成本案例第 1 轮正式推演。记录接口按当前学生登录态返回。
  useEffect(() => {
    let active = true
    api.get<StudentSubmission[]>('/student/records')
      .then(({ data: rows }) => {
        if (!active) return
        setRoundsDone(rows.filter((row) => row.student_token === token)
          .reduce((total, row) => total + (row.turn_count || 0), 0))
      })
      .catch(() => { if (active) setRoundsDone(0) })
    return () => { active = false }
  }, [token])

  function enter(experience: Experience) {
    if (experience === 'story' && roundsDone < 1) return
    sessionStorage.setItem(`student_experience:${token}`, experience)
    navigate(`/student/${encodeURIComponent(token)}/${experience === 'story' ? 'story' : 'play'}`)
  }

  if (error) return <Alert type="warning" showIcon message={error} />
  if (!data) return <div className="student-centered-loading"><Spin /></div>

  const hasProgress = Number(sessionStorage.getItem(`student_session:${token}`)) > 0
  const storyUnlocked = roundsDone >= 1
  return (
    <section className="experience-select" aria-labelledby="experience-title">
      <div className="experience-intro">
        <Tag color="magenta">{caseTypeLabel(data.case_type)}</Tag>
        <Typography.Title id="experience-title" level={2}>{data.case_title}</Typography.Title>
        <Typography.Paragraph className="experience-dilemma">{data.dilemma}</Typography.Paragraph>
        <Typography.Text type="secondary">
          {hasProgress ? '你的进度已经保存，可选择任一界面继续同一份推演。' : '先选择一种体验方式。两种模式使用同一组经营数据与专业规则。'}
        </Typography.Text>
      </div>

      <div className="experience-mode-grid">
        <article className="experience-card experience-card-normal">
          <span className="experience-icon" aria-hidden="true"><BarChartOutlined /></span>
          <div>
            <Typography.Title level={3}>正常模式</Typography.Title>
            <Typography.Paragraph>专注案例信息、经营指标和方案判断，界面简洁，适合课堂作答与快速复盘。</Typography.Paragraph>
          </div>
          <ul>
            <li>清晰查看案例与关键指标</li>
            <li>逐轮选择并说明判断依据</li>
            <li>结果与提交记录实时保存</li>
          </ul>
          <Button type="primary" block onClick={() => enter('normal')}>进入正常模式 <ArrowRightOutlined /></Button>
        </article>

        <article className="experience-card experience-card-story">
          <span className="experience-icon" aria-hidden="true"><PlayCircleOutlined /></span>
          <div>
            <Typography.Title level={3}>剧情模式</Typography.Title>
            <Typography.Paragraph>进入案例现场，与经营团队对话，在情境推进中提出方案并观察反馈。</Typography.Paragraph>
          </div>
          <ul>
            <li>案例专属角色与情境对白</li>
            <li>以“提出方案”推进剧情</li>
            <li>专业指标和结算规则保持一致</li>
          </ul>
          {!storyUnlocked && <Typography.Text type="secondary">完成本案例第 1 轮正式推演后解锁剧情模式。</Typography.Text>}
          <Button type="primary" block disabled={!storyUnlocked} onClick={() => enter('story')}>进入剧情模式 <ArrowRightOutlined /></Button>
        </article>
      </div>
    </section>
  )
}
