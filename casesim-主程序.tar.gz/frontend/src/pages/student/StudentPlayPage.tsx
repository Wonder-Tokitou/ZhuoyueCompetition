import { memo, type CSSProperties, useEffect, useRef, useState } from 'react'
import { Alert, Button, Card, Input, Popconfirm, Space, Spin, Typography } from 'antd'
import MetricComparison from '../../components/MetricComparison'
import SettlementCard from './components/SettlementCard'
import RoundMap from './components/RoundMap'
import { narrative as buildNarrative, type DecisionNarrative } from '../../domain/decisionNarrative'
import { useNavigate } from 'react-router-dom'
import { decide, playGet, restoreStudent, rollbackStudentSubmission, startStudent } from '../../api/client'
import type { Metrics, OptionDetail, PlayResponse, RiskLevel, SessionState } from '../../api/types'
import { useStudentToken } from '../../context/StudentTokenContext'
import { useStudentAccount } from '../../context/StudentAccountContext'

/** 风险等级 → 边框/填充色：保守绿、稳健黄、激进红（任务指定色值）。 */
const RISK_META: Record<RiskLevel, { border: string; fill: string }> = {
  保守: { border: '#16a34a', fill: '#16a34a' },
  稳健: { border: '#ca8a04', fill: '#ca8a04' },
  激进: { border: '#dc2626', fill: '#dc2626' },
}
/** 无 risk_level 数据时的中性占位（学生端 OptionBrief 不含风险字段，防剧透）。
 *  后端下发 risk_level 前保留不动，RISK_META 语义配色仍优先。 */
/** 按选项序号（0/1/2 → A/B/C）固定的中性区分色：只做视觉区分，不代表风险等级。
 *  取值为阶段 1 的 CSS 令牌，避免在 JS 里再写死一份十六进制；调色时只改 index.css。 */
const OPTION_STYLE = [
  { border: 'var(--option-a-border)', bg: 'var(--option-a-bg)' },
  { border: 'var(--option-b-border)', bg: 'var(--option-b-bg)' },
  { border: 'var(--option-c-border)', bg: 'var(--option-c-bg)' },
]

/** 同账号在另一设备/标签页已开始过本案例：后端返回 409 + detail.code=submission_exists。 */
const SUBMISSION_EXISTS = '已有本案例推演记录，请从「我的记录」继续'

function isSubmissionExists(error: unknown): boolean {
  const failure = error as { status?: number; code?: string } | null
  return failure?.status === 409 && failure?.code === 'submission_exists'
}

/** 趋势箭头：增=绿（#16a34a）、降=红（#dc2626）；无对比基准时返回 null 不显示。 */
function TrendArrow({ dir }: { dir: 'up' | 'down' }) {
  return <span className="metric-trend" style={{ color: dir === 'up' ? '#16a34a' : '#dc2626' }} aria-label={dir === 'up' ? '较上轮上升' : '较上轮下降'}>{dir === 'up' ? '↑' : '↓'}</span>
}

/** 2×2 财务指标卡：营收大数字、毛利率/份额百分比+趋势箭头、现金流文字；net_profit 额外一行。
 *  图标一律由 CSS ::before 注入（见 StudentLayout.css 阶段 4 段），label 的文本节点保持原样，
 *  否则 F10「净利润 -12.35 万元」这类拼接断言会红。 */
export function MetricsBar({ metrics, before }: { metrics: (Metrics & { net_profit?: number; cash_flow_amount?: number }) | null; before?: (Metrics & { net_profit?: number }) | null }) {
  if (!metrics) return null
  const trend = (current: string | undefined, previous: string | undefined): 'up' | 'down' | null => {
    if (current === undefined || previous === undefined) return null
    const c = parseFloat(current), p = parseFloat(previous)
    if (Number.isNaN(c) || Number.isNaN(p) || c === p) return null
    return c > p ? 'up' : 'down'
  }
  const marginTrend = trend(metrics.gross_margin, before?.gross_margin)
  const shareTrend = trend(metrics.market_share, before?.market_share)
  // aria-label 只补可访问名（避免图标被读成「💰 营收」），label 的文本节点逐字不变。
  // key 用固定语义而非数组下标：第 5 张「净利润」卡出现/消失时，前四张不会重挂载。
  return <div className="student-metrics">
    <div key="revenue" className="metric-card metric-revenue"><span className="metric-label" aria-label="营收">营收</span><span className="metric-value">{metrics.revenue} 万元</span></div>
    <div key="margin" className="metric-card"><span className="metric-label" aria-label="毛利率">毛利率</span><span className="metric-value">{metrics.gross_margin}{marginTrend && <TrendArrow dir={marginTrend} />}</span></div>
    <div key="share" className="metric-card"><span className="metric-label" aria-label="市场份额">市场份额</span><span className="metric-value">{metrics.market_share}{shareTrend && <TrendArrow dir={shareTrend} />}</span></div>
    <div key="cash" className="metric-card"><span className="metric-label" aria-label="现金流">现金流</span><span className="metric-value">{metrics.cash_flow}</span>{typeof metrics.cash_flow_amount === 'number' && <span className="metric-note">本期现金净流量 {metrics.cash_flow_amount.toFixed(2)} 万元</span>}</div>
    {typeof metrics.net_profit === 'number' && <div key="net-profit" className="metric-card"><span className="metric-label" aria-label="净利润">净利润 </span><span className="metric-value">{metrics.net_profit.toFixed(2)} 万元</span></div>}
  </div>
}

/** C4：指标条是每次决策后必刷新的热点，props 是 state/data 里的对象引用（父组件不新建字面量），
 *  memo 才能挡住「输入理由 / 切换选项」这类与指标无关的重渲染。
 *  导出名 MetricsBar 仍是普通函数——tests/progressive-display.test.cjs 直接调用它。 */
const MetricsBarMemo = memo(MetricsBar)

export default function StudentPlayPage() {
  const token = useStudentToken(), navigate = useNavigate()
  const account = useStudentAccount()
  const [data, setData] = useState<PlayResponse | null>(null)
  const [state, setState] = useState<SessionState | null>(null)
  const [name, setName] = useState(account.real_name)
  const [reason, setReason] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const [loading, setLoading] = useState(true)
  const [at, setAt] = useState(Date.now())
  const [loadedToken, setLoadedToken] = useState('')
  const [selected, setSelected] = useState<string | null>(null)
  const [showResult, setShowResult] = useState(false)
  // U1 即时结算单：提交成功后弹出，关闭后保留「继续下一回合」入口。
  // 走查报告 P1-5：结算卡已承担本轮结果反馈，页面不再重复展示「本轮结果」Alert。
  const [settlement, setSettlement] = useState<{ round: number; chosenLabel: string; narrative: DecisionNarrative } | null>(null)
  const [settlementOpen, setSettlementOpen] = useState(false)
  const [uncertain, setUncertain] = useState(false)
  // 跨设备/跨标签页重复开始时为 true：页面提示已有记录，并给出"我的记录"入口。
  const [duplicate, setDuplicate] = useState(false)
  const page = useRef({ token, active: false, busy: false, nodeId: null as number | null, uncertain: false })
  const node = data?.nodes.find((n) => n.id === state?.next_node_id)
  // 教师停止推演：整页只读（不能开始/提交/回退/覆盖），历史记录保留可查
  const locked = data?.play_locked === true || state?.play_locked === true

  useEffect(() => {
    let cancelled = false
    const current = { token, active: true, busy: false, nodeId: null as number | null, uncertain: false }
    page.current = current
    setLoading(true); setError(''); setState(null); setData(null)
    setReason(''); setBusy(false); setName(account.real_name)
    setSelected(null); setShowResult(false); setUncertain(false); setDuplicate(false)
    setSettlement(null); setSettlementOpen(false)
    async function load() {
      try {
        const session = Number(sessionStorage.getItem('student_session:' + token))
        if (session) {
          const saved = await restoreStudent(token, session)
          if (!cancelled) { setState(saved); setData(saved.play); setName(saved.student_name); current.nodeId = saved.next_node_id }
        } else {
          const play = await playGet(token)
          if (!cancelled) setData(play)
        }
      } catch (e) { if (!cancelled) setError(e instanceof Error ? e.message : '案例暂不可用') }
      finally { if (!cancelled) { setLoadedToken(token); setLoading(false); setAt(Date.now()) } }
    }
    void load()
    return () => { cancelled = true; current.active = false }
  }, [token])

  async function begin() {
    const current = page.current
    if (!name.trim() || !current.active || current.token !== token || current.busy || locked) return
    current.busy = true
    setBusy(true); setError(''); setDuplicate(false)
    try {
      const next = await startStudent(token, name.trim())
      if (!current.active) return
      setState(next); setData(next.play); setAt(Date.now())
      current.nodeId = next.next_node_id
      sessionStorage.setItem('student_session:' + token, String(next.session_id))
      sessionStorage.setItem('student_name:' + token, next.student_name)
      window.dispatchEvent(new Event('student-session-updated'))
    } catch (e) {
      if (!current.active) return
      // 换设备/新标签页时本地 sessionStorage 里没有 session_id，只能重新建会话；
      // 该学生已有本案例记录 → 409 submission_exists，此时要引导回"我的记录"恢复进度，
      // 而不是显示"参数不符合要求"这类误导文案。
      if (isSubmissionExists(e)) { setDuplicate(true); setError(SUBMISSION_EXISTS); return }
      setError(e instanceof Error ? e.message : '开始失败')
    } finally { current.busy = false; if (current.active) setBusy(false) }
  }

  function acceptSaved(saved: SessionState, submittedNode: number, key: string) {
    const accepted = saved.turns.find(turn => turn.node_id === submittedNode)
    setState(saved); setData(saved.play)
    page.current.nodeId = saved.next_node_id
    page.current.uncertain = false; setUncertain(false)
    if (accepted) {
      setSelected(null); setReason(''); setShowResult(true)
      setError(accepted.chosen_option === key ? '' : '此回合已由另一页面提交，下面显示服务器实际保存的策略，请核对。')
      // U1 即时结算单：提交成功即弹出，讲清「为什么」与「下一轮关注」。
      // 数据只取学生本轮已经拿到的 before/after 指标，不读教师端测算结果，因此不剧透。
      const roundIndex = saved.turns.indexOf(accepted)
      const settledNode = saved.play.nodes.find(n => n.id === accepted.node_id)
      const chosenLabel = accepted.chosen_label || settledNode?.options[settledNode.options.findIndex(o => o.key === accepted.chosen_option)]?.label || '历史策略内容不可用'
      const beforeMetrics = roundIndex > 0 ? saved.turns[roundIndex - 1].after_metrics : saved.play.base_metrics
      setSettlement({ round: roundIndex + 1, chosenLabel,
        narrative: buildNarrative(beforeMetrics, accepted.after_metrics, chosenLabel, saved.financial_state?.cash_flow_amount) })
      setSettlementOpen(true)
      window.dispatchEvent(new Event('student-session-updated'))
    } else {
      setError('本回合尚未保存，请核对所选策略后重新确认提交。')
    }
  }

  async function reconcile() {
    const current = page.current
    if (!state || !node || !selected || current.busy || !current.active || current.token !== token) return
    current.busy = true; setBusy(true)
    try {
      const saved = await restoreStudent(token, state.session_id)
      if (current.active) acceptSaved(saved, node.id, selected)
    } catch { if (current.active) setError('仍无法核对服务器进度，请稍后重试；不会重复提交或自动选择其他策略。') }
    finally { current.busy = false; if (current.active) setBusy(false) }
  }

  async function submit() {
    const current = page.current
    if (!node || !state || !selected || !node.options.some(o => o.key === selected) || showResult ||
        !current.active || current.token !== token || current.busy || current.uncertain || current.nodeId !== node.id || locked) return
    const key = selected
    current.busy = true
    setBusy(true); setError('')
    try {
      await decide(token, { student_name: state.student_name, session_id: state.session_id,
        node_id: node.id, option_key: key, input_text: reason.trim() || undefined,
        duration_ms: Math.max(0, Date.now() - at) })
      if (!current.active) return
      const saved = await restoreStudent(token, state.session_id)
      if (!current.active) return
      acceptSaved(saved, node.id, key)
    } catch {
      if (!current.active) return
      // A lost response does not prove that the POST failed. Reconcile first;
      // never blindly retry a decision which may already have been committed.
      try {
        const saved = await restoreStudent(token, state.session_id)
        if (current.active) acceptSaved(saved, node.id, key)
      } catch {
        if (current.active) {
          current.uncertain = true; setUncertain(true)
          setError('提交状态待确认，请点击“核对已保存进度”。核对前不会再次提交，以免重复作答。')
        }
      }
    }
    finally { current.busy = false; if (current.active) setBusy(false) }
  }

  if (loading || loadedToken !== token) return <Spin />
  const selectedIndex = node?.options.findIndex(o => o.key === selected) ?? -1
  const selectedOption = node?.options[selectedIndex]
  // MetricsBar 趋势箭头（毛利/份额环比）的对比基准：上一轮 after_metrics，无上轮时取案例基线。
  const beforeLast = state && state.turns.length > 1 ? state.turns[state.turns.length - 2].after_metrics : data?.base_metrics
  // 关卡式进度：轮次总数取案例节点数（缺省 3），当前轮取 next_node_id，已完成轮取已提交条数。
  // 这三项都来自页面已有状态，RoundMap 自己不请求任何接口（阶段 5 · C5）。
  const roundTotal = data?.nodes?.length || 3
  const roundCurrent = state && !state.finished ? (node?.idx ?? state.turns.length + 1) : 0
  async function rollback(nodeId: number, idx: number) {
    const current = page.current
    if (!state || current.busy || current.uncertain || !current.active || locked) return
    current.busy = true; setBusy(true)
    try {
      const updated = await rollbackStudentSubmission(token, state.session_id, data?.nodes.find(n => n.id === nodeId)?.idx || idx)
      if (!current.active) return
      setState(updated); setData(updated.play); setSelected(null); setReason(''); setShowResult(false); setSettlementOpen(false); setError('已回退到该决策点，后续节点记录和旧复盘已移除，可以重新选择。')
      current.nodeId = updated.next_node_id; setAt(Date.now())
      window.dispatchEvent(new Event('student-session-updated'))
    } catch {
      if (!current.active) return
      // A lost reset response may already have changed the server: restore before allowing another action.
      try {
        const saved = await restoreStudent(token, state.session_id)
        if (!current.active) return
        setState(saved); setData(saved.play); current.nodeId = saved.next_node_id
        setSelected(null); setReason(''); setShowResult(false); setError('已核对服务器进度，请检查当前回合后继续。')
        window.dispatchEvent(new Event('student-session-updated'))
      } catch { if (current.active) { setError('暂时无法确认回退结果，请重新载入案例以核对进度。'); setData(null) } }
    } finally { current.busy = false; if (current.active) setBusy(false) }
  }
  return <Space className="normal-play-page" direction="vertical" size={16} style={{ width: '100%' }}>
    {error && <Alert type="warning" showIcon message={error} />}
    {locked && <div role="note" style={{ padding: '10px 14px', borderRadius: 10, background: '#fef3c7', color: '#92400e', border: '1px solid #fcd34d' }}>
      教师已停止该案例的推演，当前为只读模式；你之前的推演记录已保留，可在「我的记录」中查看。
    </div>}
    {!data && <Button block onClick={() => { sessionStorage.removeItem('student_session:' + token); window.location.reload() }}>重新载入案例</Button>}
    {data && <Card title={data.case_title} size="small" className="normal-case-overview">
      <details open={!state}><summary>案例背景与当前任务</summary><Typography.Paragraph>{data.background}</Typography.Paragraph><Typography.Paragraph>{data.dilemma}</Typography.Paragraph></details>
      {state && <><Typography.Text strong>{state.finished ? '三轮推演已完成' : `第 ${node?.idx ?? state.turns.length + 1} / 3 轮`} · 已提交 {state.turns.length} 轮</Typography.Text>
        <RoundMap total={roundTotal} current={roundCurrent} done={state.turns.length} /></>}
      <MetricsBarMemo metrics={state?.current_metrics || data.base_metrics} before={beforeLast} />
      {state && <Typography.Text type="secondary">每轮提交后都会保存进度，下次回来可以接着完成。</Typography.Text>}
    </Card>}
    {data && !state && <Card title="开始推演" size="small">
      {locked ? <div role="note" style={{ color: '#92400e' }}>教师已停止该案例的推演，当前无法开始新的推演记录。</div>
        : <><Typography.Paragraph>实名作答：{account.real_name}</Typography.Paragraph>
      <Button block type="primary" loading={busy} disabled={!name.trim()} onClick={() => void begin()}>开始推演</Button>
      {duplicate && <Button block style={{ marginTop: 12 }} onClick={() => navigate('/student/records')}>前往「我的记录」继续</Button>}</>}
    </Card>}
    {state && state.turns.length > 0 && <details className="decision-history"><summary>查看此前决策（{state.turns.length} 轮）与修改入口</summary>{state.turns.map((turn, index) => <Card key={`history-${turn.node_id}`} size="small" title={`此前决策 ${index + 1}：${data?.nodes.find(n => n.id === turn.node_id)?.title || ''}`}>
      <Typography.Paragraph>{data?.nodes.find(n => n.id === turn.node_id)?.background}</Typography.Paragraph>
      <Typography.Paragraph>已选 {turn.display_option || ''}：{turn.chosen_label || turn.chosen_option}</Typography.Paragraph>
      <Typography.Paragraph>决策理由：{turn.input_text || '未填写'}</Typography.Paragraph>
      {turn.warning && <Alert type="warning" showIcon message={turn.warning} />}
      <Typography.Paragraph>{turn.summary}</Typography.Paragraph>
      <MetricComparison before={index ? state.turns[index - 1].after_metrics : data?.base_metrics} after={turn.after_metrics} />
      {data && <Popconfirm title={`回退到第 ${index + 1} 轮？`} description="此轮及后续作答、旧复盘将被清除，教师端记录同步改变，无法撤销。" okText="确认回退" cancelText="保留记录" onConfirm={() => rollback(turn.node_id, index + 1)}><Button disabled={busy || uncertain || locked}>修改此决策及后续节点</Button></Popconfirm>}
    </Card>)}</details>}
    {showResult && node && !locked && <Space direction="vertical" style={{ width: '100%' }}>
      <Button block type="primary" onClick={() => { setShowResult(false); setSettlementOpen(false); setSelected(null); setAt(Date.now()) }}>继续下一回合</Button>
      {/* P2-8：快捷回退入口——回退刚提交的这轮，避免手机端必须展开「查看此前决策」才能修改。 */}
      {state && state.turns.length > 0 && <Popconfirm title={`回退到第 ${state.turns.length} 轮？`} description="此轮及后续作答、旧复盘将被清除，教师端记录同步改变，无法撤销。" okText="确认回退" cancelText="保留记录" onConfirm={() => { const settled = state.turns.at(-1); if (settled) rollback(settled.node_id, state.turns.length) }}><Button block>修改上一轮</Button></Popconfirm>}
    </Space>}
    {node && !showResult && !locked && <Card size="small" title={'第 ' + node.idx + ' 回合 · ' + node.node_role} className="scenario-bg">
      <Typography.Title level={4}>{node.title}</Typography.Title>
      <Typography.Paragraph>{node.background}</Typography.Paragraph>
      <Space direction="vertical" style={{ width: '100%', marginTop: 12 }}>
        {node.options.map((o, index) => {
          // 后端下发 risk_level 时走 RISK_META 语义配色（保守绿/稳健黄/激进红）；
          // 未下发（当前 OptionBrief 只有 key+label，防剧透）时按选项序号 A/B/C 固定配色。
          const risk = (o as Partial<OptionDetail>).risk_level
          const meta = risk ? RISK_META[risk] : null
          const tone = OPTION_STYLE[index % OPTION_STYLE.length]
          const isSelected = selected === o.key
          // 有 risk_level：深色填充 + 白字（语义配色优先）；无 risk_level：浅底 + 深字，
          // 选中态用外扩 outline 把边框「加粗」，不依赖白字，也不影响布局。
          const cardStyle: CSSProperties = meta
            ? { borderColor: isSelected ? meta.fill : meta.border, ...(isSelected ? { background: meta.fill } : {}) }
            : { borderColor: tone.border, background: tone.bg, ...(isSelected ? { outline: `2px solid ${tone.border}`, outlineOffset: '2px' } : {}) }
          return <div key={`${node.id}:${o.key}`} className="strategy-option-card" style={cardStyle}>
            <Button className="strategy-option" block
              type={isSelected ? 'primary' : 'default'} aria-pressed={isSelected}
              disabled={busy || uncertain}
              style={isSelected ? (meta ? { background: meta.fill, borderColor: meta.fill, color: '#fff' } : { background: tone.bg, borderColor: tone.border, color: 'var(--student-text)' }) : {}}
              onClick={() => {
                if (!page.current.busy && !page.current.uncertain && page.current.nodeId === node.id) setSelected(o.key)
              }}>
              <span className="strategy-letter">{['🛡️', '⚖️', '🚀'][index % 3]}</span>
              <span className="strategy-body">
                <span className="strategy-name">{o.label}</span>
                {o.detail?.positioning && <span className="strategy-position">{o.detail.positioning}</span>}
              </span>
            </Button>
            {o.detail && <details className="strategy-basis">
              <summary>查看决策依据</summary>
              <dl>
                <dt>具体动作</dt><dd>{o.detail.actions}</dd>
                <dt>资源投入</dt><dd>{o.detail.investment}</dd>
                <dt>预期收益</dt><dd>{o.detail.expected_return}</dd>
                <dt>潜在代价</dt><dd>{o.detail.tradeoff}</dd>
                {o.detail.theory && o.detail.theory.length > 0 && <><dt>理论依据</dt><dd>{o.detail.theory.join('、')}</dd></>}
              </dl>
            </details>}
          </div>
        })}
      </Space>
      <label htmlFor="decision-reason" className="decision-reason-label">说说你的判断（选填）</label>
      <Input.TextArea id="decision-reason" rows={3} maxLength={4000} showCount disabled={busy || uncertain} value={reason} onChange={(e) => setReason(e.target.value)} placeholder="例如：为什么这个方案更适合当前局面？" />
      <div className="decision-submit">
      {selectedOption && <Typography.Paragraph role="status" style={{ marginTop: 12 }}>
        {busy ? '正在保存' : '当前方案'}：{selectedOption.label}
      </Typography.Paragraph>}
      {uncertain ? <Button block loading={busy} onClick={() => void reconcile()}>核对已保存进度</Button> :
        <Button block type="primary" loading={busy} disabled={!selectedOption || busy} aria-busy={busy || undefined} onClick={() => void submit()}>确认提交本回合</Button>}
      </div>
      <Typography.Paragraph className="decision-gentle-hint" type="secondary">提交前可以随时更换方案；提交后会展示这一轮的经营变化。</Typography.Paragraph>
    </Card>}
    {state?.finished && <Button type="primary" block onClick={() => navigate('/student/' + token + '/review?session=' + state.session_id)}>推演完成 · 查看复盘</Button>}
    {settlement && <SettlementCard open={settlementOpen} round={settlement.round} chosenLabel={settlement.chosenLabel} narrative={settlement.narrative} onClose={() => setSettlementOpen(false)} />}
  </Space>
}
