export type TeacherSection = 'workbench' | 'records' | 'students' | 'trash' | 'accounts'

/**
 * 教师端兼容两种入口：当前登录会话使用 /teacher，历史链接仍可带 URL 口令。
 * 统一在此生成路径，避免空口令拼出 /teacher//section 后被路由器误认成口令。
 */
export function teacherSectionPath(teacherToken: string | undefined, section: TeacherSection): string {
  const basePath = teacherToken ? `/teacher/${encodeURIComponent(teacherToken)}` : '/teacher'
  return section === 'workbench' ? basePath : `${basePath}/${section}`
}
