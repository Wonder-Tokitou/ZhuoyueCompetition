import { Alert, Progress, Space, Typography } from 'antd'
import type { AiTaskResponse } from '../../api/types'

/** 案例生成阶段 → 中文说明 + 进度百分比 */
const STAGES: Record<string, { label: string; percent: number }> = {
  queued: { label: '等待执行', percent: 5 },
  extract_source: { label: '素材已解析', percent: 20 },
  generate_case: { label: '生成与校验案例', percent: 40 },
  case_baseline: { label: '生成案例基准', percent: 55 },
  generate_nodes: { label: '生成决策节点', percent: 72 },
  persist_nodes: { label: '保存决策节点', percent: 85 },
  validate_case: { label: '校验通过', percent: 93 },
  persist_draft: { label: '保存待校准版本', percent: 100 },
  completed: { label: '生成完成', percent: 100 },
  failed: { label: '生成失败', percent: 0 },
  retrying: { label: '暂时失败，后台重试中', percent: 30 },
}
export const pendingTask = (task: AiTaskResponse | null) => !!task && ['queued', 'running'].includes(task.status)


export default function TaskStatus({ task, busy }: { task: AiTaskResponse; busy: boolean }) {
  const meta = STAGES[task.stage] ?? { label: '处理中', percent: 15 }
  const isFailed = task.status === 'failed'
  const isDone = task.status === 'succeeded'
  return (
    <Alert
      showIcon
      type={isFailed ? 'error' : isDone ? 'success' : 'info'}
      message={
        <Space direction="vertical" style={{ width: '100%' }} size={4}>
          <Typography.Text strong>案例准备进度：{meta.label}</Typography.Text>
          {!isDone && !isFailed && (
            <Progress
              percent={meta.percent}
              status="active"
              size="small"
              strokeColor="#1a3a5c"
              style={{ width: '100%', marginBottom: 0 }}
            />
          )}
        </Space>
      }
      description={task.error || (busy ? '可以先处理其他内容，返回本页后会继续显示当前进度。' : undefined)}
    />
  )
}
