/**
 * 好感度侧栏（T5.1 实现）。
 * 右侧竖排 3 条：店长(粉)/财务(蓝)/市场(紫)，宽 8px 圆角；
 * 数值变化 transition height .4s（reduced-motion 无动画）；
 * role="progressbar" + aria-valuenow；本轮增量显示 +N/−N 浮字（@keyframes 1s 上浮消失）。
 */
import type { Affection } from '../engine/dialogueEngine'

interface MoodBarProps {
  affection: Affection
  /** 本轮好感度增量；null 表示不显示浮字（如开场/恢复） */
  deltas: Affection | null
  /** 轮次，作为浮字动画 key 触发重放 */
  round: number
  labels?: Record<'manager' | 'cfo' | 'cmo', string>
}

const ROLES = [
  { id: 'manager', label: '店长', tone: 'pink' },
  { id: 'cfo', label: '财务', tone: 'blue' },
  { id: 'cmo', label: '市场', tone: 'purple' },
] as const

export default function MoodBar({ affection, deltas, round, labels }: MoodBarProps) {
  return (
    <div className="galgame-moodbar" role="group" aria-label="角色好感度">
      {ROLES.map((role) => {
        const value = Math.round(affection[role.id])
        const delta = deltas?.[role.id] ?? 0
        return (
          <div key={role.id} className={`galgame-mood-item is-${role.tone}`}>
            <span className="galgame-mood-name">{labels?.[role.id] || role.label}</span>
            <div
              className="galgame-mood-track"
              role="progressbar"
              aria-valuemin={0}
              aria-valuemax={100}
              aria-valuenow={value}
              aria-label={`${labels?.[role.id] || role.label}信任度 ${value}`}
            >
              <div className="galgame-mood-fill" style={{ width: `${value}%` }} />
            </div>
            <span className="galgame-mood-value">{value}</span>
            {delta !== 0 && (
              <span
                key={`${round}-${role.id}`}
                className={`galgame-mood-float is-${delta > 0 ? 'up' : 'down'}`}
              >
                {delta > 0 ? `+${delta}` : String(delta)}
              </span>
            )}
          </div>
        )
      })}
    </div>
  )
}
