/**
 * 通用经营决策现场。
 * 内联 SVG 480x300：工作台、信息板、窗、协作桌与环境人物；
 * act 1 白天暖黄 / act 2 傍晚橙 / act 3 夜晚深蓝 + 两盏灯；
 * crowd 0–4 决定小人数量，messy 0–2 决定桌上杂物线条数量。
 * 颜色全部集中在 COLORS 常量（var + fallback 兜底，铁律 10），不许散落魔法值。
 */
export interface SceneBackgroundProps {
  act: number
  netProfit: number
  crowd: number
  messy: number
}

/** 场景专属色：变量未在主题落地前走 #fallback 兜底。 */
const COLORS = {
  skyDay: 'var(--galgame-sky-day, #fef3c7)',
  skyDusk: 'var(--galgame-sky-dusk, #fdba74)',
  skyNight: 'var(--galgame-sky-night, #1e293b)',
  floorDay: 'var(--galgame-floor-day, #f5f0e8)',
  floorDusk: 'var(--galgame-floor-dusk, #f0e0c8)',
  floorNight: 'var(--galgame-floor-night, #334155)',
  floorLine: 'var(--galgame-floor-line, #d6cbb8)',
  wallWindow: 'var(--galgame-window, #bfdbfe)',
  windowLight: 'var(--galgame-window-light, #fef9c3)',
  windowFrame: 'var(--galgame-window-frame, #94a3b8)',
  menuBoard: 'var(--galgame-menu, #78350f)',
  menuLine: 'var(--galgame-menu-line, #fef3c7)',
  counter: 'var(--galgame-counter, #a16207)',
  counterTop: 'var(--galgame-counter-top, #f59e0b)',
  table: 'var(--galgame-table, #92400e)',
  chair: 'var(--galgame-chair, #b45309)',
  lamp: 'var(--galgame-lamp, #fde68a)',
  personBody: 'var(--galgame-person, #4b5563)',
  personHead: 'var(--galgame-person-head, #fcd34d)',
  mess: 'var(--galgame-mess, #78716c)',
}

const ACT_SKY = { 1: COLORS.skyDay, 2: COLORS.skyDusk, 3: COLORS.skyNight }
const ACT_FLOOR = { 1: COLORS.floorDay, 2: COLORS.floorDusk, 3: COLORS.floorNight }

/** 椅子：座面 + 靠背，围绕桌面上下布置。 */
function Chair({ x, y, flip }: { x: number; y: number; flip: boolean }) {
  const seatY = flip ? y - 16 : y + 12
  return (
    <g>
      <rect x={x} y={seatY} width={26} height={6} rx={2} fill={COLORS.chair} />
      <rect x={flip ? x + 2 : x + 6} y={flip ? seatY - 10 : seatY + 6} width={4} height={10} rx={1} fill={COLORS.chair} />
    </g>
  )
}

/** 小人：圆头 + 身体，位置由调用方给定。 */
function Person({ x, y }: { x: number; y: number }) {
  return (
    <g>
      <circle cx={x} cy={y - 14} r={7} fill={COLORS.personHead} />
      <rect x={x - 6} y={y - 5} width={12} height={16} rx={5} fill={COLORS.personBody} />
    </g>
  )
}

export default function SceneBackground({ act, crowd, messy }: SceneBackgroundProps) {
  const normalized = (act === 2 || act === 3 ? act : 1) as 1 | 2 | 3
  const sky = ACT_SKY[normalized]
  const floor = ACT_FLOOR[normalized]
  const isNight = normalized === 3
  const people = Math.max(0, Math.min(4, crowd))
  const messCount = Math.max(0, Math.min(2, messy))

  // 小人位置：柜台前 2 个 + 两桌旁各 1 个
  const personSpots = [
    { x: 200, y: 240 },
    { x: 150, y: 205 },
    { x: 100, y: 250 },
    { x: 370, y: 250 },
  ].slice(0, people)

  // 杂物：两桌桌面各 messCount 组短线
  const messLines = [70, 314].flatMap((tx) =>
    Array.from({ length: messCount }, (_, i) => ({
      x: tx + 16 + i * 30,
      y: 221 + (i % 2) * 5,
    })),
  )

  return (
    <svg viewBox="0 0 480 300" role="img" aria-label="经营决策现场" className="galgame-scene-svg">
      {/* 天空 / 背景 */}
      <rect x={0} y={0} width={480} height={300} fill={sky} />
      {/* 夜晚两盏吊灯（光晕圆 + 灯体） */}
      {isNight && (
        <g>
          {[120, 360].map((lx) => (
            <g key={lx}>
              <circle cx={lx} cy={60} r={46} fill={COLORS.lamp} opacity={0.18} />
              <circle cx={lx} cy={60} r={18} fill={COLORS.lamp} opacity={0.4} />
              <rect x={lx - 2} y={48} width={4} height={10} fill={COLORS.lamp} opacity={0.8} />
            </g>
          ))}
        </g>
      )}
      {/* 窗户（左）：窗框 + 天光 + 十字窗棂 */}
      <g>
        <rect x={24} y={28} width={110} height={80} rx={6} fill={COLORS.wallWindow} />
        <rect x={30} y={34} width={98} height={68} rx={4} fill={COLORS.windowLight} />
        <line x1={30} y1={68} x2={128} y2={68} stroke={COLORS.windowFrame} strokeWidth={3} />
        <line x1={79} y1={34} x2={79} y2={102} stroke={COLORS.windowFrame} strokeWidth={3} />
        <rect x={24} y={28} width={110} height={80} rx={6} fill="none" stroke={COLORS.windowFrame} strokeWidth={4} />
      </g>
      {/* 菜单板（右）：3 行短线 */}
      <g>
        <rect x={330} y={20} width={100} height={70} rx={8} fill={COLORS.menuBoard} />
        {[38, 52, 66].map((ly) => (
          <line key={ly} x1={342} y1={ly} x2={418} y2={ly} stroke={COLORS.menuLine} strokeWidth={4} strokeLinecap="round" />
        ))}
      </g>
      {/* 地面 */}
      <rect x={0} y={200} width={480} height={100} fill={floor} />
      <line x1={0} y1={200} x2={480} y2={200} stroke={COLORS.floorLine} strokeWidth={2} />
      {/* 柜台（中）：柜体 + 台面 */}
      <g>
        <rect x={150} y={150} width={180} height={52} rx={6} fill={COLORS.counter} />
        <rect x={142} y={146} width={196} height={10} rx={5} fill={COLORS.counterTop} />
        <rect x={150} y={184} width={180} height={4} rx={2} fill={COLORS.counter} opacity={0.55} />
      </g>
      {/* 两桌四椅 */}
      {[70, 314].map((tx) => (
        <g key={tx}>
          <rect x={tx} y={222} width={96} height={9} rx={3} fill={COLORS.table} />
          <rect x={tx + 8} y={231} width={6} height={14} fill={COLORS.table} />
          <rect x={tx + 82} y={231} width={6} height={14} fill={COLORS.table} />
          <Chair x={tx + 4} y={222} flip={false} />
          <Chair x={tx + 66} y={222} flip={true} />
        </g>
      ))}
      {/* 桌上杂物（messy） */}
      {messLines.map((m, i) => (
        <line key={i} x1={m.x} y1={m.y} x2={m.x + 10} y2={m.y + 2} stroke={COLORS.mess} strokeWidth={2} strokeLinecap="round" />
      ))}
      {/* 客流（crowd） */}
      {personSpots.map((p, i) => (
        <Person key={i} x={p.x} y={p.y} />
      ))}
    </svg>
  )
}
