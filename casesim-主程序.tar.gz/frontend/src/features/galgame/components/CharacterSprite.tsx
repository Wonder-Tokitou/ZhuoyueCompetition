/**
 * 角色立绘（阶段 2 实现）。
 * 店长 👩‍💼 中 / 财务总监 👨‍🔬 左 / 市场经理 🧑‍🚀 右；
 * 表情角标 happy/calm/worried/anxious/excited（元素带 data-mood）；
 * active 放大 1.08 + 粉色描边，dimmed 透明度 0.75，点击回调 onSelect。
 * 定位与动画样式在 galgame.css（375px 下不重叠）。
 */
export type CharacterExpression = 'happy' | 'calm' | 'worried' | 'anxious' | 'excited'

export interface CharacterSpriteProps {
  id: string
  expression: CharacterExpression
  active: boolean
  dimmed: boolean
  name?: string
  onSelect?: () => void
}

const CHARACTERS: Record<string, { emoji: string; name: string }> = {
  manager: { emoji: '👩‍💼', name: '店长' },
  cfo: { emoji: '👨‍🔬', name: '财务' },
  cmo: { emoji: '🧑‍🚀', name: '市场' },
}

const EXPRESSIONS: Record<CharacterExpression, { emoji: string; label: string }> = {
  happy: { emoji: '😊', label: '开心' },
  calm: { emoji: '😐', label: '平静' },
  worried: { emoji: '😟', label: '担忧' },
  anxious: { emoji: '😰', label: '焦虑' },
  excited: { emoji: '🤩', label: '兴奋' },
}

export default function CharacterSprite({ id, expression, active, dimmed, name, onSelect }: CharacterSpriteProps) {
  const character = CHARACTERS[id] ?? { emoji: '🙂', name: id }
  const displayName = name?.trim() || character.name
  const mood = EXPRESSIONS[expression] ?? EXPRESSIONS.calm
  const className = ['galgame-character', active ? 'is-active' : '', dimmed ? 'is-dimmed' : '']
    .filter(Boolean)
    .join(' ')

  return (
    <button
      type="button"
      className={className}
      data-character-id={id}
      aria-label={`${displayName}：${mood.label}`}
      onClick={onSelect}
    >
      <span className="galgame-character-emoji" aria-hidden="true">{character.emoji}</span>
      <span className="galgame-character-name">{displayName}</span>
      <span className="galgame-character-mood" data-mood={expression} aria-hidden="true">{mood.emoji}</span>
    </button>
  )
}
