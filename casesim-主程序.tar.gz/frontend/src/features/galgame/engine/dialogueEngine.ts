/**
 * 分支判定 / 好感度 / 评分 / 结局（阶段 1 实现）。
 * 全部纯函数，禁止 import react。改评分公式只改 scoreRound。
 */
export type RiskBranch = 'conservative' | 'balanced' | 'aggressive'
export type RiskLevel = '保守' | '稳健' | '激进'
export type Mood = 'warm' | 'neutral' | 'cold'

export interface Affection {
  manager: number
  cfo: number
  cmo: number
}

export interface ScoreState {
  score: number
  /** 分项整句说明（T5.2 模板），空数组表示第 1 轮无分项可列 */
  breakdown: string[]
}

export interface RoundOutcome {
  /** Δ净利润 = net_profit(本轮) − net_profit(上轮)；第 1 轮以 0 为基准 */
  netProfitDelta: number
  /** 本轮现金净流量相对上一轮的变化（万元） */
  cashFlowDelta: number
  /** 份额环比（百分点） */
  shareDelta: number
  risk: RiskBranch
}

/** 保守关键词（含预检扩词：深耕/现有/复购/口碑/聚焦/小幅/暂缓/提效） */
const CONSERVATIVE_WORDS = ['收缩', '控本', '降本', '压缩', '保留', '现金', '库存', '维持', '守住', '削减', '深耕', '现有', '复购', '口碑', '聚焦', '小幅', '暂缓', '提效']
/** 激进关键词（含预检扩词：快速/大规模/高频/全线/提价/溢价） */
const AGGRESSIVE_WORDS = ['扩张', '投放', '让利', '补贴', '促销', '降价', '抢占', '加大', '新增', '签约', '铺开', '快速', '大规模', '高频', '全线', '提价', '溢价']

/**
 * 关键词分类器：有 riskLevel 直接用（主线 U6 下发后自动切走）；
 * 否则按关键词打分，保守分 > 激进分 → conservative，激进分 > 保守分 → aggressive，
 * 打平或无命中 → balanced。空串 / "方案 A" 这类兜底 label 一律 balanced，不许抛。
 */
export function classifyRisk(label: string, riskLevel?: RiskLevel): RiskBranch {
  if (riskLevel === '保守') return 'conservative'
  if (riskLevel === '稳健') return 'balanced'
  if (riskLevel === '激进') return 'aggressive'
  const text = label ?? ''
  let conservative = 0
  let aggressive = 0
  for (const word of CONSERVATIVE_WORDS) if (text.includes(word)) conservative++
  for (const word of AGGRESSIVE_WORDS) if (text.includes(word)) aggressive++
  if (conservative > aggressive) return 'conservative'
  if (aggressive > conservative) return 'aggressive'
  return 'balanced'
}

/** D5 好感度增量表：保守/激进两列按原文，稳健列是必要补充。 */
export function affectionDelta(risk: RiskBranch): Affection {
  switch (risk) {
    case 'conservative':
      return { manager: 0, cfo: 10, cmo: -10 }
    case 'aggressive':
      return { manager: 0, cfo: -10, cmo: 10 }
    case 'balanced':
    default:
      return { manager: 6, cfo: 2, cmo: 2 }
  }
}

function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value))
}

/** 应用本轮好感度增量，clamp(0, 100)。 */
export function applyAffection(prev: Affection, risk: RiskBranch): Affection {
  const delta = affectionDelta(risk)
  return {
    manager: clamp(prev.manager + delta.manager, 0, 100),
    cfo: clamp(prev.cfo + delta.cfo, 0, 100),
    cmo: clamp(prev.cmo + delta.cmo, 0, 100),
  }
}

/** 语气阈值：≥75 warm / 45–74 neutral / <45 cold。 */
export function moodOf(value: number): Mood {
  if (value >= 75) return 'warm'
  if (value >= 45) return 'neutral'
  return 'cold'
}

/**
 * D5 评分（唯一口径，改公式只改这里）：
 *   profit = +10 (Δ>0) | −8 (Δ<0) | 0 (Δ=0)
 *   cash   = +5 (现金净流量环比增加) | −5 (环比减少) | 0 (不变)
 *   match  = +5 若 (现金净流量减少且 risk=conservative) 或 (份额环比 > 0 且 risk=aggressive)
 *   mismatch = −6 若 (现金净流量环比减少超过5万元且 risk=aggressive)
 *   score = clamp(score + profit + cash + match + mismatch, 0, 100)
 */
export function scoreRound(prev: ScoreState, outcome: RoundOutcome): ScoreState {
  const breakdown: string[] = []
  let delta = 0

  if (outcome.netProfitDelta > 0) {
    delta += 10
    breakdown.push(`净利润比上一轮增加了 ${outcome.netProfitDelta} 万元，经营有起色。`)
  } else if (outcome.netProfitDelta < 0) {
    delta -= 8
    breakdown.push(`净利润比上一轮少了 ${-outcome.netProfitDelta} 万元，这一轮在亏钱。`)
  }

  if (outcome.cashFlowDelta > 0) {
    delta += 5
    breakdown.push(`现金净流量比上一轮增加了 ${outcome.cashFlowDelta} 万元。`)
  } else if (outcome.cashFlowDelta < 0) {
    delta -= 5
    breakdown.push(`现金净流量比上一轮减少了 ${-outcome.cashFlowDelta} 万元，要留意资金压力。`)
  }

  if (outcome.cashFlowDelta < 0 && outcome.risk === 'conservative') {
    delta += 5
    breakdown.push('你选了保守策略，而当前现金流紧张，策略和局面是对得上的。')
  } else if (outcome.shareDelta > 0 && outcome.risk === 'aggressive') {
    delta += 5
    breakdown.push('你选了激进策略，而当前市场份额在涨，策略和局面是对得上的。')
  }

  if (outcome.cashFlowDelta < -5 && outcome.risk === 'aggressive') {
    delta -= 6
    breakdown.push('现金流已经很紧张，这一轮还在加大投入，风险偏高。')
  }

  return { score: clamp(prev.score + delta, 0, 100), breakdown }
}

/** 结局阈值：>80 success / 50–80 normal / <50 fail。 */
export function endingOf(score: number): 'success' | 'normal' | 'fail' {
  if (score > 80) return 'success'
  if (score >= 50) return 'normal'
  return 'fail'
}
