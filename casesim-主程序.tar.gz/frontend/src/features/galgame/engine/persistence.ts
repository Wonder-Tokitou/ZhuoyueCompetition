/**
 * 本地存档 + 服务器重建（阶段 1 实现；P1-F2 起带 mode 命名空间）。
 * localStorage 键：galgame_save:<token>:<mode>；session_id 由 engine/session.ts 按模式存取。
 */
import { applyAffection, classifyRisk, scoreRound } from './dialogueEngine'
import type { Affection, RiskBranch, ScoreState } from './dialogueEngine'
import type { GameMode } from './session'
import type { FinancialMetrics, Metrics, SessionState } from '../../../api/types'

export interface GalgameHistoryEntry {
  round: number
  risk: RiskBranch
  /** 本轮现金净流量（万元）；从服务器 turns 重建时无法恢复，填 0 */
  cashFlowAmount: number
  /** 本轮净利润（万元，financial_state 口径）；重建时无法恢复，缺省 */
  netProfit?: number
}

export interface GalgameSave {
  v: 1
  session_id: number | null
  round: number
  affection: Affection
  score: number
  finished: boolean
  history: GalgameHistoryEntry[]
  /** 分支/事件记账：`ev:r{n}` 存事件标题（已触发过 = 不再弹）；其余布尔标记 */
  flags: Record<string, boolean | string>
  seenCg: string[]
  seenSide: string[]
}

const KEY = (token: string, mode: GameMode) => `galgame_save:${token}:${mode}`

export const INITIAL_AFFECTION: Affection = { manager: 70, cfo: 60, cmo: 65 }

function emptySave(): GalgameSave {
  return {
    v: 1,
    session_id: null,
    round: 1,
    affection: { ...INITIAL_AFFECTION },
    score: 50,
    finished: false,
    history: [],
    flags: {},
    seenCg: [],
    seenSide: [],
  }
}

export function loadSave(token: string, mode: GameMode): GalgameSave | null {
  try {
    const raw = globalThis.localStorage?.getItem(KEY(token, mode))
    if (!raw) return null
    const parsed = JSON.parse(raw) as GalgameSave
    if (parsed?.v !== 1 || typeof parsed.affection?.cfo !== 'number') return null
    return parsed
  } catch {
    return null
  }
}

export function saveSave(token: string, mode: GameMode, save: GalgameSave): void {
  globalThis.localStorage?.setItem(KEY(token, mode), JSON.stringify(save))
}

/**
 * 从服务器 SessionState 重建本地表现层存档：
 * round 与 finished 以服务器为准；好感度用 turns 的 chosen_label 逐轮累计；
 * 分数逐轮从服务器保存的 after_metrics 重算，刷新或换设备不会换一套口径。
 * 有财务仿真时使用净利润与现金净流量；旧案例缺少财务字段时才回退到营收变化。
 */
export function outcomeFromMetrics(before: Metrics | null, after: Metrics | null, risk: RiskBranch) {
  const beforeFinancial = before as FinancialMetrics | null
  const afterFinancial = after as FinancialMetrics | null
  const beforeProfit = typeof beforeFinancial?.net_profit === 'number' ? beforeFinancial.net_profit : before?.revenue
  const afterProfit = typeof afterFinancial?.net_profit === 'number' ? afterFinancial.net_profit : after?.revenue
  const netProfitDelta = typeof beforeProfit === 'number' && typeof afterProfit === 'number'
    ? Number((afterProfit - beforeProfit).toFixed(2))
    : 0
  const beforeCash = typeof beforeFinancial?.cash_flow_amount === 'number' ? beforeFinancial.cash_flow_amount : null
  const afterCash = typeof afterFinancial?.cash_flow_amount === 'number' ? afterFinancial.cash_flow_amount : null
  const cashFlowDelta = beforeCash !== null && afterCash !== null
    ? Number((afterCash - beforeCash).toFixed(2))
    : 0
  const shareDelta = Number((parseFloat(after?.market_share ?? '0') - parseFloat(before?.market_share ?? '0')).toFixed(2))
  return { netProfitDelta, cashFlowDelta, shareDelta, risk }
}

export function rebuildFromSession(state: SessionState): GalgameSave {
  const save = emptySave()
  save.session_id = state.session_id
  save.round = state.turns.length + 1
  save.finished = state.finished
  let affection: Affection = { ...INITIAL_AFFECTION }
  let scoreState: ScoreState = { score: 50, breakdown: [] }
  for (let i = 0; i < state.turns.length; i++) {
    const label = state.turns[i].chosen_label ?? ''
    const risk = classifyRisk(label)
    affection = applyAffection(affection, risk)
    const before = i > 0 ? state.turns[i - 1].after_metrics : state.play?.base_metrics ?? null
    const after = state.turns[i].after_metrics
    const financialAfter = after as FinancialMetrics | null
    scoreState = scoreRound(scoreState, outcomeFromMetrics(before, after, risk))
    save.history.push({
      round: i + 1,
      risk,
      cashFlowAmount: typeof financialAfter?.cash_flow_amount === 'number' ? financialAfter.cash_flow_amount : 0,
      netProfit: typeof financialAfter?.net_profit === 'number' ? financialAfter.net_profit : undefined,
    })
  }
  save.affection = affection
  save.score = scoreState.score
  return save
}
