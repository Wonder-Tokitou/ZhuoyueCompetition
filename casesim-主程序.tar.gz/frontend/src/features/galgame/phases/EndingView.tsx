import { useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import type { PlayResponse, SessionState } from '../../../api/types'
import { endingOf } from '../engine/dialogueEngine'
import type { GalgameSave } from '../engine/persistence'
import type { GameMode } from '../engine/session'
import { ENDINGS } from '../data/endings'
import { packFor } from '../data/professionalPacks'

/** 经营日记键（P1-F2：localStorage["galgame_diary:<token>:<session_id>:<mode>"]，≤12 条截断）。 */
const DIARY_KEY = (token: string, mode: GameMode, sessionId: number | null) => `galgame_diary:${token}:${sessionId ?? 'none'}:${mode}`

export interface DiaryEntry {
  round: number
  title: string
  label: string
  summary: string
  revenueDelta: number | null
  cashFlow: number
  events: string[]
}

function loadDiary(token: string, mode: GameMode, sessionId: number | null): DiaryEntry[] {
  try {
    const raw = globalThis.localStorage?.getItem(DIARY_KEY(token, mode, sessionId))
    const arr = raw ? JSON.parse(raw) : []
    return Array.isArray(arr) ? arr : []
  } catch {
    return []
  }
}

/** 结局页：优先使用案例分析阶段保存的收束对白，经营结果和复盘仍走统一规则。 */
export default function EndingView({
  token,
  save,
  turns,
  data,
  mode,
  onRestart,
}: {
  token: string
  save: GalgameSave | null
  turns: SessionState['turns']
  data: PlayResponse | null
  mode: GameMode
  onRestart: () => void
}) {
  const [showDiary, setShowDiary] = useState(false)
  const diaryRef = useRef<HTMLOListElement>(null)
  const kind = endingOf(save?.score ?? 50)
  const ending = ENDINGS.find((e) => e.id === `end.${kind}`) ?? ENDINGS[1]
  const pack = packFor(data?.case_type)
  const achievementIndex = Math.min(3, Math.max(0, Math.floor((save?.score ?? 50) / 25)))
  const authoredEnding = data?.story?.ending?.filter((line) => line.speaker?.trim() && line.text?.trim()) ?? []
  const diary = loadDiary(token, mode, save?.session_id ?? null)
  const diaryEntries = diary.length > 0
    ? diary
    : turns.map((turn, i) => ({
        round: i + 1,
        title: data?.nodes.find((n) => n.id === turn.node_id)?.title ?? '决策',
        label: turn.chosen_label ?? '已保存',
        summary: turn.summary,
        revenueDelta: null,
        cashFlow: 0,
        events: [],
      }))

  /** 切换日记：展开后自动滚动到日记区（结算卡在屏幕底部时列表展开在视口外，必须可见反馈）。 */
  function toggleDiary() {
    setShowDiary((v) => {
      const next = !v
      if (next) {
        requestAnimationFrame(() => {
          diaryRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' })
        })
      }
      return next
    })
  }
  return (
    <div className="galgame-finished">
      <p className="galgame-finished-title">{ending.title}</p>
      <ul className="galgame-ending-lines">
        {authoredEnding.length > 0
          ? authoredEnding.map((line, index) => <li key={`${line.speaker}-${index}`}><strong>{line.speaker}：</strong>{line.text}</li>)
          : ending.lines.map((line) => <li key={line}>{line}</li>)}
      </ul>
      <p className="galgame-final-score">
        经营表现分 {Math.round(save?.score ?? 50)}
      </p>
      <p className="galgame-achievement">本次称号：{pack.achievements[achievementIndex]}</p>
      <p className="galgame-ending-dimensions">结局评价关注：{pack.evaluation.join('、')}</p>
      <div className="galgame-finished-actions">
        <button type="button" className="galgame-confirm" onClick={toggleDiary}>
          {showDiary ? '收起经营日记' : '查看经营日记'}
        </button>
        {mode === 'formal' && (
          <Link
            className="galgame-review-link galgame-confirm"
            to={`/student/${token}/review?session=${save?.session_id ?? ''}`}
          >
            查看完整复盘（含各轮数据）
          </Link>
        )}
        {mode === 'practice' && (
          <button type="button" className="galgame-confirm" onClick={onRestart}>
            再来一局
          </button>
        )}
      </div>
      {showDiary && (
        <ol className="galgame-diary" ref={diaryRef}>
          {diaryEntries.length === 0 && <li>暂无经营记录。</li>}
          {diaryEntries.map((entry, i) => (
            <li key={i}>
              <strong>第 {entry.round} 轮 · {entry.title}</strong>
              <span>选了「{entry.label}」</span>
              <span>{entry.summary}</span>
              {entry.revenueDelta != null && <span>营收 {entry.revenueDelta > 0 ? '+' : ''}{entry.revenueDelta} 万元</span>}
              {entry.events.length > 0 && <span className="galgame-diary-event">事件：{entry.events.join('、')}</span>}
            </li>
          ))}
        </ol>
      )}
    </div>
  )
}
