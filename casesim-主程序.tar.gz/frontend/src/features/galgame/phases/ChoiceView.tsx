import type { CaseType, Metrics, OptionBrief } from '../../../api/types'
import ChoiceButtons from '../components/ChoiceButtons'
import { packFor } from '../data/professionalPacks'

/** 选项面板（phase=choice）与财务追问表单（phase=reason）。 */
export default function ChoiceView({
  phase,
  options,
  metrics,
  disabled,
  onConfirm,
  reasonExtra,
  onReasonExtra,
  onSubmit,
  caseType,
}: {
  phase: 'choice' | 'reason'
  options: OptionBrief[]
  metrics: Metrics | null
  disabled: boolean
  onConfirm: (key: string) => void
  reasonExtra: string
  onReasonExtra: (value: string) => void
  onSubmit: () => void
  caseType?: CaseType | null
}) {
  if (phase === 'choice') {
    return (
      <ChoiceButtons
        options={options}
        disabled={disabled}
        onConfirm={onConfirm}
        metrics={metrics}
      />
    )
  }
  const pack = packFor(caseType)
  return (
    <div className="galgame-reason">
      <p className="galgame-reason-hint">{pack.promptHint}</p>
      <label className="galgame-reason-extra">
        {pack.promptTitle} / 判断依据（选填，≤200 字）
        <textarea
          rows={3}
          maxLength={200}
          value={reasonExtra}
          disabled={disabled}
          onChange={(e) => onReasonExtra(e.target.value)}
        />
      </label>
      <button
        type="button"
        className="galgame-confirm"
        disabled={disabled}
        onClick={onSubmit}
      >
        提交这个方案
      </button>
    </div>
  )
}
