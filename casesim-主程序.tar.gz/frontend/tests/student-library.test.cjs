const { test } = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs'), path = require('node:path'), vm = require('node:vm'), ts = require('typescript')

/** 案例模式显示名等常量：源码只依赖类型导入，转译后无运行时依赖。 */
function loadCaseConstants() {
  const exports = {}
  const code = ts.transpileModule(fs.readFileSync(path.resolve(__dirname, '../src/domain/caseConstants.ts'), 'utf8'), {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 },
  }).outputText
  vm.runInNewContext(code, { exports, require: () => ({}) })
  return exports
}

function mount(file, name, api, extra = {}) {  let index = 0, tree, nextTimer = 0
  const hooks = [], pending = [], timers = new Map(), navigations = []
  const navigate = (...args) => navigations.push(args)
  const same = (a, b) => a && b && a.length === b.length && a.every((v, i) => Object.is(v, b[i]))
  const jsx = (type, props) => ({ type, props })
  const mocks = {
    react: {
      useState(initial) { const n = index++; if (!(n in hooks)) hooks[n] = initial; return [hooks[n], v => { hooks[n] = typeof v === 'function' ? v(hooks[n]) : v }] },
      useEffect(effect, deps) { const n = index++, old = hooks[n]; if (!same(old?.deps, deps)) pending.push(() => { old?.cleanup?.(); hooks[n] = { deps, cleanup: effect() } }) },
    },
    'react/jsx-runtime': { jsx, jsxs: jsx, Fragment: 'Fragment' },
    antd: { Alert: 'Alert', Button: 'Button', Card: 'Card', Input: 'Input', Space: 'Space', Spin: 'Spin', Tag: 'Tag', Radio: { Group: 'RadioGroup', Button: 'RadioButton' }, Typography: { Title: 'Title', Paragraph: 'Paragraph', Text: 'Text' } },
    'react-router-dom': { useNavigate: () => navigate },
    '../../api/client': { api },
    '../../context/StudentAccountContext': { useStudentAccount: () => ({ real_name: '同学' }) },
    '../../components/StudentScanner': { __esModule: true, default: 'Scanner' },
    '../../domain/caseConstants': loadCaseConstants(),
    './StudentSpacePages': { StudentCasesPage: 'CaseLibrary' },
    ...extra,
  }
  const exports = {}
  const code = ts.transpileModule(fs.readFileSync(path.resolve(__dirname, file), 'utf8'), { compilerOptions: { module: ts.ModuleKind.CommonJS, jsx: ts.JsxEmit.ReactJSX, target: ts.ScriptTarget.ES2022 } }).outputText
  vm.runInNewContext(code, { exports, require: id => { if (!(id in mocks)) throw Error(id); return mocks[id] }, AbortController, URL, URLSearchParams,
    window: { location: { search: '' }, setTimeout: fn => { timers.set(++nextTimer, fn); return nextTimer }, clearTimeout: id => timers.delete(id) } })
  function render() { index = 0; tree = exports[name](); while (pending.length) pending.shift()() }
  function find(type, node = tree) {
    if (!node || typeof node !== 'object') return []
    if (Array.isArray(node)) return node.flatMap(item => find(type, item ?? null))
    return [...(node.type === type ? [node.props] : []), ...find(type, node.props?.children ?? null)]
  }
  render()
  return { find, navigations,
    async flush() { for (let i = 0; i < 3; i++) { await new Promise(setImmediate); render() } },
    async tick() { const fns = [...timers.values()]; timers.clear(); fns.forEach(fn => fn()); await this.flush() },
    close() { hooks.forEach(h => h?.cleanup?.()) },
    get timerCount() { return timers.size },
  }
}

/** 递归收集树中的可见文本（处理 JSX 片段数组与数字子节点） */
function collectText(node, out = []) {
  if (node == null || typeof node === 'boolean') return out
  if (typeof node === 'string' || typeof node === 'number') { out.push(String(node)); return out }
  if (Array.isArray(node)) { node.forEach(n => collectText(n, out)); return out }
  if (typeof node === 'object' && node.props) { collectText(node.props.children, out) }
  return out
}

test('student home shows case library first and keeps optional token and scanner entry', () => {
  const page = mount('../src/pages/student/StudentLandingPage.tsx', 'default', {})
  assert.equal(page.find('CaseLibrary').length, 1)
  assert.equal(page.find('details').length, 1)
  assert.ok(!page.find('details')[0].open)
  assert.equal(page.find('Input').length, 1)
  assert.equal(page.find('Scanner').length, 1)
  page.find('Scanner')[0].onScan('/student/saved-token')
  assert.equal(page.navigations[0][0], '/student/saved-token')
  page.close()
})

test('library discovers newly published cases and opens a case without manual token input', async () => {
  let requests = 0
  const page = mount('../src/pages/student/StudentSpacePages.tsx', 'StudentCasesPage', { get: async url => {
    assert.equal(url, '/student/cases')
    return { data: ++requests === 1 ? [] : [{ id: 9, title: '教师案例', case_type: '战略决策类', version: 2, background: '背景', student_token: 'from-library' }] }
  } })
  await page.flush()
  assert.equal(page.find('Card').length, 0)
  await page.tick()
  assert.equal(page.find('Card')[0]?.title, '教师案例')
  page.find('Button').find(b => b.children === '进入推演').onClick()
  assert.equal(page.navigations[0][0], '/student/from-library')
  assert.equal(page.find('Input').length, 0)
  page.close()
  assert.equal(page.timerCount, 0)
})

test('library shows teacher name, case type and cumulative play count for school cases', async () => {
  const page = mount('../src/pages/student/StudentSpacePages.tsx', 'StudentCasesPage', { get: async () => ({ data: [
    { id: 3, title: '案例三', case_type: '市场营销类', version: 1, background: '背景', student_token: 't3', teacher_name: '王老师', play_count: 12 },
    { id: 4, title: '案例四', case_type: '财务管理类', version: 1, background: '背景', student_token: 't4' },
  ] }) })
  await page.flush()
  const body = page.find('Card').map(card => collectText(card.children).join(''))
  assert.ok(body.some(t => t.includes('王老师')), '应展示上传教师名称')
  assert.ok(body.some(t => t.includes('市场营销模式')), '应展示案例模式标签')
  assert.ok(body.some(t => t.includes('累计推演：12 次')), '应展示累计推演次数')
  // 无教师归属的历史案例回退为"平台管理员"，无推演记录显示 0
  assert.ok(body.some(t => t.includes('平台管理员')), '无归属案例应回退平台管理员')
  assert.ok(body.some(t => t.includes('累计推演：0 次')), '无推演记录应显示 0 次')
  page.close()
})

test('library filters cases by type and passes the filter to the api', async () => {
  let lastParams
  const page = mount('../src/pages/student/StudentSpacePages.tsx', 'StudentCasesPage', { get: async (url, config) => {
    lastParams = config?.params || {}
    return { data: [{ id: 5, title: '类型案例', case_type: '市场营销类', version: 1, background: '背景', student_token: 't5', teacher_name: '李老师', play_count: 3 }] }
  } })
  await page.flush()
  assert.equal(page.find('RadioGroup').length, 1, '应有案例类型筛选器')
  // 初始为全部类型：请求不带 case_type
  assert.equal(lastParams.case_type, undefined)
  const group = page.find('RadioGroup')[0]
  assert.ok(group.onChange, '筛选器应可切换类型')
  group.onChange({ target: { value: '市场营销类' } })
  await page.flush()
  assert.equal(lastParams.case_type, '市场营销类', '切换类型后请求应携带 case_type')
  assert.equal(page.find('Card').length, 1)
  page.close()
})

test('library retries transient errors and ignores responses after unmount', async () => {
  let requests = 0, resolve
  const page = mount('../src/pages/student/StudentSpacePages.tsx', 'StudentCasesPage', { get: async () => {
    if (++requests === 1) throw Error('offline')
    return new Promise(r => { resolve = r })
  } })
  await page.flush()
  assert.equal(page.find('Alert')[0].message, 'offline')
  await page.tick()
  assert.equal(requests, 2)
  page.close()
  resolve({ data: [{ id: 1, title: 'late-case' }] })
  await page.flush()
  assert.equal(page.find('Card').length, 0)
  assert.equal(page.timerCount, 0)
})
