const { test } = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const vm = require('node:vm')
const ts = require('typescript')

function loadPacks() {
  const source = fs.readFileSync(path.resolve(__dirname, '../src/features/galgame/data/professionalPacks.ts'), 'utf8')
  const js = ts.transpileModule(source, {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 },
  }).outputText
  const exports = {}
  vm.runInNewContext(js, { exports, module: { exports }, require: () => ({}) })
  return exports
}

const MODES = ['战略决策类', '市场营销类', '财务管理类']

test('三个分析模块各有 5 个专属随机事件', () => {
  const { PROFESSIONAL_PACKS } = loadPacks()
  for (const mode of MODES) {
    assert.equal(PROFESSIONAL_PACKS[mode].events.length, 5, `${mode} 事件数量`)
  }
})

test('三个分析模块各锚定 5 个课程知识点', () => {
  const { PROFESSIONAL_PACKS } = loadPacks()
  for (const mode of MODES) {
    assert.equal(PROFESSIONAL_PACKS[mode].knowledge.length, 5, `${mode} 知识点数量`)
  }
  assert.ok(PROFESSIONAL_PACKS['战略决策类'].knowledge.includes('国际化战略'))
  assert.ok(PROFESSIONAL_PACKS['财务管理类'].knowledge.includes('财务比率分析'))
})

test('成就称号按课程命名，营销为增长黑客', () => {
  const { PROFESSIONAL_PACKS } = loadPacks()
  for (const mode of MODES) {
    assert.equal(PROFESSIONAL_PACKS[mode].achievements.length, 4, `${mode} 成就数量`)
  }
  assert.ok(PROFESSIONAL_PACKS['市场营销类'].achievements.includes('增长黑客'))
})

test('剧情模式入口以完成正式推演第 1 轮为解锁条件', () => {
  const source = fs.readFileSync(path.resolve(__dirname, '../src/pages/student/StudentModePage.tsx'), 'utf8')
  assert.match(source, /\/student\/records/)
  assert.match(source, /roundsDone < 1/)
  assert.match(source, /disabled=\{!storyUnlocked\}/)
})
