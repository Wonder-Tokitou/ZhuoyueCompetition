const { test } = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const vm = require('node:vm')
const ts = require('typescript')

const source = (relative) => fs.readFileSync(path.join(__dirname, '..', relative), 'utf8')

function loadTeacherPaths() {
  const code = ts.transpileModule(source('src/routing/teacherPaths.ts'), {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 },
  }).outputText
  const exports = {}
  vm.runInNewContext(code, { exports })
  return exports
}

test('every teacher menu entry has a registered child route', () => {
  const layout = source('src/layouts/TeacherLayout.tsx')
  const app = source('src/App.tsx')
  const menuBlock = layout.match(/const MENU_ITEMS[\s\S]*?=\s*\[([\s\S]*?)\n\]/)?.[1] ?? ''
  const menuKeys = [...menuBlock.matchAll(/key:\s*'([^']+)'/g)].map((match) => match[1])
  const childRoutes = new Set([...app.matchAll(/<Route\s+path="([^"]+)"/g)].map((match) => match[1]))

  assert.ok(menuKeys.includes('trash'), '回收站应在教师菜单中')
  for (const key of menuKeys.filter((key) => key !== 'workbench')) {
    assert.ok(childRoutes.has(key), `教师菜单 ${key} 缺少对应子路由`)
  }
  assert.match(app, /path="trash"\s+element=\{<TeacherTrashPage\s*\/>\}/)
})

test('teacher section links are canonical with and without a legacy URL token', () => {
  const { teacherSectionPath } = loadTeacherPaths()
  assert.equal(teacherSectionPath('', 'trash'), '/teacher/trash')
  assert.equal(teacherSectionPath(undefined, 'records'), '/teacher/records')
  assert.equal(teacherSectionPath('legacy token', 'accounts'), '/teacher/legacy%20token/accounts')
  assert.equal(teacherSectionPath('', 'workbench'), '/teacher')
})
