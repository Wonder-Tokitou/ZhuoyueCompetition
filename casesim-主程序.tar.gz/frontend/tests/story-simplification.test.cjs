const { test } = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')

const read = (name) => fs.readFileSync(path.join(__dirname, '../src/features/galgame', name), 'utf8')

test('剧情对话框可滚动且不再裁掉长对白', () => {
  const css = read('galgame.css')
  const block = css.match(/\.galgame-dialogue\s*\{[\s\S]*?\}/)?.[0] || ''
  assert.match(block, /overflow-y:\s*auto/)
  assert.doesNotMatch(block, /overflow:\s*hidden/)
})

test('剧情模式只保留正式业务选项和一个选填理由，不显示三组伪选项', () => {
  const choice = read('phases/ChoiceView.tsx')
  assert.doesNotMatch(choice, /phrases\.map/)
  assert.match(choice, /判断依据（选填/)
  assert.match(choice, /onSubmit/)
})

test('剧情主流程不再插入随机事件或CG动画', () => {
  const page = read('GalgamePlayPage.tsx')
  const flow = read('engine/useGalgameFlow.ts')
  assert.doesNotMatch(page, /EventView/)
  assert.doesNotMatch(flow, /pickEvent|setEventPopup|setCg\(/)
})

test('剧情结束页直接提供醒目的完整复盘入口且不展示粗糙CG', () => {
  const ending = read('phases/EndingView.tsx')
  assert.match(ending, /查看完整复盘/)
  assert.doesNotMatch(ending, /galgame-cg-placeholder|cgSrc/)
})
