const test = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')

const read = (file) => fs.readFileSync(path.join(__dirname, '..', file), 'utf8')

test('student enters a clean mode chooser before either experience', () => {
  const app = read('src/App.tsx')
  assert.match(app, /StudentModePage/)
  assert.match(app, /path="play"/)
  assert.match(app, /path="story"/)
  const mode = read('src/pages/student/StudentModePage.tsx')
  assert.match(mode, /正常模式/)
  assert.match(mode, /剧情模式/)
  assert.match(mode, /experience-mode-grid/)
})

test('normal mode contains no game scene or implementation notes', () => {
  const play = read('src/pages/student/StudentPlayPage.tsx')
  assert.doesNotMatch(play, /<OfficeScene/)
  for (const phrase of ['本阶段不调用 AI', '教师版本', 'A\/B\/C 仅为', '未提交的理由与选择仅保留在本页']) {
    assert.doesNotMatch(play, new RegExp(phrase))
  }
})

test('student library hides refresh internals and uses aligned controls', () => {
  const page = read('src/pages/student/StudentSpacePages.tsx')
  assert.doesNotMatch(page, /每 10 秒自动更新|无需输入令牌|版本 \{r\.version\}/)
  assert.match(page, /case-filter-grid/)
  assert.match(page, /student-case-card/)
})

test('story view reads case-authored dialogue instead of a fixed milk-tea script', () => {
  const flow = read('src/features/galgame/engine/useGalgameFlow.ts')
  assert.match(flow, /(?:data\?\.story|saved\.play\.story|play\.story)/)
  const dialogue = read('src/features/galgame/data/dialogueTree.ts')
  assert.doesNotMatch(dialogue, /奶茶店|开始营业/)
})
