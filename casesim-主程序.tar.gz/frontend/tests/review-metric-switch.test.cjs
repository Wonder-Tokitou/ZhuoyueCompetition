const { test } = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const vm = require('node:vm')
const ts = require('typescript')

function loadReviewCharts() {
  const source = fs.readFileSync(path.resolve(__dirname, '../src/features/ai/ReviewCharts.tsx'), 'utf8')
  const js = ts.transpileModule(source, {
    compilerOptions: { module: ts.ModuleKind.CommonJS, jsx: ts.JsxEmit.ReactJSX, target: ts.ScriptTarget.ES2022 },
  }).outputText
  const noop = () => null
  const mocks = {
    react: { useState: (value) => [value, noop], useEffect: noop, useRef: () => ({ current: null }) },
    antd: { Select: 'Select' },
    'echarts/core': { use: noop, init: () => ({ setOption: noop, resize: noop, dispose: noop }) },
    'echarts/charts': { LineChart: {}, RadarChart: {} },
    'echarts/components': { GridComponent: {}, LegendComponent: {}, TitleComponent: {}, TooltipComponent: {} },
    'echarts/renderers': { CanvasRenderer: {} },
  }
  const exports = {}
  vm.runInNewContext(js, { exports, module: { exports }, require: (name) => mocks[name] ?? {}, console })
  return exports
}

test('复盘走势图按模式给出默认指标：营销份额、战略风险、财务净利润', () => {
  const { DEFAULT_METRIC_KEY } = loadReviewCharts()
  assert.equal(DEFAULT_METRIC_KEY['市场营销类'], 'market_share')
  assert.equal(DEFAULT_METRIC_KEY['战略决策类'], 'risk_score')
  assert.equal(DEFAULT_METRIC_KEY['财务管理类'], 'net_profit')
})

test('三种模式都配置了默认指标', () => {
  const { DEFAULT_METRIC_KEY } = loadReviewCharts()
  assert.deepEqual(Object.keys(DEFAULT_METRIC_KEY).sort(), ['战略决策类', '市场营销类', '财务管理类'].sort())
  assert.ok(Object.values(DEFAULT_METRIC_KEY).every((key) => typeof key === 'string' && key.length > 0))
})
