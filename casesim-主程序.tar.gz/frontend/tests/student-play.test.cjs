const { test } = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const vm = require('node:vm')
const ts = require('typescript')

function deferred() { let resolve, reject; const promise = new Promise((a, b) => { resolve = a; reject = b }); return { promise, resolve, reject } }

// 真实加载纯函数模块（不 mock），与 task-workspace.test.cjs 的 load 同一套转译约定。
function loadModule(file, mocks = {}) {
  const exports = {}
  const source = fs.readFileSync(path.resolve(__dirname, '../src', file), 'utf8')
  vm.runInNewContext(ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, jsx: ts.JsxEmit.ReactJSX, target: ts.ScriptTarget.ES2022 } }).outputText, { exports, require: n => mocks[n] || {} })
  return exports
}

function play(token) { return { case_title: token, background: '', dilemma: '', base_metrics: null, nodes: [{ id: 1, idx: 1, title: token, background: '', node_role: '', options: [{ key: 'C', label: '渠道策略' }, { key: 'A', label: '定价策略' }, { key: 'B', label: '营销策略' }] }] } }
function session(token) { return { session_id: token === 'a' ? 11 : 22, student_name: '学生', play: play(token), next_node_id: 1, case_version: 1, turns: [] } }

function mount(overrides = {}, saved = false) {
  const hooks = [], pending = [], navs = [], storage = new Map(saved ? [['student_session:a', '11']] : [])
  let cursor = 0, token = 'a', tree
  const mocks = {
    react: {
      // C4 用 memo 包裹指标条；这里保持恒等（不改变组件身份），断言口径不受影响。
      memo: (component) => component,
      useState(initial) { const i = cursor++; if (!(i in hooks)) hooks[i] = initial; return [hooks[i], (value) => { hooks[i] = typeof value === 'function' ? value(hooks[i]) : value }] },
      useRef(initial) { const i = cursor++; return hooks[i] ||= { current: initial } },
      useEffect(effect, deps) { const i = cursor++, prev = hooks[i]; if (!prev || deps.some((v, j) => !Object.is(v, prev.deps[j]))) pending.push(() => { prev?.cleanup?.(); hooks[i] = { deps, cleanup: effect() } }) },
    },
    'react/jsx-runtime': { jsx: (type, props) => ({ type, props }), jsxs: (type, props) => ({ type, props }) },
    '../../components/MetricComparison': { __esModule: true, default: 'MetricComparison' },
    // 结算卡的真实渲染由 tests/settlement-card.test.cjs 覆盖；页面级只看它是否挂载与关闭。
    './components/SettlementCard': { __esModule: true, default: 'SettlementCard' },
    // 阶段 5：Steps 已被 RoundMap 取代，Steps 键保留（页面不再使用，留着不影响）；
    // RoundMap 是纯展示组件，页面级只关心挂载参数。
    './components/RoundMap': { __esModule: true, default: 'RoundMap' },
    './components/OfficeScene': { __esModule: true, default: 'OfficeScene' },
    // 文案纯函数用真实实现，页面级断言才真的在校验「为什么」的分支命中。
    '../../domain/decisionNarrative': loadModule('domain/decisionNarrative.ts'),
    antd: { Popconfirm: 'Popconfirm', Alert: 'Alert', Button: 'Button', Card: 'Card', Input: { TextArea: 'TextArea' }, Progress: 'Progress', Steps: 'Steps', Spin: 'Spin', Space: 'Space', Typography: { Paragraph: 'Paragraph', Text: 'Text', Title: 'Title' } },
    'react-router-dom': { useNavigate: () => (to) => navs.push(to) },
    '../../context/StudentTokenContext': { useStudentToken: () => token },
    '../../context/StudentAccountContext': { useStudentAccount: () => ({ id: 1, real_name: '学生' }) },
    '../../api/client': { playGet: async (t) => play(t), startStudent: async (t) => session(t), restoreStudent: async (t) => session(t), decide: async () => ({}), ...overrides },
  }
  const code = ts.transpileModule(fs.readFileSync(path.resolve(__dirname, '../src/pages/student/StudentPlayPage.tsx'), 'utf8'), { compilerOptions: {
    module: ts.ModuleKind.CommonJS, jsx: ts.JsxEmit.ReactJSX, target: ts.ScriptTarget.ES2022,
  } }).outputText
  const exports = {}
  vm.runInNewContext(code, { exports, require: (name) => { if (name in mocks) return mocks[name]; throw new Error(name) },
    Promise, Error, Event, Date, sessionStorage: { getItem: (k) => storage.get(k) || null, setItem: (k, v) => storage.set(k, v) },
    window: { dispatchEvent() {} } })
  function render() { cursor = 0; tree = exports.default(); while (pending.length) pending.shift()() }
  function all(type, node = tree) {
    if (!node || typeof node !== 'object') return []
    if (Array.isArray(node)) return node.flatMap((n) => all(type, n ?? null))
    return [...(node.type === type ? [node.props] : []), ...all(type, node.props?.children ?? null)]
  }
  render()
  return { all, navs, navigate(next) { token = next; render() }, close() { for (const h of hooks) h?.cleanup?.() },
    async flush() { for (let i = 0; i < 4; i++) { await new Promise(setImmediate); render() } } }
}

test('late start response cannot replace the newly selected case', async () => {
  const start = deferred(), page = mount({ startStudent: () => start.promise })
  await page.flush()
  page.all('Button').find((b) => b.children === '开始推演').onClick()
  page.navigate('b'); await page.flush()
  start.resolve(session('a')); await page.flush()
  assert.equal(page.all('Card')[0].title, 'b')
  assert.ok(page.all('Button').some((b) => b.children === '开始推演'))
  page.close()
})

test('late decision response cannot import previous session into another case', async () => {
  const decision = deferred(), page = mount({ decide: () => decision.promise }, true)
  await page.flush()
  page.all('Button').find((b) => b.className === 'strategy-option').onClick()
  await page.flush()
  page.all('Button').find(b => b.children === '确认提交本回合').onClick()
  page.navigate('b'); await page.flush()
  decision.resolve({}); await page.flush()
  assert.ok(page.all('Button').some((b) => b.children === '开始推演'))
  page.close()
})

function options(page) { return page.all('Button').filter(b => b.className === 'strategy-option') }
function button(page, name) { return page.all('Button').find(b => b.children === name) }
function accepted(key = 'C') {
  const saved = session('a')
  saved.play.nodes.push({ ...play('a').nodes[0], id: 2, idx: 2 })
  saved.next_node_id = 2
  saved.turns = [{ node_id: 1, chosen_option: key, after_metrics: null, summary: '与所选策略对应的结果' }]
  return saved
}

test('display A submits its shuffled stable key C exactly once and pauses on the saved strategy', async () => {
  const decision = deferred(), calls = []
  let restores = 0
  const page = mount({ decide: (_token, body) => { calls.push(body); return decision.promise },
    restoreStudent: async () => ++restores === 1 ? session('a') : accepted('C') }, true)
  await page.flush()
  assert.equal(button(page, '确认提交本回合').disabled, true)
  options(page)[0].onClick(); await page.flush()
  const confirm = button(page, '确认提交本回合').onClick
  confirm(); confirm(); await page.flush()
  assert.equal(calls.length, 1)
  assert.equal(calls[0].option_key, 'C')
  assert.equal(options(page).filter(b => b['aria-pressed']).length, 1)
  assert.equal(options(page)[0].type, 'primary')
  decision.resolve({}); await page.flush()
  assert.equal(options(page).length, 0, 'no automatic click-through to the next question')
  // P1-5：原「本轮结果」success Alert 已移除，保存的策略改由结算卡展示。
  const cards = page.all('SettlementCard')
  assert.equal(cards.length, 1, '提交成功后结算卡必须挂载')
  assert.equal(cards[0].chosenLabel, '渠道策略', '要显示学生实际提交的策略名')
  assert.equal(cards[0].round, 1, '第 1 轮提交后 round 应为 1')
  confirm(); await page.flush()
  assert.equal(calls.length, 1, 'stale handlers must not submit again')
  button(page, '继续下一回合').onClick(); await page.flush()
  assert.equal(options(page).filter(b => b['aria-pressed']).length, 0)
  assert.equal(button(page, '确认提交本回合').disabled, true)
  page.close()
})

test('selection can change before confirmation; displayed B posts key A, not array index', async () => {
  const calls = []
  const page = mount({ decide: async (_t, body) => { calls.push(body) } }, true)
  await page.flush()
  options(page)[0].onClick(); await page.flush()
  options(page)[1].onClick(); await page.flush()
  assert.equal(calls.length, 0)
  assert.deepEqual(options(page).map(b => b['aria-pressed']), [false, true, false])
  button(page, '确认提交本回合').onClick(); await page.flush()
  assert.equal(calls[0].option_key, 'A')
  page.close()
})

test('a lost POST response restores the accepted choice without sending a second decision', async () => {
  let restores = 0, posts = 0
  const page = mount({ decide: async () => { posts++; throw new Error('response lost') },
    restoreStudent: async () => ++restores === 1 ? session('a') : accepted() }, true)
  await page.flush(); options(page)[0].onClick(); await page.flush()
  button(page, '确认提交本回合').onClick(); await page.flush()
  assert.ok(button(page, '继续下一回合'))
  assert.equal(posts, 1)
  assert.equal(page.all('Alert').filter(a => a.type === 'warning').length, 0)
  page.close()
})

test('uncertain network failure locks submission until server reconciliation', async () => {
  let restores = 0, posts = 0, online = false
  const page = mount({ decide: async () => { posts++; throw new Error('offline') },
    restoreStudent: async () => { if (++restores === 1) return session('a'); if (!online) throw new Error('offline'); return session('a') } }, true)
  await page.flush(); options(page)[2].onClick(); await page.flush()
  button(page, '确认提交本回合').onClick(); await page.flush()
  assert.ok(button(page, '核对已保存进度'))
  assert.ok(options(page).every(b => b.disabled))
  options(page)[0].onClick(); await page.flush()
  assert.equal(options(page)[2]['aria-pressed'], true)
  online = true
  button(page, '核对已保存进度').onClick(); await page.flush()
  assert.equal(posts, 1)
  assert.equal(button(page, '确认提交本回合').disabled, false)
  assert.equal(options(page)[2]['aria-pressed'], true)
  page.close()
})

test('server conflict shows actual accepted strategy, not the attempted choice', async () => {
  let restores = 0
  const page = mount({ decide: async () => { throw new Error('409') },
    restoreStudent: async () => ++restores === 1 ? session('a') : accepted('A') }, true)
  await page.flush(); options(page)[0].onClick(); await page.flush()
  button(page, '确认提交本回合').onClick(); await page.flush()
  assert.match(page.all('Alert').find(a => a.type === 'warning').message, /另一页面提交/)
  // P1-5：服务端实际保存的策略改由结算卡 chosenLabel 展示（原 success Alert 已移除）。
  assert.equal(page.all('SettlementCard')[0].chosenLabel, '定价策略')
  page.close()
})

test('decision reason is cleared when navigating to a different case', async () => {
  const page = mount({}, true)
  await page.flush()
  page.all('TextArea')[0].onChange({ target: { value: '只属于案例甲的理由' } })
  page.navigate('b'); await page.flush()
  page.all('Button').find((b) => b.children === '开始推演').onClick(); await page.flush()
  assert.equal(page.all('TextArea')[0].value, '')
  page.close()
})

test('double start before rerender only sends one create request', async () => {
  let count = 0
  const start = deferred(), page = mount({ startStudent: () => { count++; return start.promise } })
  await page.flush()
  const click = page.all('Button').find((b) => b.children === '开始推演').onClick
  click(); click()
  start.resolve(session('a')); await page.flush()
  assert.equal(count, 1)
  page.close()
})

test('choosing displayed A highlights only that strategy without committing or greying all options', async () => {
  let count = 0
  const decision = deferred()
  const page = mount({ decide: () => { count++; return decision.promise } }, true)
  await page.flush()
  page.all('Button').find(b => b.className === 'strategy-option').onClick()
  await page.flush()
  const options = page.all('Button').filter(b => b.className === 'strategy-option')
  assert.equal(options.filter(b => b['aria-pressed'] === true).length, 1, 'one visibly selected choice required')
  assert.equal(options.filter(b => b.disabled).length, 0, 'selection must remain changeable until confirmation')
  assert.equal(count, 0, 'touching an option must not silently submit a turn')
  page.close()
})

function failure(message, status, code) {
  return Object.assign(new Error(message), { name: 'ApiError', status, code })
}

test('duplicate submission shows the real reason and offers the records entry', async () => {
  const page = mount({ startStudent: async () => { throw failure('已有本案例推演记录，请从提交记录继续，或选择覆盖原记录后重做。', 409, 'submission_exists') } })
  await page.flush()
  page.all('Button').find(b => b.children === '开始推演').onClick(); await page.flush()
  const alert = page.all('Alert').find(a => a.type === 'warning')
  assert.match(alert.message, /已有本案例推演记录，请从「我的记录」继续/)
  const entry = page.all('Button').find(b => String(b.children).includes('我的记录'))
  assert.ok(entry, 'a clickable entry to the saved record is required')
  entry.onClick()
  assert.deepEqual(page.navs, ['/student/records'])
  page.close()
})

test('other start failures keep the backend message and show no records entry', async () => {
  const page = mount({ startStudent: async () => { throw failure('案例已下架', 409, 'case_unavailable') } })
  await page.flush()
  page.all('Button').find(b => b.children === '开始推演').onClick(); await page.flush()
  assert.equal(page.all('Alert').find(a => a.type === 'warning').message, '案例已下架')
  assert.ok(!page.all('Button').some(b => String(b.children).includes('我的记录')))
  assert.deepEqual(page.navs, [])
  page.close()
})

// ---- U1 即时结算单 ----

/** 提交成功后带真实指标的会话：营收 78→86.5、毛利率 60.0%→55.0%（营收↑毛利率↓）。 */
function acceptedWithMetrics({ key = 'C', label = '渠道策略', cash = 12, revenueBefore = 78, revenueAfter = 86.5, marginBefore = '60.0%', marginAfter = '55.0%' } = {}) {
  const saved = session('a')
  saved.play.base_metrics = { revenue: revenueBefore, gross_margin: marginBefore, market_share: '20.0%', cash_flow: '平稳' }
  saved.play.nodes.push({ ...play('a').nodes[0], id: 2, idx: 2 })
  saved.next_node_id = 2
  saved.current_metrics = { revenue: revenueAfter, gross_margin: marginAfter, market_share: '21.0%', cash_flow: '收紧' }
  saved.financial_state = { net_profit: -12.35, cash_flow_amount: cash }
  saved.turns = [{ node_id: 1, chosen_option: key, chosen_label: label, after_metrics: saved.current_metrics, summary: '与所选策略对应的结果' }]
  return saved
}

test('U1: after an accepted turn the settlement modal opens with round, label and cause', async () => {
  const saved = acceptedWithMetrics()
  let restores = 0
  const page = mount({ decide: async () => ({}), restoreStudent: async () => ++restores === 1 ? session('a') : saved }, true)
  await page.flush()
  options(page)[0].onClick(); await page.flush()
  button(page, '确认提交本回合').onClick(); await page.flush()

  const cards = page.all('SettlementCard')
  assert.equal(cards.length, 1, '结算卡必须挂载到页面上')
  assert.equal(cards[0].open, true, '提交成功后必须自动弹出')
  assert.equal(cards[0].round, 1, '第 1 轮提交后 round 应为 1')
  assert.equal(cards[0].chosenLabel, '渠道策略', '要显示学生实际提交的策略名')
  assert.match(cards[0].narrative.why, /降价或让利换来了更多客户/, '营收↑毛利率↓ 要命中对应因果分支')
  assert.match(cards[0].narrative.why, /渠道策略/, '因果句要点名所选策略')
  assert.match(cards[0].narrative.deltaText, /营收 78\.00 → 86\.50 万元/, '要给出旧值 → 新值')
  assert.equal(page.all('Alert').filter(a => a.type === 'success').length, 0, '「本轮结果」Alert 已按 P1-5 移除，结果展示统一由结算卡承担')
  page.close()
})

test('U1: closing the settlement modal keeps the continue button', async () => {
  const saved = acceptedWithMetrics()
  let restores = 0
  const page = mount({ decide: async () => ({}), restoreStudent: async () => ++restores === 1 ? session('a') : saved }, true)
  await page.flush()
  options(page)[0].onClick(); await page.flush()
  button(page, '确认提交本回合').onClick(); await page.flush()

  page.all('SettlementCard')[0].onClose(); await page.flush()
  assert.equal(page.all('SettlementCard')[0].open, false, '点「继续」后结算卡要关闭')
  assert.equal(page.all('Alert').filter(a => a.type === 'success').length, 0, '「本轮结果」Alert 已按 P1-5 移除，不随结算卡关闭而复现')
  assert.ok(button(page, '继续下一回合'), '关闭结算卡后仍要能继续下一回合')
  page.close()
})

test('U1: negative cash flow makes the next focus about cash survival', async () => {
  const saved = acceptedWithMetrics({ cash: -12.5 })
  let restores = 0
  const page = mount({ decide: async () => ({}), restoreStudent: async () => ++restores === 1 ? session('a') : saved }, true)
  await page.flush()
  options(page)[0].onClick(); await page.flush()
  button(page, '确认提交本回合').onClick(); await page.flush()

  assert.equal(page.all('SettlementCard')[0].narrative.nextFocus, '现金流能否撑住下一轮扩张')
  page.close()
})

test('U1: rolling back a decision closes the settlement modal so stale numbers are not shown', async () => {
  const saved = acceptedWithMetrics()
  let restores = 0
  const page = mount({ decide: async () => ({}), restoreStudent: async () => ++restores === 1 ? session('a') : saved, rollbackStudentSubmission: async () => { const back = session('a'); return back } }, true)
  await page.flush()
  options(page)[0].onClick(); await page.flush()
  button(page, '确认提交本回合').onClick(); await page.flush()
  assert.equal(page.all('SettlementCard')[0].open, true)

  // 回退入口是 Popconfirm，点「修改此决策及后续节点」只弹确认框，真正回退走 onConfirm。
  page.all('Popconfirm')[0].onConfirm(); await page.flush()
  assert.equal(page.all('SettlementCard')[0].open, false, '回退后不得继续展示上一轮的结算数字')
  page.close()
})

test('U1: switching to another case closes the settlement modal', async () => {
  const saved = acceptedWithMetrics()
  let restores = 0
  const page = mount({ decide: async () => ({}), restoreStudent: async () => ++restores === 1 ? session('a') : saved }, true)
  await page.flush()
  options(page)[0].onClick(); await page.flush()
  button(page, '确认提交本回合').onClick(); await page.flush()
  assert.equal(page.all('SettlementCard')[0].open, true)

  page.navigate('b'); await page.flush()
  assert.equal(page.all('SettlementCard').filter(c => c.open).length, 0, '换案例后不得残留上一案例的结算卡')
  page.close()
})

test('决策依据：策略定位随选项展示，五要素收在折叠区内', async () => {
  const saved = session('a')
  saved.play.nodes[0].options[0].detail = {
    positioning: '以线下渠道为核心',
    actions: '优先进驻核心城市 120 家标杆门店',
    investment: '新增营销费用约 5000 万元',
    expected_return: '销量增速 3%-5%',
    tradeoff: '起量慢，可能错过窗口期',
    theory: ['4P 渠道策略'],
  }
  const page = mount({ restoreStudent: async () => saved }, true)
  await page.flush()
  const positions = page.all('span').filter((s) => s.className === 'strategy-position')
  assert.equal(positions.length, 1)
  assert.equal(positions[0].children, '以线下渠道为核心')
  const basis = page.all('details').filter((d) => d.className === 'strategy-basis')
  assert.equal(basis.length, 1)
  page.close()
})
