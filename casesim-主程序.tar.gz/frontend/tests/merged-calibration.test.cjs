const { test } = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs'), path = require('node:path'), vm = require('node:vm'), ts = require('typescript')
// ProgressivePanel 依赖 domain/frameworkMetrics（PROCESS_FIELDS/PROCESS_TITLES/normalizeImpact/syncFinancial），按真实模块注入。
const frameworkMetricsExports = {}
vm.runInNewContext(ts.transpileModule(fs.readFileSync(path.join(__dirname, '../src/domain/frameworkMetrics.ts'), 'utf8'), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText, { exports: frameworkMetricsExports, require: () => ({}) })
test('merged impact editor preserves five editable rules and their option identity', () => {
  const source = fs.readFileSync(path.join(__dirname, '../src/pages/teacher/components/ProgressivePanel.tsx'), 'utf8')
  const exports = {}, setters = [], values = [{ '7:A': { revenue_pct: 12, margin_pp: -4, expense_pct: 3, cash_pct: -2, share_pp: 1 } }]
  let index = 0, editor
  const jsx = (type, props) => ({ type, props })
  vm.runInNewContext(ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, jsx: ts.JsxEmit.ReactJSX } }).outputText, {
    exports, require: name => name === 'react' ? { useEffect: () => {}, useRef: () => ({ current: false }), useState: initial => { const i = index++; return [i in values ? values[i] : initial, value => setters.push([i, value])] } }
      : name === 'react/jsx-runtime' ? { jsx, jsxs: jsx }
      : name === 'antd' ? { App: { useApp: () => ({ message: {} }) }, InputNumber: 'InputNumber', Typography: {} }
      : name === '../../../domain/frameworkMetrics' ? frameworkMetricsExports : {},
  })
  exports.default({ detail: { case: { id: 1, case_type: '财务管理类' }, nodes: [] }, token: 'test', children: render => { editor = render('7:A'); return null } })
  // renderImpact 结构：标题 / 过程指标输入 / 财务传导指标 details / 测算依据 details；
  // 五个可编辑财务系数位于「查看财务传导指标」折叠内的 Space 子节点。
  const inputs = editor.props.children[2].props.children[1].props.children
  assert.equal(inputs.length, 5)
  assert.deepEqual(Array.from(inputs, i => i.props.value), [12, -4, 3, -2, 1])
  inputs[0].props.onChange(8)
  const updated = setters.find(([i]) => i === 0)[1](values[0])
  assert.equal(updated['7:A'].revenue_pct, 8)
  assert.equal(updated['7:A'].cash_pct, -2)
})
test('option table hides legacy amounts but retains baseline and cash description', () => {
  // 行为断言：挂载 NodeSection（CalibratePanel 拆分后的 stage=2 子组件），遍历渲染树找到 Table 列配置，校验列结构
  const source = fs.readFileSync(path.join(__dirname, '../src/pages/teacher/components/NodeSection.tsx'), 'utf8')
  let index = 0
  const hooks = [], pending = []
  const react = {
    useState(initial) {
      const i = index++
      if (!(i in hooks)) hooks[i] = typeof initial === 'function' ? initial() : initial
      return [hooks[i], (v) => { hooks[i] = typeof v === 'function' ? v(hooks[i]) : v }]
    },
    useRef(initial) { return hooks[index++] ||= { current: initial } },
    useEffect(effect) { const i = index++; if (!hooks[i]) { pending.push(effect); hooks[i] = {} } },
  }
  const tables = []
  // jsx 对函数型组件直接调用以遍历子树；字符串组件返回虚拟节点
  const jsx = (type, props) => {
    if (typeof type === 'function') return type(props)
    return { type, props }
  }
  const passthrough = (props) => props.children
  const detail = {
    case: { id: 1, title: '案例', status: 'ready', version: 1, base_metrics: { revenue: 200, gross_margin: '20%', market_share: '30%', cash_flow: '本期流入' }, base_net_profit: 80, financial_assumptions: { operating_cost: 160, operating_expense: 20 } },
    nodes: [{ id: 7, idx: 1, title: '节点', node_role: '核心战略', options: [{ key: 'A', label: '策略A', summary: '摘要', risk_level: '稳健', metrics: { revenue: 100, gross_margin: '50%', market_share: '20%', cash_flow: '流入' } }] }],
  }
  const mocks = {
    react, 'react/jsx-runtime': { jsx, jsxs: jsx, Fragment: 'Fragment' },
    './ProgressivePanel': { __esModule: true, default: (props) => props.children ? props.children((id) => ({ type: 'ImpactCell', props: { id } })) : null },
    './baselineFinance': { baselineError: () => null, linkedBaseline: () => ({ cost: 160, margin: '20%' }) },
    './metricAnnotation': { metricAnnotation: (v) => ({ value: v, note: '' }) },
    antd: {
      App: { useApp: () => ({ message: {} }) },
      Alert: 'Alert', Button: 'Button', Card: passthrough, Collapse: passthrough,
      Input: { TextArea: 'TextArea' }, InputNumber: 'InputNumber', Select: 'Select',
      Space: passthrough, Table: (props) => { tables.push(props); return { type: 'Table', props } },
      Tabs: (props) => (props.items || []).map(item => item.children), Tag: 'Tag',
      Typography: { Text: 'Text', Title: 'Title', Paragraph: 'Paragraph' },
    },
    '../../../api/client': { generateCaseNodes: async () => ({}), patchCase: async () => ({}), patchNode: async () => ({}), api: { get: async () => ({ data: {} }), post: async () => ({ data: {} }), put: async () => ({ data: {} }) } },
    '../../../features/ai/api': { getAiTask: async () => ({}), listCaseAiTasks: async () => [] },
    '../../../features/ai/TaskStatus': { __esModule: true, default: () => null, pendingTask: () => null },
    '../../../domain/idempotency.js': { stableIdempotencyKey: () => 'key' },
    '../../../domain/financials.js': { calculateNetProfit: () => 80 },
    '../teacherConstants': {
      METRIC_FIELDS: [
        { key: 'revenue', label: '营收（万元）', numeric: true },
        { key: 'gross_margin', label: '毛利率', numeric: false },
        { key: 'market_share', label: '市场份额', numeric: false },
        { key: 'cash_flow', label: '现金流', numeric: false },
      ],
      RISK_META: { 保守: { color: 'default' }, 稳健: { color: 'blue' }, 激进: { color: 'red' } },
      RISK_OPTIONS: [{ value: '保守', label: '保守' }, { value: '稳健', label: '稳健' }, { value: '激进', label: '激进' }],
      STATUS_META: { draft: { text: '草稿', color: 'default' }, generating: { text: '生成中', color: 'gold' }, ready: { text: '已就绪', color: 'blue' }, published: { text: '已发布', color: 'green' } },
      CASH_FLOW_TEXTAREA_STYLE: {},
    },
  }
  const exports = {}
  vm.runInNewContext(ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, jsx: ts.JsxEmit.ReactJSX, target: ts.ScriptTarget.ES2022 } }).outputText, {
    exports, require: (name) => { if (!(name in mocks)) throw Error(name); return mocks[name] },
    sessionStorage: { getItem: () => null, setItem: () => {} },
    window: { addEventListener: () => {}, removeEventListener: () => {} },
    setTimeout: () => 0, clearTimeout: () => {},
  })
  exports.default({ token: 'test', detail, nodes: detail.nodes, dirtyNodes: [], activeNode: undefined, setActiveNode: () => {}, savingCase: false, savingNodeId: null, prerequisitesDirty: false, onDirtyChange: () => {}, onSaveNode: async () => {}, onSummariesSaved: () => {}, updateNode: () => {}, updateOption: () => {}, updateOptionMetric: () => {} })
  const tableProps = tables.find(t => Array.isArray(t.columns) && t.columns.length === 6)
  assert.ok(tableProps, 'option table should render 6 columns')
  // 列数固定为 6（选项键/风险/策略/摘要/现金流/递进影响）
  assert.equal(tableProps.columns.length, 6)
  // 不出现 financial_assumptions 列（旧版按选项金额已隐藏）
  const columnKeys = tableProps.columns.map(c => c.dataIndex || c.key)
  assert.ok(!columnKeys.includes('financial_assumptions'))
  // 递进影响列（index 5）的 render 是函数，且调用后产出非空节点
  const impactCol = tableProps.columns[5]
  assert.equal(typeof impactCol.render, 'function')
  const renderedImpact = impactCol.render(null, { key: 'A' })
  assert.ok(renderedImpact !== null && renderedImpact !== undefined)
})
