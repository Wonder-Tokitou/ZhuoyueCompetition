const { test } = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs'), path = require('node:path'), vm = require('node:vm'), ts = require('typescript')

function load(file, mocks = {}) {
  const exports = {}
  const source = fs.readFileSync(path.join(__dirname, '../src', file), 'utf8')
  vm.runInNewContext(ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, jsx: ts.JsxEmit.ReactJSX, target: ts.ScriptTarget.ES2022 } }).outputText, { exports, require: n => mocks[n] || {} })
  return exports
}

test('record summary deduplicates accounts, preserves namesakes and respects case version filters', () => {
  const { filterRecords, summarizeRecords } = load('domain/recordSummary.ts')
  const rows = [
    { student_name: '同名', student_id: 1, case_version: 1, turns: [{ idx: 1 }, { idx: 2 }, { idx: 3 }] },
    { student_name: '同名', student_id: 1, case_version: 1, turns: [{ idx: 1 }] },
    { student_name: '同名', student_id: 2, case_version: 2, turns: [{ idx: 1 }] },
    { student_name: '旧记录', turns: [] },
  ]
  const all = summarizeRecords(rows)
  assert.equal(all.participants, 3)
  assert.equal(all.completed, 1)
  assert.deepEqual(Array.from(all.rounds), [2, 1, 1])
  assert.equal(filterRecords(rows, '同名', 'unfinished', '2').length, 1)
  assert.equal(filterRecords(rows, '', 'all', 'unknown').length, 1)
  assert.equal(filterRecords(rows, '不存在', 'all', 'all').length, 0)
})

test('metric changes preserve zero, signed cash and percentage-point semantics without parsing prose', () => {
  const { metricChange } = load('components/MetricComparison.tsx')
  assert.equal(metricChange(-10, -12), '-2.00 万元')
  assert.equal(metricChange(0, 0), '0.00 万元')
  assert.equal(metricChange('20%', '22%', true), '+2.00 个百分点')
  assert.equal(metricChange('约20%（假设）', '22%', true), '—')
  assert.equal(metricChange(undefined, 2), '—')
})

function calibration() {
  let index = 0, tree, props, dirty = []
  const hooks = [], effects = [], calls = []
  const jsx = (type, props) => typeof type === 'function' ? type(props) : ({ type, props })
  const react = {
    useState(initial) { const i = index++; if (!(i in hooks)) hooks[i] = typeof initial === 'function' ? initial() : initial; return [hooks[i], v => { hooks[i] = typeof v === 'function' ? v(hooks[i]) : v }] },
    useRef(initial) { return hooks[index++] ||= { current: initial } },
    useEffect(fn, deps) { const i = index++, old = hooks[i]; if (!old || deps.some((v, j) => !Object.is(v, old.deps[j]))) effects.push(() => { old?.cleanup?.(); hooks[i] = { deps, cleanup: fn() } }) },
  }
  const mock = {
    react, 'react/jsx-runtime': { jsx, jsxs: jsx },
    antd: { App: { useApp: () => ({ message: { success() {}, warning() {}, error() {} } }) }, Input: Object.assign('Input', { TextArea: 'TextArea' }), InputNumber: 'InputNumber', Card: 'Card', Button: 'Button', Space: 'Space', Typography: { Text: 'Text', Paragraph: 'Paragraph' } },
    './baselineFinance': load('pages/teacher/components/baselineFinance.ts'),
    './metricAnnotation': load('pages/teacher/components/metricAnnotation.ts'),
    '../../../domain/financials.js': load('domain/financials.js'),
    '../../../features/ai/api': { listCaseAiTasks: async () => [] },
    '../../../features/ai/TaskStatus': { pendingTask: () => false },
    '../../../api/client': { patchCase: async (...args) => calls.push(args), patchNode: async () => {} },
    '../teacherConstants': { STATUS_META: { ready: { text: 'ready' } }, METRIC_FIELDS: [{ key: 'revenue', numeric: true, label: '营收' }, { key: 'gross_margin', label: '毛利率' }, { key: 'market_share', label: '份额' }, { key: 'cash_flow', label: '现金流' }] },
    '../components/baselineFinance': load('pages/teacher/components/baselineFinance.ts'),
    '../../../domain/caseConstants': {
      PROCESS_BASELINE_DEFAULTS: { marketing: {}, strategy: {} },
      PROCESS_BASELINE_FIELDS: { marketing: [], strategy: [] },
      MODE_LABELS: { finance: '财务管理模式', marketing: '市场营销模式', strategy: '战略决策模式' },
      resolveMode: (mode, caseType) => mode || (caseType === '市场营销类' ? 'marketing' : caseType === '战略决策类' ? 'strategy' : 'finance'),
    },
  }
  // Function-valued Input is unnecessary in this renderer; attach TextArea to an object.
  mock.antd.Input = { TextArea: 'TextArea' }
  // CalibratePanel 拆分后：薄壳真实加载 hook 与两个子组件（子组件在拆分后承载原 UI 与联动）
  mock['../hooks/useCalibrationState'] = load('pages/teacher/hooks/useCalibrationState.ts', mock)
  mock['./BaselineSection'] = load('pages/teacher/components/BaselineSection.tsx', mock)
  mock['./NodeSection'] = load('pages/teacher/components/NodeSection.tsx', mock)
  const component = load('pages/teacher/components/CalibratePanel.tsx', mock).default
  props = { teacherToken: 'test', stage: 1, draftRevision: 1, onDirtyChange: parts => { dirty = parts }, onRefresh: async () => {}, onSaveRefresh: async () => {},
    detail: { case: { id: 1, title: '原始案例', background: '背景', dilemma: '困境', status: 'ready', version: 1,
      base_metrics: { revenue: 100, gross_margin: '20%', market_share: '10%', cash_flow: '流入' }, base_net_profit: 10, financial_assumptions: { operating_cost: 80, operating_expense: 10 } }, nodes: [] } }
  function render() { index = 0; tree = component(props); while (effects.length) effects.shift()() }
  function all(node = tree) { if (!node || typeof node !== 'object') return []; if (Array.isArray(node)) return node.flatMap(n => all(n ?? null)); return [node.props, ...all(node.props?.children ?? null)] }
  render()
  return { calls, field: () => all().find(p => p?.addonBefore === '案例标题'), dirty: () => dirty,
    button: label => all().find(p => p?.children === label),
    stage(n) { props = { ...props, stage: n }; render() },
    refresh(title) { props = { ...props, draftRevision: props.draftRevision + 1, detail: { ...props.detail, case: { ...props.detail.case, title } } }; render() },
    async flush() { for (let n = 0; n < 4; n++) { await new Promise(setImmediate); render() } },
    close() { hooks.forEach(h => h?.cleanup?.()) },
  }
}

test('stage navigation and incoming task refresh preserve unsaved baseline; saving clears only that draft', async () => {
  const page = calibration(); await page.flush()
  page.field().onChange({ target: { value: '教师正在编辑的标题' } }); await page.flush()
  assert.ok(page.dirty().includes('财务基准与案例信息'))
  page.stage(2); await page.flush(); page.stage(1); await page.flush()
  assert.equal(page.field().value, '教师正在编辑的标题')
  page.refresh('后台迟到的新标题'); await page.flush()
  assert.equal(page.field().value, '教师正在编辑的标题')
  await page.button('保存案例信息').onClick(); await page.flush()
  assert.equal(page.calls[0][2].title, '教师正在编辑的标题')
  assert.equal(page.dirty().length, 0)
  page.close()
})
