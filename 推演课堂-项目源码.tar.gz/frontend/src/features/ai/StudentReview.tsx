import { useEffect, useState } from 'react'
import { Alert, Button, Card, Popconfirm, Progress, Spin, Space, Table, Typography } from 'antd'
import { review, retryStudentReview } from './api'
import type { ReviewResponse } from '../../api/types'
import { FrameworkLineChart, RadarScoreChart, RoundLineChart } from './ReviewCharts'

export const PROFESSIONAL_METRICS = {
  市场营销类: [['sales_index', '销量指数'], ['market_share', '市场份额'], ['customer_satisfaction', '客户满意度'], ['repeat_purchase_rate', '复购率'], ['marketing_roi', '营销 ROI']],
  战略决策类: [['market_opportunity', '市场机会'], ['resource_match', '资源匹配度'], ['risk_score', '风险指数'], ['overseas_revenue_share', '目标市场收入占比'], ['payback_period', '投入回收期']],
  财务管理类: [['profitability', '盈利质量'], ['liquidity', '现金流安全'], ['solvency', '偿债能力'], ['operating_efficiency', '运营效率']],
} as const

const POLL_MS = 2000

/** 复盘任务阶段 → 进度百分比 + 中文说明 */
const STAGE_META: Record<string, { percent: number; label: string }> = {
  queued: { percent: 10, label: '正在准备你的复盘…' },
  prepare_review: { percent: 30, label: '正在整理你的推演数据…' },
  generate_review: { percent: 70, label: '正在结合三轮选择整理分析…' },
  retrying: { percent: 40, label: '上次生成失败，正在自动重试…' },
  completed: { percent: 100, label: '完成' },
  failed: { percent: 0, label: '生成失败' },
}

export function comparisonParagraphs(content: string) {
  // Insert whitespace only: keep every claim, number and punctuation unchanged.
  return content.replace(/(第\s*[一二三123]\s*轮|累计|建议[：:])/g, '\n\n$1')
    .replace(/([，。；;])\s*(?=(?:学生(?:营收|收入|毛利率|现金)|参考(?:营收|收入|毛利率|现金)|差额))/g, '$1\n')
    .split(/\n\s*\n/).map(text => text.trim()).filter(Boolean)
}

export default function StudentReview({ token, sid, onRestart, onBack, restarting = false }: { token: string; sid: number; onRestart: () => void | Promise<void>; onBack: () => void; restarting?: boolean }) {
  const [data, setData] = useState<ReviewResponse | null>(null)
  const [error, setError] = useState('')
  const [refresh, setRefresh] = useState(0)
  const [connection, setConnection] = useState('')

  useEffect(() => {
    let cancelled = false
    let timer: number | undefined
    let wake: (() => void) | undefined
    const controller = new AbortController()
    const wait = (ms: number) => new Promise<void>((resolve) => {
      wake = resolve
      timer = window.setTimeout(resolve, ms)
    })
    setError('')
    setConnection('')
    setData(null)
    async function load() {
      if (!sid) {
        setError('缺少推演会话')
        return
      }
      let failures = 0
      while (!cancelled) {
        try {
          const result = await review(token, sid, controller.signal)
          if (cancelled) return
          failures = 0
          setConnection('')
          setData(result)
          if (result.status !== 'pending' && result.status !== 'running') return
          await wait(POLL_MS)
        } catch (cause) {
          if (cancelled) return
          const status = (cause as { status?: number })?.status
          if (status && status >= 400 && status < 500 && status !== 408 && status !== 429) {
            setError(cause instanceof Error ? cause.message : '复盘暂不可用')
            return
          }
          failures += 1
          setConnection('网络有些不稳定，正在重新连接。你的推演记录不会丢失。')
          await wait(Math.min(30000, POLL_MS * 2 ** Math.min(failures, 4)))
        }
      }
    }
    void load()
    return () => { cancelled = true; controller.abort(); window.clearTimeout(timer); wake?.() }
  }, [token, sid, refresh])

  if (error) return <Space direction="vertical"><Alert type="warning" message="复盘暂不可用" description={error} /><Button onClick={() => setRefresh((x) => x + 1)}>重新查看</Button></Space>
  if (!data) {
    return <Space direction="vertical" style={{ width: '100%', maxWidth: 480 }}>
      <Spin /><Typography.Text>正在加载复盘，请稍候。</Typography.Text>
      {connection && <Alert type="warning" message={connection} />}
    </Space>
  }
  if (data.status === 'failed') return <Space direction="vertical"><Alert type="warning" message="复盘暂时没有完成，请稍后再试。" /><Button onClick={async () => { try { await retryStudentReview(token, sid); setData(null); setRefresh(x => x + 1) } catch(e) { setError(e instanceof Error ? e.message : '重试失败') } }}>重新整理</Button></Space>
  if (data.status !== 'succeeded') {
    const meta = STAGE_META[data.stage || 'queued'] ?? { percent: 50, label: '正在生成…' }
    return <Space direction="vertical" style={{ width: '100%', maxWidth: 480 }}>
      <Typography.Title level={4} style={{ margin: 0 }}>推演复盘</Typography.Title>
      <Progress percent={meta.percent} status="active" strokeColor="#2f6bff" />
      <Typography.Text type="secondary">{meta.label}</Typography.Text>
      {connection && <Alert type="warning" message={connection} />}
    </Space>
  }
  return (
    <Space direction="vertical" style={{ width: '100%' }}>
      <Typography.Title level={3}>推演复盘</Typography.Title>
      {(data.dimension_scores?.length ?? 0) > 0 && (
        <RadarScoreChart scores={data.dimension_scores ?? []} frameworkType={data.framework_type} />
      )}
      {data.path_comparison && data.case_type && <FrameworkLineChart pathComparison={data.path_comparison} caseType={data.case_type}
        metrics={[...PROFESSIONAL_METRICS[data.case_type], ['net_profit', '净利润'] as const]} />}
      {data.path_comparison && <details><summary>查看财务结果走势</summary><RoundLineChart pathComparison={data.path_comparison} /></details>}
      <Typography.Text type="secondary">{data.framework_type}</Typography.Text>
      <Card title="综合结论">{data.conclusion}</Card>
      {<>
      <details><summary>展开完整分析维度</summary>
      <Card title="分析维度">
        {data.dimensions.map((dimension, index) => (
          <Card size="small" key={`${dimension.name}-${index}`} title={dimension.name}>
            {dimension.name === '参考路径差异与影响' ? comparisonParagraphs(dimension.content).map((paragraph, i) => <Typography.Paragraph key={i} style={{ whiteSpace: 'pre-wrap', lineHeight: 1.8, overflowWrap: 'anywhere', marginBottom: 16 }}>{paragraph}</Typography.Paragraph>) : dimension.content}
          </Card>
        ))}
      </Card>
      </details>
      </>}
      {data.status === 'succeeded' && data.path_comparison && <Card title={`参考方案（标准路径）· ${data.path_comparison.kind === 'historical' ? '案例实际采用路径' : '教师推荐方案'}`}>
        <Typography.Paragraph><strong>我的方案：</strong>{data.path_comparison.rounds.map(row => row.student_strategy).join(' → ')}</Typography.Paragraph>
        <Typography.Paragraph><strong>教师/推荐方案：</strong>{data.path_comparison.rounds.map(row => row.reference_strategy).join(' → ')}</Typography.Paragraph>
        <Typography.Paragraph type="secondary">{data.path_comparison.note}</Typography.Paragraph>
        {data.path_comparison.rounds.map(row => <Card size="small" key={row.round} title={`第 ${row.round} 轮 · ${row.same ? '策略一致' : '策略不同'}`}>
          <p>我的策略：{row.student_strategy}</p><p>参考策略：{row.reference_strategy}</p>
          {data.case_type && <Table size="small" rowKey="key" bordered pagination={false}
            dataSource={PROFESSIONAL_METRICS[data.case_type].map(([key, label]) => ({ key, label, mine: row.student_metrics[key] ?? '未记录', reference: row.reference_metrics[key] ?? '未记录' }))}
            columns={[{ title: '专业指标', dataIndex: 'label' }, { title: '我的方案', dataIndex: 'mine' }, { title: '参考方案', dataIndex: 'reference' }]} />}
          <details><summary>查看本轮财务指标</summary><Table size="small" rowKey="key" bordered pagination={false}
            dataSource={([['revenue', '营收（万元）'], ['operating_cost', '营业成本（万元）'], ['operating_expense', '运营费用（万元）'], ['net_profit', '净利润（万元）'], ['cash_flow_amount', '现金净流量（万元）']] as const).map(([key, label]) => ({
              key, label,
              mine: row.student_metrics[key] ?? '未记录',
              reference: row.reference_metrics[key] ?? '未记录',
              diff: row.difference[key] ?? '未记录',
            }))}
            columns={[
              { title: '财务指标', dataIndex: 'label', key: 'label' },
              { title: '我的方案', dataIndex: 'mine', key: 'mine' },
              { title: '教师/推荐方案', dataIndex: 'reference', key: 'reference' },
              { title: '差额', dataIndex: 'diff', key: 'diff' },
            ]} /></details>
          <p>毛利率：我 {row.student_metrics.gross_margin} / 参考 {row.reference_metrics.gross_margin}；市场份额：我 {row.student_metrics.market_share} / 参考 {row.reference_metrics.market_share}</p>
        </Card>)}
      </Card>}
      <Space direction="vertical" style={{ width: '100%' }}>
        <Button block onClick={onBack}>返回推演</Button>
        <Popconfirm title="重新推演并覆盖原记录？" description="当前作答和复盘将被清除，教师端记录同步替换，并使用当前发布版本重新开始；无法撤销。" okText="确认覆盖" cancelText="保留记录" onConfirm={onRestart}>
          <Button size="large" type="primary" block loading={restarting}>重新推演并覆盖原记录</Button>
        </Popconfirm>
      </Space>
    </Space>
  )
}
