import type { CaseType, StoryConfig } from '../../../api/types'

export interface ProfessionalPack {
  cast: StoryConfig['cast']
  promptTitle: string
  promptHint: string
  knowledge: string[]
  events: { title: string; text: string }[]
  evaluation: string[]
  achievements: string[]
}

export const PROFESSIONAL_PACKS: Record<CaseType, ProfessionalPack> = {
  战略决策类: {
    cast: { manager: 'CEO', finance: '风控总监', marketing: '战略总监' },
    promptTitle: '战略研判说明',
    promptHint: '说明方案依据、主要风险和资源配置思路，可结合 SWOT、风险等级或资源匹配度。',
    knowledge: ['SWOT', '风险等级', '资源匹配度', '市场进入策略', '国际化战略'],
    events: [
      { title: '突发贸易壁垒', text: '目标市场临时提高准入要求，原定进入节奏需要重新评估。' },
      { title: '竞品跨界并购', text: '主要竞争者完成并购，渠道和技术资源明显增强。' },
      { title: '核心技术迭代', text: '关键产品技术出现代际更新，既有产线投入面临贬值风险。' },
      { title: '地方政策调整', text: '目标市场调整外资准入与补贴政策，原定落地节奏需要重排。' },
      { title: '供应链中断', text: '关键零部件供应出现波动，资源配置方案面临压力。' },
    ],
    evaluation: ['市场地位', '风险可控性', '资源利用效率', '长期增长潜力'],
    achievements: ['稳健掌舵人', '破局先锋', '风险平衡大师', '国际化先行者'],
  },
  市场营销类: {
    cast: { manager: '品牌总监', finance: '市场研究主管', marketing: '渠道经理' },
    promptTitle: '营销逻辑阐述',
    promptHint: '说明目标人群、4P 组合搭配理由和预期市场反馈。',
    knowledge: ['4P 营销理论', '市场份额', '客户满意度', '品牌定位', '渠道效率'],
    events: [
      { title: '竞品突然降价', text: '主要竞品临时降价，原有定价优势正在缩小。' },
      { title: '头部达人翻车', text: '合作头部达人出现舆情争议，相关投放素材需要紧急下架。' },
      { title: '渠道政策变动', text: '核心渠道调整进场条件，铺货节奏和预算需要重新平衡。' },
      { title: '爆款断货', text: '新品销量超出预期，主力 SKU 断货，复购节奏被打断。' },
      { title: '负面舆情发酵', text: '一条产品体验投诉开始扩散，品牌团队需要快速回应。' },
    ],
    evaluation: ['市场份额提升', '品牌声量', '客户满意度', '营销投入 ROI'],
    achievements: ['品牌操盘手', '增长黑客', '渠道破局者', '口碑赢家'],
  },
  财务管理类: {
    cast: { manager: 'CFO', finance: '内审主管', marketing: '财务经理' },
    promptTitle: '财务测算依据',
    promptHint: '说明对利润和现金流的影响，以及准备控制的风险指标范围。',
    knowledge: ['盈利质量', '现金流管理', '资本结构', '偿债能力', '财务比率分析'],
    events: [
      { title: '汇率大幅波动', text: '主要结算货币汇率单周波动扩大，外币债务成本随之变化。' },
      { title: '银行银根收紧', text: '银行调低授信额度，后续资金安排需要留出更大余量。' },
      { title: '税务政策调整', text: '适用税率与抵扣口径调整，年度税负测算需要重做。' },
      { title: '应收账款坏账', text: '一笔大额应收款出现延期迹象，现金回收节奏受到影响。' },
      { title: '原材料涨价', text: '核心原材料报价上调，毛利和采购计划需要同步复核。' },
    ],
    evaluation: ['盈利质量', '现金流安全', '偿债能力', '运营效率'],
    achievements: ['现金流管家', '资本运作高手', '风控合规官', '利润优化师'],
  },
}

export function packFor(caseType?: CaseType | null): ProfessionalPack {
  return PROFESSIONAL_PACKS[caseType ?? '财务管理类']
}

/** 同一会话同一轮结果固定，避免刷新后事件变化；约三分之一轮次触发。 */
export function pickProfessionalEvent(sessionId: number | string, round: number, caseType?: CaseType | null) {
  const pack = packFor(caseType)
  const seed = `${sessionId}:${round}:${caseType ?? ''}`
  let hash = 0
  for (let i = 0; i < seed.length; i += 1) hash = ((hash * 31) + seed.charCodeAt(i)) >>> 0
  return hash % 3 === 0 ? pack.events[hash % pack.events.length] : null
}
