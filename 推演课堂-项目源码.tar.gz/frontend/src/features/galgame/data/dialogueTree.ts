import type { CaseType, StoryConfig, StudentNode } from '../../../api/types'
import { moodOf } from '../engine/dialogueEngine'
import type { RiskBranch } from '../engine/dialogueEngine'
import { packFor } from './professionalPacks'

export interface DialogueLine { speaker: string; text: string }

function clean(lines: DialogueLine[] | undefined): DialogueLine[] {
  return (lines ?? []).filter((line) => line && line.speaker?.trim() && line.text?.trim()).slice(0, 6)
}

/** 旧案例保留原台词，只把通用角色名换成本课程角色，避免历史内容失效。 */
function professionalize(lines: DialogueLine[], story: StoryConfig | null | undefined, caseType?: CaseType | null): DialogueLine[] {
  const pack = packFor(caseType)
  const rolePairs: [string, string][] = [
    [story?.cast?.manager ?? '', pack.cast.manager],
    [story?.cast?.finance ?? '', pack.cast.finance],
    [story?.cast?.marketing ?? '', pack.cast.marketing],
    ['负责人', pack.cast.manager], ['店长', pack.cast.manager],
    ['财务', pack.cast.finance], ['财务负责人', pack.cast.finance],
    ['市场', pack.cast.marketing], ['市场负责人', pack.cast.marketing],
  ]
  const roleMap = new Map<string, string>(rolePairs.filter(([from]) => Boolean(from)))
  return lines.map((line) => ({ ...line, speaker: roleMap.get(line.speaker) ?? line.speaker }))
}

function roundOf(story: StoryConfig | null | undefined, act: number) {
  return story?.rounds?.find((round) => round.idx === act)
}

export function coverLines(story?: StoryConfig | null, title = '本次案例', caseType?: CaseType | null): DialogueLine[] {
  const pack = packFor(caseType)
  const authored = professionalize(clean(story?.opening), story, caseType)
  if (authored.length) return authored
  return [
    { speaker: pack.cast.manager, text: `欢迎进入《${title}》。接下来的关键判断由你来作出。` },
    { speaker: pack.cast.finance, text: `本次讨论会重点关注${pack.knowledge.slice(0, 2).join('与')}。` },
    { speaker: pack.cast.marketing, text: '先看清局面，再提出你的方案。' },
  ]
}

export function actOpening(act: number, prevRisk: string | null, story?: StoryConfig | null, node?: StudentNode, caseType?: CaseType | null): DialogueLine[] {
  const pack = packFor(caseType)
  const authored = professionalize(clean(roundOf(story, act)?.opening), story, caseType)
  if (authored.length) return authored
  const transition = prevRisk === 'conservative'
    ? '上轮先稳住了基本盘，这轮要判断下一步空间。'
    : prevRisk === 'aggressive'
      ? '上轮主动抢了窗口，这轮要接住增长压力。'
      : prevRisk === 'balanced'
        ? '上轮兼顾了多项目标，这轮要继续明确重点。'
        : `第 ${act} 轮经营讨论开始。`
  return [
    { speaker: pack.cast.manager, text: node?.title ? `现在要处理的是：${node.title}。` : transition },
    { speaker: pack.cast.marketing, text: `先结合当前信息，从${pack.knowledge[(act - 1) % pack.knowledge.length]}的角度提出方案。` },
  ]
}

export function reactionScene(
  act: number,
  risk: RiskBranch,
  affection: number,
  story?: StoryConfig | null,
  optionKey?: string,
  selectedLabel?: string,
  caseType?: CaseType | null,
): DialogueLine[] {
  const pack = packFor(caseType)
  const authored = optionKey ? professionalize(clean(roundOf(story, act)?.reactions?.[optionKey]), story, caseType) : []
  if (authored.length) return authored
  const mood = moodOf(affection)
  const lead = selectedLabel ? `“${selectedLabel}”这个方案` : '这个方案'
  if (risk === 'conservative') return [
    { speaker: pack.cast.finance, text: mood === 'cold' ? `${lead}能控制风险，但还需要更明确的推进安排。` : `${lead}守住了安全边界，也给执行留出了余地。` },
    { speaker: pack.cast.manager, text: '思路清楚了，再说说你最看重的依据。' },
  ]
  if (risk === 'aggressive') return [
    { speaker: mood === 'cold' ? pack.cast.finance : pack.cast.marketing, text: `${lead}推进速度快，也要提前准备风险缓冲。` },
    { speaker: pack.cast.manager, text: '方向已经提出，再把判断依据讲清楚。' },
  ]
  return [
    { speaker: pack.cast.finance, text: `${lead}兼顾了多项目标，关键在于执行顺序。` },
    { speaker: pack.cast.manager, text: '请补充你这样取舍的理由。' },
  ]
}

export function askReason(act: number, _risk: RiskBranch, _story?: StoryConfig | null, selectedLabel?: string, caseType?: CaseType | null): DialogueLine {
  const pack = packFor(caseType)
  const speaker = pack.cast.finance
  const shortLabel = selectedLabel?.trim().replace(/[，。；].*$/, '').slice(0, 24)
  const prompts = [pack.promptHint, `你会怎样用${pack.knowledge[act % pack.knowledge.length]}说明这次取舍？`, `你准备观察哪些${pack.knowledge[0]}相关指标？`]
  return {
    speaker,
    text: shortLabel ? `关于“${shortLabel}”，${prompts[(act - 1) % prompts.length]}` : prompts[(act - 1) % prompts.length],
  }
}

export function buildInputText(label: string, reason: string): string {
  return reason.trim() ? `【${label}】${reason.trim()}` : `【${label}】（未说明理由）`
}

export function resumeScene(_story?: StoryConfig | null, title = '案例', caseType?: CaseType | null): DialogueLine[] {
  const speaker = packFor(caseType).cast.manager
  return [
    { speaker, text: `欢迎回来，《${title}》的进度已经为你保存。` },
    { speaker, text: '我们接着上一轮的判断继续。' },
  ]
}
