/**
 * 剧情成就称号表（可选挂件）。
 * 6 个成就 id 固定：first_decision / conservative / adventurer / treasurer / social / tycoon。
 * 剧情结局实际发放的称号按课程资源包 `pack.achievements` 的分数档取，本表只提供 id 与名称。
 */
export interface Achievement {
  id: string
  label: string
}

export const ACHIEVEMENTS: Achievement[] = [
  { id: 'first_decision', label: '首次决策' },
  { id: 'conservative', label: '稳字当头' },
  { id: 'adventurer', label: '冒险家' },
  { id: 'treasurer', label: '现金管家' },
  { id: 'social', label: '人脉王' },
  { id: 'tycoon', label: '商业大亨' },
]
