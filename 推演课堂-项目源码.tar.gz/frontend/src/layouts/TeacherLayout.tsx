import { AppstoreOutlined, DeleteOutlined, LogoutOutlined, ProfileOutlined, TeamOutlined, UserOutlined } from '@ant-design/icons'
import { Alert, Button, Layout, Menu, Modal } from 'antd'
import type { MenuProps } from 'antd'
import { Outlet, useBlocker, useLocation, useNavigate, useParams } from 'react-router-dom'
import { getTeacherMe, logoutTeacher } from '../api/client'
import { useIsNarrow } from '../hooks/useIsNarrow'
import './TeacherLayout.css'
import { useEffect, useRef, useState } from 'react'
import { TeacherDraftContext } from '../context/TeacherDraftContext'
import { teacherSectionPath } from '../routing/teacherPaths'
import type { TeacherSection } from '../routing/teacherPaths'
import type { TeacherRole } from '../api/client'

const { Sider, Content } = Layout

/** 侧边栏分组菜单：教学运营 / 学生 / 系统（窄屏收成图标条时分组标题由 antd 自动隐藏） */
const MENU_ITEMS: MenuProps['items'] = [
  {
    type: 'group',
    label: '教学运营',
    children: [
      { key: 'workbench', icon: <AppstoreOutlined />, label: '工作台' },
      { key: 'records', icon: <ProfileOutlined />, label: '案例记录' },
    ],
  },
  {
    type: 'group',
    label: '学生',
    children: [
      { key: 'students', icon: <TeamOutlined />, label: '学生管理' },
    ],
  },
  {
    type: 'group',
    label: '系统',
    children: [
      { key: 'trash', icon: <DeleteOutlined />, label: '案例回收站' },
      { key: 'accounts', icon: <UserOutlined />, label: '教师账号' },
    ],
  },
]

/** 顶栏面包屑文案（与菜单同名，保证两处不会各改各的） */
const SECTION_LABELS: Record<TeacherSection, string> = {
  workbench: '工作台',
  records: '案例记录',
  students: '学生管理',
  trash: '案例回收站',
  accounts: '教师账号',
}

/** 2026-10-27 权限隔离：普通教师不显示「教师账号」入口（后端同样仅管理员可操作） */
function visibleMenuItems(items: MenuProps['items'], role: TeacherRole | null): MenuProps['items'] {
  if (role !== 'teacher') return items
  return (items ?? [])
    .map((item) => {
      if (item && 'children' in item && Array.isArray(item.children)) {
        const children = item.children.filter((child) => (child as { key?: string }).key !== 'accounts')
        return children.length ? { ...item, children } : null
      }
      return item
    })
    .filter((item): item is NonNullable<typeof item> => item !== null)
}

/**
 * 老师端布局（桌面优先，B端工作台风格）：左侧分组 Menu + 顶栏（面包屑/用户区）+ 右侧内容区。
 * 窄于 768px 时顶部出提示条，侧边栏收成图标条，保证记录页在手机上仍可操作。
 */
export default function TeacherLayout() {
  const [hasDraft, setHasDraft] = useState(false)
  const loggingOut = useRef(false)
  const blocker = useBlocker(({ currentLocation, nextLocation }) => hasDraft && !loggingOut.current && currentLocation.pathname !== nextLocation.pathname)
  useEffect(() => {
    if (blocker.state !== 'blocked') return
    const confirmation = Modal.confirm({ title: '离开未保存的编辑？', content: '未保存的草稿将丢失。已受理的后台任务仍会继续。', okText: '放弃编辑并离开', cancelText: '继续编辑', onOk: () => blocker.proceed(), onCancel: () => blocker.reset() })
    return () => confirmation.destroy()
  }, [blocker])
  const mayLeave = () => !hasDraft || window.confirm('还有未保存的编辑或正在执行的操作。离开会丢弃本页未保存内容，是否离开？')
  const isNarrow = useIsNarrow(768)
  const { teacherToken = '' } = useParams<{ teacherToken: string }>()
  const navigate = useNavigate()
  const { pathname } = useLocation()
  const [teacherName, setTeacherName] = useState<string | null>(null)
  const [role, setRole] = useState<TeacherRole | null>(null)

  // 多账号：拉取当前教师姓名与角色展示在顶栏；全局口令令牌没有账号信息（role=admin）
  useEffect(() => {
    let cancelled = false
    const token = sessionStorage.getItem('teacher_token') || teacherToken
    if (!token) return
    getTeacherMe(token).then(({ teacher, role: nextRole }) => {
      if (!cancelled) { setTeacherName(teacher?.real_name ?? null); setRole(nextRole ?? (teacher ? 'teacher' : 'admin')) }
    })
      .catch(() => { if (!cancelled) setTeacherName(null) })
    return () => { cancelled = true }
  }, [teacherToken])

  const activeKey = pathname.replace(/\/+$/, '').endsWith('/students') ? 'students'
    : pathname.replace(/\/+$/, '').endsWith('/records') ? 'records'
    : pathname.replace(/\/+$/, '').endsWith('/trash') ? 'trash'
    : pathname.replace(/\/+$/, '').endsWith('/accounts') ? 'accounts' : 'workbench'

  const onMenuClick: MenuProps['onClick'] = ({ key }) => {
    navigate(teacherSectionPath(teacherToken || undefined, key as TeacherSection))
  }

  /** 退出：先请服务端吊销令牌，再清本地副本；网络失败也要完成本地登出。 */
  async function handleLogout() {
    if (!mayLeave()) return
    loggingOut.current = true
    const token = sessionStorage.getItem('teacher_token') || teacherToken
    try {
      if (token) await logoutTeacher(token)
    } catch { /* 服务端不可达时仍允许本地登出 */ }
    finally {
      sessionStorage.removeItem('teacher_token')
      sessionStorage.removeItem('teacher_selected_case')
      navigate('/teacher/login', { replace: true })
    }
  }

  return (
    <Layout className="teacher-shell" hasSider>
      <Sider
        className="teacher-sider"
        theme="light"
        width={208}
        collapsedWidth={64}
        collapsed={isNarrow}
        trigger={null}
      >
        <div className="teacher-brand">{isNarrow ? '教师' : '案例推演 · 教师端'}</div>
        <Menu
          mode="inline"
          selectedKeys={[activeKey]}
          items={visibleMenuItems(MENU_ITEMS, role)}
          onClick={onMenuClick}
        />
        <Button
          className="teacher-logout"
          type="text"
          icon={<LogoutOutlined />}
          block
          onClick={() => void handleLogout()}
        >
          {isNarrow ? null : '退出登录'}
        </Button>
      </Sider>

      <Layout className="teacher-main">
        <div className="teacher-topbar">
          <div className="teacher-topbar-crumb">
            <span className="teacher-topbar-crumb-root">首页</span>
            <span className="teacher-topbar-crumb-sep">/</span>
            <span className="teacher-topbar-crumb-current">{SECTION_LABELS[activeKey as TeacherSection]}</span>
          </div>
          <div className="teacher-topbar-user">
            <span className="teacher-topbar-avatar">{(teacherName ?? (role === 'admin' ? '管' : '师')).slice(0, 1)}</span>
            {!isNarrow && <span className="teacher-topbar-name">{teacherName ?? (role === 'admin' ? '系统管理员' : '教师')}</span>}
          </div>
        </div>
        {isNarrow && (
          <Alert
            className="teacher-narrow-alert"
            type="warning"
            showIcon
            banner
            message="建议在电脑上操作"
            description="当前为手机宽度：侧边栏已收成图标条，案例记录页可左右滑动查看完整表格。"
          />
        )}
        <Content className="teacher-content-scroll">
          <div className="teacher-content">
            <TeacherDraftContext.Provider value={setHasDraft}><Outlet context={{ role }} /></TeacherDraftContext.Provider>
          </div>
        </Content>
      </Layout>
    </Layout>
  )
}
