export type ScanTarget =
  | { kind: 'case'; token: string }
  | { kind: 'class'; code: string }

const CLASS_PREFIX = 'class-'

function toPath(input: string): string | null {
  const trimmed = input.trim()
  if (!trimmed) return null
  try {
    return new URL(trimmed).pathname
  } catch {
    return trimmed
  }
}

/**
 * 统一解析学生端扫码结果：
 * - 案例码：/student/{token} 或裸令牌 → 进入案例推演
 * - 班级码：/student/join/{code} 或 class- 开头的裸码 → 加入班级
 * 两者都兼容「完整链接 / 纯路径 / 裸码」三种写法。无法识别返回 null。
 */
export function resolveScanTarget(raw: string): ScanTarget | null {
  const input = (raw || '').trim()
  if (!input) return null

  if (input.startsWith(CLASS_PREFIX)) return { kind: 'class', code: input }

  const path = toPath(input)
  if (!path) return null

  const join = path.match(/^\/student\/join\/([A-Za-z0-9_-]+)\/?$/)
  if (join) return { kind: 'class', code: join[1] }

  const student = path.match(/^\/student\/([A-Za-z0-9_-]+)\/?$/)
  if (student) return { kind: 'case', token: student[1] }

  if (/^[A-Za-z0-9_-]+$/.test(path)) return { kind: 'case', token: path }

  return null
}
