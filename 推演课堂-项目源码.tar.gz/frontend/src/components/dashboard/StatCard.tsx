import type { CSSProperties } from 'react'
import './dashboard.css'

export interface StatCardProps {
  label: string
  value: string | number
  /** 彩色竖条/圆点强调色 */
  accent?: 'blue' | 'green' | 'orange' | 'purple' | 'cyan' | 'red'
  /** 副指标行：• 标签 值 */
  sub?: Array<{ label: string, value: string | number }>
}

const ACCENT_VARS: Record<NonNullable<StatCardProps['accent']>, string> = {
  blue: 'var(--color-primary-teacher)',
  green: 'var(--t-success)',
  orange: 'var(--t-warning)',
  purple: 'var(--t-purple)',
  cyan: 'var(--t-cyan)',
  red: 'var(--t-danger)',
}

/** KPI 统计卡：左侧彩色竖条 + 大数字 + 副指标行（B端工作台参考样式） */
export default function StatCard({ label, value, accent = 'blue', sub = [] }: StatCardProps) {
  return (
    <div className="stat-card" style={{ '--stat-accent': ACCENT_VARS[accent] } as CSSProperties}>
      <div className="stat-card-value">{value}</div>
      <div className="stat-card-label">{label}</div>
      {sub.length > 0 && (
        <div className="stat-card-sub">
          {sub.map((item) => (
            <span key={item.label} className="stat-card-sub-item">
              <i className="stat-card-dot" />
              {item.label} <b>{item.value}</b>
            </span>
          ))}
        </div>
      )}
    </div>
  )
}
