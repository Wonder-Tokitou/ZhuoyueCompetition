import type { ReactNode } from 'react'
import './dashboard.css'

export interface QuickEntryItem {
  key: string
  icon: ReactNode
  label: string
  tone?: 'blue' | 'green' | 'orange' | 'purple' | 'cyan'
  onClick?: () => void
}

/** 快捷入口宫格：彩色圆角图标块 + 文字（B端工作台参考样式） */
export default function QuickEntry({ items }: { items: QuickEntryItem[] }) {
  return (
    <div className="quick-entry">
      {items.map((item) => (
        <button key={item.key} type="button" className="quick-entry-item" onClick={item.onClick}>
          <span className={`quick-entry-icon tone-${item.tone ?? 'blue'}`}>{item.icon}</span>
          <span className="quick-entry-label">{item.label}</span>
        </button>
      ))}
    </div>
  )
}
