import { Button, Card, Typography } from 'antd'
import { useNavigate } from 'react-router-dom'

/**
 * 师生登录入口；扫码链接仅标识案例，不代替账号身份。
 * 落在 / 或未知路径时不白屏，给出明确指引。
 * 2026-10-27（组长图1）：左右 hero 布局——左侧渐变大标题与访问指引，右侧三大入口卡片。
 */
export default function EntryHintPage() {
  const navigate = useNavigate()
  return (
    <div className="entry-hint">
      <div className="entry-hero">
        <section className="entry-hero-left">
          <h1 className="entry-hero-title">推演课堂</h1>
          <Typography.Paragraph type="secondary" className="entry-hero-sub" style={{ marginBottom: 24 }}>
            学生登录后选择教师发布的案例进行决策推演，也可以扫描案例二维码直达；作答保存后，教师端实时可查。
          </Typography.Paragraph>
          <Card size="small" title="访问指引" style={{ maxWidth: 460 }}>
            <div className="entry-guide-row">
              <Typography.Text code>/teacher/login</Typography.Text>
              <Button type="link" size="small" style={{ padding: 0 }} onClick={() => navigate('/teacher/login')}>前往教师登录</Button>
            </div>
            <div className="entry-guide-row">
              <Typography.Text code>/student</Typography.Text>
              <Button type="link" size="small" style={{ padding: 0 }} onClick={() => navigate('/student')}>前往学生端</Button>
            </div>
            <div className="entry-guide-row">
              <Typography.Text code>/student/{'{studentToken}'}</Typography.Text>
              <Typography.Text type="secondary">扫码直达案例（教师发布后生成）</Typography.Text>
            </div>
          </Card>
        </section>
        <section className="entry-hero-right">
          <Card hoverable className="entry-card" onClick={() => navigate('/teacher/login')}>
            <h3>教师端</h3>
            <p>创建与发布案例、查看作答记录、批阅复盘与班级数据</p>
            <Button type="primary" size="large" block>教师登录</Button>
          </Card>
          <Card hoverable className="entry-card" onClick={() => navigate('/student')}>
            <h3>学生端</h3>
            <p>登录或首次注册后选择案例开始推演，随时回看自己的复盘</p>
            <Button size="large" block>进入个人空间</Button>
          </Card>
          <Card hoverable className="entry-card" onClick={() => navigate('/student/scan')}>
            <h3>扫码进入案例</h3>
            <p>扫描教师发布的案例二维码，无需查找直达推演</p>
            <Button size="large" block>打开扫码</Button>
          </Card>
        </section>
      </div>
    </div>
  )
}
