import { useEffect, useState } from 'react'
import { Alert, Button, Card, Collapse, Form, Input, Popconfirm, Radio, Space, Spin, Tag, Typography } from 'antd'
import { useNavigate } from 'react-router-dom'
import { api, deleteStudentSubmission, resetStudentSubmission } from '../../api/client'
import type { StudentSubmission } from '../../api/types'
import { clearStudentLogin, useStudentAccount } from '../../context/StudentAccountContext'
import { caseTypeLabel } from '../../domain/caseConstants'

interface PublishedCase { id: number; title: string; case_type: string; student_token: string; version: number; background: string; play_locked?: boolean; teacher_name?: string; play_count?: number }
type Submission = StudentSubmission

const LIBRARY_TYPE_OPTIONS = [
  { label: '全部模式', value: 'all' },
  { label: '战略决策模式', value: '战略决策类' },
  { label: '市场营销模式', value: '市场营销类' },
  { label: '财务管理模式', value: '财务管理类' },
]

/** 学生端「校案例库」：汇集各教师上传到校案例库的已发布案例。
 *  每个案例展示上传教师名称、案例类型与累计推演次数，学生可按类型筛选后选择进入推演。 */
export function StudentCasesPage() {
  const [rows, setRows] = useState<PublishedCase[] | null>(null), [error, setError] = useState('')
  const [refresh, setRefresh] = useState(0), [loading, setLoading] = useState(false)
  const [caseType, setCaseType] = useState('all')
  const nav = useNavigate()
  useEffect(() => {
    let active = true, timer: number | undefined
    const controller = new AbortController()
    async function load() {
      let retry = true
      setLoading(true)
      try {
        const { data } = await api.get<PublishedCase[]>('/student/cases', {
          params: { case_type: caseType === 'all' ? undefined : caseType }, signal: controller.signal,
        })
        if (active) { setRows(data); setError('') }
      } catch (e) {
        const failure = e as { message?: string; status?: number; response?: { status?: number } }
        retry = ![401, 403].includes(failure.status || failure.response?.status || 0)
        if (active) setError(failure.message || '案例列表暂时无法加载，请重试')
      } finally {
        if (active) {
          setLoading(false)
          if (retry) timer = window.setTimeout(load, 10000)
        }
      }
    }
    void load()
    return () => { active = false; controller.abort(); window.clearTimeout(timer) }
  }, [refresh, caseType])
  return <Space className="student-cases-page" direction="vertical" style={{ width: '100%' }}>
    <div className="student-section-heading"><div><Typography.Title level={3}>选择一个案例</Typography.Title><Typography.Text type="secondary">从真实经营情境出发，完成三轮关键决策。</Typography.Text></div><Button loading={loading} onClick={() => setRefresh(v => v + 1)}>刷新</Button></div>
    <Radio.Group className="case-filter-grid" value={caseType} onChange={(e) => setCaseType(e.target.value)} optionType="button" buttonStyle="solid">
      {LIBRARY_TYPE_OPTIONS.map((o) => <Radio.Button key={o.value} value={o.value}>{o.label}</Radio.Button>)}
    </Radio.Group>
    {error && <Alert type="error" message={error} />}
    {!rows && !error && <Spin />}
    {rows?.length === 0 && !error && <Alert message="校案例库暂无案例" description="教师发布到校案例库的推演案例会出现在这里；发布到个人案例库的案例仅经教师分发的链接进入。" />}
    {rows?.map((r) => <Card className="student-case-card" key={r.id} title={r.play_locked ? <span>{r.title}<Tag color="red" style={{ marginLeft: 8 }}>已暂停</Tag></span> : r.title}><div className="student-case-meta">
      <Tag color="blue">{caseTypeLabel(r.case_type)}</Tag>
      <span>{r.teacher_name || '平台管理员'}</span>
      <span>累计推演：{r.play_count ?? 0} 次</span>
    </div><p className="student-case-summary">{r.background}</p><Button type="primary" onClick={() => nav('/student/' + encodeURIComponent(r.student_token))}>{r.play_locked ? '查看已有记录' : '进入推演'}</Button></Card>)}
  </Space>
}

export function StudentRecordsPage() {
  const [rows, setRows] = useState<Submission[] | null>(null), [error, setError] = useState('')
  const nav = useNavigate()
  const load = () => api.get<Submission[]>('/student/records').then(({ data }) => setRows(data)).catch((e) => setError(e.message))
  useEffect(() => { let active = true; api.get('/student/records').then(({ data }) => { if (active) setRows(data) }).catch((e) => { if (active) setError(e.message) }); return () => { active = false } }, [])
  return <Space direction="vertical" style={{ width: '100%' }}>
    <Typography.Title level={3}>我的提交记录</Typography.Title>
    {error && <Alert type="error" message={error} />}{!rows && !error && <Spin />}
    {rows?.length === 0 && <Alert message="还没有推演记录，去案例推演开始学习吧" />}
    {rows?.map((r) => <Card key={r.session_id} title={<Space size={8}>{r.case_title}{r.case_status && r.case_status !== 'normal' && <Tag color={r.case_status === 'deleted' ? 'red' : 'orange'}>{r.case_status === 'deleted' ? '案例已删除' : '案例已下架'}</Tag>}</Space>} extra={<span>第 {r.attempt_no} 次</span>}>
      <p>{r.created_at.replace('T', ' ')} · 已完成 {r.turn_count}/3 轮</p>
      <Collapse items={[{ key: 'answers', label: '查看作答与已保存复盘', children: <>{(r.turns || []).map((t, i) => <div key={t.node_id}><b>第 {i + 1} 回合</b><p>已选策略 {t.display_option || ''}：{t.chosen_label || '历史记录未提供策略文字'}</p><p>理由：{t.input_text || '未填写'}</p><p>{t.result.summary}</p></div>)}{r.review && <>{r.review.dimensions.map((d) => <p key={d.name}><b>{d.name}：</b>{d.content}</p>)}<p>{r.review.conclusion}</p></>}</> }]} />
      <Space style={{ marginTop: 12 }} wrap><Button disabled={!r.available} onClick={() => {
        sessionStorage.setItem('student_session:' + r.student_token, String(r.session_id))
        nav('/student/' + r.student_token)
      }}>{r.finished_at ? '查看 / 修改推演' : '继续推演'}</Button>
      <Popconfirm title="覆盖这条推演记录？" description="重新选择后将替换教师端当前记录，旧作答和复盘将被清除。" okText="覆盖原记录" cancelText="取消" onConfirm={async () => {
        try { const state = await resetStudentSubmission(r.student_token, r.session_id); sessionStorage.setItem('student_session:' + r.student_token, String(state.session_id)); nav('/student/' + r.student_token) }
        catch (e) { setError(e instanceof Error ? e.message : '覆盖失败') }
      }}><Button disabled={!r.available}>重新推演并覆盖</Button></Popconfirm>
      <Popconfirm title="删除这条推演记录？" description="删除后教师端将不再看到该记录，无法恢复。" okText="删除记录" cancelText="取消" okButtonProps={{ danger: true }} onConfirm={async () => {
        try { await deleteStudentSubmission(r.student_token, r.session_id); await load() }
        catch (e) { setError(e instanceof Error ? e.message : '删除失败') }
      }}><Button danger>删除记录</Button></Popconfirm></Space>
      {!r.available && <p>案例已下架；上述历史作答仍可查看。</p>}
    </Card>)}
  </Space>
}

interface MyClassItem { id: number; name: string; joined_at: string; teacher_name: string | null }

export function StudentProfilePage() {
  const account = useStudentAccount(), nav = useNavigate()
  const [busy, setBusy] = useState(false), [error, setError] = useState('')
  // 2026-10-27 组长图3：已加入的班级（含指导教师姓名）
  const [classes, setClasses] = useState<MyClassItem[] | null>(null)
  useEffect(() => {
    let active = true
    api.get<MyClassItem[]>('/student/my-classes').then(({ data }) => { if (active) setClasses(data) }).catch(() => { if (active) setClasses([]) })
    return () => { active = false }
  }, [])
  return <Card title="个人与账号信息"><p>姓名：{account.real_name}</p><p>账号：{account.username}</p><p>注册时间：{account.created_at.replace('T', ' ')}</p>
    <div className="student-profile-classes">
      <b>已加入的班级：</b>
      {classes === null ? '加载中…' : classes.length === 0 ? <span style={{ color: 'rgba(0,0,0,0.45)' }}>未加入任何班级，等待教师分享加入二维码</span>
        : classes.map((c) => <Tag key={c.id}>{c.name}（指导老师：{c.teacher_name ?? '未指定'}）</Tag>)}
    </div>
    {error && <Alert type="error" message={error} />}
    <Form layout="vertical" onFinish={async (values) => { setBusy(true); setError(''); try { await api.post('/student/password', values); clearStudentLogin(); nav('/student/login') } catch (e) { setError(e instanceof Error ? e.message : '修改失败') } finally { setBusy(false) } }}>
      <Form.Item name="current_password" label="当前密码" rules={[{ required: true }]}><Input.Password autoComplete="current-password" /></Form.Item>
      <Form.Item name="new_password" label="新密码" rules={[{ required: true, min: 8, max: 128 }]}><Input.Password autoComplete="new-password" /></Form.Item>
      <Button htmlType="submit" loading={busy}>修改密码并重新登录</Button>
    </Form>
    <Button block onClick={() => { clearStudentLogin(); nav('/student/login', { replace: true }) }}>退出登录</Button>
  </Card>
}
