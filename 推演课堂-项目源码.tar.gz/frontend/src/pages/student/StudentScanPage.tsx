import { useState } from 'react'
import { Alert, Button, Card, Input, Space, Typography } from 'antd'
import { useNavigate } from 'react-router-dom'
import StudentScanner from '../../components/StudentScanner'
import { resolveScanTarget } from '../../studentScanResolver'

/**
 * 学生端扫码入口（小程序形态的一级页面）：
 * 识别老师二维码后，按内容分流到案例推演页或班级加入页。
 * 相机不可用（HTTP/无 HTTPS、无 BarcodeDetector）时，保留图片识别与粘贴链接兜底。
 */
export default function StudentScanPage() {
  const navigate = useNavigate()
  const [error, setError] = useState('')
  const [manual, setManual] = useState('')

  function route(raw: string) {
    const target = resolveScanTarget(raw)
    if (!target) {
      setError('无法识别该二维码。请确认是本站案例或班级二维码，或粘贴教师发来的链接 / 进入码。')
      return
    }
    if (target.kind === 'case') navigate(`/student/${encodeURIComponent(target.token)}`)
    else navigate(`/student/join/${encodeURIComponent(target.code)}`)
  }

  return (
    <Space direction="vertical" size={16} style={{ width: '100%' }}>
      <Card>
        <Typography.Title level={4} style={{ marginTop: 0 }}>扫码进入</Typography.Title>
        <Typography.Paragraph type="secondary" style={{ marginBottom: 12 }}>
          对准老师出示的二维码：<b>案例二维码</b>直接进入推演，<b>班级二维码</b>直接加入班级。
        </Typography.Paragraph>
        <StudentScanner onScan={route} />
        {error && <Alert type="warning" showIcon message={error} style={{ marginTop: 12 }} />}
      </Card>

      <Card title="或粘贴链接 / 进入码">
        <Space direction="vertical" style={{ width: '100%' }}>
          <Input.TextArea
            rows={2}
            value={manual}
            onChange={(e) => setManual(e.target.value)}
            placeholder="粘贴教师发来的案例链接、进入码，或班级邀请码（class- 开头）"
            aria-label="粘贴链接或进入码"
          />
          <Button type="primary" block disabled={!manual.trim()} onClick={() => route(manual)}>
            进入
          </Button>
        </Space>
      </Card>
    </Space>
  )
}
