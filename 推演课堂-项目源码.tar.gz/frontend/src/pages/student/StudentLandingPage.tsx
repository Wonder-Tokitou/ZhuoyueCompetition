import { useEffect, useState } from 'react'
import { Alert, Button, Card, Input, Space, Typography } from 'antd'
import { QrcodeOutlined } from '@ant-design/icons'
import { useNavigate } from 'react-router-dom'
import StudentScanner from '../../components/StudentScanner'
import { useStudentAccount } from '../../context/StudentAccountContext'
import { resolveScanTarget } from '../../studentScanResolver'
import { StudentCasesPage } from './StudentSpacePages'

/** 长期可访问的学生端入口；扫码/链接仍会落到同一套学生端布局，由统一解析器分流到案例或班级。 */
export default function StudentLandingPage() {
  const navigate = useNavigate()
  const account = useStudentAccount()
  const [value, setValue] = useState('')
  const [error, setError] = useState('')

  useEffect(() => {
    const queryToken = new URLSearchParams(window.location.search).get('case')
    if (queryToken?.trim()) navigate(`/student/${encodeURIComponent(queryToken.trim())}`, { replace: true })
  }, [navigate])

  function route(raw: string) {
    const target = resolveScanTarget(raw)
    if (!target) {
      setError('无法识别该链接或二维码，请确认是本站案例或班级二维码，或粘贴教师发来的进入码。')
      return
    }
    setError('')
    if (target.kind === 'case') navigate(`/student/${encodeURIComponent(target.token)}`)
    else navigate(`/student/join/${encodeURIComponent(target.code)}`)
  }

  return (
    <Space direction="vertical" size={16} style={{ width: '100%' }}>
      <Card title={`${account.real_name}的学习空间`}>
        <Space wrap>
          <Button type="primary" onClick={() => navigate('/student/cases')}>案例推演</Button>
          <Button onClick={() => navigate('/student/records')}>我的提交记录</Button>
          <Button onClick={() => navigate('/student/profile')}>个人与账号信息</Button>
        </Space>
      </Card>
      <Card>
        <Space direction="vertical" size={12} style={{ width: '100%' }}>
          <Button type="primary" size="large" block icon={<QrcodeOutlined />} onClick={() => navigate('/student/scan')}>
            扫码进入案例 / 加入班级
          </Button>
          <Typography.Paragraph type="secondary" style={{ margin: 0 }}>
            也可以直接打开老师发布的案例二维码，或扫描班级二维码加入课程。
          </Typography.Paragraph>
        </Space>
      </Card>
      <StudentCasesPage />
      <Card>
        <details>
        <summary style={{ cursor: 'pointer' }}>其他进入方式：教师链接、进入码或二维码</summary>
        <Typography.Paragraph type="secondary">
          学校案例可直接在上方案例库选择。收到教师发来的专属链接或二维码，也可以从这里打开。
        </Typography.Paragraph>
        <Input
          size="large"
          value={value}
          onChange={(event) => setValue(event.target.value)}
          onPressEnter={() => route(value)}
          placeholder="粘贴教师发来的链接、案例进入码或班级邀请码"
          aria-label="链接或进入码"
        />
        <Button type="primary" size="large" block style={{ marginTop: 12 }} onClick={() => route(value)}>
          进入
        </Button>
        {error && <Alert type="warning" showIcon message={error} style={{ marginTop: 12 }} />}
        <div style={{ marginTop: 16 }}><StudentScanner onScan={route} /></div>
        </details>
      </Card>
      <Typography.Text type="secondary" className="student-hint">
        作答关联当前实名账号，仅你本人和教师可以查看。扫码链接只用于选择案例或加入班级，不代替账号登录。
      </Typography.Text>
    </Space>
  )
}
