/**
 * 班级仪表盘图表：选择分布分组柱状图（3 个决策点 × A/B/C = 9 柱，组长图17）。
 * ECharts 按需引入：只注册用到的图表、组件与 Canvas 渲染器，禁止 `import * as echarts` 全量引入。
 * 数据来源：GET /teacher/dashboard/option-distribution 的 nodes[]（第一次正式推演口径）；
 * 无数据时显示空态提示，不展示占位假数据。
 */
import { useEffect, useRef } from 'react'
import * as echarts from 'echarts/core'
import { BarChart } from 'echarts/charts'
import { GridComponent, TooltipComponent, LegendComponent, TitleComponent } from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'
import type { EChartsOption } from 'echarts'

echarts.use([BarChart, GridComponent, TooltipComponent, LegendComponent, TitleComponent, CanvasRenderer])

/** A/B/C 三系列的柱色（教师端品牌蓝系 + 功能色辅助）。 */
const SERIES_COLORS: Record<string, string> = { A: '#2f6bff', B: '#10b981', C: '#f59e0b' }

/** 轻量 ECharts React 封装：挂载时 init，option 变化时 setOption，卸载时 dispose，窗口 resize 时自适应。 */
function EChart({ option, height }: { option: EChartsOption; height: number }) {
  const elRef = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const el = elRef.current
    if (!el) return
    const chart = echarts.init(el)
    chart.setOption(option)
    const onResize = () => chart.resize()
    window.addEventListener('resize', onResize)
    return () => {
      window.removeEventListener('resize', onResize)
      chart.dispose()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- 仅在挂载时 init 一次
  }, [])
  useEffect(() => {
    const el = elRef.current
    if (!el) return
    const chart = echarts.getInstanceByDom(el)
    if (chart) chart.setOption(option)
  }, [option])
  return <div ref={elRef} style={{ height, width: '100%' }} />
}

/** 无真实数据时的空态提示（不渲染图表，不展示 mock 假数据）。 */
function EmptyChart({ height }: { height: number }) {
  return (
    <div style={{ height, width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#8c8c8c', fontSize: 13 }}>
      暂无作答数据
    </div>
  )
}

export interface DistributionNode {
  node_index: number
  node_title: string | null
  options: { option: string; option_label: string | null; count: number }[]
}

export interface OptionDistributionChartProps {
  nodes?: DistributionNode[]
  height?: number
  maxWidth?: number | string
}

/** 选择分布分组柱状图：x 轴 = 3 个决策点，每个决策点并排 A/B/C 三根柱（共 9 柱）。 */
export function OptionDistributionChart({ nodes = [], height = 240, maxWidth = '100%' }: OptionDistributionChartProps) {
  const hasData = nodes.some((n) => n.options.some((o) => o.count > 0))
  if (!nodes.length || !hasData) return <div style={{ width: '100%', maxWidth }}><EmptyChart height={height} /></div>
  const categories = nodes.map((n) => n.node_title
    ? `决策点 ${n.node_index}·${n.node_title}`
    : `决策点 ${n.node_index}`)
  const optionKeys = nodes[0]?.options.map((o) => o.option) ?? []
  const labelOf = (key: string) => {
    for (const n of nodes) {
      const found = n.options.find((o) => o.option === key)
      if (found?.option_label) return `${key} · ${found.option_label}`
    }
    return key
  }
  const series = optionKeys.map((key) => ({
    name: labelOf(key),
    type: 'bar' as const,
    barGap: '10%',
    itemStyle: { borderRadius: [4, 4, 0, 0] as [number, number, number, number], color: SERIES_COLORS[key] ?? '#6d96ba' },
    data: nodes.map((n) => n.options.find((o) => o.option === key)?.count ?? 0),
  }))
  const option: EChartsOption = {
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'shadow' },
      valueFormatter: (value) => `${value} 人次`,
    },
    legend: { top: 0, icon: 'circle', itemWidth: 10, itemHeight: 10, textStyle: { fontSize: 12, color: '#5a6b85' } },
    grid: { left: 8, right: 8, top: 32, bottom: 8, containLabel: true },
    xAxis: { type: 'category', data: categories, axisTick: { alignWithLabel: true }, axisLabel: { interval: 0, fontSize: 11 } },
    yAxis: { type: 'value', minInterval: 1, axisLabel: { formatter: '{value}' }, splitLine: { lineStyle: { color: '#eef2f6' } } },
    series,
  }
  return (
    <div style={{ width: '100%', maxWidth }}>
      <EChart option={option} height={height} />
    </div>
  )
}

export default OptionDistributionChart
