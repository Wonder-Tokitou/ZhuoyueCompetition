/**
 * 工作台待办与最近动态（组长图10）：数据来自 GET /teacher/dashboard/todos。
 * 草稿未发布 / 有待批阅 / AI 失败三类待办，点击项跳对应案例；最近动态只读展示。
 */
import { useEffect, useState } from 'react'
import { Alert, Badge, Card, Empty, Space, Tag, Typography } from 'antd'
import { api } from '../../../api/client'
import type { CaseListItem } from '../../../api/types'

interface TodosResponse {
  case_stats: { draft: number; generating: number; ready: number; published: number; total: number }
  todos: {
    draft_unpublished: { count: number; case_ids: number[] }
    pending_review: { count: number; case_ids: number[] }
    ai_failed: { count: number; case_ids: number[] }
  }
  recent: { type: string; text: string; case_id: number; ts: string }[]
}

export default function WorkbenchTodos({ teacherToken, caseList, onOpenCase, onGotoRecords }: {
  teacherToken: string
  caseList: CaseListItem[]
  onOpenCase: (caseId: number) => void
  onGotoRecords: () => void
}) {
  const [data, setData] = useState<TodosResponse | null>(null)

  useEffect(() => {
    let active = true
    api.get<TodosResponse>('/teacher/dashboard/todos', { params: { token: teacherToken } })
      .then(({ data: body }) => { if (active) setData(body) })
      .catch(() => { if (active) setData(null) })
    const onFocus = () => {
      api.get<TodosResponse>('/teacher/dashboard/todos', { params: { token: teacherToken } })
        .then(({ data: body }) => { if (active) setData(body) })
        .catch(() => { /* 静默：待办是辅助信息 */ })
    }
    window.addEventListener('focus', onFocus)
    return () => { active = false; window.removeEventListener('focus', onFocus) }
  }, [teacherToken])

  if (!data) return null
  const { todos } = data
  const nothing = !todos.draft_unpublished.count && !todos.pending_review.count && !todos.ai_failed.count
  const titleOf = (id: number) => caseList.find((c) => c.id === id)?.title ?? `案例 #${id}`

  const items = [
    { key: 'draft', label: '个草稿未发布', count: todos.draft_unpublished.count, ids: todos.draft_unpublished.case_ids, action: onOpenCase, color: 'gold' as const },
    { key: 'review', label: '个案例有待批阅', count: todos.pending_review.count, ids: todos.pending_review.case_ids, action: onGotoRecords, color: 'blue' as const },
    { key: 'ai', label: '个案例生成失败', count: todos.ai_failed.count, ids: todos.ai_failed.case_ids, action: onOpenCase, color: 'red' as const },
  ].filter((i) => i.count > 0)

  return <Card size="small" title="待办与最近动态">
    {nothing
      ? <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="暂无待办，一切就绪" style={{ padding: '8px 0' }} />
      : <Space wrap size={16} style={{ marginBottom: data.recent.length ? 12 : 0 }}>
        {items.map((item) => (
          <Badge key={item.key} count={item.count} offset={[-2, 2]} color={item.color}>
            <button type="button" className="todo-chip" onClick={() => item.action(item.ids[0])} title={item.ids.map(titleOf).join('、')}>
              {item.label}
            </button>
          </Badge>
        ))}
      </Space>}
    {data.recent.length > 0 && <Space direction="vertical" size={4}>
      {data.recent.slice(0, 3).map((r, i) => (
        <Typography.Text key={i} type="secondary" style={{ fontSize: 12 }}>· {r.text}（{r.ts.slice(5, 16).replace('T', ' ')}）</Typography.Text>
      ))}
    </Space>}
  </Card>
}
