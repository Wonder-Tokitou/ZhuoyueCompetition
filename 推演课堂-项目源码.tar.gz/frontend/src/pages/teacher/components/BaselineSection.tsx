import type { Dispatch, SetStateAction } from 'react'
import { Alert, Button, Card, Collapse, Input, InputNumber, Select, Space, Tag, Typography } from 'antd'
import { linkedBaseline } from './baselineFinance'
import { metricAnnotation } from './metricAnnotation'
import type { MetricsDraft } from '../hooks/useCalibrationState'
import { METRIC_FIELDS, CASH_FLOW_TEXTAREA_STYLE } from '../teacherConstants'
import { calculateNetProfit } from '../../../domain/financials.js'
import { PROCESS_BASELINE_FIELDS, MODE_LABELS, type ProcessBaselineField } from '../../../domain/caseConstants'
import TaskStatus from '../../../features/ai/TaskStatus'
import type { AiTaskResponse, GetCaseResponse } from '../../../api/types'

const { TextArea } = Input

type CaseMode = 'finance' | 'marketing' | 'strategy'

interface BaselineSectionProps {
  detail: GetCaseResponse
  title: string
  setTitle: (value: string) => void
  background: string
  setBackground: (value: string) => void
  dilemma: string
  setDilemma: (value: string) => void
  metrics: MetricsDraft
  setMetrics: Dispatch<SetStateAction<MetricsDraft>>
  operatingCost: number | null
  setOperatingCost: (value: number | null) => void
  operatingExpense: number | null
  setOperatingExpense: (value: number | null) => void
  netProfit: number | null
  setNetProfit: (value: number | null) => void
  revenueLink: 'margin' | 'cost'
  setRevenueLink: (value: 'margin' | 'cost') => void
  baselineDirty: boolean
  savingCase: boolean
  onSaveCase: () => void
  nodesCount: number
  generatingNodes: boolean
  nodeError: string
  setNodeError: (value: string) => void
  nodeProgressError: string
  setNodeProgressError: (value: string) => void
  nodeTask: AiTaskResponse | null
  onGenerateNodes: () => void
  /** 2.5(2)：分析模式（finance / marketing / strategy） */
  mode: CaseMode
  /** 2.5(2)：可编辑的过程指标基线 */
  processBaseline: Record<string, number> | null
  setProcessBaseline: (value: Record<string, number>) => void
}

function baselineFieldInput(
  field: ProcessBaselineField,
  value: number,
  onChange: (next: number) => void,
) {
  if (field.options && field.options.length > 0) {
    // 三档下拉：显示档位名，存储档位代表分值；取不超过当前值的最大下界，兼容历史连续分值。
    const selectedValue = field.options
      .map((o) => o.value)
      .filter((v) => v <= value)
      .sort((a, b) => b - a)[0] ?? field.options[0].value
    return (
      <Select
        key={field.key}
        aria-label={field.label}
        value={selectedValue}
        style={{ width: '100%' }}
        onChange={(next: number) => onChange(next)}
        options={field.options.map((o) => ({ value: o.value, label: o.label }))}
      />
    )
  }
  return (
    <InputNumber
      key={field.key}
      aria-label={field.label}
      addonBefore={field.label}
      addonAfter={field.unit}
      style={{ width: '100%' }}
      min={field.min}
      max={field.max}
      step={field.step ?? 0.1}
      value={value}
      onChange={(next) => onChange(next == null ? 0 : Number(next))}
    />
  )
}

/** stage=1 财务基准与案例信息：受控表单 + 营收/毛利率/成本联动（100% 走 linkedBaseline）。
 *  2.5(2)：营销/战略模式在「案例信息」下方前置「过程指标基线」面板（上半区），
 *  财务经营指标折叠到下半区（默认收起可展开）；财务模式保持原样直接展开。 */
export default function BaselineSection({
  detail, title, setTitle, background, setBackground, dilemma, setDilemma,
  metrics, setMetrics, operatingCost, setOperatingCost, operatingExpense, setOperatingExpense,
  netProfit, setNetProfit, revenueLink, setRevenueLink, baselineDirty, savingCase, onSaveCase,
  nodesCount, generatingNodes, nodeError, setNodeError, nodeProgressError, setNodeProgressError,
  nodeTask, onGenerateNodes, mode, processBaseline, setProcessBaseline,
}: BaselineSectionProps) {
  const processFields = PROCESS_BASELINE_FIELDS[mode] ?? []
  const showProcessPanel = mode !== 'finance' && processFields.length > 0
  // 战略模式预警：高风险（≥70）且资源匹配不足（<40）触发双预警
  const riskScore = processBaseline?.risk_score ?? 0
  const resourceMatch = processBaseline?.resource_match ?? 0
  const dangerWarn = mode === 'strategy' && riskScore >= 67 && resourceMatch < 40
  const softWarn = mode === 'strategy' && !dangerWarn && (riskScore >= 67 || resourceMatch < 40)

  const financeBlock = (
    <>
      <div className="metrics-grid">
        {METRIC_FIELDS.map((field) =>
          field.numeric ? (
            <InputNumber
              key={field.key}
              min={0}
              step={0.1}
              value={metrics.revenue}
              placeholder={field.label}
              addonBefore={field.label}
              style={{ width: 240 }}
              onChange={(value) => {
                const revenue = value ?? null
                const linked = linkedBaseline(revenue, metrics.gross_margin, operatingCost, revenueLink)
                setMetrics((prev) => ({ ...prev, revenue, gross_margin: linked?.margin ?? prev.gross_margin }))
                if (linked) setOperatingCost(linked.cost)
                setNetProfit(calculateNetProfit(revenue, linked?.cost ?? operatingCost, operatingExpense))
              }}
            />
          ) : field.key === 'cash_flow' ? (
            <TextArea key={field.key} rows={5} autoSize={{ minRows: 5, maxRows: 12 }} style={CASH_FLOW_TEXTAREA_STYLE}
              value={String(metrics.cash_flow ?? '')} placeholder={field.label}
              onChange={(event) => setMetrics((prev) => ({ ...prev, cash_flow: event.target.value }))} />
          ) : (
            <div key={field.key} style={{ width: 240 }}>
              <Input
                value={metricAnnotation(String(metrics[field.key] ?? '')).value}
                placeholder={field.label}
                addonBefore={field.label}
                style={{ width: 240 }}
                onChange={(event) => {
                  const note = metricAnnotation(String(metrics[field.key] ?? '')).note || metricAnnotation(String(detail.case.base_metrics?.[field.key] ?? '')).note
                  const value = event.target.value + (note ? ` ${note}` : '')
                  setMetrics((prev) => ({ ...prev, [field.key]: value }))
                  if (field.key === 'gross_margin') {
                    const linked = linkedBaseline(metrics.revenue, value, operatingCost, 'margin')
                    if (linked) { setOperatingCost(linked.cost); setNetProfit(calculateNetProfit(metrics.revenue, linked.cost, operatingExpense)) }
                  }
                }}
              />
              <Typography.Text type="secondary" style={{ display: 'block', fontSize: 12, lineHeight: 1.5, marginTop: 4 }}>{(metricAnnotation(String(metrics[field.key] ?? '')).note || metricAnnotation(String(detail.case.base_metrics?.[field.key] ?? '')).note) && `注：${metricAnnotation(String(metrics[field.key] ?? '')).note || metricAnnotation(String(detail.case.base_metrics?.[field.key] ?? '')).note}`}</Typography.Text>
            </div>
          ),
        )}
        <InputNumber min={0} step={0.1} value={operatingCost} placeholder="营业成本（万元）" addonBefore="营业成本"
          style={{ width: 240 }} onChange={(value) => {
            setOperatingCost(value)
            const linked = linkedBaseline(metrics.revenue, metrics.gross_margin, value, 'cost')
            if (linked) setMetrics(prev => ({ ...prev, gross_margin: linked.margin }))
            setNetProfit(calculateNetProfit(metrics.revenue, value, operatingExpense))
          }} />
        <InputNumber min={0} step={0.1} value={operatingExpense} placeholder="运营费用（万元）" addonBefore="运营费用"
          style={{ width: 240 }} onChange={(value) => { setOperatingExpense(value); setNetProfit(calculateNetProfit(metrics.revenue, operatingCost, value)) }} />
        <InputNumber precision={2} value={netProfit} readOnly placeholder="净利润（万元）" addonBefore="净利润 · 自动计算" style={{ width: 260 }} />
      </div>
      <div className="node-actions">
        <Typography.Text type="secondary">
          修改营收时：<Select aria-label="营收联动方式" value={revenueLink} style={{ width: 180 }} options={[{ value: 'margin', label: '保持毛利率，计算成本' }, { value: 'cost', label: '保持成本，计算毛利率' }]} onChange={setRevenueLink} />。直接修改毛利率会计算成本；直接修改成本会反算毛利率。净利润同步计算。营收为零时无法反算毛利率。
        </Typography.Text>
        <Button type="primary" loading={savingCase} onClick={() => void onSaveCase()}>
          保存案例信息
        </Button>
      </div>
      {showProcessPanel && (
        <Typography.Paragraph type="secondary" style={{ margin: 0, fontSize: 12 }}>
          财务经营指标仍全程保留。保存后引擎按「{MODE_LABELS[mode]}」传导过程指标 → 财务联动重算；学生端复盘按本模式展示专业指标。
        </Typography.Paragraph>
      )}
    </>
  )

  return (
    <>
      <Card size="small" type="inner" title="案例信息与经营基准" extra={<Tag color={baselineDirty ? 'orange' : 'default'}>{baselineDirty ? '未保存' : '已载入 / 已保存'}</Tag>}>
        <Space direction="vertical" size={12} style={{ width: '100%' }}>
          <Input
            addonBefore="案例标题"
            value={title}
            maxLength={200}
            onChange={(event) => setTitle(event.target.value)}
          />
          <TextArea rows={3} value={background} onChange={(event) => setBackground(event.target.value)} placeholder="企业背景" />
          <TextArea rows={3} value={dilemma} onChange={(event) => setDilemma(event.target.value)} placeholder="核心经营困境" />
          {showProcessPanel && (
            <>
              <Card size="small" type="inner" title={`过程指标基线 · ${MODE_LABELS[mode]}（教学核心指标，可编辑）`}>
                <Space direction="vertical" size={12} style={{ width: '100%' }}>
                  <div className="metrics-grid">
                    {/* 2026-10-27（组长图13）：label 显式展示在控件上方（"资源匹配度基线"等），
                        控件占满字段份额，不再被 flex 行挤压成单字 */}
                    {processFields.map((field) => (
                      <div key={field.key} className="baseline-field">
                        <label className="baseline-field-label">{field.label}{field.unit ? `（${field.unit}）` : ''}</label>
                        {baselineFieldInput(field, processBaseline?.[field.key] ?? 0, (next) => {
                          setProcessBaseline({ ...(processBaseline ?? {}), [field.key]: next })
                        })}
                      </div>
                    ))}
                  </div>
                  {processFields.some((f) => f.hint) && (
                    <Typography.Paragraph type="secondary" style={{ margin: 0, fontSize: 12 }}>
                      {processFields.filter((f) => f.hint).map((f) => `${f.label}：${f.hint}`).join('；')}
                    </Typography.Paragraph>
                  )}
                  {dangerWarn && (
                    <Alert showIcon type="error" message="高风险 × 资源匹配不足" description={`当前风险得分 ${riskScore}（≥67 高风险）且资源匹配度 ${resourceMatch}（<40 不足）。学生选择激进策略时将同时触发风险与匹配度双预警，复盘按 SWOT 模型重点讲评。`} />
                  )}
                  {softWarn && (
                    <Alert showIcon type="warning" message={riskScore >= 67 ? '风险得分偏高' : '资源匹配度偏低'} description={riskScore >= 67 ? `当前风险得分 ${riskScore}（≥67 为高风险档），请核对基线是否符合教学目标。` : `当前资源匹配度 ${resourceMatch}（<40 为资源不足档），请核对基线是否符合教学目标。`} />
                  )}
                </Space>
              </Card>
              <Collapse
                size="small"
                items={[{ key: 'finance', label: '财务经营指标（营收 / 成本 / 费用 / 净利润，默认收起）', children: financeBlock }]}
              />
            </>
          )}
          {!showProcessPanel && financeBlock}
          <Typography.Paragraph type="secondary" style={{ margin: 0, fontSize: 12 }}>
            企业背景：{detail.case.background || '（空）'}
            <br />
            核心经营困境：{detail.case.dilemma || '（空）'}
            <br />
            这两项是学生端首屏题面。编辑后请保存；重新发布后用于新推演，已有推演保持原快照。
          </Typography.Paragraph>
        </Space>
      </Card>
      {nodeError && <Alert showIcon type="error" message="决策节点生成失败" description={nodeError} closable onClose={() => setNodeError('')} />}
      {nodeProgressError && <Alert showIcon type="warning" message={nodeProgressError} closable onClose={() => setNodeProgressError('')} />}
      {nodesCount === 0 && <Button type="primary" loading={generatingNodes} disabled={savingCase || operatingCost === null || operatingExpense === null || !detail.case.base_metrics} onClick={() => void onGenerateNodes()}>确认经营基准并生成决策节点</Button>}
      {nodeTask && <TaskStatus task={nodeTask} busy={generatingNodes} />}
    </>
  )
}
