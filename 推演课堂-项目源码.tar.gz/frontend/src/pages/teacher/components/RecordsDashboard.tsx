/**
 * 案例作答看板（按案例维度）：KPI 行 + 完成状态环形图 + 各轮提交柱状图 + 最新作答动态。
 * 数据全部来自 T9 records 明细的前端聚合，无 mock；实时性由 T9.5 SSE 推送驱动外层重拉。
 * ECharts 按需引入（Pie/Bar + Tooltip/Legend/Grid + Canvas），与 ReviewCharts 同一套约定。
 */
import { useEffect, useMemo, useRef } from 'react'
import * as echarts from 'echarts/core'
import { BarChart, PieChart } from 'echarts/charts'
import { GridComponent, LegendComponent, TooltipComponent } from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'
import type { EChartsOption } from 'echarts'
import StatCard from '../../../components/dashboard/StatCard'
import type { StudentRecord } from '../../../api/types'
import { participantKey, recordFinished, recordKey } from '../../../domain/recordSummary'
import { formatTime } from '../teacherConstants'
import './recordsDashboard.css'

echarts.use([PieChart, BarChart, TooltipComponent, LegendComponent, GridComponent, CanvasRenderer])

/** 轻量 ECharts React 封装：挂载时 init，option 变化时 setOption，卸载时 dispose，窗口 resize 自适应。 */
function EChart({ option, height }: { option: EChartsOption; height: number }) {
  const elRef = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const el = elRef.current
    if (!el) return
    const chart = echarts.init(el)
    chart.setOption(option)
    const onResize = () => chart.resize()
    window.addEventListener('resize', onResize)
    return () => {
      window.removeEventListener('resize', onResize)
      chart.dispose()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- 仅在挂载时 init 一次
  }, [])
  useEffect(() => {
    const el = elRef.current
    if (!el) return
    const chart = echarts.getInstanceByDom(el)
    if (chart) chart.setOption(option)
  }, [option])
  return <div ref={elRef} style={{ height, width: '100%' }} />
}

export interface RecordsDashboardProps {
  /** 与下方记录表同一筛选范围的作答记录（班级/姓名/状态/版本） */
  records: StudentRecord[]
  loading?: boolean
}

export default function RecordsDashboard({ records, loading }: RecordsDashboardProps) {
  const stats = useMemo(() => {
    const participants = new Set(records.map(participantKey)).size
    const finished = records.filter(recordFinished).length
    const durations = records.map((r) => r.total_duration_min).filter((n): n is number => typeof n === 'number')
    const avgDuration = durations.length ? Math.round((durations.reduce((a, b) => a + b, 0) / durations.length) * 10) / 10 : null
    const totalTurns = records.reduce((sum, r) => sum + r.turns.length, 0)
    const rounds = [1, 2, 3].map((idx) => records.filter((r) => r.turns.some((t) => t.idx === idx)).length)
    const recent = [...records]
      .map((r) => ({ key: recordKey(r), name: r.student_name, attempt: r.attempt_no ?? 1, finished: recordFinished(r), duration: r.total_duration_min, at: r.turns.length ? r.turns[r.turns.length - 1].created_at : r.created_at }))
      .filter((x): x is typeof x & { at: string } => !!x.at)
      .sort((a, b) => (a.at < b.at ? 1 : -1))
    return { participants, finished, avgDuration, durationCount: durations.length, totalTurns, rounds, recent }
  }, [records])

  const completionRate = stats.participants ? Math.round((stats.finished / stats.participants) * 100) : 0
  const hasData = records.length > 0

  const donutOption: EChartsOption = {
    tooltip: { trigger: 'item' },
    legend: { bottom: 0, icon: 'circle', itemWidth: 10, itemHeight: 10, textStyle: { color: '#5a6b85', fontSize: 12 } },
    title: {
      text: `${completionRate}%`,
      subtext: '完成率',
      left: 'center',
      top: '32%',
      textStyle: { fontSize: 24, fontWeight: 700, color: '#1b2a41' },
      subtextStyle: { fontSize: 12, color: '#5a6b85' },
    },
    series: [
      {
        type: 'pie',
        radius: ['58%', '78%'],
        center: ['50%', '42%'],
        itemStyle: { borderRadius: 6, borderColor: '#fff', borderWidth: 2 },
        label: { show: false },
        data: [
          { name: '已完成', value: stats.finished, itemStyle: { color: '#10b981' } },
          { name: '未完成', value: records.length - stats.finished, itemStyle: { color: '#e8eef7' } },
        ],
      },
    ],
  }

  const barOption: EChartsOption = {
    tooltip: { trigger: 'axis' },
    grid: { left: 8, right: 8, top: 24, bottom: 8, containLabel: true },
    xAxis: { type: 'category', data: ['第 1 轮', '第 2 轮', '第 3 轮'], axisLine: { lineStyle: { color: '#e8eef7' } }, axisLabel: { color: '#5a6b85' } },
    yAxis: { type: 'value', minInterval: 1, splitLine: { lineStyle: { color: '#eef2f8' } }, axisLabel: { color: '#94a3b8' } },
    series: [{ type: 'bar', barWidth: 28, itemStyle: { borderRadius: [6, 6, 0, 0], color: '#2f6bff' }, data: stats.rounds }],
  }

  const latest = stats.recent[0] ?? null
  return (
    <section className="records-dashboard" aria-label="案例作答看板">
      <div className="records-kpi-row">
        <StatCard label="参与人数" value={stats.participants} accent="blue" sub={[{ label: '完成', value: stats.finished }, { label: '完成率', value: `${completionRate}%` }]} />
        <StatCard label="推演次数" value={records.length} accent="green" sub={[{ label: '进行中', value: records.length - stats.finished }, { label: '提交回合', value: stats.totalTurns }]} />
        <StatCard label="平均用时" value={stats.avgDuration === null ? '—' : `${stats.avgDuration} 分钟`} accent="orange" sub={[{ label: '计时样本', value: stats.durationCount }]} />
        <StatCard label="最近作答" value={latest ? latest.name : '—'} accent="purple" sub={[{ label: '时间', value: latest ? formatTime(latest.at) : '—' }]} />
      </div>
      <div className="records-charts-row">
        <div className="chart-card">
          <div className="chart-card-title">完成状态</div>
          {hasData ? <EChart option={donutOption} height={210} /> : <div className="chart-empty">{loading ? '正在加载…' : '暂无作答记录'}</div>}
        </div>
        <div className="chart-card">
          <div className="chart-card-title">各轮提交人数</div>
          {hasData ? <EChart option={barOption} height={210} /> : <div className="chart-empty">{loading ? '正在加载…' : '暂无作答记录'}</div>}
        </div>
        <div className="chart-card">
          <div className="chart-card-title">最新作答动态</div>
          {stats.recent.length ? (
            <div className="recent-list">
              {stats.recent.slice(0, 5).map((item) => (
                <div key={item.key} className="recent-item">
                  <i className={`recent-dot ${item.finished ? 'finished' : 'unfinished'}`} />
                  <span>{item.name} · 第 {item.attempt} 次{item.finished ? '' : ' · 进行中'}</span>
                  <span className="recent-time">{formatTime(item.at)}</span>
                </div>
              ))}
            </div>
          ) : <div className="chart-empty">{loading ? '正在加载…' : '暂无作答记录'}</div>}
        </div>
      </div>
    </section>
  )
}
