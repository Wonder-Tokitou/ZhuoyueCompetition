﻿import ReviewEditor from '../../features/ai/ReviewEditor'
import { RadarScoreChart, RoundLineChart } from '../../features/ai/ReviewCharts'
import { useEffect, useMemo, useState } from 'react'
import { Alert, Button, Card, Drawer, Input, Popconfirm, Select, Space, Table, Tag, Typography } from 'antd'
import { getClassMembers, getLeaderboard, getRecords, listCases, listTeacherClasses, setCasePlayLock } from '../../api/client'
import type { CaseListItem, ClassGroupItem, LeaderboardItem, LeaderboardResponse, StudentRecord } from '../../api/types'
import { useTeacherToken } from '../../context/TeacherTokenContext'
import { formatDuration, formatTime } from './teacherConstants'
import MetricComparison from '../../components/MetricComparison'
import { filterRecords, recordFinished, recordKey } from '../../domain/recordSummary'
import RecordsDashboard from './components/RecordsDashboard'
import { caseModeColumns } from './leaderboardColumns'
import './teacher.css'

export default function TeacherRecordsPage() {
  const token = useTeacherToken()
  const [cases, setCases] = useState<CaseListItem[]>([]), [caseId, setCaseId] = useState<number | null>(null)
  const [records, setRecords] = useState<StudentRecord[]>([]), [error, setError] = useState('')
  const [loading, setLoading] = useState(false), [refresh, setRefresh] = useState(0)
  const [name, setName] = useState(''), [status, setStatus] = useState('all'), [version, setVersion] = useState('all')
  const [opened, setOpened] = useState<string | null>(null)
  const [board, setBoard] = useState<LeaderboardResponse | null>(null), [boardLoading, setBoardLoading] = useState(false)
  const [lockBusy, setLockBusy] = useState(false)
  // 班级筛选：数据面板（统计 + 排行榜 + 记录列表）按班级学生成员过滤；历史匿名记录（无账号）不属于任何班级。
  const [classes, setClasses] = useState<ClassGroupItem[]>([])
  const [classFilter, setClassFilter] = useState<number | 'all'>('all')
  const [classMemberMap, setClassMemberMap] = useState<Record<number, Set<number>>>({})
  useEffect(() => {
    let active = true
    listTeacherClasses(token).then(async (groups) => {
      if (!active) return
      setClasses(groups)
      const map: Record<number, Set<number>> = {}
      await Promise.all(groups.map(async (g) => {
        try { map[g.id] = new Set((await getClassMembers(token, g.id)).map(m => m.student_id)) } catch { map[g.id] = new Set() }
      }))
      if (active) setClassMemberMap(map)
    }).catch(() => { /* 班级列表加载失败时静默降级为“全部班级” */ })
    return () => { active = false }
  }, [token])
  const currentCase = cases.find(c => c.id === caseId)
  // 停止/恢复推演：停止后学生端只读，历史记录保留（教师记录页顶部一键切换）
  async function togglePlayLock() {
    if (caseId === null || !currentCase) return
    setLockBusy(true)
    try {
      await setCasePlayLock(caseId, token, !currentCase.play_locked)
      setCases(rows => rows.map(c => c.id === caseId ? { ...c, play_locked: !c.play_locked } : c))
      setError('')
    } catch (e) {
      setError(e instanceof Error ? e.message : '操作失败，请重试')
    } finally {
      setLockBusy(false)
    }
  }
  useEffect(() => { let active = true; listCases(token).then(rows => { if (active) { setCases(rows); setCaseId(v => v ?? rows[0]?.id ?? null) } }).catch(e => { if (active) setError(e.message) }); return () => { active = false } }, [token])
  useEffect(() => {
    let active = true
    setRecords([]); setError('')
    if (caseId === null) return
    setLoading(true)
    getRecords(caseId, token).then(rows => { if (active) setRecords(rows) }).catch(e => { if (active) setError(e.message) }).finally(() => { if (active) setLoading(false) })
    return () => { active = false }
  }, [caseId, token, refresh])
  useEffect(() => {
    let active = true
    setBoard(null)
    if (caseId === null) return
    setBoardLoading(true)
    getLeaderboard(caseId, token).then(data => { if (active) setBoard(data) }).catch(e => { if (active) setError(e.message) }).finally(() => { if (active) setBoardLoading(false) })
    return () => { active = false }
  }, [caseId, token, refresh])
  // T9.5 实时推送：学生提交决策后收到 record_changed 事件，去抖重拉记录与排行榜；
  // 断线由 EventSource 原生自动重连兜底，组件卸载/切换案例时 close()。
  useEffect(() => {
    if (caseId === null) return
    const source = new EventSource(`/api/cases/${caseId}/records/stream?token=${encodeURIComponent(token)}`)
    let timer: number | undefined
    source.onmessage = (e) => {
      try {
        const event = JSON.parse(e.data) as { type?: string }
        if (event.type !== 'record_changed') return
      } catch { return }
      window.clearTimeout(timer)
      timer = window.setTimeout(() => setRefresh(v => v + 1), 400)
    }
    return () => { window.clearTimeout(timer); source.close() }
  }, [caseId, token])
  // 班级筛选：统计、排行榜、记录列表三处共用同一份成员集合过滤。
  // 排行榜过滤后按班级内重新编号名次，避免出现跳跃排名。
  const classMemberIds = classFilter === 'all' ? null : (classMemberMap[classFilter] ?? new Set<number>())
  const inClass = (id?: number | null) => classMemberIds === null || (id != null && classMemberIds.has(id))
  const recordsInClass = useMemo(() => classMemberIds === null ? records : records.filter(r => inClass(r.student_id)), [records, classMemberIds])
  const filtered = useMemo(() => filterRecords(recordsInClass, name, status, version), [recordsInClass, name, status, version])
  const boardItems = useMemo(() => {
    const items = classMemberIds === null ? (board?.items ?? []) : (board?.items ?? []).filter(r => inClass(r.student_id))
    return items.map((item, i) => ({ ...item, rank: i + 1 }))
  }, [board, classMemberIds])
  const selected = records.find(r => recordKey(r) === opened)
  const versions = [...new Set(records.map(r => String(r.case_version ?? 'unknown')))]
  const reviewStatus = (r: StudentRecord) => r.review_status === 'succeeded' ? '已生成' : r.review_status === 'failed' ? '生成失败' : !r.review_status || r.review_status === 'not_started' ? '尚未生成' : '生成中'
  return <Space direction="vertical" size={20} style={{ width: '100%' }}>
    <div><Typography.Title level={3}>学生作答记录</Typography.Title><Typography.Text type="secondary">先找到需要关注的作答，再查看策略、理由与复盘。</Typography.Text></div>
    <Space wrap className="record-filters">
      <Select aria-label="选择案例" style={{ width: 280, maxWidth: '100%' }} value={caseId} options={cases.map(r => ({ value: r.id, label: r.title }))} onChange={id => { setOpened(null); setVersion('all'); setCaseId(id) }} />
      <Select aria-label="班级筛选" style={{ width: 170 }} value={classFilter}
        options={[{ value: 'all', label: '全部班级' }, ...classes.map(c => ({ value: c.id, label: `${c.name}（${c.member_count}人）` }))]}
        onChange={v => { setOpened(null); setClassFilter(v) }} />
      <Input.Search aria-label="搜索学生" placeholder="搜索学生姓名" allowClear value={name} onChange={e => setName(e.target.value)} style={{ width: 220 }} />
      <Select aria-label="完成状态" value={status} onChange={setStatus} style={{ width: 140 }} options={[{ value: 'all', label: '全部状态' }, { value: 'finished', label: '已完成' }, { value: 'unfinished', label: '未完成' }]} />
      <Select aria-label="案例版本" value={version} onChange={setVersion} style={{ width: 150 }} options={[{ value: 'all', label: '全部版本' }, ...versions.map(v => ({ value: v, label: v === 'unknown' ? '历史版本未知' : `版本 ${v}` }))]} />
      <Button onClick={() => setRefresh(v => v + 1)} loading={loading}>刷新记录</Button>
      {currentCase && <Popconfirm title={currentCase.play_locked ? '恢复该案例的推演？' : '停止该案例的推演？'}
        description={currentCase.play_locked
          ? '恢复后学生可以继续开始和提交推演。'
          : '停止后学生不能开始或继续推演，但已有推演记录全部保留，学生端可查看（只读）。'}
        okText={currentCase.play_locked ? '恢复推演' : '停止推演'} cancelText="取消"
        onConfirm={() => void togglePlayLock()}>
        <Button loading={lockBusy} danger={!currentCase.play_locked}>
          {currentCase.play_locked ? '恢复推演' : '停止推演'}
        </Button>
      </Popconfirm>}
      {currentCase?.play_locked && <Tag color="red" style={{ alignSelf: 'center' }}>该案例已停止推演（学生端只读）</Tag>}
    </Space>
    {error && <Alert type="error" message={error} />}
    <RecordsDashboard records={filtered} loading={loading} />
    <Typography.Text type="secondary">统计仅覆盖当前筛选（班级/姓名/状态/版本）的已有记录，按学生账号去重；任一次完成即计入完成人数。历史匿名记录按姓名归并、不属于任何班级，不表示全班应到人数或在线状态。</Typography.Text>
    <Card size="small" title={board?.reference_path ? `学生推演结果排行榜 · 教师推荐路径 ${board.reference_path}` : '学生推演结果排行榜'}>
      {board && !board.reference_path && <Alert type="info" showIcon message="未设置教师推荐路径，当前默认按净利润降序；可先在案例校准中设置推荐方案。" style={{ marginBottom: 12 }} />}
      <Table<LeaderboardItem> rowKey={r => `${r.student_id ?? r.student_name}-${r.attempt_no}-${r.path}`} dataSource={boardItems} loading={boardLoading} size="small" pagination={false} locale={{ emptyText: classFilter !== 'all' ? '该班级暂无学生作答' : '暂无学生作答，排行榜为空' }}
        expandable={{
          // 组长图15：财务四指标作为辅助折叠，点开查看
          expandedRowRender: (r) => <Space wrap size={16} style={{ padding: '4px 0' }}>
            {([[`营收：${r.metrics.revenue ?? '—'} 万元`], [`毛利率：${r.metrics.gross_margin ?? '—'}`], [`市场份额：${r.metrics.market_share ?? '—'}`], [`现金流：${r.metrics.cash_flow_amount ?? '—'} 万元`], [`净利润：${r.metrics.net_profit ?? '—'} 万元`], [`总时长：${r.total_duration_min} 分钟`]] as string[][]).flat().map((text) => <Tag key={text}>{text}</Tag>)}
          </Space>,
          rowExpandable: () => true,
        }}
        columns={[
        { title: '排名', width: 64, align: 'center', render: (_, r) => r.rank <= 3 ? <Tag color={['gold', 'blue', 'cyan'][r.rank - 1]}>{r.rank}</Tag> : r.rank },
        { title: '学生', render: (_, r) => <><strong>{r.student_name}</strong><div>{r.student_id ? `账号 #${r.student_id}` : '历史匿名记录'}</div></> },
        // 组长图14：口径=第一次正式推演的路径与指标；"推演次数"列=正式推演总次数
        { title: '推演次数', width: 96, render: (_, r) => `共 ${r.total_attempts ?? 1} 次` },
        { title: '推演路径（第一次）', render: (_, r) => <Space>{r.path}{r.matched ? <Tag color="green">推荐路径</Tag> : r.path_score !== null && <Tag>{`匹配 ${r.path_score}/3`}</Tag>}</Space> },
        // 组长图15：按案例模式展示专业指标主列（营销=销量/份额/满意度，战略=风险/机会，财务=盈利/流动性），数据缺失显示 "—"
        ...caseModeColumns(currentCase?.case_type).map((col) => ({
          title: col.title,
          sorter: (a: LeaderboardItem, b: LeaderboardItem) => (a.metrics[col.key as keyof LeaderboardItem['metrics']] as number | null ?? -1) - (b.metrics[col.key as keyof LeaderboardItem['metrics']] as number | null ?? -1),
          render: (_: unknown, r: LeaderboardItem) => (r.metrics[col.key as keyof LeaderboardItem['metrics']] as number | null) ?? '—',
        })),
        { title: '操作', width: 96, render: (_, r) => <Button size="small" onClick={() => { const target = filtered.find(x => (x.student_id ?? null) === (r.student_id ?? null)); if (target) setOpened(recordKey(target)) }} disabled={!filtered.some(x => (x.student_id ?? null) === (r.student_id ?? null))}>详情</Button> },
      ]} />
    </Card>
    <Typography.Text type="secondary">排行榜口径：展示每位学生的**第一次**正式推演（路径与指标）；最新数据点「详情」查看全部推演。财务指标已折叠在行首展开箭头内。</Typography.Text>
    <Drawer title={selected ? `${selected.student_name} · 第 ${selected.attempt_no ?? 1} 次推演` : '作答详情'} width={720} open={opened !== null} onClose={() => setOpened(null)}>
      {selected ? <Space direction="vertical" size={16} style={{ width: '100%' }}>
        <Typography.Text>案例版本 {selected.case_version ?? '未记录'} · {reviewStatus(selected)}</Typography.Text>
        {selected.turns.map(t => <Card key={t.id} size="small" title={`第 ${t.idx} 轮`}><p><strong>已选策略：</strong>{t.chosen_label || '历史策略文字未记录'}</p><p>理由：{t.input_text || '未填写'}</p><p>{t.result_json.summary}</p><MetricComparison before={t.before_metrics} after={t.after_metrics ?? t.result_json.metrics} /><p>{formatTime(t.created_at)} · 作答耗时 {formatDuration(t.duration_ms)}</p></Card>)}
        {selected.review?.status === 'succeeded' && <Card size="small" title="该学生推演情况可视化">
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 16 }}>
            <div style={{ flex: '1 1 280px', minWidth: 260 }}>
              <Typography.Text type="secondary">维度评分（{selected.review.framework_type}，按推演真实指标推导）</Typography.Text>
              <RadarScoreChart scores={selected.review.dimension_scores ?? []} frameworkType={selected.review.framework_type} />
            </div>
            <div style={{ flex: '1 1 300px', minWidth: 280 }}>
              <Typography.Text type="secondary">各轮净利润对比（我的路径 vs 标杆路径，万元）</Typography.Text>
              <RoundLineChart pathComparison={selected.review.path_comparison ?? null} />
            </div>
          </div>
        </Card>}
        <Typography.Title level={5}>AI 复盘 · {reviewStatus(selected)}</Typography.Title>
        {selected.review && <ReviewEditor key={`${selected.review_id}-${refresh}`} record={selected} token={token} onSaved={() => setRefresh(v => v + 1)} />}
      </Space> : <Typography.Text>{loading ? '正在更新记录…' : '该记录已不可用，请关闭后刷新列表。'}</Typography.Text>}
    </Drawer>
  </Space>
}
