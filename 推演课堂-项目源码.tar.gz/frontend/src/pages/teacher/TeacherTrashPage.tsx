import { useCallback, useEffect, useMemo, useState } from 'react'
import { Alert, App as AntdApp, Button, Card, Input, Popconfirm, Space, Spin, Table, Tag, Typography } from 'antd'
import { batchPurgeCases, batchRestoreCases, listTrashCases, purgeCase, restoreCase } from '../../api/client'
import type { TrashCaseItem } from '../../api/types'
import { useTeacherToken } from '../../context/TeacherTokenContext'

const STATUS_META: Record<string, { color: string; text: string }> = {
  draft: { color: 'default', text: '草稿' },
  generating: { color: 'processing', text: '生成中' },
  ready: { color: 'gold', text: '待发布' },
  published: { color: 'green', text: '已发布' },
}

/**
 * 案例回收站：教师"删除"的案例进入这里（软删除）。
 * 可恢复回工作台，或彻底删除（不可撤销）。
 * 2026-10-27（组长图5/图11）：新增多选批量恢复/批量彻底删除、标题搜索与分页。
 */
export default function TeacherTrashPage() {
  const teacherToken = useTeacherToken()
  const { message } = AntdApp.useApp()
  const [rows, setRows] = useState<TrashCaseItem[] | null>(null)
  const [error, setError] = useState('')
  const [busyId, setBusyId] = useState<number | null>(null)
  const [search, setSearch] = useState('')
  const [selectedKeys, setSelectedKeys] = useState<React.Key[]>([])
  const [batchBusy, setBatchBusy] = useState(false)

  const load = useCallback(() => {
    let active = true
    listTrashCases(teacherToken).then((data) => { if (active) setRows(data) })
      .catch((e: unknown) => { if (active) setError(e instanceof Error ? e.message : '回收站加载失败') })
    return () => { active = false }
  }, [teacherToken])

  useEffect(() => load(), [load])

  // 搜索只按标题过滤（本地过滤，服务端响应结构不变）
  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase()
    if (!rows) return []
    return q ? rows.filter((r) => r.title.toLowerCase().includes(q)) : rows
  }, [rows, search])

  async function handleRestore(row: TrashCaseItem) {
    setBusyId(row.id)
    try {
      await restoreCase(row.id, teacherToken)
      message.success(`已恢复案例「${row.title}」`)
      setError(''); load()
    } catch { /* 失败提示由拦截器统一处理 */ }
    finally { setBusyId(null) }
  }

  async function handlePurge(row: TrashCaseItem) {
    setBusyId(row.id)
    try {
      await purgeCase(row.id, teacherToken)
      message.success(`已彻底删除案例「${row.title}」`)
      setError(''); load()
    } catch { /* 失败提示由拦截器统一处理 */ }
    finally { setBusyId(null) }
  }

  function summarizeSkipped(skipped: { case_id: number; reason: string }[]) {
    if (!skipped.length) return ''
    const reasons = skipped.map((s) => s.reason === 'not_in_trash' ? `#${s.case_id} 不在回收站` : s.reason === 'not_owned' ? `#${s.case_id} 无权操作` : `#${s.case_id} ${s.reason}`).join('；')
    return `，跳过 ${skipped.length} 项（${reasons}）`
  }

  /** 批量恢复（组长图5）：调用后端批量端点，单事务、返回跳过明细。 */
  async function handleBatchRestore() {
    const ids = selectedKeys.map(Number).filter((n) => Number.isFinite(n))
    if (!ids.length) return
    setBatchBusy(true)
    try {
      const { restored, skipped } = await batchRestoreCases(ids, teacherToken)
      message.success(`成功恢复 ${restored.length} 项${summarizeSkipped(skipped)}`)
      setSelectedKeys([]); setError(''); load()
    } catch { /* 失败提示由拦截器统一处理 */ }
    finally { setBatchBusy(false) }
  }

  async function handleBatchPurge() {
    const ids = selectedKeys.map(Number).filter((n) => Number.isFinite(n))
    if (!ids.length) return
    setBatchBusy(true)
    try {
      const { purged, skipped } = await batchPurgeCases(ids, teacherToken)
      message.success(`已彻底删除 ${purged.length} 项${summarizeSkipped(skipped)}`)
      setSelectedKeys([]); setError(''); load()
    } catch { /* 失败提示由拦截器统一处理 */ }
    finally { setBatchBusy(false) }
  }

  return <Space direction="vertical" style={{ width: '100%' }}>
    <div className="teacher-page-head">
      <div>
        <Typography.Title level={3} style={{ margin: 0 }}>案例回收站</Typography.Title>
        <Typography.Text type="secondary">被删除的案例进入这里，学生端推演与列表立即失效；可恢复，或彻底删除（不可撤销）。</Typography.Text>
      </div>
      <Button onClick={() => { setRows(null); setError(''); load() }}>刷新</Button>
    </div>
    {error && <Alert type="error" message={error} />}
    {!rows && !error && <Spin />}
    {rows && <Card size="small">
      {rows.length === 0
        ? <Alert type="info" message="回收站是空的" description="在工作台删除案例后会出现在这里，可恢复或彻底删除。" />
        : <>
          <Space wrap style={{ marginBottom: 12 }}>
            <Input.Search aria-label="搜索案例标题" placeholder="搜索案例标题" allowClear value={search}
              onChange={(e) => setSearch(e.target.value)} style={{ width: 260 }} />
            <Typography.Text type="secondary">已选 {selectedKeys.length} 项</Typography.Text>
            <Popconfirm title={`批量恢复 ${selectedKeys.length} 个案例？`} okText="批量恢复" cancelText="取消"
              onConfirm={() => void handleBatchRestore()}>
              <Button type="primary" ghost disabled={!selectedKeys.length} loading={batchBusy}>批量恢复</Button>
            </Popconfirm>
            <Popconfirm title={`批量彻底删除 ${selectedKeys.length} 个案例？`}
              description="案例、学生提交记录及关联 AI 产物将一并删除，且无法撤销。"
              okText="批量彻底删除" cancelText="取消" okButtonProps={{ danger: true }}
              onConfirm={() => void handleBatchPurge()}>
              <Button danger disabled={!selectedKeys.length} loading={batchBusy}>批量彻底删除</Button>
            </Popconfirm>
          </Space>
          <Table<TrashCaseItem> rowKey="id" dataSource={filtered} size="middle"
            rowSelection={{ selectedRowKeys: selectedKeys, onChange: setSelectedKeys }}
            pagination={{ pageSize: 10, showSizeChanger: true, hideOnSinglePage: true }}
            columns={[
              { title: '案例标题', dataIndex: 'title', key: 'title', render: (title: string) => <Typography.Text strong>{title}</Typography.Text> },
              { title: '状态', dataIndex: 'status', key: 'status', render: (status: string) => <Tag color={STATUS_META[status]?.color ?? 'default'}>{STATUS_META[status]?.text ?? status}</Tag> },
              { title: '删除时间', dataIndex: 'deleted_at', key: 'deleted_at', render: (v: string) => v.replace('T', ' ').slice(0, 16) },
              { title: '创建时间', dataIndex: 'created_at', key: 'created_at', render: (v: string) => v.replace('T', ' ').slice(0, 16) },
              { title: '操作', key: 'actions',
                render: (_, row) => <Space>
                  <Button size="small" type="primary" ghost loading={busyId === row.id} onClick={() => void handleRestore(row)}>恢复</Button>
                  <Popconfirm title={`彻底删除案例「${row.title}」？`}
                    description="案例、学生提交记录及关联 AI 产物将一并删除，且无法撤销。"
                    okText="彻底删除" cancelText="取消" okButtonProps={{ danger: true }}
                    onConfirm={() => void handlePurge(row)}>
                    <Button size="small" danger loading={busyId === row.id}>彻底删除</Button>
                  </Popconfirm>
                </Space> },
            ]} />
        </>}
    </Card>}
  </Space>
}
