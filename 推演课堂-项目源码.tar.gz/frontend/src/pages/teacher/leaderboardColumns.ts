/**
 * 排行榜按案例模式的专业指标列（组长图15）：
 * 营销 = 销量指数/市场份额/客户满意度；战略 = 风险指数/市场机会；财务 = 盈利质量/现金流安全。
 * 指标键与文案与 StudentReview 的 PROFESSIONAL_METRICS 同源（第一次正式推演的末轮 after_metrics）；
 * 财务四件套（营收/毛利率/市场份额/现金流/净利润）统一折叠为辅助行。
 */
export interface ModeMetricColumn {
  /** after_metrics / leaderboard metrics 里的键 */
  key: string
  title: string
}

const MODE_COLUMNS: Record<string, ModeMetricColumn[]> = {
  市场营销类: [
    { key: 'sales_index', title: '销量指数' },
    { key: 'market_share_pct', title: '市场份额（%）' },
    { key: 'customer_satisfaction', title: '客户满意度' },
  ],
  战略决策类: [
    { key: 'risk_score', title: '风险指数' },
    { key: 'market_opportunity', title: '市场机会' },
  ],
  财务管理类: [
    { key: 'net_profit', title: '净利润（万元）' },
    { key: 'gross_margin_pct', title: '毛利率（%）' },
    { key: 'cash_flow_amount', title: '现金流（万元）' },
  ],
}

/** 未识别类型时的兜底列（保持原有财务口径） */
const FALLBACK_COLUMNS: ModeMetricColumn[] = [
  { key: 'revenue', title: '营收（万元）' },
  { key: 'gross_margin_pct', title: '毛利率（%）' },
  { key: 'market_share_pct', title: '市场份额（%）' },
  { key: 'cash_flow_amount', title: '现金流（万元）' },
]

export function caseModeColumns(caseType?: string | null): ModeMetricColumn[] {
  if (!caseType) return FALLBACK_COLUMNS
  return MODE_COLUMNS[caseType] ?? FALLBACK_COLUMNS
}
