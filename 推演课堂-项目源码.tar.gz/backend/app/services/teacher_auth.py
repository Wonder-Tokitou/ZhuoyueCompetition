"""教师端鉴权、角色与归属判定（2026-10-27 权限隔离改造）。

角色口径（固定，不引入 role 字段）：
- 系统管理员 = 全局口令 TEACHER_PASSWORD 登录，teacher_session.teacher_id 为 NULL；
- 普通教师 = 账号 + 密码登录，令牌关联 teacher_account.id。

归属判定内核从 routers/teacher.py 平移至此，供教师/账号/班级各路由复用，
避免 routers 之间的横向依赖。
"""
import secrets
from datetime import datetime, timedelta
from typing import Optional

from fastapi import HTTPException
from sqlalchemy import delete, select
from sqlalchemy.orm import Session as OrmSession

from backend.app import models

# T1 固定返回的教师令牌（SPEC.md T1）。任务状态不再保存在进程内。
#: 进程内缓存（快路径 + 测试兼容）。**它不是权威来源**：多 worker 部署或进程
#: 重启后必然缺失，鉴权会回查 teacher_session 表，因此令牌不会随进程内存丢失。
TEACHER_TOKENS: set[str] = set()

#: 教师令牌有效期（小时）。与前端一次 sessionStorage 会话的周期相当。
TEACHER_TOKEN_TTL_HOURS = 12


def current_teacher(db: OrmSession, token: str) -> Optional[models.TeacherAccount]:
    """按令牌解析当前教师账号；全局口令令牌（teacher_id 为 NULL）返回 None（即管理员）。"""
    if not token:
        return None
    row = db.get(models.TeacherSession, token)
    # getattr 兜底：测试用 SimpleNamespace 模拟令牌行时可能没有 teacher_id 属性
    teacher_id = getattr(row, "teacher_id", None)
    if row is None or row.expires_at <= datetime.now() or teacher_id is None:
        return None
    return db.get(models.TeacherAccount, teacher_id)


def is_valid_teacher_token(db: OrmSession, token: str) -> bool:
    """教师令牌校验：先查进程内缓存，未命中再回查 teacher_session 表。

    多 worker 时登录落在 worker A、后续请求轮询到 worker B —— B 的缓存里没有
    该令牌，但数据库里有，因此仍然放行。这正是「登录后被踢出」的根治点。
    """
    if not token:
        return False
    if token in TEACHER_TOKENS:
        return True
    row = db.get(models.TeacherSession, token)
    if row is None:
        return False
    return row.expires_at > datetime.now()


def issue_teacher_token(db: OrmSession, teacher_id: Optional[int] = None) -> str:
    """签发并持久化教师令牌；顺手清理过期记录，避免表单调增长。

    teacher_id 关联 TeacherAccount；全局口令模式（历史部署）为 None。
    """
    now = datetime.now()
    db.execute(delete(models.TeacherSession).where(models.TeacherSession.expires_at <= now))
    token = secrets.token_urlsafe(32)
    db.add(models.TeacherSession(token=token, teacher_id=teacher_id, created_at=now,
                                 expires_at=now + timedelta(hours=TEACHER_TOKEN_TTL_HOURS)))
    db.commit()
    TEACHER_TOKENS.add(token)
    return token


def ensure_admin(db: OrmSession, token: str) -> None:
    """管理员门槛：令牌有效且为全局口令令牌，否则 403。"""
    if not is_valid_teacher_token(db, token):
        raise HTTPException(status_code=403, detail="令牌无效")
    if current_teacher(db, token) is not None:
        raise HTTPException(status_code=403, detail="仅系统管理员可操作")


def case_accessible(teacher: Optional[models.TeacherAccount], case: models.Case) -> bool:
    """案例归属判定内核（与 _get_case_or_fail 同一口径）：

    - 管理员（teacher=None）全量可见；
    - 普通教师可见自己的案例与无归属历史案例（teacher_id NULL，保证老部署不丢数据）。
    """
    if teacher is None:
        return True
    return case.teacher_id in (None, teacher.id)


def class_or_fail(db: OrmSession, teacher: Optional[models.TeacherAccount], class_id: int) -> models.ClassGroup:
    """取班级并做归属校验：普通教师只能访问自己创建的班级（404 隐藏存在性）。"""
    group = db.get(models.ClassGroup, class_id)
    if group is None:
        raise HTTPException(status_code=404, detail="班级不存在")
    if teacher is not None and group.teacher_id != teacher.id:
        raise HTTPException(status_code=404, detail="班级不存在")
    return group


def visible_student_ids(db: OrmSession, teacher: models.TeacherAccount) -> set[int]:
    """普通教师可见的学生集合 = 自己班级的成员 ∪ 自己案例下作答过的学生。

    学生可同时加入多个班级（多对多），因此不做物理归属列，动态推导。
    管理员不需要调用本函数（全量视野）。
    """
    ids: set[int] = set()
    rows = db.execute(
        select(models.ClassMembership.student_id)
        .join(models.ClassGroup, models.ClassGroup.id == models.ClassMembership.class_id)
        .where(models.ClassGroup.teacher_id == teacher.id)
    ).all()
    ids.update(r[0] for r in rows)
    rows = db.execute(
        select(models.Session.student_id)
        .join(models.Case, models.Case.id == models.Session.case_id)
        .where(models.Case.teacher_id == teacher.id, models.Session.student_id.is_not(None))
    ).all()
    ids.update(r[0] for r in rows)
    return ids
