"""案例作答记录的进程内 SSE 事件总线（按 case_id 订阅，T9.5）。

仅在同进程内有效：gunicorn 必须保持 --workers 1（与 TRY_STORE、AI 任务去重
同一条命脉）；多 worker 部署时订阅方收不到其他 worker 里的提交事件。
"""
import asyncio
import json
from collections import defaultdict
from collections.abc import AsyncIterator
from typing import Optional

# 心跳间隔（秒）：链路保活 + 断线探测；测试可 monkeypatch 缩短
HEARTBEAT_INTERVAL = 20.0

# 每个订阅者的待发事件上限：慢消费者丢事件即可，前端收到任一事件都会重拉全量数据
_QUEUE_SIZE = 64

_subscribers: dict[int, set[asyncio.Queue]] = defaultdict(set)

# 教师级频道（2026-10-27）：跨案例聚合看板（班级仪表盘/工作台待办）的失效信号。
# teacher_id=None（系统管理员）注册到独立的管理员桶，广播时全量送达。
_teacher_subscribers: dict[int, set[asyncio.Queue]] = defaultdict(set)
_admin_subscribers: set[asyncio.Queue] = set()


def subscribe(case_id: int) -> asyncio.Queue:
    queue: asyncio.Queue = asyncio.Queue(maxsize=_QUEUE_SIZE)
    _subscribers[case_id].add(queue)
    return queue


def unsubscribe(case_id: int, queue: asyncio.Queue) -> None:
    _subscribers[case_id].discard(queue)
    if not _subscribers[case_id]:
        _subscribers.pop(case_id, None)


def notify_case_records_changed(case_id: int) -> None:
    """S2 decide 落库成功后调用（同事件循环内），向该案例的全部订阅者广播。"""
    payload = json.dumps({"type": "record_changed", "case_id": case_id}, ensure_ascii=False)
    for queue in list(_subscribers.get(case_id, ())):
        try:
            queue.put_nowait(payload)
        except asyncio.QueueFull:
            pass


async def record_event_stream(case_id: int) -> AsyncIterator[str]:
    """SSE 事件流：连上先推一条当前状态，之后转发广播；无事件时按间隔发心跳。"""
    queue = subscribe(case_id)
    try:
        initial = json.dumps({"type": "record_changed", "case_id": case_id}, ensure_ascii=False)
        yield f"data: {initial}\n\n"
        while True:
            try:
                event = await asyncio.wait_for(queue.get(), timeout=HEARTBEAT_INTERVAL)
                yield f"data: {event}\n\n"
            except asyncio.TimeoutError:
                yield f"data: {json.dumps({'type': 'heartbeat'}, ensure_ascii=False)}\n\n"
    finally:
        unsubscribe(case_id, queue)


def subscribe_teacher(teacher_id: Optional[int]) -> asyncio.Queue:
    """教师级订阅：teacher_id=None（系统管理员）进入管理员桶，广播全量送达。"""
    queue: asyncio.Queue = asyncio.Queue(maxsize=_QUEUE_SIZE)
    if teacher_id is None:
        _admin_subscribers.add(queue)
    else:
        _teacher_subscribers[teacher_id].add(queue)
    return queue


def unsubscribe_teacher(teacher_id: Optional[int], queue: asyncio.Queue) -> None:
    if teacher_id is None:
        _admin_subscribers.discard(queue)
    else:
        _teacher_subscribers[teacher_id].discard(queue)
        if not _teacher_subscribers[teacher_id]:
            _teacher_subscribers.pop(teacher_id, None)


def notify_teachers(teacher_ids: set, payload: dict) -> None:
    """向指定教师（及全部管理员）的聚合看板投递失效信号；只发信号不重算指标。"""
    body = json.dumps(payload, ensure_ascii=False)
    targets: set = set(_admin_subscribers)
    for tid in teacher_ids:
        targets |= _teacher_subscribers.get(tid, set())
    for queue in targets:
        try:
            queue.put_nowait(body)
        except asyncio.QueueFull:
            pass


async def teacher_event_stream(teacher_id: Optional[int]) -> AsyncIterator[str]:
    """教师级 SSE 事件流：连上先发一条就绪信号，之后转发广播；无事件按间隔发心跳。"""
    queue = subscribe_teacher(teacher_id)
    try:
        yield f"data: {json.dumps({'type': 'ready'}, ensure_ascii=False)}\n\n"
        while True:
            try:
                event = await asyncio.wait_for(queue.get(), timeout=HEARTBEAT_INTERVAL)
                yield f"data: {event}\n\n"
            except asyncio.TimeoutError:
                yield f"data: {json.dumps({'type': 'heartbeat'}, ensure_ascii=False)}\n\n"
    finally:
        unsubscribe_teacher(teacher_id, queue)
