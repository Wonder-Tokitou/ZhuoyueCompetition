"""T9.5 案例作答记录 SSE：事件总线广播与流格式（进程内，不依赖路由/数据库）。"""
import asyncio
import json

import pytest

from backend.app import record_events


def test_notify_reaches_subscriber_and_cleans_up():
    async def scenario():
        queue = record_events.subscribe(7)
        try:
            record_events.notify_case_records_changed(7)
            event = await asyncio.wait_for(queue.get(), timeout=1)
            assert json.loads(event) == {"type": "record_changed", "case_id": 7}
        finally:
            record_events.unsubscribe(7, queue)
        # 退订后广播不再投递，订阅表回收空桶
        record_events.notify_case_records_changed(7)
        assert 7 not in record_events._subscribers
    asyncio.run(scenario())


def test_notify_isolated_per_case():
    async def scenario():
        q7 = record_events.subscribe(7)
        q9 = record_events.subscribe(9)
        try:
            record_events.notify_case_records_changed(7)
            with pytest.raises(asyncio.TimeoutError):
                await asyncio.wait_for(q9.get(), timeout=0.05)
        finally:
            record_events.unsubscribe(7, q7)
            record_events.unsubscribe(9, q9)
    asyncio.run(scenario())


def test_stream_yields_initial_event_then_heartbeat(monkeypatch):
    monkeypatch.setattr(record_events, "HEARTBEAT_INTERVAL", 0.05)

    async def scenario():
        gen = record_events.record_event_stream(3)
        first = await gen.__anext__()
        assert first.startswith("data: ")
        assert json.loads(first.removeprefix("data: ").strip()) == {"type": "record_changed", "case_id": 3}
        heartbeat = await gen.__anext__()
        assert json.loads(heartbeat.removeprefix("data: ").strip()) == {"type": "heartbeat"}
        # 广播事件插队后立即下发
        record_events.notify_case_records_changed(3)
        third = await gen.__anext__()
        assert json.loads(third.removeprefix("data: ").strip())["case_id"] == 3
        await gen.aclose()

    asyncio.run(scenario())


def test_slow_consumer_drops_events_without_blocking():
    async def scenario():
        queue = record_events.subscribe(11)
        # 塞满队列后再广播：不抛错、不阻塞（慢消费者策略）
        for i in range(record_events._QUEUE_SIZE + 5):
            record_events.notify_case_records_changed(11)
        assert queue.qsize() == record_events._QUEUE_SIZE
        record_events.unsubscribe(11, queue)
    asyncio.run(scenario())
