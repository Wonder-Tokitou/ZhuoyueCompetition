from sqlalchemy import create_engine, inspect, text

from backend.app import migrations
from backend.app import models


def test_legacy_records_preserved_and_not_claimed_by_name(tmp_path, monkeypatch):
    path = tmp_path / 'old.db'
    engine = create_engine('sqlite:///' + path.as_posix())
    with engine.begin() as conn:
        conn.execute(text('CREATE TABLE "case" (id INTEGER PRIMARY KEY, title TEXT)'))
        conn.execute(text('CREATE TABLE "session" (id INTEGER PRIMARY KEY, case_id INTEGER, student_name TEXT)'))
        conn.execute(text('INSERT INTO "case" VALUES (7, :title)'), {'title': '原案例'})
        conn.execute(text('INSERT INTO "session" VALUES (9, 7, :name)'), {'name': '同名学生'})
    monkeypatch.setattr(migrations, 'engine', engine)
    migrations.migrate()
    migrations.migrate()
    assert (tmp_path / 'old.db.bak-v6').exists()
    assert 'student_id' in {c['name'] for c in inspect(engine).get_columns('session')}
    with engine.connect() as conn:
        row = conn.execute(text('SELECT id, student_name, student_id, case_version FROM "session"')).one()
        assert tuple(row) == (9, '同名学生', None, 1)
        assert conn.execute(text('SELECT title FROM "case"')).scalar() == '原案例'
    engine.dispose()


def test_migration_before_seed_on_empty_database(tmp_path, monkeypatch):
    engine = create_engine('sqlite:///' + (tmp_path / 'new.db').as_posix())
    monkeypatch.setattr(migrations, 'engine', engine)
    migrations.migrate()
    models.Base.metadata.create_all(engine)
    migrations.migrate()
    assert {'student_account', 'student_login'} <= set(inspect(engine).get_table_names())
    engine.dispose()


def test_practice_migration_keeps_child_foreign_keys_on_session(tmp_path, monkeypatch):
    """Rebuilding the legacy two-column UNIQUE must not retarget child FKs."""
    engine = create_engine('sqlite:///' + (tmp_path / 'practice-old.db').as_posix())
    with engine.begin() as conn:
        conn.execute(text('CREATE TABLE "case" (id INTEGER PRIMARY KEY)'))
        conn.execute(text('CREATE TABLE student_account (id INTEGER PRIMARY KEY)'))
        conn.execute(text('''
            CREATE TABLE "session" (
                id INTEGER PRIMARY KEY,
                case_id INTEGER NOT NULL REFERENCES "case"(id),
                student_name TEXT NOT NULL,
                student_id INTEGER REFERENCES student_account(id),
                created_at DATETIME NOT NULL,
                finished_at DATETIME,
                attempt_no INTEGER NOT NULL DEFAULT 1,
                UNIQUE(case_id, student_id)
            )'''))
        conn.execute(text('''
            CREATE TABLE turn (
                id INTEGER PRIMARY KEY,
                session_id INTEGER NOT NULL REFERENCES "session"(id)
            )'''))
        conn.execute(text('INSERT INTO "case" (id) VALUES (7)'))
        conn.execute(text('INSERT INTO student_account (id) VALUES (3)'))
        conn.execute(text('''
            INSERT INTO "session" (id, case_id, student_name, student_id, created_at)
            VALUES (9, 7, '学生', 3, CURRENT_TIMESTAMP)
        '''))
        conn.execute(text('INSERT INTO turn (id, session_id) VALUES (4, 9)'))

    monkeypatch.setattr(migrations, 'engine', engine)
    migrations.migrate()
    migrations.migrate()

    with engine.connect() as conn:
        turn_sql = conn.execute(text(
            "SELECT sql FROM sqlite_master WHERE type='table' AND name='turn'"
        )).scalar_one()
        assert 'session_legacy' not in turn_sql
        assert 'REFERENCES "session"' in turn_sql
        assert conn.execute(text('SELECT id, session_id FROM turn')).all() == [(4, 9)]
        conn.exec_driver_sql('PRAGMA foreign_keys=ON')
        conn.execute(text('INSERT INTO turn (id, session_id) VALUES (5, 9)'))
    engine.dispose()


def test_migration_repairs_database_left_by_broken_session_rename(tmp_path, monkeypatch):
    """The deployed broken migration left valid rows pointing at a deleted table."""
    engine = create_engine('sqlite:///' + (tmp_path / 'broken.db').as_posix())
    with engine.begin() as conn:
        conn.execute(text('CREATE TABLE "case" (id INTEGER PRIMARY KEY)'))
        conn.execute(text('CREATE TABLE student_account (id INTEGER PRIMARY KEY)'))
        conn.execute(text('''
            CREATE TABLE "session" (
                id INTEGER PRIMARY KEY,
                case_id INTEGER NOT NULL REFERENCES "case"(id),
                kind TEXT NOT NULL DEFAULT 'formal',
                student_name TEXT NOT NULL,
                student_id INTEGER REFERENCES student_account(id),
                created_at DATETIME NOT NULL,
                finished_at DATETIME,
                attempt_no INTEGER NOT NULL DEFAULT 1,
                case_version INTEGER NOT NULL DEFAULT 1,
                case_snapshot_json JSON NOT NULL DEFAULT '{}',
                current_metrics_json JSON NOT NULL DEFAULT '{}'
            )'''))
        conn.execute(text('''
            CREATE TABLE turn (
                id INTEGER PRIMARY KEY,
                session_id INTEGER NOT NULL REFERENCES "session_legacy"(id)
            )'''))
        conn.execute(text('INSERT INTO "case" (id) VALUES (7)'))
        conn.execute(text('INSERT INTO student_account (id) VALUES (3)'))
        conn.execute(text('''
            INSERT INTO "session" (id, case_id, student_name, student_id, created_at)
            VALUES (9, 7, '学生', 3, CURRENT_TIMESTAMP)
        '''))
        conn.execute(text('INSERT INTO turn (id, session_id) VALUES (4, 9)'))

    monkeypatch.setattr(migrations, 'engine', engine)
    migrations.migrate()

    with engine.connect() as conn:
        broken = conn.execute(text(
            "SELECT name FROM sqlite_master WHERE sql LIKE '%session_legacy%'"
        )).all()
        assert broken == []
        conn.exec_driver_sql('PRAGMA foreign_keys=ON')
        conn.execute(text('INSERT INTO turn (id, session_id) VALUES (5, 9)'))
    engine.dispose()
