"""班级仪表盘聚合接口测试：summary / option-distribution / recent-activity。"""
import pytest
from datetime import datetime
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from fastapi.testclient import TestClient

from backend.app.db import Base, get_db
from backend.app.main import app
from backend.app import models
from backend.app.routers.teacher import issue_teacher_token


@pytest.fixture()
def env(tmp_path, monkeypatch):
    engine = create_engine(f"sqlite:///{tmp_path / 'dash.db'}")
    Base.metadata.create_all(engine)

    def override_get_db():
        with sessionmaker(bind=engine)() as db:
            yield db

    app.dependency_overrides[get_db] = override_get_db
    monkeypatch.setenv("TEACHER_PASSWORD", "secret")
    try:
        yield TestClient(app), engine
    finally:
        app.dependency_overrides.clear()


def _seed(engine):
    with sessionmaker(bind=engine)() as db:
        case = models.Case(
            title="测试案例", source_text="素材", case_type="市场营销类",
            teacher_token="tt-dash", student_token="st-dash",
            background="背景", dilemma="困境", version=2,
        )
        db.add(case); db.flush()
        for idx in (1, 2, 3):
            db.add(models.Node(case_id=case.id, idx=idx, title=f"节点{idx}",
                               scenario="场景", background="节点背景",
                               options_json=[{"option": "A"}, {"option": "B"}],
                               node_role="核心战略"))
        u1 = models.StudentAccount(username="u1", real_name="甲", status="active", password_hash="x")
        u2 = models.StudentAccount(username="u2", real_name="乙", status="active", password_hash="x")
        db.add_all([u1, u2]); db.flush()
        # 已完成：3 轮全走完，末轮 revenue=15
        s1 = models.Session(case_id=case.id, student_name="甲", student_id=u1.id,
                            finished_at=datetime.now(), case_version=2)
        db.add(s1); db.flush()
        for idx, opt in ((1, "A"), (2, "B"), (3, "C")):
            db.add(models.Turn(session_id=s1.id, node_id=case.nodes[idx - 1].id,
                               chosen_option=opt, duration_ms=60000, attempt_no=1,
                               after_metrics_json={"revenue": 15.0, "gross_margin": "60.0%"},
                               result_json={}))
        # 卡在节点 2：只完成 1 轮
        s2 = models.Session(case_id=case.id, student_name="乙", student_id=u2.id, case_version=1)
        db.add(s2); db.flush()
        db.add(models.Turn(session_id=s2.id, node_id=case.nodes[0].id,
                           chosen_option="A", duration_ms=120000, attempt_no=1,
                           after_metrics_json={"revenue": 8.0}, result_json={}))
        db.commit()
        return case.id


def _login(client):
    resp = client.post("/api/teacher/login", json={"password": "secret"})
    assert resp.status_code == 200
    return resp.json()["teacher_token"]


def test_dashboard_summary(env):
    client, engine = env
    _seed(engine)
    token = _login(client)
    resp = client.get("/api/teacher/dashboard/summary", params={"token": token})
    assert resp.status_code == 200
    body = resp.json()
    assert body["total"] == 2
    assert body["completed"] == 1
    assert body["stuck_node2"] == 1
    assert body["avg_revenue"] == 11.5  # (15.0 + 8.0) / 2，两个 session 末轮均带 revenue
    assert body["avg_duration"] == 1.2  # (60000*3 + 120000)/4 / 60000


def test_dashboard_option_distribution(env):
    client, engine = env
    case_id = _seed(engine)
    token = _login(client)
    resp = client.get("/api/teacher/dashboard/option-distribution",
                      params={"case_id": case_id, "token": token})
    assert resp.status_code == 200
    body = resp.json()
    assert body["case_title"] == "测试案例"
    assert body["case_version"] == 2
    assert body["case_count"] == 1
    # 2026-10-27 口径：第一次正式推演 × 3 决策点 × A/B/C = 9 柱
    assert len(body["nodes"]) == 3
    nodes = {n["node_index"]: {o["option"]: o["count"] for o in n["options"]} for n in body["nodes"]}
    assert nodes[1] == {"A": 2, "B": 0, "C": 0}
    assert nodes[2] == {"A": 0, "B": 1, "C": 0}
    assert nodes[3] == {"A": 0, "B": 0, "C": 1}


def test_dashboard_recent_activity(env):
    client, engine = env
    _seed(engine)
    token = _login(client)
    resp = client.get("/api/teacher/dashboard/recent-activity", params={"token": token})
    assert resp.status_code == 200
    items = resp.json()["items"]
    assert len(items) == 2
    first = items[0]
    assert first["label"] == "第1次"
    assert first["case_title"] == "测试案例"
    assert first["case_version"] == 2
    assert first["value"] == 3  # 第 1 个 session 走完 3 轮


def test_dashboard_requires_valid_token(env):
    client, engine = env
    _seed(engine)
    for path in ("/api/teacher/dashboard/summary", "/api/teacher/dashboard/recent-activity"):
        resp = client.get(path, params={"token": "bad"})
        assert resp.status_code == 403


def _make_case(db, title, owner_id):
    case = models.Case(title=title, source_text="素材", case_type="市场营销类",
                       teacher_token="tt-" + title, student_token="st-" + title,
                       background="背景", dilemma="困境", version=1, teacher_id=owner_id)
    db.add(case); db.flush()
    for idx in (1, 2, 3):
        db.add(models.Node(case_id=case.id, idx=idx, title=f"节点{idx}",
                           scenario="场景", background="节点背景",
                           options_json=[{"option": "A"}], node_role="核心战略"))
    return case


def _finish_session(db, case, student):
    s = models.Session(case_id=case.id, student_name=student.real_name,
                       student_id=student.id, finished_at=datetime.now(), case_version=1)
    db.add(s); db.flush()
    for idx, opt in ((1, "A"), (2, "A"), (3, "A")):
        db.add(models.Turn(session_id=s.id, node_id=case.nodes[idx - 1].id,
                           chosen_option=opt, duration_ms=60000, attempt_no=1,
                           after_metrics_json={"revenue": 10.0}, result_json={}))
    return s


def test_dashboard_summary_scoped_by_teacher(env):
    """两个教师各自只看到自己归属案例下的学生数据，互不可见。"""
    client, engine = env
    with sessionmaker(bind=engine)() as db:
        tA = models.TeacherAccount(username="tea", real_name="师A", password_hash="x")
        tB = models.TeacherAccount(username="teb", real_name="师B", password_hash="x")
        db.add_all([tA, tB]); db.flush()
        caseA = _make_case(db, "A案例", tA.id)
        caseB = _make_case(db, "B案例", tB.id)
        u1 = models.StudentAccount(username="u1", real_name="甲", status="active", password_hash="x")
        u2 = models.StudentAccount(username="u2", real_name="乙", status="active", password_hash="x")
        db.add_all([u1, u2]); db.flush()
        # 甲只在 A 案例完成，乙只在 B 案例完成
        _finish_session(db, caseA, u1)
        _finish_session(db, caseB, u2)
        tokA = issue_teacher_token(db, teacher_id=tA.id)
        tokB = issue_teacher_token(db, teacher_id=tB.id)
        db.commit()

    rA = client.get("/api/teacher/dashboard/summary", params={"token": tokA}).json()
    rB = client.get("/api/teacher/dashboard/summary", params={"token": tokB}).json()
    # 各自仅 1 名参与学生、1 名已完成；互不混入对方案例的数据
    assert rA["total"] == 1 and rA["completed"] == 1
    assert rB["total"] == 1 and rB["completed"] == 1
    assert rA["total"] == 1 and rB["total"] == 1


def test_dashboard_recent_activity_scoped_by_teacher(env):
    """最近活跃趋势也只统计当前教师可见案例下的推演。"""
    client, engine = env
    with sessionmaker(bind=engine)() as db:
        tA = models.TeacherAccount(username="tea2", real_name="师A2", password_hash="x")
        tB = models.TeacherAccount(username="teb2", real_name="师B2", password_hash="x")
        db.add_all([tA, tB]); db.flush()
        caseA = _make_case(db, "A案例2", tA.id)
        caseB = _make_case(db, "B案例2", tB.id)
        u1 = models.StudentAccount(username="ua", real_name="甲", status="active", password_hash="x")
        u2 = models.StudentAccount(username="ub", real_name="乙", status="active", password_hash="x")
        db.add_all([u1, u2]); db.flush()
        _finish_session(db, caseA, u1)
        _finish_session(db, caseB, u2)
        tokA = issue_teacher_token(db, teacher_id=tA.id)
        tokB = issue_teacher_token(db, teacher_id=tB.id)
        db.commit()

    itemsA = client.get("/api/teacher/dashboard/recent-activity", params={"token": tokA}).json()["items"]
    itemsB = client.get("/api/teacher/dashboard/recent-activity", params={"token": tokB}).json()["items"]
    assert [i["case_title"] for i in itemsA] == ["A案例2"]
    assert [i["case_title"] for i in itemsB] == ["B案例2"]


def _seed_leaderboard(engine):
    with sessionmaker(bind=engine)() as db:
        case = models.Case(
            title="排行榜案例", source_text="素材", case_type="市场营销类",
            teacher_token="tt-lead", student_token="st-lead",
            background="背景", dilemma="困境", version=1,
        )
        db.add(case); db.flush()
        for idx in (1, 2, 3):
            db.add(models.Node(case_id=case.id, idx=idx, title=f"节点{idx}",
                               scenario="场景", background="节点背景",
                               options_json=[{"option": "A"}, {"option": "B"}],
                               node_role="核心战略"))
        db.add(models.SimulationConfig(
            case_id=case.id,
            draft_json={"reference_path": {"path": "A→B→C", "kind": "recommended"}},
        ))
        u1 = models.StudentAccount(username="lead1", real_name="甲", status="active", password_hash="x")
        u2 = models.StudentAccount(username="lead2", real_name="乙", status="active", password_hash="x")
        db.add_all([u1, u2]); db.flush()
        # 甲：完全匹配推荐路径 A→B→C
        s1 = models.Session(case_id=case.id, student_name="甲", student_id=u1.id,
                            finished_at=datetime.now(), case_version=1)
        db.add(s1); db.flush()
        for idx, opt in ((1, "A"), (2, "B"), (3, "C")):
            db.add(models.Turn(session_id=s1.id, node_id=case.nodes[idx - 1].id,
                               chosen_option=opt, duration_ms=60000, attempt_no=1,
                               after_metrics_json={"revenue": 15.0, "gross_margin": "60.0%",
                                                   "market_share": "18.0%", "cash_flow_amount": 5.0,
                                                   "net_profit": 2.0, "cash_flow": "本期现金净流量 5.00 万元"},
                               result_json={}))
        # 乙：路径 A→A→A，仅 1 轮匹配
        s2 = models.Session(case_id=case.id, student_name="乙", student_id=u2.id,
                            finished_at=datetime.now(), case_version=1)
        db.add(s2); db.flush()
        for idx, opt in ((1, "A"), (2, "A"), (3, "A")):
            db.add(models.Turn(session_id=s2.id, node_id=case.nodes[idx - 1].id,
                               chosen_option=opt, duration_ms=45000, attempt_no=1,
                               after_metrics_json={"revenue": 8.0, "gross_margin": "50.0%",
                                                   "market_share": "12.0%", "cash_flow_amount": 3.0,
                                                   "net_profit": 1.0, "cash_flow": "本期现金净流量 3.00 万元"},
                               result_json={}))
        db.commit()
        return case.id


def test_case_leaderboard(env):
    client, engine = env
    case_id = _seed_leaderboard(engine)
    token = _login(client)
    resp = client.get(f"/api/cases/{case_id}/leaderboard", params={"token": token})
    assert resp.status_code == 200
    body = resp.json()
    assert body["reference_path"] == "A→B→C"
    assert len(body["items"]) == 2
    first, second = body["items"]
    assert first["rank"] == 1 and first["student_name"] == "甲"
    assert first["path"] == "A→B→C" and first["path_score"] == 3 and first["matched"] is True
    assert second["rank"] == 2 and second["student_name"] == "乙"
    assert second["path_score"] == 1 and second["matched"] is False
    assert first["metrics"]["revenue"] == 15.0
    assert first["metrics"]["gross_margin_pct"] == 60.0
    assert first["metrics"]["market_share_pct"] == 18.0
    assert first["metrics"]["cash_flow_amount"] == 5.0
    assert first["metrics"]["net_profit"] == 2.0
    assert first["total_duration_min"] == 3.0  # 60000*3 / 60000


def test_records_include_total_duration(env):
    client, engine = env
    case_id = _seed_leaderboard(engine)
    token = _login(client)
    resp = client.get(f"/api/cases/{case_id}/records", params={"token": token})
    assert resp.status_code == 200
    rows = resp.json()
    assert len(rows) == 2
    by_name = {r["student_name"]: r for r in rows}
    assert by_name["甲"]["total_duration_min"] == 3.0
    assert by_name["乙"]["total_duration_min"] == 2.2  # 45000*3 / 60000 = 2.25 → 2.2
