"""权限与数据隔离（2026-10-27）：角色矩阵、班级/学生隔离、越权修复、迁移幂等。

角色口径：全局口令 TEACHER_PASSWORD 令牌 = 系统管理员（teacher=None）；账号+密码 = 普通教师。
"""
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, inspect, select, text
from sqlalchemy.orm import sessionmaker

from backend.app import models
from backend.app.db import Base
from backend.app.db import get_db
from backend.app.main import app
from backend.app.migrations import migrate


@pytest.fixture()
def env(tmp_path, monkeypatch):
    engine = create_engine(f"sqlite:///{tmp_path / 'perm.db'}", connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine)
    factory = sessionmaker(bind=engine, autoflush=False, autocommit=False)

    def override_db():
        with factory() as db:
            yield db

    app.dependency_overrides[get_db] = override_db
    monkeypatch.setenv("TEACHER_PASSWORD", "admin-secret")
    client = TestClient(app)
    yield client, factory
    app.dependency_overrides.clear()
    client.close()
    engine.dispose()


def _register(client, username, password="teacher-pass"):
    r = client.post("/api/teacher/register", json={
        "username": username, "real_name": username, "password": password, "admin_password": "admin-secret"})
    assert r.status_code == 200, r.text
    return r.json()


def _login(client, username=None, password="admin-secret"):
    body = {"password": password} if username is None else {"username": username, "password": password}
    r = client.post("/api/teacher/login", json=body)
    assert r.status_code == 200, r.text
    return r.json()["teacher_token"]


def test_me_role_admin_vs_teacher(env):
    client, _ = env
    admin = _login(client)
    me = client.get("/api/teacher/me", params={"token": admin}).json()
    assert me["role"] == "admin" and me["teacher"] is None
    _register(client, "teacher_a")
    token = _login(client, "teacher_a", "teacher-pass")
    me = client.get("/api/teacher/me", params={"token": token}).json()
    assert me["role"] == "teacher" and me["teacher"]["username"] == "teacher_a"


def test_accounts_endpoints_admin_only(env):
    client, _ = env
    _register(client, "teacher_a")
    token = _login(client, "teacher_a", "teacher-pass")
    assert client.get("/api/teacher/accounts", params={"token": token}).status_code == 403
    assert client.post("/api/teacher/accounts", params={"token": token},
                       json={"username": "ghost", "real_name": "G", "password": "password1"}).status_code == 403
    admin = _login(client)
    assert client.get("/api/teacher/accounts", params={"token": admin}).status_code == 200
    assert client.post("/api/teacher/accounts", params={"token": admin},
                       json={"username": "teacher_b", "real_name": "B", "password": "password1"}).status_code == 200


def test_class_isolation_and_ownership(env):
    client, factory = env
    _register(client, "teacher_a")
    _register(client, "teacher_b")
    ta = _login(client, "teacher_a", "teacher-pass")
    tb = _login(client, "teacher_b", "teacher-pass")
    cid = client.post("/api/teacher/classes", params={"token": ta}, json={"name": "A班"}).json()["id"]
    # B 看不到 A 的班，也不能操作它（404 隐藏存在性）
    assert all(g["id"] != cid for g in client.get("/api/teacher/classes", params={"token": tb}).json())
    assert client.get(f"/api/teacher/classes/{cid}/members", params={"token": tb}).status_code == 404
    assert client.get(f"/api/teacher/classes/{cid}/qrcode", params={"token": tb}).status_code == 404
    assert client.post(f"/api/teacher/classes/{cid}/members", params={"token": tb},
                       json={"username": "ghost"}).status_code == 404
    admin = _login(client)
    assert any(g["id"] == cid for g in client.get("/api/teacher/classes", params={"token": admin}).json())
    # 建班归属：账号教师建的班 teacher_id=本人；管理员建的班为 NULL
    with factory() as db:
        row = db.scalar(select(models.ClassGroup).where(models.ClassGroup.id == cid))
        assert row.teacher_id is not None
        admin_gid = client.post("/api/teacher/classes", params={"token": admin}, json={"name": "管理班"}).json()["id"]
        assert db.scalar(select(models.ClassGroup).where(models.ClassGroup.id == admin_gid)).teacher_id is None


def test_students_list_scoped(env):
    client, factory = env
    _register(client, "teacher_a")
    _register(client, "teacher_b")
    ta = _login(client, "teacher_a", "teacher-pass")
    tb = _login(client, "teacher_b", "teacher-pass")
    client.post("/api/teacher/students", params={"token": ta},
                json={"username": "s1", "real_name": "生一", "password": "student-pass1", "class_name": ""})
    client.post("/api/teacher/students", params={"token": tb},
                json={"username": "s2", "real_name": "生二", "password": "student-pass1", "class_name": ""})
    ca = client.post("/api/teacher/classes", params={"token": ta}, json={"name": "A班"}).json()["id"]
    cb = client.post("/api/teacher/classes", params={"token": tb}, json={"name": "B班"}).json()["id"]
    assert client.post(f"/api/teacher/classes/{ca}/members", params={"token": ta},
                       json={"username": "s1"}).status_code == 200
    assert client.post(f"/api/teacher/classes/{cb}/members", params={"token": tb},
                       json={"username": "s2"}).status_code == 200
    names_a = {r["username"] for r in client.get("/api/teacher/students", params={"token": ta}).json()}
    names_b = {r["username"] for r in client.get("/api/teacher/students", params={"token": tb}).json()}
    assert "s1" in names_a and "s2" not in names_a
    assert "s2" in names_b and "s1" not in names_b
    admin = _login(client)
    names_admin = {r["username"] for r in client.get("/api/teacher/students", params={"token": admin}).json()}
    assert {"s1", "s2"} <= names_admin


def test_student_status_admin_only(env):
    client, factory = env
    _register(client, "teacher_a")
    ta = _login(client, "teacher_a", "teacher-pass")
    client.post("/api/teacher/students", params={"token": ta},
                json={"username": "s1", "real_name": "生一", "password": "student-pass1", "class_name": ""})
    cid = client.post("/api/teacher/classes", params={"token": ta}, json={"name": "A班"}).json()["id"]
    client.post(f"/api/teacher/classes/{cid}/members", params={"token": ta}, json={"username": "s1"})
    sid = client.get("/api/teacher/students", params={"token": ta}).json()[0]["id"]
    # 改名（非 status 字段）→ 教师对自己的可见学生可行
    assert client.patch(f"/api/teacher/students/{sid}", params={"token": ta},
                        json={"real_name": "新名"}).status_code == 200
    # 停用/启用 → 仅系统管理员
    assert client.patch(f"/api/teacher/students/{sid}", params={"token": ta},
                        json={"status": "disabled"}).status_code == 403
    admin = _login(client)
    assert client.patch(f"/api/teacher/students/{sid}", params={"token": admin},
                        json={"status": "disabled"}).status_code == 200


def test_my_classes_returns_teacher_name(env):
    client, factory = env
    _register(client, "teacher_a")
    ta = _login(client, "teacher_a", "teacher-pass")
    cid = client.post("/api/teacher/classes", params={"token": ta}, json={"name": "A班"}).json()["id"]
    client.post("/api/teacher/students", params={"token": ta},
                json={"username": "s1", "real_name": "生一", "password": "student-pass1", "class_name": ""})
    client.post(f"/api/teacher/classes/{cid}/members", params={"token": ta}, json={"username": "s1"})
    # 学生登录后查已加入班级 → 带教师姓名
    stoken = client.post("/api/student/login", json={"username": "s1", "password": "student-pass1"}).json()["access_token"]
    rows = client.get("/api/student/my-classes", headers={"Authorization": f"Bearer {stoken}"}).json()
    assert rows and rows[0]["name"] == "A班" and rows[0]["teacher_name"] == "teacher_a"


def test_publish_default_personal_and_shared_scope(env, monkeypatch):
    """图7：只有显式发布到校案例库的案例才进共享库；publish 缺省 scope=personal。"""
    client, factory = env
    _register(client, "teacher_a")
    _register(client, "teacher_b")
    ta = _login(client, "teacher_a", "teacher-pass")
    tb = _login(client, "teacher_b", "teacher-pass")
    a_id = client.get("/api/teacher/me", params={"token": ta}).json()["teacher"]["id"]
    from backend.tests.test_teacher_library import _make_publishable
    monkeypatch.setattr("backend.app.routers.teacher.QRCODE_DIR", __import__("pathlib").Path("tmp-qrcode"))
    c_school, _ = _make_publishable(factory, teacher_id=a_id, status="ready")
    # 显式 school → 进共享库
    assert client.post(f"/api/cases/{c_school}/publish", params={"token": ta, "scope": "school"}).status_code == 200
    # B 从共享库复制一份到自己名下（草稿、personal），再以缺省 scope 发布 → 默认 personal
    copied = client.post(f"/api/teacher/cases/{c_school}/copy", params={"token": tb}).json()["case"]["id"]
    with factory() as db:
        db.get(models.Case, copied).status = "ready"
        db.commit()
    assert client.post(f"/api/cases/{copied}/publish", params={"token": tb}).status_code == 200
    shared_b = {row["id"] for row in client.get("/api/teacher/library/shared", params={"token": tb}).json()}
    assert c_school in shared_b and copied not in shared_b
    with factory() as db:
        assert db.get(models.Case, copied).library_scope == "personal"


def test_delete_session_after_unpublish(env, monkeypatch):
    """图4：案例下架/进回收站后，学生仍可删除自己的推演记录（原 404「推演链接无效」）。"""
    client, factory = env
    _register(client, "teacher_a")
    ta = _login(client, "teacher_a", "teacher-pass")
    a_id = client.get("/api/teacher/me", params={"token": ta}).json()["teacher"]["id"]
    from backend.tests.test_teacher_library import _make_publishable
    monkeypatch.setattr("backend.app.routers.teacher.QRCODE_DIR", __import__("pathlib").Path("tmp-qrcode"))
    case_id, student_token = _make_publishable(factory, teacher_id=a_id, status="ready")
    assert client.post(f"/api/cases/{case_id}/publish", params={"token": ta}).status_code == 200
    # 学生登录后开一局并推一步
    from backend.tests.account_helpers import login_student
    login_student(client, factory)
    state = client.post(f"/api/play/{student_token}/sessions", json={"student_name": "小张"}).json()
    node = state["play"]["nodes"][0]
    r = client.post(f"/api/play/{student_token}/decide", json={"session_id": state["session_id"], "student_name": "小张", "node_id": node["id"], "option_key": node["options"][0]["key"], "duration_ms": 10})
    assert r.status_code == 200, r.text
    sid = state["session_id"]
    # 教师软删除案例（下架）
    assert client.delete(f"/api/cases/{case_id}", params={"token": ta}).status_code == 200
    # 学生删除自己的记录 → 修复前 404「推演链接无效」，现在应成功
    assert client.delete(f"/api/play/{student_token}/sessions/{sid}").status_code == 200


def test_create_case_requires_token(env):
    """不带头令牌的 POST /api/cases → 422（token 为必填表单字段），杜绝无主案例。"""
    client, _ = env
    r = client.post("/api/cases", data={"title": "匿名案例", "case_type": "战略决策类", "text": "素材" * 150})
    assert r.status_code == 422


def test_migration_adds_teacher_id_idempotent(tmp_path, monkeypatch):
    db_file = tmp_path / "mig.db"
    raw = create_engine(f"sqlite:///{db_file}", connect_args={"check_same_thread": False})
    Base.metadata.create_all(raw)
    # 模拟旧库：class_group 换成无 teacher_id 列的旧结构（teacher_id 被 FK 引用，无法直接 DROP COLUMN）
    with raw.begin() as conn:
        conn.execute(text("PRAGMA foreign_keys=OFF"))
        conn.execute(text("DROP TABLE class_group"))
        conn.execute(text(
            "CREATE TABLE class_group (id INTEGER PRIMARY KEY, name VARCHAR(64) NOT NULL, "
            "join_code VARCHAR(32) NOT NULL UNIQUE, created_at DATETIME NOT NULL)"))
        conn.execute(text("INSERT INTO class_group (name, join_code, created_at) VALUES ('旧班级', 'code-legacy-1', CURRENT_TIMESTAMP)"))
    monkeypatch.setattr("backend.app.migrations.engine", raw)
    migrate()
    cols = {c["name"] for c in inspect(raw).get_columns("class_group")}
    assert "teacher_id" in cols
    # 存量班级不回填归属（保持 NULL = 管理员视野）
    with raw.connect() as conn:
        assert conn.execute(text("SELECT teacher_id FROM class_group WHERE name='旧班级'")).scalar() is None
    # 幂等：重复执行不报错、列不重复
    migrate()
    assert len([c for c in inspect(raw).get_columns("class_group") if c["name"] == "teacher_id"]) == 1
    raw.dispose()
