"""多次推演独立记录（文档 4.1）：重新推演不覆盖历史，教师端可按次查看。"""
from backend.tests.test_student_workflow import URL, begin, complete, env  # noqa: F401 (env 是 fixture)
from backend.tests.teacher_helpers import login_teacher


def test_restart_creates_a_new_record_and_keeps_history(env):
    client, _ = env
    first = complete(client, begin(client))

    restart = client.post(URL + '/sessions/%s/reset' % first)
    assert restart.status_code == 200, restart.text
    second = restart.json()['session_id']
    assert second != first
    assert restart.json()['turns'] == []

    # 旧记录原样保留
    old = client.get(URL + '/sessions/%s' % first).json()
    assert len(old['turns']) == 3 and old['finished']
    # 记录列表两条，且按次区分
    records = client.get('/api/student/records').json()
    assert len(records) == 2
    assert {row['session_id'] for row in records} == {first, second}
    assert sorted(row['attempt_no'] for row in records) == [1, 2]


def test_second_run_does_not_touch_first_run_turns(env):
    client, _ = env
    first = complete(client, begin(client))
    before = client.get(URL + '/sessions/%s' % first).json()['turns']
    second = client.post(URL + '/sessions/%s/reset' % first).json()
    state = {'session_id': second['session_id'], 'play': second['play']}
    complete(client, state)

    after = client.get(URL + '/sessions/%s' % first).json()['turns']
    assert [t['chosen_option'] for t in after] == [t['chosen_option'] for t in before]
    assert len(client.get(URL + '/sessions/%s' % second['session_id']).json()['turns']) == 3


def test_teacher_records_list_every_attempt(env, monkeypatch):
    client, _ = env
    token = login_teacher(client, monkeypatch)
    case_id = client.get('/api/cases', params={'token': token}).json()[0]['id']
    first = complete(client, begin(client))
    second = client.post(URL + '/sessions/%s/reset' % first).json()['session_id']
    complete(client, {'session_id': second, 'play': client.get(URL + '/sessions/%s' % second).json()['play']})

    rows = client.get('/api/cases/%s/records' % case_id, params={'token': token}).json()
    assert len(rows) == 2
    assert {row['session_id'] for row in rows} == {first, second}
    assert all(len(row['turns']) == 3 for row in rows)


def test_leaderboard_keeps_one_row_per_student_and_counts_attempts(env, monkeypatch):
    client, _ = env
    token = login_teacher(client, monkeypatch)
    case_id = client.get('/api/cases', params={'token': token}).json()[0]['id']
    first = complete(client, begin(client))
    second = client.post(URL + '/sessions/%s/reset' % first).json()['session_id']
    complete(client, {'session_id': second, 'play': client.get(URL + '/sessions/%s' % second).json()['play']})

    board = client.get('/api/cases/%s/leaderboard' % case_id, params={'token': token}).json()
    assert len(board['items']) == 1, '同一学生多次推演不应占用多行'
    assert board['items'][0]['total_attempts'] == 2


def test_play_locked_case_still_rejects_restart(env, monkeypatch):
    client, _ = env
    token = login_teacher(client, monkeypatch)
    case_id = client.get('/api/cases', params={'token': token}).json()[0]['id']
    first = begin(client)
    client.post(f'/api/cases/{case_id}/play-lock', params={'token': token}, json={'locked': True})
    assert client.post(URL + '/sessions/%s/reset' % first['session_id']).status_code == 403
