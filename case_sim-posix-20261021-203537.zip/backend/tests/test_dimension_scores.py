"""维度评分推导单测：确定性、按框架区分、无数据兜底。"""
from backend.app.domain.dimension_scores import compute_dimension_scores
from backend.app.domain import rules


def _comparison(student, reference):
    return {
        "kind": "historical",
        "rounds": [
            {"round": 1, "student_metrics": student, "reference_metrics": reference,
             "student_strategy": "A", "reference_strategy": "B", "same": False, "difference": {}},
            {"round": 2, "student_metrics": student, "reference_metrics": reference,
             "student_strategy": "A", "reference_strategy": "B", "same": False, "difference": {}},
            {"round": 3, "student_metrics": student, "reference_metrics": reference,
             "student_strategy": "A", "reference_strategy": "B", "same": False, "difference": {}},
        ],
    }


STUDENT = {"revenue": 15.0, "gross_margin": "65.0%", "market_share": "24.0%",
           "net_profit": 3.6, "cash_flow_amount": 1.8}
REFERENCE = {"revenue": 12.0, "gross_margin": "62.0%", "market_share": "20.0%",
             "net_profit": 2.4, "cash_flow_amount": 1.2}


def test_swot_five_dimensions_ordered():
    scores = compute_dimension_scores("SWOT分析模型", _comparison(STUDENT, REFERENCE))
    names = [s["name"] for s in scores]
    assert names == rules.FRAMEWORK_DIMENSIONS["SWOT分析模型"]
    assert len(names) == 5
    by = {s["name"]: s["score"] for s in scores}
    # 学生全面优于参考：优势=最强指标（市场份额 24/20=120→100），劣势=最弱（现金流 150→100 前为最低? 全超100→clamp 100）
    assert by["优势（S）"] == 100.0
    assert by["综合结论"] == 100.0  # 净利润 3.6/2.4=150 → clamp 100


def test_four_p_mapping():
    scores = compute_dimension_scores("4P营销理论", _comparison(STUDENT, REFERENCE))
    by = {s["name"]: s["score"] for s in scores}
    assert list(by.keys()) == rules.FRAMEWORK_DIMENSIONS["4P营销理论"]
    # 产品=毛利率 65/62≈104.8→100；价格=营收 15/12=125→100
    assert by["产品（Product）"] == 100.0
    assert by["价格（Price）"] == 100.0


def test_break_even_four_dimensions():
    scores = compute_dimension_scores("盈亏平衡分析", _comparison(STUDENT, REFERENCE))
    names = [s["name"] for s in scores]
    assert names == rules.FRAMEWORK_DIMENSIONS["盈亏平衡分析"]
    assert len(names) == 4


def test_student_worse_than_reference_scores_below_100():
    worse = {"revenue": 9.0, "gross_margin": "50.0%", "market_share": "15.0%",
             "net_profit": 1.0, "cash_flow_amount": 0.5}
    scores = compute_dimension_scores("4P营销理论", _comparison(worse, REFERENCE))
    by = {s["name"]: s["score"] for s in scores}
    assert by["价格（Price）"] == 75.0  # 9/12=75
    assert by["产品（Product）"] == round(50.0 / 62.0 * 100, 1)  # ≈80.6
    assert by["渠道（Place）"] == 75.0  # 15/20=75
    assert by["综合结论"] == round(1.0 / 2.4 * 100, 1)  # ≈41.7


def test_no_comparison_returns_empty():
    assert compute_dimension_scores("4P营销理论", None) == []
    assert compute_dimension_scores("SWOT分析模型", {}) == []
    assert compute_dimension_scores("SWOT分析模型", {"rounds": []}) == []


def test_unknown_framework_returns_empty():
    assert compute_dimension_scores("不存在框架", _comparison(STUDENT, REFERENCE)) == []


def test_percentage_string_and_negative_profit():
    student = dict(STUDENT, net_profit=-1.0)
    scores = compute_dimension_scores("盈亏平衡分析", _comparison(student, REFERENCE))
    by = {s["name"]: s["score"] for s in scores}
    assert by["盈利端"] == 0.0  # 负值 clamp 到 0


def test_missing_reference_metrics_uses_100():
    student = dict(STUDENT, cash_flow_amount=2.0)
    reference = dict(REFERENCE, cash_flow_amount=None)
    scores = compute_dimension_scores("4P营销理论", _comparison(student, reference))
    by = {s["name"]: s["score"] for s in scores}
    assert by["促销（Promotion）"] == 100.0
