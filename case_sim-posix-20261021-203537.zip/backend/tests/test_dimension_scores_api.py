"""复盘接口 dimension_scores 集成测试：真实推演 → 复盘成功 → 按框架返回真实分数。"""
import pytest
from sqlalchemy import select

from backend.app import models
from backend.app.domain import rules
from backend.tests.test_student_workflow import env, begin, URL
from backend.tests.test_progressive import setup_case

DIMENSIONS_4P = rules.FRAMEWORK_DIMENSIONS["4P营销理论"]
DIMENSIONS_SWOT = rules.FRAMEWORK_DIMENSIONS["SWOT分析模型"]
DIMENSIONS_BE = rules.FRAMEWORK_DIMENSIONS["盈亏平衡分析"]


def _finish_play(client, state):
    """沿三轮节点提交决策（每节点选 A），使会话完成。"""
    for node in state["play"]["nodes"]:
        r = client.post(URL + "/decide", json=dict(
            session_id=state["session_id"], student_name="student",
            node_id=node["id"], option_key="A", duration_ms=1))
        assert r.status_code == 200, r.text


def _insert_review(factory, session_id, framework_type):
    with factory() as db:
        dims = [{"name": n, "content": f"结合本次决策的{n}分析"} for n in rules.FRAMEWORK_DIMENSIONS[framework_type]]
        db.add(models.Review(session_id=session_id, attempt_no=1,
                             framework_type=framework_type, dimensions_json=dims,
                             conclusion="整体评价与可执行改进"))
        db.commit()


def _get_review(client, state):
    return client.get(URL + f"/review?session_id={state['session_id']}")


def _with_reference_path(factory):
    """给 seed 案例追加带 reference_path 的仿真配置（复用 progressive setup）。"""
    case_id, config, _ = setup_case(factory)
    with factory() as db:
        row = db.get(models.SimulationConfig, case_id)
        cfg = row.draft_json
        cfg["reference_path"] = {"path": "A→B→A", "kind": "recommended"}
        from backend.app.services.simulation import prepare
        case = db.get(models.Case, case_id)
        snap, _ = prepare(case, cfg)
        row.draft_json = cfg
        row.published_snapshot_json = snap
        db.commit()
    return case_id


def test_review_returns_four_p_dimension_scores(env):
    client, factory = env
    _with_reference_path(factory)
    state = begin(client)
    _finish_play(client, state)
    _insert_review(factory, state["session_id"], "4P营销理论")
    r = _get_review(client, state)
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["status"] == "succeeded"
    scores = body["dimension_scores"]
    assert [s["name"] for s in scores] == DIMENSIONS_4P
    assert all(isinstance(s["score"], (int, float)) and 0 <= s["score"] <= 100 for s in scores)


def test_review_swot_five_scores(env):
    client, factory = env
    _with_reference_path(factory)
    state = begin(client)
    _finish_play(client, state)
    _insert_review(factory, state["session_id"], "SWOT分析模型")
    r = _get_review(client, state)
    assert r.status_code == 200
    scores = r.json()["dimension_scores"]
    assert [s["name"] for s in scores] == DIMENSIONS_SWOT
    assert len(scores) == 5


def test_review_break_even_four_scores(env):
    client, factory = env
    _with_reference_path(factory)
    state = begin(client)
    _finish_play(client, state)
    _insert_review(factory, state["session_id"], "盈亏平衡分析")
    r = _get_review(client, state)
    assert r.status_code == 200
    scores = r.json()["dimension_scores"]
    assert [s["name"] for s in scores] == DIMENSIONS_BE
    assert len(scores) == 4


def test_review_no_comparison_returns_empty_scores(env):
    """未配置参考路径（无 path_comparison）时 dimension_scores 为空数组，不渲染雷达图。"""
    client, factory = env
    state = begin(client)
    _finish_play(client, state)
    _insert_review(factory, state["session_id"], "4P营销理论")
    r = _get_review(client, state)
    assert r.status_code == 200
    assert r.json()["dimension_scores"] == []
