"""复盘雷达图维度评分：按案例分析框架，从推演真实指标确定性推导 0-100 分。

设计原则
- 分数完全来自学生本次推演与参考路径的数值对比（path_comparison.rounds），
  不依赖 AI 输出、不产生 mock 假数据；无对比数据时返回空列表，前端不渲染雷达图。
- 三类框架（SWOT / 4P / 盈亏平衡）维度名取自 rules.FRAMEWORK_DIMENSIONS，
  每个维度映射到可解释的财务子分，保证「指标口径一致、图表随框架不同」。
"""
from typing import Any, Dict, List, Optional
from backend.app.domain import rules

_MAX = 100.0


def _to_number(value: Any, default: Optional[float] = None) -> Optional[float]:
    """兼容数值与 '62.0%' / '20.5%' 字符串百分比。"""
    if value is None:
        return default
    if isinstance(value, bool):
        return default
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        s = value.strip().rstrip("%").strip()
        try:
            return float(s)
        except ValueError:
            return default
    return default


def _clamp(x: Optional[float], default: float = 100.0) -> float:
    if x is None or not _is_finite(x):
        return default
    return round(min(max(x, 0.0), _MAX), 1)


def _is_finite(x: float) -> bool:
    import math
    return math.isfinite(x)


def _ratio(student: Optional[float], reference: Optional[float]) -> Optional[float]:
    """学生相对参考路径的达成率（百分制）。参考缺失或为 0 时按 100 处理（视为持平）。"""
    if student is None:
        return None
    if reference is None or reference == 0:
        return 100.0
    return student / reference * 100.0


def _round_metrics(comparison: Optional[Dict[str, Any]]) -> Dict[str, Dict[str, Optional[float]]]:
    """聚合末轮学生/参考的数值指标。取末轮（最终经营结果）作为评分依据。"""
    if not comparison:
        return {}
    rounds = comparison.get("rounds") or []
    if not rounds:
        return {}
    last = rounds[-1]
    out: Dict[str, Dict[str, Optional[float]]] = {"student": {}, "reference": {}}
    for side, key in (("student", "student_metrics"), ("reference", "reference_metrics")):
        m = last.get(key) or {}
        out[side]["revenue"] = _to_number(m.get("revenue"))
        out[side]["gross_margin"] = _to_number(m.get("gross_margin"))
        out[side]["market_share"] = _to_number(m.get("market_share"))
        out[side]["net_profit"] = _to_number(m.get("net_profit"))
        out[side]["cash_flow_amount"] = _to_number(m.get("cash_flow_amount"))
    return out


def _financial_scores(metrics: Dict[str, Dict[str, Optional[float]]]) -> Dict[str, float]:
    """五个财务子分（0-100）：营收 / 毛利率 / 市场份额 / 净利润 / 现金流。"""
    s, r = metrics.get("student", {}), metrics.get("reference", {})
    return {
        "revenue": _clamp(_ratio(s.get("revenue"), r.get("revenue"))),
        "margin": _clamp(_ratio(s.get("gross_margin"), r.get("gross_margin"))),
        "share": _clamp(_ratio(s.get("market_share"), r.get("market_share"))),
        "profit": _clamp(_ratio(s.get("net_profit"), r.get("net_profit"))),
        "cash": _clamp(_ratio(s.get("cash_flow_amount"), r.get("cash_flow_amount"))),
    }


def _framework_score_map(framework: str, fin: Dict[str, float]) -> Optional[Dict[str, float]]:
    """框架维度 → 财务子分映射。未知框架返回 None（不渲染）。"""
    dims = rules.FRAMEWORK_DIMENSIONS.get(framework)
    if not dims:
        return None
    fin_values = [fin[k] for k in ("revenue", "margin", "share", "profit", "cash")]
    if framework == "SWOT分析模型":
        # 优势=最强指标、劣势=最弱指标、机会=营收与份额的成长面、威胁=现金流压力、综合=净利润
        return {
            "优势（S）": max(fin_values),
            "劣势（W）": min(fin_values),
            "机会（O）": round((fin["revenue"] + fin["share"]) / 2, 1),
            "威胁（T）": fin["cash"],
            "综合结论": fin["profit"],
        }
    if framework == "4P营销理论":
        # 产品=毛利率、价格=营收、渠道=市场份额、促销=现金流、综合=净利润
        return {
            "产品（Product）": fin["margin"],
            "价格（Price）": fin["revenue"],
            "渠道（Place）": fin["share"],
            "促销（Promotion）": fin["cash"],
            "综合结论": fin["profit"],
        }
    if framework == "盈亏平衡分析":
        # 成本端=毛利率（成本控制）、销量端=营收、盈利端=净利润、综合=五项平均
        avg = round(sum(fin_values) / len(fin_values), 1)
        return {
            "成本端": fin["margin"],
            "销量端": fin["revenue"],
            "盈利端": fin["profit"],
            "综合结论": avg,
        }
    return None


def compute_dimension_scores(framework: str, comparison: Optional[Dict[str, Any]]) -> List[Dict[str, float]]:
    """按框架输出 [{name, score}]；无对比数据或未知框架时返回 []。"""
    metrics = _round_metrics(comparison)
    if not metrics:
        return []
    fin = _financial_scores(metrics)
    mapping = _framework_score_map(framework, fin)
    if not mapping:
        return []
    return [{"name": name, "score": mapping[name]} for name in rules.FRAMEWORK_DIMENSIONS[framework]]
