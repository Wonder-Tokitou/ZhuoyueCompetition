/**
 * 角色头像栏：推演页顶部显示三个角色，当前回合对应的角色高亮。
 * 纯展示组件，不请求任何数据。
 */

type RosterMember = {
  key: string
  face: string
  name: string
}

const ROSTER: RosterMember[] = [
  { key: 'manager', face: '👩‍💼', name: '店长' },
  { key: 'finance', face: '👨‍🔬', name: '财务总监' },
  { key: 'marketing', face: '🧑‍🚀', name: '市场经理' },
]

export default function RosterBar({ activeRole }: { activeRole?: string }) {
  return (
    <div className="roster-bar" role="group" aria-label="决策团队">
      {ROSTER.map((m) => (
        <div key={m.key} className={`roster-avatar ${activeRole === m.key ? 'is-active' : ''}`}>
          <div className="roster-avatar-face" aria-hidden="true">{m.face}</div>
          <div className="roster-avatar-name">{m.name}</div>
        </div>
      ))}
    </div>
  )
}
