/**
 * 办公室场景推演背景：按用户mockup实现。
 * 米色墙壁 + 窗户 + 办公桌 + 三个角色站位 + 右上角数值条。
 */

type OfficeSceneProps = {
  activeRole?: string
  scores?: { manager: number; finance: number; marketing: number }
}

export default function OfficeScene({ activeRole, scores }: OfficeSceneProps) {
  return (
    <div className="office-scene" aria-hidden="true">
      {/* 墙壁 */}
      <div className="office-wall">
        {/* 窗户 */}
        <div className="office-window">
          <div className="window-pane" />
          <div className="window-pane" />
        </div>

        {/* 右上角：角色数值条 */}
        <div className="office-stats">
          <div className="stat-row">
            <span className="stat-label">店长</span>
            <div className="stat-bar"><div className="stat-fill" style={{ width: `${scores?.manager ?? 70}%`, background: '#ec4899' }} /></div>
            <span className="stat-value">{scores?.manager ?? 70}</span>
          </div>
          <div className="stat-row">
            <span className="stat-label">财务</span>
            <div className="stat-bar"><div className="stat-fill" style={{ width: `${scores?.finance ?? 60}%`, background: '#3b82f6' }} /></div>
            <span className="stat-value">{scores?.finance ?? 60}</span>
          </div>
          <div className="stat-row">
            <span className="stat-label">市场</span>
            <div className="stat-bar"><div className="stat-fill" style={{ width: `${scores?.marketing ?? 65}%`, background: '#8b5cf6' }} /></div>
            <span className="stat-value">{scores?.marketing ?? 65}</span>
          </div>
        </div>

        {/* 三个角色 */}
        <div className={`office-character char-finance ${activeRole === 'finance' ? 'is-active' : ''}`}>
          <div className="char-face">👨‍🔬</div>
          <div className="char-name">财务</div>
        </div>
        <div className={`office-character char-manager ${activeRole === 'manager' ? 'is-active' : ''}`}>
          <div className="char-desk" />
          <div className="char-face">👩‍💼</div>
          <div className="char-name">店长</div>
        </div>
        <div className={`office-character char-marketing ${activeRole === 'marketing' ? 'is-active' : ''}`}>
          <div className="char-face">🧑‍🚀</div>
          <div className="char-name">市场</div>
        </div>
      </div>

      {/* 地板 */}
      <div className="office-floor">
        <div className="floor-desk desk-left" />
        <div className="floor-desk desk-right" />
      </div>
    </div>
  )
}
