import { Button, Modal, Typography } from 'antd'
import type { DecisionNarrative } from '../../../domain/decisionNarrative'

/**
 * U1 即时结算单：提交成功后弹出，讲清「为什么涨、为什么跌、下一轮看什么」。
 *
 * 走查报告 P1-5 之后的两条红线（见 docs/ui-baseline/text-assertions.md 的 F23 / 阶段共用红线 2）：
 * 1. 必须用 Modal，不能用 Alert —— 页面内唯一 success Alert（原「本轮结果」）已按 P1-5 移除，
 *    本轮结果反馈统一由结算卡承担；student-play 用例对 success Alert 的数量断言已同步更新。
 * 2. 关闭后不清空页面的 showResult，「继续下一回合」按钮保持不变。
 */
export default function SettlementCard({ open, round, chosenLabel, narrative, onClose }: {
  open: boolean
  round: number
  chosenLabel: string
  narrative: DecisionNarrative | null
  onClose: () => void
}) {
  return <Modal open={open} title={`本轮结算 · 第 ${round} 轮`} onCancel={onClose}
    className="settlement-modal"
    footer={<Button type="primary" block onClick={onClose}>继续</Button>}>
    {narrative && <div className="settlement-card">
      <Typography.Paragraph><Typography.Text type="secondary">你的决策</Typography.Text><br />
        <Typography.Text strong>{chosenLabel}</Typography.Text></Typography.Paragraph>
      <Typography.Paragraph><Typography.Text type="secondary">数字变化</Typography.Text><br />
        <span className="settlement-delta">{narrative.deltaText}</span></Typography.Paragraph>
      <Typography.Paragraph><Typography.Text type="secondary">为什么</Typography.Text><br />
        {narrative.why}</Typography.Paragraph>
      <Typography.Paragraph><Typography.Text type="secondary">下一轮关注</Typography.Text><br />
        {narrative.nextFocus}</Typography.Paragraph>
    </div>}
  </Modal>
}
