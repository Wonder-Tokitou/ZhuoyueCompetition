/**
 * 复盘可视化：按案例分析框架渲染的雷达图 + 3 轮净利润对比折线图。
 * ECharts 按需引入：只注册用到的图表、组件与 Canvas 渲染器，禁止 `import * as echarts from 'echarts'` 全量引入。
 * 数据来源（全部为真实数据，无 mock）：
 *  - 雷达图：后端 ReviewResponse.dimension_scores（按框架 SWOT 5 / 4P 5 / 盈亏平衡 4 维度，
 *    由后端从推演指标确定性推导）；为空时不渲染雷达图，只展示提示，不画假数据。
 *  - 折线图：path_comparison.rounds 每轮 student_metrics / reference_metrics 的 net_profit；
 *    数据不全时不渲染折线图，只展示提示。
 */
import { useEffect, useRef } from 'react'
import * as echarts from 'echarts/core'
import { LineChart, RadarChart } from 'echarts/charts'
import { GridComponent, LegendComponent, TitleComponent, TooltipComponent } from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'
import type { EChartsOption } from 'echarts'
import type { ReviewResponse } from '../../api/types'

echarts.use([RadarChart, LineChart, GridComponent, TooltipComponent, LegendComponent, TitleComponent, CanvasRenderer])

/** 轻量 ECharts React 封装：挂载时 init，option 变化时 setOption，卸载时 dispose，窗口 resize 时自适应。 */
function EChart({ option, height }: { option: EChartsOption; height: number }) {
  const elRef = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const el = elRef.current
    if (!el) return
    const chart = echarts.init(el)
    chart.setOption(option)
    const onResize = () => chart.resize()
    window.addEventListener('resize', onResize)
    return () => {
      window.removeEventListener('resize', onResize)
      chart.dispose()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- 仅在挂载时 init 一次
  }, [])
  useEffect(() => {
    const el = elRef.current
    if (!el) return
    const chart = echarts.getInstanceByDom(el)
    if (chart) chart.setOption(option)
  }, [option])
  return <div ref={elRef} style={{ height, width: '100%' }} />
}

export interface RadarScoreChartProps {
  /** 后端按框架下发的维度评分；为空数组时提示"暂无维度评分"，不渲染雷达图。 */
  scores: { name: string; score: number }[]
  /** 案例分析框架名（SWOT分析模型 / 4P营销理论 / 盈亏平衡分析），用于标题与维度展示。 */
  frameworkType?: string
  height?: number
}

/** 按案例分析框架渲染的维度评分雷达图（每维 max=100）。 */
export function RadarScoreChart({ scores, frameworkType = '', height = 280 }: RadarScoreChartProps) {
  if (!scores || scores.length === 0) {
    return (
      <div style={{ width: '100%', padding: '24px 16px', textAlign: 'center', color: 'rgba(0,0,0,0.45)', fontSize: 13, border: '1px dashed #d3dbe6', borderRadius: 14, background: 'linear-gradient(180deg, #fbfcfe 0%, #f6f8fc 100%)', lineHeight: 1.8 }}>
        <div style={{ fontSize: 26, lineHeight: 1, marginBottom: 8, opacity: 0.55 }}>◎</div>
        {frameworkType ? `${frameworkType} · ` : ''}暂无维度评分数据，完成推演并生成复盘后展示。
      </div>
    )
  }
  const option: EChartsOption = {
    tooltip: {},
    legend: { data: ['综合得分'], bottom: 0, itemWidth: 14, itemHeight: 10 },
    radar: {
      indicator: scores.map((s) => ({ name: s.name, max: 100 })),
      // 窄容器下长维度名在圆周上相邻标签会水平重叠：
      // ① radius 由 62% 缩至 55%，外圈标签留出更多空间；
      // ② axisName.formatter 把 4 字及以上维度名拆成多行（如"优势（S）"→"优势\n（S）"），
      //    水平跨度减半且纵向错开，相邻标签不再互相挤压。
      radius: '55%',
      axisName: {
        color: '#1a3a5c',
        fontSize: 11,
        formatter: (name?: string) => {
          const n = name ?? ''
          if (n.length <= 2) return n
          const half = Math.ceil(n.length / 2)
          return `${n.slice(0, half)}\n${n.slice(half)}`
        },
      },
      splitLine: { lineStyle: { color: '#dbe4ee' } },
      splitArea: { areaStyle: { color: ['rgba(26, 58, 92, 0.03)', 'rgba(26, 58, 92, 0.07)'] } },
      axisLine: { lineStyle: { color: '#dbe4ee' } },
    },
    series: [
      {
        type: 'radar',
        data: [
          {
            value: scores.map((s) => s.score),
            name: '综合得分',
            areaStyle: { color: 'rgba(26, 58, 92, 0.25)' },
            lineStyle: { color: '#1a3a5c', width: 2 },
            itemStyle: { color: '#1a3a5c' },
          },
        ],
      },
    ],
  }
  return (
    <div style={{ width: '100%' }}>
      <EChart option={option} height={height} />
    </div>
  )
}

export interface RoundLineChartProps {
  /** 复盘接口的路径对比（含每轮学生/参考指标）；数据不全时提示，不画假数据。 */
  pathComparison?: ReviewResponse['path_comparison']
  height?: number
}

/** 3 轮净利润对比折线图：我的路径（深蓝 #1a3a5c）vs 标杆路径（玫红 #db2777）。 */
export function RoundLineChart({ pathComparison, height = 220 }: RoundLineChartProps) {
  const rounds = pathComparison?.rounds ?? []
  const mine = rounds.map((r) => Number(r.student_metrics.net_profit)).filter((n) => Number.isFinite(n))
  const ref = rounds.map((r) => Number(r.reference_metrics.net_profit)).filter((n) => Number.isFinite(n))
  if (rounds.length === 0 || mine.length !== rounds.length || ref.length !== rounds.length) {
    return (
      <div style={{ width: '100%', padding: '24px 16px', textAlign: 'center', color: 'rgba(0,0,0,0.45)', fontSize: 13, border: '1px dashed #d3dbe6', borderRadius: 14, background: 'linear-gradient(180deg, #fbfcfe 0%, #f6f8fc 100%)', lineHeight: 1.8 }}>
        <div style={{ fontSize: 26, lineHeight: 1, marginBottom: 8, opacity: 0.55 }}>↗</div>
        暂无完整净利润数据，完成推演并生成复盘后展示走势对比。
      </div>
    )
  }
  const labels = rounds.map((r) => `第 ${r.round} 轮`)
  const option: EChartsOption = {
    tooltip: { trigger: 'axis' },
    // 图例置顶（top:4, left:center）+ 圆点图例图标，X 轴标签独占底部，两条折线的标识互不遮挡。
    legend: { data: ['我的路径', '标杆路径'], top: 4, left: 'center', icon: 'circle', itemWidth: 14, itemHeight: 10, itemGap: 28 },
    grid: { left: 8, right: 8, top: 40, bottom: 8, containLabel: true },
    xAxis: { type: 'category', boundaryGap: false, data: labels },
    yAxis: { type: 'value', name: '净利润（万元）', nameTextStyle: { color: 'rgba(0,0,0,0.45)', fontSize: 11 }, splitLine: { lineStyle: { color: '#eef2f6' } } },
    series: [
      { name: '我的路径', type: 'line', smooth: true, symbol: 'circle', symbolSize: 6, data: mine, lineStyle: { color: '#1a3a5c', width: 2 }, itemStyle: { color: '#1a3a5c' } },
      { name: '标杆路径', type: 'line', smooth: true, symbol: 'circle', symbolSize: 6, data: ref, lineStyle: { color: '#db2777', width: 2 }, itemStyle: { color: '#db2777' } },
    ],
  }
  return (
    <div style={{ width: '100%' }}>
      <EChart option={option} height={height} />
    </div>
  )
}

export default RadarScoreChart
