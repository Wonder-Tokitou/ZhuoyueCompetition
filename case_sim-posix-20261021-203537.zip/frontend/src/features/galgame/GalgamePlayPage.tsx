/**
 * galgame 支线主页（阶段 4 实现）。
 * 流程：封面对话 → 开始营业（startStudent）→ 幕前对话 → 选项 → 反应对话 →
 * 财务追问（理由采集）→ decide → restore → 结算卡 → 下一幕；3 轮后 finished。
 * 落库仍走主线 decide，提交体 { student_name, session_id, node_id, option_key, input_text, duration_ms }；
 * 门闩 busy/uncertain/nodeId 三元组防重复提交；decide 失败先 restore 核对，绝不盲目重试。
 *
 * P2-D1：状态机与 API 调用抽到 engine/useGalgameFlow.ts；六个阶段视图拆到 phases/。
 */
import { useNavigate } from 'react-router-dom'
import { useGalgameFlow } from './engine/useGalgameFlow'
import CoverView from './phases/CoverView'
import LinesView from './phases/LinesView'
import ChoiceView from './phases/ChoiceView'
import ResultView from './phases/ResultView'
import EndingView from './phases/EndingView'
import EventView from './phases/EventView'
import './galgame.css'

export default function GalgamePlayPage() {
  const f = useGalgameFlow()
  const nav = useNavigate()

  if (f.loading) {
    return <div className="galgame-loading">加载中…</div>
  }

  const activeId = f.currentLine && f.currentLine.speaker !== null
    ? (f.currentLine.speaker === '店长' ? 'manager' : f.currentLine.speaker === '财务' ? 'cfo' : 'cmo')
    : null
  const activeDuringReason = f.phase === 'reason' ? 'cfo' : activeId
  const cashFlow = f.state?.financial_state?.cash_flow_amount ?? null
  const lastTurn = f.state?.turns?.at(-1) as { delta_metrics?: { market_share?: number } | null } | undefined
  const shareDelta = lastTurn?.delta_metrics?.market_share ?? 0

  return (
    <div className="galgame-stage">
      <LinesView
        act={f.act}
        netProfit={f.state?.financial_state?.net_profit ?? 0}
        activeId={activeDuringReason}
        cashFlow={cashFlow}
        shareDelta={shareDelta}
        currentLine={f.currentLine}
        showDialogue={f.phase === 'dialogue' || (f.phase === 'cover' && !!f.currentLine)}
        dialogueKind={f.dialogueKind}
        lineIdx={f.lineIdx}
        onAdvance={f.advanceDialogue}
        affection={f.save?.affection ?? { manager: 70, cfo: 60, cmo: 65 }}
        deltas={f.phase === 'settlement' ? f.settlement?.deltas ?? null : null}
        round={f.settlement?.round ?? 0}
      />

      <CoverView
        visible={f.phase === 'cover' && !!f.currentLine && f.lineIdx >= f.dialogueLines.length - 1}
        disabled={f.busy || f.practiceDisabled || f.practiceUnknown}
        mode={f.mode}
        note={f.practiceDisabled ? '先完成正式局第 1 轮，再来练习' : f.practiceUnknown ? '正在检测正式推演进度…' : undefined}
        onStart={() => void f.begin()}
      />

      {f.practiceUnknown && (
        <div className="galgame-locked" role="status">
          <p>还没检测到你的正式推演进度。练习模式需要先完成至少 1 轮正式推演。</p>
          <button type="button" className="galgame-confirm" onClick={() => nav('/student/' + f.token)}>
            去正式推演
          </button>
        </div>
      )}

      {(f.phase === 'choice' || f.phase === 'reason') && f.node && !f.practiceLocked && (
        <ChoiceView
          phase={f.phase as 'choice' | 'reason'}
          options={f.node.options}
          metrics={f.metrics}
          disabled={f.busy}
          onConfirm={f.handleConfirm}
          pendingRisk={f.pendingRisk}
          reasonPhrase={f.reasonPhrase}
          reasonExtra={f.reasonExtra}
          onReasonPhrase={f.setReasonPhrase}
          onReasonExtra={f.setReasonExtra}
          onSubmit={f.submitReason}
        />
      )}

      {f.practiceLocked && (
        <div className="galgame-locked" role="status">
          <p>第 {f.act} 轮尚未在正式推演中提交，先完成正式局第 {f.act} 轮再来练</p>
          <button type="button" className="galgame-confirm" onClick={() => nav('/student/' + f.token)}>
            去正式推演
          </button>
        </div>
      )}

      {f.phase === 'submitting' && <div className="galgame-saving" role="status">正在保存你的决策…</div>}

      {f.phase === 'uncertain' && (
        <div className="galgame-uncertain">
          <p>{f.error}</p>
          <button type="button" className="galgame-confirm" disabled={f.busy} onClick={() => void f.reconcile()}>
            核对已保存进度
          </button>
        </div>
      )}

      {f.phase === 'settlement' && f.settlement && (
        <ResultView
          settlement={f.settlement}
          finished={!!f.state?.finished}
          mode={f.mode}
          onNext={f.nextAct}
        />
      )}

      {f.phase === 'locked' && (
        <div className="galgame-locked" role="status">
          <p>本次推演已结束，无法继续提交。</p>
        </div>
      )}

      {f.phase === 'finished' && (
        <EndingView
          token={f.token}
          save={f.save}
          turns={f.state?.turns ?? []}
          data={f.data}
          mode={f.mode}
          onRestart={() => void f.restartPractice()}
        />
      )}

      {f.error && f.phase !== 'uncertain' && f.phase !== 'locked' && <p className="galgame-error">{f.error}</p>}

      <EventView
        eventPopup={f.eventPopup}
        cg={f.cg}
        toast={f.toast}
        onCloseEvent={f.closeEvent}
        onDoneCg={() => f.setCg(null)}
      />
    </div>
  )
}