import { useEffect, useRef, useState } from 'react'
import { decide, playGet, resetStudentSubmission, restoreStudent, startStudent } from '../../../api/client'
import type { PlayResponse, SessionState } from '../../../api/types'
import { useStudentToken } from '../../../context/StudentTokenContext'
import { useStudentAccount } from '../../../context/StudentAccountContext'
import { affectionDelta, applyAffection, classifyRisk, endingOf, scoreRound } from './dialogueEngine'
import type { RiskBranch } from './dialogueEngine'
import { loadSave, rebuildFromSession, saveSave } from './persistence'
import type { GalgameSave } from './persistence'
import { modeFromUrl, persistSessionId, readSessionId } from './session'
import type { GameMode } from './session'
import { ENDINGS } from '../data/endings'
import {
  actOpening,
  askReason,
  buildInputText,
  coverLines,
  reactionScene,
  resumeScene,
} from '../data/dialogueTree'
import type { DialogueLine } from '../data/dialogueTree'
import { pickEvent } from '../data/randomEvents'
import type { RandomEvent } from '../data/randomEvents'
import { ACHIEVEMENTS, evaluate as evaluateAchievements } from '../data/achievements'
import type { SettlementData } from '../phases/ResultView'
import type { DiaryEntry } from '../phases/EndingView'

export type DialogueKind = 'cover' | 'actOpening' | 'react' | 'askReason' | 'resume'
export type Phase = 'cover' | 'dialogue' | 'choice' | 'reason' | 'submitting' | 'settlement' | 'uncertain' | 'locked' | 'finished'

/** P1-F2：成就/日记键按模式命名空间隔离，practice 绝不写 formal 数据。 */
const ACH_KEY = (token: string, mode: GameMode) => `galgame_achievements:${token}:${mode}`
const DIARY_KEY = (token: string, mode: GameMode, sessionId: number | null) => `galgame_diary:${token}:${sessionId ?? 'none'}:${mode}`

function loadAchievements(token: string, mode: GameMode): string[] {
  try {
    const raw = globalThis.localStorage?.getItem(ACH_KEY(token, mode))
    const arr = raw ? JSON.parse(raw) : []
    return Array.isArray(arr) ? arr.filter((x): x is string => typeof x === 'string') : []
  } catch {
    return []
  }
}

function appendDiary(token: string, mode: GameMode, sessionId: number | null, entry: DiaryEntry): void {
  let arr: DiaryEntry[] = []
  try {
    const raw = globalThis.localStorage?.getItem(DIARY_KEY(token, mode, sessionId))
    arr = raw ? JSON.parse(raw) : []
  } catch { arr = [] }
  arr.push(entry)
  while (arr.length > 12) arr.shift()
  globalThis.localStorage?.setItem(DIARY_KEY(token, mode, sessionId), JSON.stringify(arr))
}

interface Gate { token: string; active: boolean; busy: boolean; nodeId: number | null; uncertain: boolean }

export function useGalgameFlow() {
  const token = useStudentToken()
  const account = useStudentAccount()
  const [data, setData] = useState<PlayResponse | null>(null)
  const [state, setState] = useState<SessionState | null>(null)
  const [save, setSave] = useState<GalgameSave | null>(null)
  const [phase, setPhase] = useState<Phase>('cover')
  const [dialogueKind, setDialogueKind] = useState<DialogueKind>('cover')
  const [dialogueLines, setDialogueLines] = useState<DialogueLine[]>([])
  const [lineIdx, setLineIdx] = useState(0)
  const [selectedKey, setSelectedKey] = useState<string | null>(null)
  const [pendingRisk, setPendingRisk] = useState<RiskBranch | null>(null)
  const [reasonPhrase, setReasonPhrase] = useState<string | null>(null)
  const [reasonExtra, setReasonExtra] = useState('')
  const [settlement, setSettlement] = useState<SettlementData | null>(null)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const [loading, setLoading] = useState(true)
  const [at, setAt] = useState(Date.now())
  const [eventPopup, setEventPopup] = useState<RandomEvent | null>(null)
  const [cg, setCg] = useState<{ id: string; label: string } | null>(null)
  const [toast, setToast] = useState('')
  // P1-F1：模式由 URL ?mode= 决定；practice 走独立 session/存档命名空间
  const mode: GameMode = modeFromUrl()
  // F5（铁律 17）：practice 门禁 —— 正式局已提交轮数；null = 尚未加载 / 非 practice
  const [unlockedRounds, setUnlockedRounds] = useState<number | null>(null)
  const page = useRef<Gate>({ token, active: false, busy: false, nodeId: null, uncertain: false })

  useEffect(() => {
    if (!toast) return
    const t = window.setTimeout(() => setToast(''), 3000)
    return () => window.clearTimeout(t)
  }, [toast])

  function mergeLocalPersistence(rebuilt: GalgameSave): GalgameSave {
    const local = loadSave(token, mode)
    if (!local) return rebuilt
    return {
      ...rebuilt,
      flags: { ...(local.flags ?? {}), ...(rebuilt.flags ?? {}) },
      seenCg: [...new Set([...(local.seenCg ?? []), ...(rebuilt.seenCg ?? [])])],
      seenSide: [...new Set([...(local.seenSide ?? []), ...(rebuilt.seenSide ?? [])])],
    }
  }

  function applySession(saved: SessionState) {
    setState(saved)
    setData(saved.play)
    page.current.nodeId = saved.next_node_id
    const rebuilt = mergeLocalPersistence(rebuildFromSession(saved))
    setSave(rebuilt)
    saveSave(token, mode, rebuilt)
  }

  /** F5：读正式局已提交轮数（unlockedRounds）。读不到 session 返回 null（未知，不是 0），由 UI 引导去正式页恢复。 */
  async function refreshUnlockedRounds(): Promise<number | null> {
    if (mode !== 'practice') return Infinity
    const formalSid = readSessionId(token, 'formal')
    if (!formalSid) return null
    try {
      const formal = await restoreStudent(token, formalSid)
      return formal.turns?.length ?? 0
    } catch {
      return null
    }
  }

  useEffect(() => {
    let cancelled = false
    const current: Gate = { token, active: true, busy: false, nodeId: null, uncertain: false }
    page.current = current
    setLoading(true)
    setError('')
    async function load() {
      try {
        if (mode === 'practice') {
          setUnlockedRounds(await refreshUnlockedRounds())
        } else {
          setUnlockedRounds(null)
        }
        const session = readSessionId(token, mode)
        if (session) {
          const saved = await restoreStudent(token, session)
          if (cancelled) return
          setState(saved)
          setData(saved.play)
          current.nodeId = saved.next_node_id
          const rebuilt = mergeLocalPersistence(rebuildFromSession(saved))
          setSave(rebuilt)
          if (saved.play_locked) {
            setPhase('locked')
            setError('本次推演已结束，无法继续提交。')
          } else if (saved.finished) setPhase('finished')
          else if (saved.turns.length > 0) {
            setDialogueKind('resume')
            setDialogueLines(resumeScene())
            setPhase('dialogue')
          } else {
            setDialogueKind('cover')
            setDialogueLines(coverLines())
            setPhase('cover')
          }
        } else {
          const play = await playGet(token)
          if (cancelled) return
          setData(play)
          setDialogueKind('cover')
          setDialogueLines(coverLines())
          setPhase('cover')
        }
      } catch (e) {
        if (!cancelled) setError(e instanceof Error ? e.message : '案例暂不可用')
      } finally {
        if (!cancelled) { setLoading(false); setAt(Date.now()) }
      }
    }
    void load()
    return () => { cancelled = true; current.active = false }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token])

  async function begin() {
    const current = page.current
    if (!current.active || current.busy) return
    current.busy = true
    setBusy(true)
    setError('')
    try {
      // F5：正式 0 轮时 practice 不可用（铁律 17）
      if (mode === 'practice') {
        const rounds = await refreshUnlockedRounds()
        if (!current.active) return
        setUnlockedRounds(rounds)
        if (rounds === 0) {
          setError('先完成正式局第 1 轮，再来练习')
          return
        }
      }
      let next: SessionState
      if (state?.session_id) {
        next = state
      } else {
        next = await startStudent(token, account.real_name || state?.student_name || '', mode)
      }
      if (!current.active) return
      applySession(next)
      persistSessionId(token, mode, next.session_id, next.student_name ?? undefined)
      window.dispatchEvent(new Event('student-session-updated'))
      const rebuilt = mergeLocalPersistence(rebuildFromSession(next))
      if (!rebuilt.seenCg.includes('opening')) {
        const withCg = { ...rebuilt, seenCg: [...rebuilt.seenCg, 'opening'] }
        setSave(withCg)
        saveSave(token, mode, withCg)
        setCg({ id: 'opening', label: '开场 CG' })
      }
      setDialogueKind('actOpening')
      setDialogueLines(actOpening(1, null))
      setLineIdx(0)
      setPhase('dialogue')
      setAt(Date.now())
    } catch (e) {
      if (!current.active) return
      setError(e instanceof Error ? e.message : '开始失败')
    } finally {
      current.busy = false
      if (current.active) setBusy(false)
    }
  }

  function advanceDialogue() {
    if (lineIdx < dialogueLines.length - 1) { setLineIdx(lineIdx + 1); return }
    if (dialogueKind === 'react') {
      setDialogueKind('askReason')
      setDialogueLines([askReason(act, pendingRisk ?? 'balanced')])
      setLineIdx(0)
    } else if (dialogueKind === 'askReason') {
      setPhase('reason')
    } else if (dialogueKind === 'resume' || dialogueKind === 'actOpening') {
      const ev = state?.session_id ? pickEvent(state.session_id, act) : null
      if (ev && !save?.flags[`ev:r${act}`]) setEventPopup(ev)
      else setPhase('choice')
    }
  }

  function closeEvent() {
    if (!eventPopup) return
    const ev = eventPopup
    const actNum = act
    const nextSave = save ? { ...save, flags: { ...save.flags, [`ev:r${actNum}`]: ev.title } } : save
    if (nextSave) { setSave(nextSave); saveSave(token, mode, nextSave) }
    appendDiary(token, mode, state?.session_id ?? null, {
      round: actNum, title: '随机事件', label: ev.title, summary: ev.text,
      revenueDelta: null, cashFlow: 0, events: [ev.title],
    })
    setEventPopup(null)
    setPhase('choice')
  }

  function handleConfirm(key: string) {
    const option = node?.options.find((o) => o.key === key)
    if (!option) return
    const risk = classifyRisk(option.label)
    setSelectedKey(key)
    setPendingRisk(risk)
    setDialogueKind('react')
    setDialogueLines(reactionScene(act, risk, save?.affection.cfo ?? 60))
    setLineIdx(0)
    setPhase('dialogue')
  }

  function acceptSaved(saved: SessionState, submittedNode: number) {
    const accepted = saved.turns.find((turn) => turn.node_id === submittedNode)
    applySession(saved)
    if (!accepted) {
      setError('本回合尚未保存，请核对所选策略后重新确认提交。')
      setPhase('choice')
      return
    }
    const roundIndex = saved.turns.indexOf(accepted)
    const before = roundIndex > 0 ? saved.turns[roundIndex - 1].after_metrics : saved.play.base_metrics
    const after = accepted.after_metrics
    const risk = pendingRisk ?? classifyRisk(accepted.chosen_label ?? '')
    const fState = saved.financial_state
    const prevNetProfit = save?.history.at(-1)?.netProfit ?? 0
    let netProfitDelta: number
    let profitValue: number | null
    let profitNote: string | undefined
    if (fState && typeof fState.net_profit === 'number') {
      profitValue = fState.net_profit
      netProfitDelta = fState.net_profit - prevNetProfit
    } else {
      profitValue = null
      netProfitDelta = (after?.revenue ?? 0) - (before?.revenue ?? 0)
      profitNote = '本案例未开启财务仿真，净利润按营收环比估算。'
    }
    const cashFlowAmount = typeof fState?.cash_flow_amount === 'number' ? fState.cash_flow_amount : 0
    const shareDelta = parseFloat(after?.market_share ?? '0') - parseFloat(before?.market_share ?? '0')
    const scored = scoreRound(
      { score: save?.score ?? 50, breakdown: [] },
      { netProfitDelta: roundIndex === 0 ? 0 : netProfitDelta, cashFlowAmount, shareDelta, risk },
    )
    const deltas = affectionDelta(risk)
    const nextAffection = applyAffection(save?.affection ?? { manager: 70, cfo: 60, cmo: 65 }, risk)
    const beforeRevenue = before?.revenue ?? 0
    const revenuePct = beforeRevenue > 0 ? (((after?.revenue ?? 0) - beforeRevenue) / beforeRevenue) * 100 : 0
    const rush = revenuePct >= 8 || shareDelta >= 1.5
    const seenCg = [...new Set([...(save?.seenCg ?? []), ...(rush ? ['rush'] : [])])]
    const nextSave: GalgameSave = {
      ...(save ?? {
        v: 1, session_id: null, round: 1,
        affection: { manager: 70, cfo: 60, cmo: 65 },
        score: 50, finished: false, history: [], flags: {}, seenCg: [], seenSide: [],
      }),
      session_id: saved.session_id,
      round: roundIndex + 1,
      finished: saved.finished,
      affection: nextAffection,
      score: scored.score,
      seenCg,
      history: [...(save?.history ?? []), { round: roundIndex + 1, risk, cashFlowAmount, netProfit: fState?.net_profit }],
    }
    setSave(nextSave)
    saveSave(token, mode, nextSave)
    const newly = evaluateAchievements(nextSave).filter((id) => !loadAchievements(token, mode).includes(id))
    if (newly.length > 0) {
      const labels = newly.map((id) => ACHIEVEMENTS.find((a) => a.id === id)?.label ?? id).join('、')
      globalThis.localStorage?.setItem(ACH_KEY(token, mode), JSON.stringify([...loadAchievements(token, mode), ...newly]))
      setToast(`解锁成就：${labels}`)
    }
    const evTitle = save?.flags[`ev:r${roundIndex + 1}`]
    appendDiary(token, mode, saved.session_id, {
      round: roundIndex + 1,
      title: data?.nodes.find((n) => n.id === submittedNode)?.title ?? '决策',
      label: accepted.chosen_label ?? '已保存',
      summary: accepted.summary,
      revenueDelta: after?.revenue != null && before?.revenue != null ? Number((after.revenue - before.revenue).toFixed(2)) : null,
      cashFlow: cashFlowAmount,
      events: typeof evTitle === 'string' ? [evTitle] : [],
    })
    if (rush && !(save?.seenCg ?? []).includes('rush')) setCg({ id: 'rush', label: '爆满 CG' })
    setSettlement({
      round: roundIndex + 1,
      chosenLabel: accepted.chosen_label ?? selectedOption?.label ?? '已保存',
      before, after, summary: accepted.summary,
      score: scored.score, breakdown: scored.breakdown,
      deltas, profitValue, profitNote,
    })
    setPhase('settlement')
    window.dispatchEvent(new Event('student-session-updated'))
  }

  async function submitDecision(inputText: string) {
    const current = page.current
    if (!node || !state || !selectedKey || current.busy || current.uncertain || current.nodeId !== node.id) return
    current.busy = true
    setBusy(true)
    setError('')
    setPhase('submitting')
    try {
      await decide(token, {
        student_name: state.student_name, session_id: state.session_id,
        node_id: node.id, option_key: selectedKey,
        input_text: inputText, duration_ms: Math.max(0, Date.now() - at),
      })
      if (!current.active) return
      const saved = await restoreStudent(token, state.session_id)
      if (!current.active) return
      acceptSaved(saved, node.id)
    } catch {
      if (!current.active) return
      try {
        const saved = await restoreStudent(token, state.session_id)
        if (current.active) acceptSaved(saved, node.id)
      } catch {
        if (current.active) {
          current.uncertain = true
          setPhase('uncertain')
          setError('提交状态待确认，请点击「核对已保存进度」。核对前不会再次提交，以免重复作答。')
        }
      }
    } finally {
      current.busy = false
      if (current.active) setBusy(false)
    }
  }

  function submitReason() {
    void submitDecision(buildInputText(selectedOption?.label ?? '未命名策略', reasonPhrase, reasonExtra))
  }

  async function reconcile() {
    const current = page.current
    if (!state || current.busy || !current.active || current.token !== token) return
    current.busy = true
    setBusy(true)
    try {
      const saved = await restoreStudent(token, state.session_id)
      if (current.active) {
        current.uncertain = false
        page.current.uncertain = false
        acceptSaved(saved, node?.id ?? -1)
      }
    } catch {
      if (current.active) setError('仍无法核对服务器进度，请稍后重试；不会重复提交或自动选择其他策略。')
    } finally {
      current.busy = false
      if (current.active) setBusy(false)
    }
  }

  function nextAct() {
    setSelectedKey(null)
    setReasonPhrase(null)
    setReasonExtra('')
    setSettlement(null)
    setError('')
    setAt(Date.now())
    if (state?.finished) {
      const kind = endingOf(save?.score ?? 50)
      const cgId = `ending.${kind}`
      if (!save?.seenCg.includes(cgId)) {
        const withCg = save ? { ...save, seenCg: [...save.seenCg, cgId] } : save
        if (withCg) { setSave(withCg); saveSave(token, mode, withCg) }
        const label = ENDINGS.find((e) => e.id === `end.${kind}`)?.title ?? '结局'
        setCg({ id: cgId, label: `${label} · 结局画面` })
      }
      setPhase('finished')
      return
    }
    const nextActNum = (save?.history.length ?? 0) + 1
    if (mode === 'practice') {
      // F5：每进入新一轮前重读正式局进度；超过 unlockedRounds 则锁定，不渲染选项
      void refreshUnlockedRounds().then((rounds) => {
        if (!page.current.active) return
        setUnlockedRounds(rounds)
        if (rounds === null || nextActNum > rounds) {
          setError(rounds === null ? '还没检测到正式推演进度，请先完成正式局再练习' : `第 ${nextActNum} 轮尚未在正式推演中提交，先完成正式局第 ${nextActNum} 轮再来练`)
          setPhase('locked')
          return
        }
        setDialogueKind('actOpening')
        setDialogueLines(actOpening(nextActNum, save?.history.at(-1)?.risk ?? null))
        setLineIdx(0)
        setPhase('dialogue')
      })
      return
    }
    setDialogueKind('actOpening')
    setDialogueLines(actOpening(nextActNum, save?.history.at(-1)?.risk ?? null))
    setLineIdx(0)
    setPhase('dialogue')
  }

  /** P1-F3：practice 结束页「再来一局」→ reset 同一 practice 会话 + 重建全新本地存档（不合并旧 flags/seenCg）。 */
  async function restartPractice() {
    const current = page.current
    if (mode !== 'practice' || !state?.session_id || current.busy || !current.active) return
    current.busy = true
    setBusy(true)
    setError('')
    try {
      const saved = await resetStudentSubmission(token, state.session_id)
      if (!current.active) return
      setState(saved)
      setData(saved.play)
      page.current.nodeId = saved.next_node_id
      const fresh = rebuildFromSession(saved)
      setSave(fresh)
      saveSave(token, mode, fresh)
      setSettlement(null)
      setSelectedKey(null)
      setPendingRisk(null)
      setReasonPhrase(null)
      setReasonExtra('')
      setDialogueKind('cover')
      setDialogueLines(coverLines())
      setLineIdx(0)
      setPhase('cover')
      setAt(Date.now())
    } catch (e) {
      if (!current.active) return
      setError(e instanceof Error ? e.message : '重开失败，请稍后再试')
    } finally {
      current.busy = false
      if (current.active) setBusy(false)
    }
  }

  const node = data?.nodes.find((n) => n.id === state?.next_node_id)
  const act = node?.idx ?? (save?.history.length ?? 0) + 1
  // F5 门禁：practice 第 N 轮 N > unlockedRounds → 锁定（不渲染选项）；正式 0 轮 → 封面禁用；null → 未知进度，引导去正式页
  const practiceLocked = mode === 'practice' && unlockedRounds !== null && act > unlockedRounds
  const practiceDisabled = mode === 'practice' && unlockedRounds === 0
  const practiceUnknown = mode === 'practice' && unlockedRounds === null
  const currentLine = dialogueLines[Math.min(lineIdx, dialogueLines.length - 1)]
  const selectedOption = node?.options.find((o) => o.key === selectedKey)
  const metrics = state?.current_metrics ?? data?.base_metrics ?? null

  return {
    token, mode, loading, error, phase, data, state, save, settlement, busy,
    dialogueKind, dialogueLines, lineIdx, currentLine, eventPopup, cg, toast,
    node, act, metrics, selectedOption, pendingRisk, reasonPhrase, reasonExtra,
    practiceLocked, practiceDisabled, practiceUnknown,
    begin, advanceDialogue, closeEvent, handleConfirm, submitDecision, submitReason, reconcile, nextAct,
    restartPractice,
    setReasonPhrase, setReasonExtra,
    setCg,
  }
}
