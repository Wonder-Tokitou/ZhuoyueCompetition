/**
 * 成就（阶段 1 实现，可选挂件）。
 * 6 个成就 id 固定：first_decision / conservative / adventurer / treasurer / social / tycoon。
 * evaluate 判定条件见各条目注释；"第 1 轮 + 选保守"时恰好返回 ['first_decision']。
 */
import type { GalgameSave } from '../engine/persistence'

export interface Achievement {
  id: string
  label: string
}

export const ACHIEVEMENTS: Achievement[] = [
  { id: 'first_decision', label: '首次决策' },
  { id: 'conservative', label: '稳字当头' },
  { id: 'adventurer', label: '冒险家' },
  { id: 'treasurer', label: '现金管家' },
  { id: 'social', label: '人脉王' },
  { id: 'tycoon', label: '商业大亨' },
]

/** 返回当前应解锁（但尚未解锁）的成就 id 列表；ctx 保留给将来扩展（如触发时机）。 */
export function evaluate(save: GalgameSave, _ctx?: unknown): string[] {
  const unlocked: string[] = []
  const { history, affection, score, finished } = save

  // first_decision：已做出第 1 轮决策
  if (history.length >= 1) unlocked.push('first_decision')
  // conservative：保守 ≥ 2 次
  if (history.filter((h) => h.risk === 'conservative').length >= 2) unlocked.push('conservative')
  // adventurer：激进 ≥ 2 次
  if (history.filter((h) => h.risk === 'aggressive').length >= 2) unlocked.push('adventurer')
  // treasurer：三轮现金流均 ≥ 0
  if (history.length >= 3 && history.every((h) => h.cashFlowAmount >= 0)) unlocked.push('treasurer')
  // social：任一角色好感 ≥ 90
  if (affection.manager >= 90 || affection.cfo >= 90 || affection.cmo >= 90) unlocked.push('social')
  // tycoon：score > 80 且已结束
  if (finished && score > 80) unlocked.push('tycoon')

  return unlocked
}
