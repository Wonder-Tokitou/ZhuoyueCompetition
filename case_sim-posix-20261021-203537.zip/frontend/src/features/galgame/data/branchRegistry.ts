/**
 * 分支注册表（阶段 1）：全量 40 节点的唯一事实来源。
 * main 23 / side 4 / ev 5 / cg 5 / end 3；可选层（ev/cg）标 optional: true，解析器按开关跳过。
 * 结构约束：只有 main.rN.choice 会调用 decide；side/ev/cg/end 全部是文案包装。
 */
import type { RiskBranch } from '../engine/dialogueEngine'

export type StoryLayer = 'main' | 'side' | 'ev' | 'cg' | 'end'
export type StoryStage = 'pre' | 'choice' | 'react' | 'result' | 'side' | 'ending'

/** 判定分支用的上下文（解析器只读，不写）。 */
export interface StoryContext {
  turnsLength: number
  finished: boolean
  /** 上一轮分类结果（第 1 轮为 null） */
  risk: RiskBranch | null
  affection: { manager: number; cfo: number; cmo: number }
  /** 本轮现金净流量（万元，负数表示净流出） */
  cashFlowAmount: number
  /** 份额环比（百分点，+1.5 表示 +1.5pp） */
  shareDelta: number
  /** 营收环比（百分比点） */
  revenueDelta: number
  score: number
  /** 结局判定结果（未判定为 null） */
  ending: 'success' | 'normal' | 'fail' | null
  nextNodeId: number | null
  seenCg: string[]
  seenSide: string[]
  /** 本轮是否命中随机事件（由 pickEvent 预先算好置位） */
  eventHit: boolean
  [key: string]: unknown
}

export interface BranchNode {
  id: string
  layer: StoryLayer
  act: number
  stage: StoryStage
  title: string
  parentId: string | null
  trigger: string
  priority: number
  once: boolean
  /** 可选挂件（ev/cg），解析器按开关跳过 */
  optional?: boolean
  when?: (ctx: StoryContext) => boolean
}

// 清单原文正则为 `(\.[a-z0-9]+)+`（至少两段后缀），与两段式 ID（main.resume / ev.rain / cg.opening）
// 冲突，放宽为 `*`（至少一段后缀），仍保留"层前缀 + 点分小写"与全局唯一约束。
const ID_RE = /^(main|side|ev|cg|end)\.[a-z0-9]+(\.[a-z0-9]+)*$/

const always = (ctx: StoryContext) => {
  void ctx
  return true
}

export const BRANCH_REGISTRY: BranchNode[] = [
  /* ---------- main：主线 23 个场次（必做） ---------- */
  // pre：7（r1.pre 1 + r2.pre 3 + r3.pre 3）
  { id: 'main.r1.pre', layer: 'main', act: 1, stage: 'pre', title: '开业第一天·幕前', parentId: null, trigger: '第 1 轮开始（turns.length === 0）', priority: 0, once: false, when: (ctx) => ctx.turnsLength === 0 },
  { id: 'main.r2.pre.conservative', layer: 'main', act: 2, stage: 'pre', title: '竞争来袭·幕前（保守线）', parentId: null, trigger: '第 2 轮开始，上一轮分类 = conservative', priority: 0, once: false, when: (ctx) => ctx.turnsLength === 1 && ctx.risk === 'conservative' },
  { id: 'main.r2.pre.balanced', layer: 'main', act: 2, stage: 'pre', title: '竞争来袭·幕前（稳健线）', parentId: null, trigger: '第 2 轮开始，上一轮分类 = balanced（含无匹配兜底）', priority: 0, once: false, when: (ctx) => ctx.turnsLength === 1 && ctx.risk !== 'aggressive' },
  { id: 'main.r2.pre.aggressive', layer: 'main', act: 2, stage: 'pre', title: '竞争来袭·幕前（激进线）', parentId: null, trigger: '第 2 轮开始，上一轮分类 = aggressive', priority: 0, once: false, when: (ctx) => ctx.turnsLength === 1 && ctx.risk === 'aggressive' },
  { id: 'main.r3.pre.conservative', layer: 'main', act: 3, stage: 'pre', title: '年终结算·幕前（保守线）', parentId: null, trigger: '第 3 轮开始，上一轮分类 = conservative', priority: 0, once: false, when: (ctx) => ctx.turnsLength === 2 && ctx.risk === 'conservative' },
  { id: 'main.r3.pre.balanced', layer: 'main', act: 3, stage: 'pre', title: '年终结算·幕前（稳健线）', parentId: null, trigger: '第 3 轮开始，上一轮分类 = balanced（含无匹配兜底）', priority: 0, once: false, when: (ctx) => ctx.turnsLength === 2 && ctx.risk !== 'aggressive' },
  { id: 'main.r3.pre.aggressive', layer: 'main', act: 3, stage: 'pre', title: '年终结算·幕前（激进线）', parentId: null, trigger: '第 3 轮开始，上一轮分类 = aggressive', priority: 0, once: false, when: (ctx) => ctx.turnsLength === 2 && ctx.risk === 'aggressive' },
  // resume：1
  { id: 'main.resume', layer: 'main', act: 0, stage: 'pre', title: '续玩开场', parentId: null, trigger: 'restore 成功且 turns.length > 0 且 !finished', priority: 0, once: false, when: (ctx) => ctx.turnsLength > 0 && !ctx.finished },
  // choice：3
  { id: 'main.r1.choice', layer: 'main', act: 1, stage: 'choice', title: '第一轮决策', parentId: 'main.r1.pre', trigger: '当前场次结束、next_node_id 非空', priority: 0, once: false, when: (ctx) => ctx.nextNodeId != null },
  { id: 'main.r2.choice', layer: 'main', act: 2, stage: 'choice', title: '第二轮决策', parentId: 'main.r2.pre.balanced', trigger: '当前场次结束、next_node_id 非空', priority: 0, once: false, when: (ctx) => ctx.nextNodeId != null },
  { id: 'main.r3.choice', layer: 'main', act: 3, stage: 'choice', title: '第三轮决策', parentId: 'main.r3.pre.balanced', trigger: '当前场次结束、next_node_id 非空', priority: 0, once: false, when: (ctx) => ctx.nextNodeId != null },
  // react：9（3 轮 × 3 分支）
  ...(['r1', 'r2', 'r3'] as const).flatMap((round) =>
    (['conservative', 'balanced', 'aggressive'] as const).map((risk) => ({
      id: `main.${round}.react.${risk}`,
      layer: 'main' as StoryLayer,
      act: Number(round.slice(1)),
      stage: 'react' as StoryStage,
      title: `${round.toUpperCase()} 反应（${risk}）`,
      parentId: `main.${round}.choice`,
      trigger: '玩家点确认，risk = classifyRisk(label)',
      priority: 0,
      once: false,
      when: always,
    })),
  ),
  // result：3
  { id: 'main.r1.result', layer: 'main', act: 1, stage: 'result', title: '第一轮结算', parentId: 'main.r1.choice', trigger: 'decide 返回并 restore 成功', priority: 0, once: false, when: always },
  { id: 'main.r2.result', layer: 'main', act: 2, stage: 'result', title: '第二轮结算', parentId: 'main.r2.choice', trigger: 'decide 返回并 restore 成功', priority: 0, once: false, when: always },
  { id: 'main.r3.result', layer: 'main', act: 3, stage: 'result', title: '第三轮结算', parentId: 'main.r3.choice', trigger: 'decide 返回并 restore 成功', priority: 0, once: false, when: always },

  /* ---------- side：支线 4 条（必做，每幕最多插 1 条，按 priority 降序取首个未触发） ---------- */
  { id: 'side.cfo.audit', layer: 'side', act: 0, stage: 'side', title: '财务总监·查账', parentId: null, trigger: 'affection.cfo >= 70 && 本轮 cash_flow_amount < 0', priority: 30, once: true, when: (ctx) => ctx.affection.cfo >= 70 && ctx.cashFlowAmount < 0 },
  { id: 'side.cmo.viral', layer: 'side', act: 0, stage: 'side', title: '市场经理·爆款复盘', parentId: null, trigger: 'affection.cmo >= 70 && 份额环比 >= +1.5pp', priority: 25, once: true, when: (ctx) => ctx.affection.cmo >= 70 && ctx.shareDelta >= 1.5 },
  { id: 'side.manager.trust', layer: 'side', act: 0, stage: 'side', title: '店长·交心', parentId: null, trigger: 'affection.manager >= 80 && turns.length >= 3', priority: 20, once: true, when: (ctx) => ctx.affection.manager >= 80 && ctx.turnsLength >= 3 },
  { id: 'side.cfo.warning', layer: 'side', act: 0, stage: 'side', title: '财务总监·施压', parentId: null, trigger: 'affection.cfo <= 35（负面支线）', priority: 40, once: true, when: (ctx) => ctx.affection.cfo <= 35 },

  /* ---------- ev：随机事件 5 条（可选挂件，optional: true） ---------- */
  ...(['rain', 'exam', 'viral', 'supplier', 'renovate'] as const).map((name) => ({
    id: `ev.${name}`,
    layer: 'ev' as StoryLayer,
    act: 0,
    stage: 'side' as StoryStage,
    title: `随机事件·${name}`,
    parentId: null,
    trigger: 'hash(session_id, "r{act}", "ev") % 100 < 30，命中后 hash % 5 取一条；每轮至多 1 条',
    priority: 0,
    once: false,
    optional: true,
    when: (ctx: StoryContext) => ctx.eventHit === true,
  })),

  /* ---------- cg：CG 演出 5 条（可选挂件，optional: true） ---------- */
  { id: 'cg.opening', layer: 'cg', act: 0, stage: 'side', title: '开场 CG', parentId: null, trigger: '第 1 轮首次进入（seenCg 不含）', priority: 0, once: true, optional: true, when: (ctx) => !ctx.seenCg.includes('opening') },
  { id: 'cg.rush', layer: 'cg', act: 0, stage: 'side', title: '爆满 CG', parentId: null, trigger: '营收环比 >= +8% 或份额环比 >= +1.5pp', priority: 0, once: true, optional: true, when: (ctx) => ctx.revenueDelta >= 8 || ctx.shareDelta >= 1.5 },
  { id: 'cg.ending.success', layer: 'cg', act: 0, stage: 'side', title: '结局 CG·成功', parentId: null, trigger: '结局判定后（success）', priority: 0, once: true, optional: true, when: (ctx) => ctx.ending === 'success' },
  { id: 'cg.ending.normal', layer: 'cg', act: 0, stage: 'side', title: '结局 CG·平稳', parentId: null, trigger: '结局判定后（normal）', priority: 0, once: true, optional: true, when: (ctx) => ctx.ending === 'normal' },
  { id: 'cg.ending.fail', layer: 'cg', act: 0, stage: 'side', title: '结局 CG·受挫', parentId: null, trigger: '结局判定后（fail）', priority: 0, once: true, optional: true, when: (ctx) => ctx.ending === 'fail' },

  /* ---------- end：结局 3 条（必做） ---------- */
  { id: 'end.success', layer: 'end', act: 0, stage: 'ending', title: '结局·成功', parentId: null, trigger: 'score > 80', priority: 0, once: true, when: (ctx) => ctx.score > 80 },
  { id: 'end.normal', layer: 'end', act: 0, stage: 'ending', title: '结局·平稳', parentId: null, trigger: '50 <= score <= 80', priority: 0, once: true, when: (ctx) => ctx.score >= 50 && ctx.score <= 80 },
  { id: 'end.fail', layer: 'end', act: 0, stage: 'ending', title: '结局·受挫', parentId: null, trigger: 'score < 50', priority: 0, once: true, when: (ctx) => ctx.score < 50 },
]

/** 支线解析：过滤 when → 按 priority 降序 → 去掉 seen → 取第 1 条（每幕最多 1 条）。 */
export function resolveSideStories(ctx: StoryContext, seen: string[]): string[] {
  const candidates = BRANCH_REGISTRY
    .filter((n) => n.layer === 'side')
    .filter((n) => !n.when || n.when(ctx))
    .sort((a, b) => b.priority - a.priority)
  for (const node of candidates) {
    if (!seen.includes(node.id)) return [node.id]
  }
  return []
}

/** 校验 ID 正则与唯一性，返回违规项列表（空数组 = 通过）。 */
export function assertRegistry(): string[] {
  const errors: string[] = []
  const seen = new Set<string>()
  for (const n of BRANCH_REGISTRY) {
    if (!ID_RE.test(n.id)) errors.push(`bad id: ${n.id}`)
    if (seen.has(n.id)) errors.push(`duplicate id: ${n.id}`)
    seen.add(n.id)
  }
  return errors
}
