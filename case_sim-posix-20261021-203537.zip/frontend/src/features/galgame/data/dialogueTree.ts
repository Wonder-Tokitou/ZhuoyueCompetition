/**
 * 台词库（阶段 1 实现）。
 * 约束：每轮对话 ≤6 句、每句 ≤40 字；main.r2.pre 三分支第一句必须不同；
 * 财务总监台词按语气（warm/neutral/cold）区分，cold 与 warm 至少差 1 句。
 */
import { moodOf } from '../engine/dialogueEngine'
import type { RiskBranch } from '../engine/dialogueEngine'

export interface DialogueLine {
  speaker: string
  text: string
}

/**
 * 决策追问（T4.0）：反应对话播完之后、decide 之前，由财务总监（👨‍🔬）追问一句。
 * 三分支文案各不相同；act 参数保留供将来按幕变化，当前按 risk 分支固定。
 */
export function askReason(_act: number, risk: RiskBranch): DialogueLine {
  if (risk === 'conservative') return { speaker: '财务', text: '这笔钱你是想先保住？' }
  if (risk === 'aggressive') return { speaker: '财务', text: '这笔钱花出去，你打算多久回本？' }
  return { speaker: '财务', text: '两边都留了余地，你的账是怎么算的？' }
}

/** 追问下方三个短语按钮（单选），按分支给三选。 */
export const REASON_PHRASES: Record<RiskBranch, string[]> = {
  conservative: ['先保现金，活下来再说', '先把成本压下去', '留点余量防风险'],
  balanced: ['两边都留余地', '先看数据再决定', '不把鸡蛋放一个篮子'],
  aggressive: ['先抢份额，规模优先', '趁对手没反应先铺开', '这笔钱能带来复购'],
}

/**
 * input_text 拼装（T4.0 固定格式）：
 * 【{所选策略 label}】{短语}。{补充}；补充为空时省略"句号+补充"；
 * 学生跳过追问（未选短语）时存 【{label}】（未说明理由）——不许存空串。
 */
export function buildInputText(label: string, phrase: string | null, extra: string): string {
  if (!phrase) return `【${label}】（未说明理由）`
  const suffix = extra.trim() ? `。${extra.trim()}` : ''
  return `【${label}】${phrase}${suffix}`
}

/** 封面（显示实名后、点"开始营业"前）。 */
export function coverLines(): DialogueLine[] {
  return [
    { speaker: '店长', text: '欢迎来到你的奶茶店，今天由你当老板。' },
    { speaker: '店长', text: '每轮一个经营决策，选完咱们立刻看结果。' },
    { speaker: '店长', text: '账算明白，店才能开得久。' },
    { speaker: '店长', text: '准备好就点「开始营业」。' },
  ]
}

/** 幕前开场：act 1 固定；act 2/3 按上一轮分类分三线，第一句各不相同。 */
export function actOpening(act: number, prevRisk: string | null): DialogueLine[] {
  if (act === 1) {
    return [
      { speaker: '店长', text: '新店刚开张，账上资金有限。' },
      { speaker: '店长', text: '第一步怎么走，你说了算。' },
    ]
  }
  if (act === 2) {
    if (prevRisk === 'conservative') {
      return [
        { speaker: '财务', text: '上一轮你守住了现金，这轮对手开始压价了。' },
        { speaker: '市场', text: '校门口新开了家竞品，客人在被分流。' },
        { speaker: '店长', text: '这轮怎么接招？' },
      ]
    }
    if (prevRisk === 'aggressive') {
      return [
        { speaker: '财务', text: '上一轮你冲得猛，现金绷得有点紧。' },
        { speaker: '市场', text: '冲出去的效果有了，趁热打铁？' },
        { speaker: '店长', text: '这轮还能再冲吗？' },
      ]
    }
    return [
      { speaker: '财务', text: '上一轮你两边都留了余地，账还算稳。' },
      { speaker: '市场', text: '竞品来势不凶，但也不能大意。' },
      { speaker: '店长', text: '这轮怎么走？' },
    ]
  }
  // act 3：年终收官
  if (prevRisk === 'conservative') {
    return [
      { speaker: '财务', text: '最后一轮，守住利润就能体面收官。' },
      { speaker: '市场', text: '但对手年底还在搞活动抢人。' },
      { speaker: '店长', text: '收官这轮，你的选择？' },
    ]
  }
  if (prevRisk === 'aggressive') {
    return [
      { speaker: '财务', text: '最后一轮，要么冲上榜首，要么翻车。' },
      { speaker: '市场', text: '年底正是抢份额的窗口期。' },
      { speaker: '店长', text: '收官这轮，你的选择？' },
    ]
  }
  return [
    { speaker: '财务', text: '最后一轮，账上余粮够你稳稳收官。' },
    { speaker: '市场', text: '稳一点，今年就算踏实过去了。' },
    { speaker: '店长', text: '收官这轮，你的选择？' },
  ]
}

/** 选后反应：按所选分支 + 财务好感度语气（warm/neutral/cold）给台词。affection 为财务总监好感度。 */
export function reactionScene(act: number, risk: string, affection: number): DialogueLine[] {
  const mood = moodOf(affection)
  const lines: DialogueLine[] = []
  if (risk === 'conservative') {
    if (mood === 'warm') lines.push({ speaker: '财务', text: '稳，账上余粮又厚了一层。' })
    else if (mood === 'cold') lines.push({ speaker: '财务', text: '你这也太保守了，市场快被抢光了。' })
    else lines.push({ speaker: '财务', text: '保守打法，账是稳的，就是慢了点。' })
    lines.push({ speaker: '市场', text: '没抢到份额，我心里有点急。' })
  } else if (risk === 'aggressive') {
    if (mood === 'warm') lines.push({ speaker: '财务', text: '冲得够猛，我陪你盯紧现金流。' })
    else if (mood === 'cold') lines.push({ speaker: '财务', text: '又在烧钱，账快撑不住了。' })
    else lines.push({ speaker: '财务', text: '投得狠，记得留够三个月粮。' })
    lines.push({ speaker: '市场', text: '这波冲出去，客人明显多了！' })
  } else {
    lines.push({ speaker: '财务', text: '两边都顾到了，账上还过得去。' })
    lines.push({ speaker: '市场', text: '不冒进也不落后，正好。' })
  }
  if (act === 1) lines.push({ speaker: '店长', text: '第一轮定调，后面就好走了。' })
  else if (act === 3) lines.push({ speaker: '店长', text: '收官的选择，直接决定今年怎么收官。' })
  else lines.push({ speaker: '店长', text: '这一轮做完，咱看看账上什么变化。' })
  return lines
}

/** 续玩开场（restore 成功且 turns.length > 0 且 !finished）。 */
export function resumeScene(): DialogueLine[] {
  return [
    { speaker: '店长', text: '欢迎回来，你的奶茶店还开着。' },
    { speaker: '店长', text: '进度我都帮你记着，接着上一轮继续。' },
  ]
}
