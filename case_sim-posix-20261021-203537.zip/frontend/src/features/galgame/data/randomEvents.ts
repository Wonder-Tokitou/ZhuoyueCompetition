/**
 * 随机事件（阶段 1 实现，可选挂件）。
 * pickEvent 用 hash(sessionId + ':r{act}:ev') 取模：命中率约 30%，命中后 hash % 5 取一条。
 * 纯函数、确定性：同一 session 同一轮刷新结果不变，禁 Math.random。
 */
export interface RandomEvent {
  id: string
  title: string
  text: string
}

export const RANDOM_EVENTS: RandomEvent[] = [
  { id: 'ev.rain', title: '雨天', text: '下了一整天雨，到店客人少了一截。' },
  { id: 'ev.exam', title: '考试周', text: '图书馆通宵的人变多，夜宵单量见涨。' },
  { id: 'ev.viral', title: '校友打卡', text: '有人在社交平台晒了咱家新品，门口排起小长队。' },
  { id: 'ev.supplier', title: '原料涨价', text: '奶源供应商说下季度要提价，成本又紧了。' },
  { id: 'ev.renovate', title: '隔壁装修', text: '隔壁店铺装修，白天噪音赶走了一批客人。' },
]

/** djb2 字符串哈希（确定性，跨进程稳定）。 */
export function hashString(input: string): number {
  let hash = 5381
  for (let i = 0; i < input.length; i++) {
    hash = ((hash << 5) + hash + input.charCodeAt(i)) >>> 0
  }
  return hash >>> 0
}

/** 事件选取：命中（% 100 < 30）返回对应事件，否则 null。每轮至多 1 条。 */
export function pickEvent(sessionId: string | number, act: number): RandomEvent | null {
  const h = hashString(`${sessionId}:r${act}:ev`)
  if (h % 100 < 30) {
    return RANDOM_EVENTS[h % RANDOM_EVENTS.length]
  }
  return null
}
