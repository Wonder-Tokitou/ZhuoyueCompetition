/**
 * 三结局（阶段 1 实现）。
 * success（>80）/ normal（50–80）/ fail（<50），各含标题 + 3–5 句台词 + CG id。
 */
export interface Ending {
  id: string
  title: string
  lines: string[]
  cgId: string
}

export const ENDINGS: Ending[] = [
  {
    id: 'end.success',
    title: '连锁霸主',
    lines: [
      '一年下来，账上现金厚实，份额也冲到了前列。',
      '财务总监难得笑了：这盘账，我服。',
      '店长把招牌擦了又擦：明年，我们开十家店。',
      '你长舒一口气——这杯奶茶，喝得值。',
    ],
    cgId: 'cg.ending.success',
  },
  {
    id: 'end.normal',
    title: '稳中求进',
    lines: [
      '一年走完，账没亏，但也没冲上顶点。',
      '财务总监点头：稳，是稳的。',
      '店长拍了拍你的肩：不折腾，也是一种本事。',
      '明年能不能再进一步，就看你的下一张菜单了。',
    ],
    cgId: 'cg.ending.normal',
  },
  {
    id: 'end.fail',
    title: '现金告急',
    lines: [
      '年末盘点，账上的钱快见底了。',
      '财务总监叹气：我提醒过你，现金流是命。',
      '店长还守着店：只要店还在，就还有翻盘的希望。',
      '如果重来一次，你会怎么选？',
    ],
    cgId: 'cg.ending.fail',
  },
]
