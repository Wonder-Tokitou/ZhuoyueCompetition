import { useEffect, useState } from 'react'
import { ArrowLeftOutlined, AppstoreOutlined, FileTextOutlined, HomeOutlined, LogoutOutlined, UserOutlined } from '@ant-design/icons'
import { Alert, Button, FloatButton, Layout, Menu, Modal, Spin } from 'antd'
import { Outlet, useLocation, useNavigate } from 'react-router-dom'
import './StudentLayout.css'
import { api } from '../api/client'
import { clearStudentLogin, StudentAccountContext } from '../context/StudentAccountContext'
import type { StudentAccount } from '../context/StudentAccountContext'
import { useIsNarrow } from '../hooks/useIsNarrow'
import StudentTutorSidebar from '../features/ai/StudentTutorSidebar'

const { Sider, Content } = Layout

/**
 * 学生端三大分类：PC 端在左侧菜单（与教师端一致的左右分布），
 * 移动端收成底部标签栏（微信式）。
 */
const STUDENT_NAV = [
  { key: 'cases', icon: <AppstoreOutlined />, label: '案例推演' },
  { key: 'records', icon: <FileTextOutlined />, label: '我的提交记录' },
  { key: 'profile', icon: <UserOutlined />, label: '个人与账号信息' },
]

/**
 * 学生端布局：
 * - PC（≥768px）：左侧固定菜单 + 右侧内容区，结构与教师端一致；
 * - 移动端（<768px）：顶部细标题栏 + 底部固定三大分类键。
 */
export default function StudentLayout() {
  const location = useLocation(), navigate = useNavigate()
  const isNarrow = useIsNarrow(768)
  const pathname = location.pathname
  const routeMatch = pathname.match(/^\/student\/([^/]+)(?:\/(review))?\/?$/)
  const isCaseRoute = routeMatch && !['cases', 'records', 'profile'].includes(routeMatch[1])
  const [tutorOpen, setTutorOpen] = useState(false)
  const canTutor = !!isCaseRoute || pathname === '/student/records'
  const previousPath = isCaseRoute
    ? routeMatch[2] === 'review' ? `/student/${routeMatch[1]}` : '/student/cases'
    : pathname !== '/student' ? '/student' : null
  const [title, setTitle] = useState('案例')
  const [account, setAccount] = useState<StudentAccount | null>(null)
  const [error, setError] = useState('')
  useEffect(() => {
    let cancelled = false
    if (!sessionStorage.getItem('student_access_token')) {
      navigate('/student/login?next=' + encodeURIComponent(pathname + location.search), { replace: true })
      return
    }
    api.get<StudentAccount>('/student/me').then(({ data }) => { if (!cancelled) setAccount(data) })
      .catch((e) => { if (!cancelled) setError(e.message) })
    return () => { cancelled = true }
  }, [navigate])
  useEffect(() => {
    const token = window.location.pathname.split('/')[2]
    setTitle(token && !['cases', 'records', 'profile', 'join'].includes(token) ? (sessionStorage.getItem('student_title:' + token) || '案例推演') : ({ cases: '案例库', records: '我的记录', profile: '账号信息', join: '加入班级' }[token] || '学习空间'))
  }, [pathname])
  // body 的限宽只在学生端路由挂载期间生效，卸载立刻移除，
  // 避免影响老师端 1000px 的内容区。
  useEffect(() => {
    document.body.classList.add('student-body')
    return () => document.body.classList.remove('student-body')
  }, [])

  async function doLogout() {
    try { await api.post('/student/logout') } finally { clearStudentLogin(); navigate('/student/login', { replace: true }) }
  }

  /** 退出登录：先弹确认框防止误触，确认后再登出。 */
  function handleLogout() {
    Modal.confirm({
      title: '退出登录',
      content: '确定要退出登录吗？',
      okText: '退出',
      cancelText: '取消',
      okButtonProps: { danger: true },
      onOk: () => doLogout(),
    })
  }

  const activeKey = (isCaseRoute || pathname === '/student' || pathname.startsWith('/student/cases')) ? 'cases'
    : pathname.startsWith('/student/records') ? 'records'
    : pathname.startsWith('/student/profile') || pathname.startsWith('/student/join') ? 'profile' : 'cases'

  // 「框框」推广到同级别页面标题，每页一套配色（tb-* 见 StudentLayout.css）：
  // 案例库 pink→blue（默认）/ 案例推演 teal / 我的记录 blue / 账号信息 purple / 加入班级 amber / 学习空间 green。
  const titleBoxVariant: 'cases' | 'play' | 'records' | 'profile' | 'join' | 'home' | null =
    pathname === '/student/cases' ? 'cases'
    : pathname === '/student/records' ? 'records'
    : pathname === '/student/profile' ? 'profile'
    : pathname === '/student/join' || pathname.startsWith('/student/join/') ? 'join'
    : pathname === '/student' ? 'home'
    : isCaseRoute ? 'play'
    : null

  // 页面级导航入口（返回上一级 / 学生首页）：PC 放左侧栏底部，移动端放底部固定导航条。
  // previousPath 已指向学生首页时（如 /student/cases 的上一级就是 /student）不再重复渲染返回键，
  // 避免两个按钮同目标造成误触困惑。
  const showHome = pathname !== '/student'
  const showBack = !!previousPath && previousPath !== '/student'
  const hasNavDock = showBack || showHome
  function goBack() { if (previousPath) navigate(previousPath) }

  if (error) return <Alert type="error" message={error} />
  if (!account) return <Spin />
  return (
    <StudentAccountContext.Provider value={account}>
    <Layout className={'student-shell' + (hasNavDock ? ' has-navdock' : '')} hasSider={!isNarrow}>
      {!isNarrow && <Sider className="student-sider" theme="light" width={208}>
        <div className="student-brand">{account.real_name} · 学生端</div>
        <Menu mode="inline" selectedKeys={[activeKey]} items={STUDENT_NAV}
          onClick={({ key }) => navigate('/student/' + key)} />
        {hasNavDock && <div className="student-sider-nav">
          {showBack && <Button className="student-nav-btn" type="text" icon={<ArrowLeftOutlined />} block
            aria-label="返回上一级" onClick={goBack}>返回上一级</Button>}
          {showHome && <Button className="student-nav-btn" type="text" icon={<HomeOutlined />} block
            aria-label="学生首页" onClick={() => navigate('/student')}>学生首页</Button>}
        </div>}
        <div className="student-sider-footer">
          <Button className="student-logout" type="text" icon={<LogoutOutlined />} block
            onClick={handleLogout}>退出登录</Button>
        </div>
      </Sider>}
      <Layout className="student-content">
        <header className="student-header">
          <h1 className={'student-title' + (titleBoxVariant ? ' title-boxed tb-' + titleBoxVariant : '')}>
            {titleBoxVariant ? <span className="student-title-box">{title}</span> : title}
          </h1>
          {isNarrow && <span>{account.real_name}</span>}
          {isNarrow && <Button onClick={handleLogout}>退出</Button>}
        </header>

        <Content className="student-main">
          <div className="student-page"><Outlet /></div>
          {canTutor && <>
            <FloatButton icon={<span className="tutor-fab-face" aria-hidden="true">🤖</span>} type="primary" tooltip="询问助教" aria-label="AI 商科助教"
              onClick={() => setTutorOpen((open) => !open)}
              style={{ right: 16, bottom: isNarrow ? 132 : 100, width: 56, height: 56 }} />
            {tutorOpen && <div className="student-tutor-panel" role="dialog" aria-label="AI 商科助教">
              <div className="student-tutor-panel-head">
                <Button type="text" aria-label="关闭助教" onClick={() => setTutorOpen(false)}>×</Button>
              </div>
              <div className="student-tutor-panel-body"><StudentTutorSidebar /></div>
            </div>}
          </>}
        </Content>
      </Layout>
      {isNarrow && <div className="student-dock">
        {hasNavDock && <nav className="student-navdock" aria-label="页面导航">
          {showBack && <button type="button" className="navdock-btn" aria-label="返回上一级" onClick={goBack}>
            <ArrowLeftOutlined /><span>返回上一级</span>
          </button>}
          {showHome && <button type="button" className="navdock-btn" aria-label="学生首页" onClick={() => navigate('/student')}>
            <HomeOutlined /><span>学生首页</span>
          </button>}
        </nav>}
        <nav className="student-tabbar" aria-label="主导航">
        {STUDENT_NAV.map((item) => (
          <button key={item.key} type="button"
            className={'tab' + (activeKey === item.key ? ' is-active' : '')}
            aria-current={activeKey === item.key ? 'page' : undefined}
            onClick={() => navigate('/student/' + item.key)}>
            {item.icon}
            <span>{item.label}</span>
          </button>
        ))}
        </nav>
      </div>}
    </Layout>
    </StudentAccountContext.Provider>
  )
}
