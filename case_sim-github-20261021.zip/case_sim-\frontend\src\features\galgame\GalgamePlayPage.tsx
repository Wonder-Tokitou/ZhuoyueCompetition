/**
 * galgame 支线主页（阶段 4 实现）。
 * 流程：封面对话 → 开始营业（startStudent）→ 幕前对话 → 选项 → 反应对话 →
 * 财务追问（理由采集）→ decide → restore → 结算卡 → 下一幕；3 轮后 finished。
 * 落库仍走主线 decide，提交体 { student_name, session_id, node_id, option_key, input_text, duration_ms }；
 * 门闩 busy/uncertain/nodeId 三元组防重复提交；decide 失败先 restore 核对，绝不盲目重试。
 */
import { useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { decide, playGet, restoreStudent, startStudent } from '../../api/client'
import type { Metrics, PlayResponse, SessionState } from '../../api/types'
import { useStudentToken } from '../../context/StudentTokenContext'
import { useStudentAccount } from '../../context/StudentAccountContext'
import { affectionDelta, applyAffection, classifyRisk, endingOf, scoreRound } from './engine/dialogueEngine'
import type { Affection, RiskBranch } from './engine/dialogueEngine'
import { loadSave, rebuildFromSession, saveSave } from './engine/persistence'
import type { GalgameSave } from './engine/persistence'
import { ENDINGS } from './data/endings'
import {
  actOpening,
  askReason,
  buildInputText,
  coverLines,
  reactionScene,
  REASON_PHRASES,
  resumeScene,
} from './data/dialogueTree'
import type { DialogueLine } from './data/dialogueTree'
import SceneBackground from './components/SceneBackground'
import CharacterSprite from './components/CharacterSprite'
import DialogueBox from './components/DialogueBox'
import ChoiceButtons from './components/ChoiceButtons'
import MoodBar from './components/MoodBar'
import RandomEventPopup from './components/RandomEventPopup'
import CGOverlay from './components/CGOverlay'
import { pickEvent } from './data/randomEvents'
import type { RandomEvent } from './data/randomEvents'
import { ACHIEVEMENTS, evaluate as evaluateAchievements } from './data/achievements'
import './galgame.css'

type DialogueKind = 'cover' | 'actOpening' | 'react' | 'askReason' | 'resume'
type Phase = 'cover' | 'dialogue' | 'choice' | 'reason' | 'submitting' | 'settlement' | 'uncertain' | 'finished'

interface SettlementData {
  round: number
  chosenLabel: string
  before: Metrics | null
  after: Metrics | null
  summary: string
  /** 本轮评分（含前几轮累计） */
  score: number
  /** 分项整句（T5.2 模板） */
  breakdown: string[]
  /** 本轮好感度增量（浮字） */
  deltas: Affection
  /** 净利润（万元，两位小数）；financial_state 缺失时 null 并带口径说明 */
  profitValue: number | null
  /** 净利润口径说明：financial_state 缺失时按营收环比估算 */
  profitNote?: string
}

const CFO = '财务'

/** 成就存档键（T6.3：localStorage["galgame_achievements:<token>"]）。 */
const ACH_KEY = (token: string) => `galgame_achievements:${token}`
/** 经营日记键（T6.3：localStorage["galgame_diary:<token>:<session_id>"]，≤12 条截断）。 */
const DIARY_KEY = (token: string, sessionId: number | null) => `galgame_diary:${token}:${sessionId ?? 'none'}`

export interface DiaryEntry {
  round: number
  title: string
  label: string
  summary: string
  revenueDelta: number | null
  cashFlow: number
  events: string[]
}

function loadAchievements(token: string): string[] {
  try {
    const raw = globalThis.localStorage?.getItem(ACH_KEY(token))
    const arr = raw ? JSON.parse(raw) : []
    return Array.isArray(arr) ? arr.filter((x): x is string => typeof x === 'string') : []
  } catch {
    return []
  }
}

function loadDiary(token: string, sessionId: number | null): DiaryEntry[] {
  try {
    const raw = globalThis.localStorage?.getItem(DIARY_KEY(token, sessionId))
    const arr = raw ? JSON.parse(raw) : []
    return Array.isArray(arr) ? arr : []
  } catch {
    return []
  }
}

function appendDiary(token: string, sessionId: number | null, entry: DiaryEntry): void {
  const arr = loadDiary(token, sessionId)
  arr.push(entry)
  while (arr.length > 12) arr.shift()
  globalThis.localStorage?.setItem(DIARY_KEY(token, sessionId), JSON.stringify(arr))
}

/** 当前财务总监表情：现金净流量 < 0 → 焦虑；否则平静。 */
function cfoExpression(cashFlow: number | null | undefined): 'anxious' | 'calm' {
  return typeof cashFlow === 'number' && cashFlow < 0 ? 'anxious' : 'calm'
}

/** 结局页（T5.2）：结局名 + 台词 + CG 占位 + 总分 + 经营日记 + AI 复盘跳转。 */
function FinishedCard({
  token,
  save,
  turns,
  data,
}: {
  token: string
  save: GalgameSave | null
  turns: SessionState['turns']
  data: PlayResponse | null
}) {
  const [showDiary, setShowDiary] = useState(false)
  const kind = endingOf(save?.score ?? 50)
  const ending = ENDINGS.find((e) => e.id === `end.${kind}`) ?? ENDINGS[1]
  return (
    <div className="galgame-finished">
      <p className="galgame-finished-title">{ending.title}</p>
      <div className={`galgame-cg-placeholder is-${kind}`} role="img" aria-label={`${ending.title} 结局画面`}>
        <span>{ending.cgId}</span>
      </div>
      <ul className="galgame-ending-lines">
        {ending.lines.map((line) => <li key={line}>{line}</li>)}
      </ul>
      <p className="galgame-final-score">
        总分 {Math.round(save?.score ?? 50)}
      </p>
      <div className="galgame-finished-actions">
        <button type="button" className="galgame-confirm" onClick={() => setShowDiary((v) => !v)}>
          查看经营日记
        </button>
        <Link
          className="galgame-review-link"
          to={`/student/${token}/review?session=${save?.session_id ?? ''}`}
        >
          查看 AI 复盘
        </Link>
      </div>
      {showDiary && (
        <ol className="galgame-diary">
          {turns.length === 0 && <li>暂无经营记录。</li>}
          {turns.map((turn, i) => {
            const nodeTitle = data?.nodes.find((n) => n.id === turn.node_id)?.title
            return (
              <li key={i}>
                <strong>第 {i + 1} 轮 · {nodeTitle ?? '决策'}</strong>
                <span>选了「{turn.chosen_label ?? '已保存'}」</span>
                <span>{turn.summary}</span>
              </li>
            )
          })}
        </ol>
      )}
    </div>
  )
}

export default function GalgamePlayPage() {
  const token = useStudentToken()
  const account = useStudentAccount()
  const [data, setData] = useState<PlayResponse | null>(null)
  const [state, setState] = useState<SessionState | null>(null)
  const [save, setSave] = useState<GalgameSave | null>(null)
  const [phase, setPhase] = useState<Phase>('cover')
  const [dialogueKind, setDialogueKind] = useState<DialogueKind>('cover')
  const [dialogueLines, setDialogueLines] = useState<DialogueLine[]>([])
  const [lineIdx, setLineIdx] = useState(0)
  const [selectedKey, setSelectedKey] = useState<string | null>(null)
  const [pendingRisk, setPendingRisk] = useState<RiskBranch | null>(null)
  const [reasonPhrase, setReasonPhrase] = useState<string | null>(null)
  const [reasonExtra, setReasonExtra] = useState('')
  const [settlement, setSettlement] = useState<SettlementData | null>(null)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const [loading, setLoading] = useState(true)
  const [at, setAt] = useState(Date.now())
  // 阶段 6：随机事件弹窗 / CG 演出 / 成就提示条
  const [eventPopup, setEventPopup] = useState<RandomEvent | null>(null)
  const [cg, setCg] = useState<{ id: string; label: string } | null>(null)
  const [toast, setToast] = useState('')
  const page = useRef({ token, active: false, busy: false, nodeId: null as number | null, uncertain: false })

  // 成就提示条：3s 自动消失（role="status"）
  useEffect(() => {
    if (!toast) return
    const t = window.setTimeout(() => setToast(''), 3000)
    return () => window.clearTimeout(t)
  }, [toast])

  const node = data?.nodes.find((n) => n.id === state?.next_node_id)
  const act = node?.idx ?? (save?.history.length ?? 0) + 1
  const prevRisk = save?.history.at(-1)?.risk ?? null
  const currentLine = dialogueLines[Math.min(lineIdx, dialogueLines.length - 1)]
  const selectedOption = node?.options.find((o) => o.key === selectedKey)
  const metrics = state?.current_metrics ?? data?.base_metrics ?? null

  // 首屏加载：恢复主线 session（sessionStorage）或拉取案例；绝不动主线数据。
  useEffect(() => {
    let cancelled = false
    const current = { token, active: true, busy: false, nodeId: null as number | null, uncertain: false }
    page.current = current
    setLoading(true)
    setError('')
    async function load() {
      try {
        const session = Number(sessionStorage.getItem('student_session:' + token))
        if (session) {
          const saved = await restoreStudent(token, session)
          if (cancelled) return
          setState(saved)
          setData(saved.play)
          current.nodeId = saved.next_node_id
          const rebuilt = rebuildFromSession(saved)
          setSave(rebuilt)
          if (saved.finished) {
            setPhase('finished')
          } else if (saved.turns.length > 0) {
            setDialogueKind('resume')
            setDialogueLines(resumeScene())
            setPhase('dialogue')
          } else {
            setDialogueKind('cover')
            setDialogueLines(coverLines())
            setPhase('cover')
          }
        } else {
          const play = await playGet(token)
          if (cancelled) return
          setData(play)
          setDialogueKind('cover')
          setDialogueLines(coverLines())
          setPhase('cover')
        }
      } catch (e) {
        if (!cancelled) setError(e instanceof Error ? e.message : '案例暂不可用')
      } finally {
        if (!cancelled) {
          setLoading(false)
          setAt(Date.now())
        }
      }
    }
    void load()
    return () => {
      cancelled = true
      current.active = false
    }
  }, [token])

  function applySession(saved: SessionState) {
    setState(saved)
    setData(saved.play)
    page.current.nodeId = saved.next_node_id
    const rebuilt = rebuildFromSession(saved)
    setSave(rebuilt)
    saveSave(token, rebuilt)
  }

  async function begin() {
    const current = page.current
    if (!current.active || current.busy) return
    current.busy = true
    setBusy(true)
    setError('')
    try {
      const next = await startStudent(token, account.real_name || state?.student_name || '')
      if (!current.active) return
      applySession(next)
      sessionStorage.setItem('student_session:' + token, String(next.session_id))
      if (next.student_name) sessionStorage.setItem('student_name:' + token, next.student_name)
      window.dispatchEvent(new Event('student-session-updated'))
      // T6.2：第 1 轮首次进入播开场 CG（同一局不重复播，seenCg 记账）
      const rebuilt = rebuildFromSession(next)
      if (!rebuilt.seenCg.includes('opening')) {
        const withCg = { ...rebuilt, seenCg: [...rebuilt.seenCg, 'opening'] }
        setSave(withCg)
        saveSave(token, withCg)
        setCg({ id: 'opening', label: '开场 CG' })
      }
      setDialogueKind('actOpening')
      setDialogueLines(actOpening(1, null))
      setLineIdx(0)
      setPhase('dialogue')
      setAt(Date.now())
    } catch (e) {
      if (!current.active) return
      setError(e instanceof Error ? e.message : '开始失败')
    } finally {
      current.busy = false
      if (current.active) setBusy(false)
    }
  }

  /** 对话推进：未播完进下一句；播完后按当前段落切换 phase。 */
  function advanceDialogue() {
    if (lineIdx < dialogueLines.length - 1) {
      setLineIdx(lineIdx + 1)
      return
    }
    if (dialogueKind === 'react') {
      setDialogueKind('askReason')
      setDialogueLines([askReason(act, pendingRisk ?? 'balanced')])
      setLineIdx(0)
    } else if (dialogueKind === 'askReason') {
      setPhase('reason')
    } else if (dialogueKind === 'resume' || dialogueKind === 'actOpening') {
      // T6.1：触发点固定在 pre 结束、choice 之前；once 按 r{n} 记账，同一轮刷新不重复弹
      const ev = state?.session_id ? pickEvent(state.session_id, act) : null
      if (ev && !save?.flags[`ev:r${act}`]) {
        setEventPopup(ev)
      } else {
        setPhase('choice')
      }
    }
    // cover 播完：phase 保持 cover，露出「开始营业」按钮
  }

  /** T6.1：事件关闭 → once 记账 + 写日记 → 继续进选项。事件不改任何数值、不改选项。 */
  function closeEvent() {
    if (!eventPopup) return
    const ev = eventPopup
    const actNum = act
    const nextSave = save
      ? { ...save, flags: { ...save.flags, [`ev:r${actNum}`]: ev.title } }
      : save
    if (nextSave) {
      setSave(nextSave)
      saveSave(token, nextSave)
    }
    appendDiary(token, state?.session_id ?? null, {
      round: actNum,
      title: `随机事件`,
      label: ev.title,
      summary: ev.text,
      revenueDelta: null,
      cashFlow: 0,
      events: [ev.title],
    })
    setEventPopup(null)
    setPhase('choice')
  }

  function handleConfirm(key: string) {
    const option = node?.options.find((o) => o.key === key)
    if (!option) return
    const risk = classifyRisk(option.label)
    setSelectedKey(key)
    setPendingRisk(risk)
    setDialogueKind('react')
    setDialogueLines(reactionScene(act, risk, save?.affection.cfo ?? 60))
    setLineIdx(0)
    setPhase('dialogue')
  }

  async function submitDecision(inputText: string) {
    const current = page.current
    if (!node || !state || !selectedKey || current.busy || current.uncertain || current.nodeId !== node.id) return
    current.busy = true
    setBusy(true)
    setError('')
    setPhase('submitting')
    try {
      await decide(token, {
        student_name: state.student_name,
        session_id: state.session_id,
        node_id: node.id,
        option_key: selectedKey,
        input_text: inputText,
        duration_ms: Math.max(0, Date.now() - at),
      })
      if (!current.active) return
      const saved = await restoreStudent(token, state.session_id)
      if (!current.active) return
      acceptSaved(saved, node.id)
    } catch {
      if (!current.active) return
      // 响应丢失不证明 POST 失败：先核对服务器，绝不盲目重试
      try {
        const saved = await restoreStudent(token, state.session_id)
        if (current.active) acceptSaved(saved, node.id)
      } catch {
        if (current.active) {
          current.uncertain = true
          setPhase('uncertain')
          setError('提交状态待确认，请点击「核对已保存进度」。核对前不会再次提交，以免重复作答。')
        }
      }
    } finally {
      current.busy = false
      if (current.active) setBusy(false)
    }
  }

  function acceptSaved(saved: SessionState, submittedNode: number) {
    const accepted = saved.turns.find((turn) => turn.node_id === submittedNode)
    applySession(saved)
    if (accepted) {
      const roundIndex = saved.turns.indexOf(accepted)
      const before = roundIndex > 0 ? saved.turns[roundIndex - 1].after_metrics : saved.play.base_metrics
      const after = accepted.after_metrics
      const risk = pendingRisk ?? classifyRisk(accepted.chosen_label ?? '')
      // 净利润口径：financial_state 可用则用其环比；否则（simulation.enabled=false 后端不下发）
      // 退化按营收环比估算并在 UI 注明（清单 T5.2 失败处理）。
      const fState = saved.financial_state
      const prevNetProfit = save?.history.at(-1)?.netProfit ?? 0
      let netProfitDelta: number
      let profitValue: number | null
      let profitNote: string | undefined
      if (fState && typeof fState.net_profit === 'number') {
        profitValue = fState.net_profit
        netProfitDelta = fState.net_profit - prevNetProfit
      } else {
        profitValue = null
        netProfitDelta = (after?.revenue ?? 0) - (before?.revenue ?? 0)
        profitNote = '本案例未开启财务仿真，净利润按营收环比估算。'
      }
      const cashFlowAmount = typeof fState?.cash_flow_amount === 'number' ? fState.cash_flow_amount : 0
      const shareDelta = parseFloat(after?.market_share ?? '0') - parseFloat(before?.market_share ?? '0')
      // I.3-10：第 1 轮没有净利润基准，profit 项恒记 0（只按现金流/匹配给分），避免"首轮本来就亏"误判为恶化 −8
      const scored = scoreRound(
        { score: save?.score ?? 50, breakdown: [] },
        { netProfitDelta: roundIndex === 0 ? 0 : netProfitDelta, cashFlowAmount, shareDelta, risk },
      )
      const deltas = affectionDelta(risk)
      const nextAffection = applyAffection(save?.affection ?? { manager: 70, cfo: 60, cmo: 65 }, risk)
      // T6.2 cg.rush：营收环比 ≥ +8% 或份额环比 ≥ +1.5pp 时播爆满 CG（同一局不重复）
      const beforeRevenue = before?.revenue ?? 0
      const revenuePct = beforeRevenue > 0 ? (((after?.revenue ?? 0) - beforeRevenue) / beforeRevenue) * 100 : 0
      const rush = revenuePct >= 8 || shareDelta >= 1.5
      const seenCg = [...(save?.seenCg ?? []), ...(rush ? ['rush'] : [])]
      const nextSave: GalgameSave = {
        ...(save ?? {
          v: 1,
          session_id: null,
          round: 1,
          affection: { manager: 70, cfo: 60, cmo: 65 },
          score: 50,
          finished: false,
          history: [],
          flags: {},
          seenCg: [],
          seenSide: [],
        }),
        session_id: saved.session_id,
        round: roundIndex + 1,
        finished: saved.finished,
        affection: nextAffection,
        score: scored.score,
        seenCg,
        history: [...(save?.history ?? []), { round: roundIndex + 1, risk, cashFlowAmount, netProfit: fState?.net_profit }],
      }
      setSave(nextSave)
      saveSave(token, nextSave)
      // T6.3：结算后判定成就（新解锁弹提示条 3s 自动消失）
      const newly = evaluateAchievements(nextSave).filter((id) => !loadAchievements(token).includes(id))
      if (newly.length > 0) {
        const labels = newly.map((id) => ACHIEVEMENTS.find((a) => a.id === id)?.label ?? id).join('、')
        globalThis.localStorage?.setItem(ACH_KEY(token), JSON.stringify([...loadAchievements(token), ...newly]))
        setToast(`解锁成就：${labels}`)
      }
      // T6.3：逐轮写经营日记（财数变化 + 触发的随机事件）
      const evTitle = save?.flags[`ev:r${roundIndex + 1}`]
      appendDiary(token, saved.session_id, {
        round: roundIndex + 1,
        title: data?.nodes.find((n) => n.id === node.id)?.title ?? '决策',
        label: accepted.chosen_label ?? '已保存',
        summary: accepted.summary,
        revenueDelta: after?.revenue != null && before?.revenue != null ? Number((after.revenue - before.revenue).toFixed(2)) : null,
        cashFlow: cashFlowAmount,
        events: typeof evTitle === 'string' ? [evTitle] : [],
      })
      if (rush) setCg({ id: 'rush', label: '爆满 CG' })
      setSettlement({
        round: roundIndex + 1,
        chosenLabel: accepted.chosen_label ?? selectedOption?.label ?? '已保存',
        before,
        after,
        summary: accepted.summary,
        score: scored.score,
        breakdown: scored.breakdown,
        deltas,
        profitValue,
        profitNote,
      })
      setPhase('settlement')
      window.dispatchEvent(new Event('student-session-updated'))
    } else {
      setError('本回合尚未保存，请核对所选策略后重新确认提交。')
      setPhase('choice')
    }
  }

  async function reconcile() {
    const current = page.current
    if (!state || current.busy || !current.active || current.token !== token) return
    current.busy = true
    setBusy(true)
    try {
      const saved = await restoreStudent(token, state.session_id)
      if (current.active) {
        current.uncertain = false
        page.current.uncertain = false
        acceptSaved(saved, node?.id ?? -1)
      }
    } catch {
      if (current.active) setError('仍无法核对服务器进度，请稍后重试；不会重复提交或自动选择其他策略。')
    } finally {
      current.busy = false
      if (current.active) setBusy(false)
    }
  }

  /** 结算卡「下一幕」：finished → 结局占位；否则进入下一幕开场。 */
  function nextAct() {
    setSelectedKey(null)
    setReasonPhrase(null)
    setReasonExtra('')
    setSettlement(null)
    setError('')
    setAt(Date.now())
    if (state?.finished) {
      // T6.2 cg.ending.*：结局判定后播一次对应 CG（seenCg 记账，不重复）
      const kind = endingOf(save?.score ?? 50)
      const cgId = `ending.${kind}`
      if (!save?.seenCg.includes(cgId)) {
        const withCg = save ? { ...save, seenCg: [...save.seenCg, cgId] } : save
        if (withCg) {
          setSave(withCg)
          saveSave(token, withCg)
        }
        const label = ENDINGS.find((e) => e.id === `end.${kind}`)?.title ?? '结局'
        setCg({ id: cgId, label: `${label} · 结局画面` })
      }
      setPhase('finished')
      return
    }
    const nextActNum = (save?.history.length ?? 0) + 1
    setDialogueKind('actOpening')
    setDialogueLines(actOpening(nextActNum, save?.history.at(-1)?.risk ?? null))
    setLineIdx(0)
    setPhase('dialogue')
  }

  if (loading) {
    return <div className="galgame-loading">加载中…</div>
  }

  const activeId = currentLine && currentLine.speaker !== null
    ? (currentLine.speaker === '店长' ? 'manager' : currentLine.speaker === '财务' ? 'cfo' : 'cmo')
    : null
  const activeDuringReason = phase === 'reason' ? 'cfo' : activeId
  const cashFlow = state?.financial_state?.cash_flow_amount ?? null

  return (
    <div className="galgame-stage">
      <div className="galgame-scene-wrap">
        <div className="galgame-scene">
          <SceneBackground act={act} netProfit={state?.financial_state?.net_profit ?? 0} crowd={2} messy={1} />
        </div>
        <div className="galgame-characters">
          <CharacterSprite
            id="manager"
            expression="calm"
            active={activeDuringReason === 'manager'}
            dimmed={activeDuringReason !== null && activeDuringReason !== 'manager'}
          />
          <CharacterSprite
            id="cfo"
            expression={cfoExpression(cashFlow)}
            active={activeDuringReason === 'cfo'}
            dimmed={activeDuringReason !== null && activeDuringReason !== 'cfo'}
          />
          <CharacterSprite
            id="cmo"
            expression="excited"
            active={activeDuringReason === 'cmo'}
            dimmed={activeDuringReason !== null && activeDuringReason !== 'cmo'}
          />
        </div>

        {(phase === 'dialogue' || (phase === 'cover' && currentLine)) && (
          <DialogueBox
            key={`${dialogueKind}-${lineIdx}`}
            speaker={currentLine?.speaker ?? null}
            avatar={currentLine?.speaker === '店长' ? '👩‍💼' : currentLine?.speaker === '市场' ? '🧑‍🚀' : currentLine?.speaker === CFO ? '👨‍🔬' : '📖'}
            text={currentLine?.text ?? ''}
            onAdvance={advanceDialogue}
          />
        )}
        <MoodBar
          affection={save?.affection ?? { manager: 70, cfo: 60, cmo: 65 }}
          deltas={phase === 'settlement' ? settlement?.deltas ?? null : null}
          round={settlement?.round ?? 0}
        />
      </div>

      {phase === 'cover' && currentLine && lineIdx >= dialogueLines.length - 1 && (
        <button type="button" className="galgame-start" disabled={busy} onClick={() => void begin()}>
          开始营业
        </button>
      )}

      {phase === 'choice' && node && (
        <ChoiceButtons
          options={node.options}
          disabled={busy}
          onConfirm={handleConfirm}
          metrics={metrics}
        />
      )}

      {phase === 'reason' && (
        <div className="galgame-reason">
          <p className="galgame-reason-hint">财务总监在等你的账：挑一句，或直接「就这样定」</p>
          <div className="galgame-reason-phrases">
            {(pendingRisk ? REASON_PHRASES[pendingRisk] : REASON_PHRASES.balanced).map((phrase) => (
              <button
                key={phrase}
                type="button"
                className={`galgame-reason-phrase${reasonPhrase === phrase ? ' is-selected' : ''}`}
                disabled={busy}
                onClick={() => setReasonPhrase(phrase)}
              >
                {phrase}
              </button>
            ))}
          </div>
          <label className="galgame-reason-extra">
            补充说明（选填，≤100 字）
            <input
              type="text"
              maxLength={100}
              value={reasonExtra}
              disabled={busy}
              onChange={(e) => setReasonExtra(e.target.value)}
            />
          </label>
          <button
            type="button"
            className="galgame-confirm"
            disabled={busy}
            onClick={() => void submitDecision(buildInputText(selectedOption?.label ?? '未命名策略', reasonPhrase, reasonExtra))}
          >
            就这样定
          </button>
        </div>
      )}

      {phase === 'submitting' && <div className="galgame-saving" role="status">正在保存你的决策…</div>}

      {phase === 'uncertain' && (
        <div className="galgame-uncertain">
          <p>{error}</p>
          <button type="button" className="galgame-confirm" disabled={busy} onClick={() => void reconcile()}>
            核对已保存进度
          </button>
        </div>
      )}

      {phase === 'settlement' && settlement && (
        <div className="galgame-settlement">
          <p className="galgame-settlement-title">第 {settlement.round} 轮结果 · {settlement.chosenLabel}</p>
          <p className="galgame-settlement-summary">{settlement.summary}</p>
          {settlement.after && (
            <dl className="galgame-metrics-grid">
              <div><dt>营收</dt><dd>{settlement.after.revenue} 万元</dd></div>
              <div><dt>毛利率</dt><dd>{settlement.after.gross_margin}</dd></div>
              <div><dt>市场份额</dt><dd>{settlement.after.market_share}</dd></div>
              <div><dt>现金流</dt><dd>{settlement.after.cash_flow}</dd></div>
              <div>
                <dt>净利润</dt>
                <dd>{settlement.profitValue === null ? '—' : `${settlement.profitValue.toFixed(2)} 万元`}</dd>
              </div>
            </dl>
          )}
          {settlement.profitNote && <p className="galgame-profit-note">{settlement.profitNote}</p>}
          <div className="galgame-settle-score">
            <span className="galgame-settle-score-label">本局分数</span>
            <span className="galgame-settle-score-value">{settlement.score}</span>
          </div>
          {settlement.breakdown.length > 0 && (
            <ul className="galgame-breakdown">
              {settlement.breakdown.map((line) => <li key={line}>{line}</li>)}
            </ul>
          )}
          <button type="button" className="galgame-confirm" onClick={nextAct}>
            {state?.finished ? '查看结局' : '进入下一幕'}
          </button>
        </div>
      )}

      {phase === 'finished' && <FinishedCard token={token} save={save} turns={state?.turns ?? []} data={data} />}

      {error && phase !== 'uncertain' && <p className="galgame-error">{error}</p>}
    </div>
  )
}
