/**
 * 本地存档 + 服务器重建（阶段 1 实现）。
 * localStorage 键：galgame_save:<token>；session_id 复用主线 student_session:<token>（本模块不写该键）。
 */
import { applyAffection, classifyRisk, scoreRound } from './dialogueEngine'
import type { Affection, RiskBranch, ScoreState } from './dialogueEngine'
import type { SessionState } from '../../../api/types'

export interface GalgameHistoryEntry {
  round: number
  risk: RiskBranch
  /** 本轮现金净流量（万元）；从服务器 turns 重建时无法恢复，填 0 */
  cashFlowAmount: number
  /** 本轮净利润（万元，financial_state 口径）；重建时无法恢复，缺省 */
  netProfit?: number
}

export interface GalgameSave {
  v: 1
  session_id: number | null
  round: number
  affection: Affection
  score: number
  finished: boolean
  history: GalgameHistoryEntry[]
  /** 分支/事件记账：`ev:r{n}` 存事件标题（已触发过 = 不再弹）；其余布尔标记 */
  flags: Record<string, boolean | string>
  seenCg: string[]
  seenSide: string[]
}

const KEY = (token: string) => `galgame_save:${token}`

export const INITIAL_AFFECTION: Affection = { manager: 70, cfo: 60, cmo: 65 }

function emptySave(): GalgameSave {
  return {
    v: 1,
    session_id: null,
    round: 1,
    affection: { ...INITIAL_AFFECTION },
    score: 50,
    finished: false,
    history: [],
    flags: {},
    seenCg: [],
    seenSide: [],
  }
}

export function loadSave(token: string): GalgameSave | null {
  try {
    const raw = globalThis.localStorage?.getItem(KEY(token))
    if (!raw) return null
    const parsed = JSON.parse(raw) as GalgameSave
    if (parsed?.v !== 1 || typeof parsed.affection?.cfo !== 'number') return null
    return parsed
  } catch {
    return null
  }
}

export function saveSave(token: string, save: GalgameSave): void {
  globalThis.localStorage?.setItem(KEY(token), JSON.stringify(save))
}

/**
 * 从服务器 SessionState 重建本地表现层存档：
 * round 与 finished 以服务器为准；好感度用 turns 的 chosen_label 逐轮累计；
 * 分数同样逐轮累计（netProfitDelta 用营收环比、cashFlowAmount 填 0，与
 * financial_state 缺失时的结算口径一致）；cashFlowAmount 无法恢复填 0。
 */
export function rebuildFromSession(state: SessionState): GalgameSave {
  const save = emptySave()
  save.session_id = state.session_id
  save.round = state.turns.length + 1
  save.finished = state.finished
  let affection: Affection = { ...INITIAL_AFFECTION }
  let scoreState: ScoreState = { score: 50, breakdown: [] }
  for (let i = 0; i < state.turns.length; i++) {
    const label = state.turns[i].chosen_label ?? ''
    const risk = classifyRisk(label)
    affection = applyAffection(affection, risk)
    const before = i > 0 ? state.turns[i - 1].after_metrics : state.play?.base_metrics ?? null
    const after = state.turns[i].after_metrics
    // I.3-10：第 1 轮无净利润基准，profit 项恒 0
    const netProfitDelta = i === 0 ? 0 : (after?.revenue ?? 0) - (before?.revenue ?? 0)
    const shareDelta = parseFloat(after?.market_share ?? '0') - parseFloat(before?.market_share ?? '0')
    scoreState = scoreRound(scoreState, { netProfitDelta, cashFlowAmount: 0, shareDelta, risk })
    save.history.push({ round: i + 1, risk, cashFlowAmount: 0 })
  }
  save.affection = affection
  save.score = scoreState.score
  return save
}
