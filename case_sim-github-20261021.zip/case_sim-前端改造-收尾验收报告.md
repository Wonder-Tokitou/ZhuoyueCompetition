# case_sim 前端改造 · 收尾验收报告

> 执行窗口：2026-10-20 18:37 – 20:12
> 项目根：`C:\Users\huang2006\Desktop\Work\upload2\case_sim-\`
> 改造范围：仅 `frontend/`，后端、契约、AI 组件的源码零改动
> 结论：**验收通过，可以收尾**

---

## 一、终态证据（本人独立复跑，非引用 agent 自述）

| 检查项 | 结果 | 复核方式 |
|---|---|---|
| 前端测试 | **60 passed / 60 total，0 fail** | 复跑 `npm test`，`# pass 60 / # fail 0`，5.37s |
| 后端测试 | **184 passed / 184 total，0 fail** | 复跑 `.venv\Scripts\python.exe -m pytest -q`，进度点 72+72+40=184 全为 `.`，100% |
| 类型检查 | **0 错误** | 复跑 `npx tsc -b`，退出码 0、无输出 |
| 前端构建 | **成功** | agent 报告 568ms；dist 1,833.78 kB（index 663.14 + antd-vendor 1,052.32 + antd-icons 118.32） |
| 红线：`baselineFinance.ts` | 未改 | 1531 B / mtime 11:04:59 / SHA256 `7f3b094e…` — 与报告逐字节一致 |
| 红线：`financials.js` | 未改 | 301 B / mtime 11:04:59 / SHA256 `40e4b91a…` — 与报告一致 |
| 红线：`backend/` `contracts/` `ai_component/` | 未改源码 | mtime 审计：晚于基线的仅 `__pycache__`、`.pytest_cache`、`data/app.db`、artifacts、requirements-dev.txt |
| 路径别名使用 | **0 处** | 全仓搜索 `from '@(components\|features\|api\|pages\|layouts\|domain)/` → 无匹配 |
| ECharts 全量引入 | **0 处** | 全仓搜索 `import * as echarts from 'echarts'` → 3 命中**全在注释里**（两处文件头说明"禁止全量引入"），真实 import 为 `from 'echarts/core'` |
| 依赖卫生 | 干净 | `package.json` 含 `echarts ^6.1.0`，**无** `echarts-for-react` |

---

## 二、九个阶段交付对照

| 阶段 | 内容 | 交付 | 状态 |
|---|---|---|---|
| 0 | AI 盘点现状 | 规模、高危点、依赖、端口 | ✅ |
| 1 | 冻结接口契约 | 权威顺序：`backend/app/schemas.py` → `api/types.ts` | ✅ |
| 1.5 | 路径别名 | `vite.config.ts` 7 条 alias + `tsconfig.app.json` paths（**配而未用**） | ✅ |
| 2 | 主题与测试保卫战 | `ThemedApp` 按路由切主色；3 个源码文本契约测试改写为行为断言 | ✅ |
| 3 | 教师端视觉收尾 | 状态文字→彩色 Tag、`STATUS_META` 改色、CSS 变量接上消费方 | ✅ |
| 4 | CalibratePanel 拆分 | 680 行 → **89 行**；新增 `useCalibrationState.ts`(398) + `BaselineSection.tsx`(140) + `NodeSection.tsx`(207) | ✅ |
| 5 | 班级仪表盘 | `OptionDistributionChart.tsx`（A/B/C 柱状 + 活跃折线）+ 4 个 KPI 卡 | ✅ |
| 6 | 学生推演页 | Steps 进度条、2×2 财务卡+趋势箭头、策略卡片化、结果 Alert | ✅ |
| 7 | 学生复盘可视化 | `ReviewCharts.tsx`（5 维雷达 280px + 3 轮折线 220px） | ✅ |
| 8 | AI 助教 FAB | `FloatButton`（#db2777，56×56）+ 浮动面板（360×480 / ≤640px 60vh） | ✅ |
| 9 | 全量回归 | 60/60 + 184/184 + 红线通过 | ✅ |

---

## 三、关键决策回顾

| 决策 | 结论 | 依据 |
|---|---|---|
| D3 图表库 | **ECharts 按需引入**（80–130KB gzip） | 用户 2026-10-20 19:09 拍板；视觉最专业，雷达图是强项 |
| `echarts-for-react` | **弃用** | 其 3.0.6 ESM 入口即 `import * as echarts from 'echarts'`，与按需引入硬冲突；构建实测 index 达 1,245KB |
| 图表封装 | 自写约 30 行（init / setOption / resize / dispose） | 彻底按需，体积增量 index 仅 +2.46 kB（与教师端共享） |
| 复盘图表落位 | `features/ai/` 而非 `pages/student/components/` | `architecture.test.cjs` 硬约束"features/ai 禁止依赖 pages/" |
| CalibratePanel 拆分方式 | 按 `stage` 拆子组件，**不新增 Steps** | 父组件已有 4 步 Steps，再加会双层嵌套 |
| 路径别名 | 配置保留，业务代码**不启用** | 测试 vm 沙箱以相对路径为 mock key，启用即崩 |

---

## 四、已知限制（全部为预先声明的 mock 或存量 bug，无隐藏项）

### 4.1 前端 mock 数据

| # | 位置 | 内容 | 待补 |
|---|---|---|---|
| 1 | 教师班级仪表盘 KPI | 已完成人数 12、卡节点 2 人数 3、人均营收 86 万、平均时长 22 分钟 | `GET /teacher/dashboard/summary` |
| 2 | 教师班级仪表盘图表 | A/B/C 占比 30/50/20、活跃趋势 7 点 | `GET /teacher/dashboard/option-distribution`、`/recent-activity` |
| 3 | 学生复盘雷达图 | 5 维分数 `[82,75,68,90,78]` | 复盘响应补 `dimension_scores` |
| 4 | 学生推演策略卡 | `risk_level` / `description` 无下发 → 走中性占位色 `#d1d5db` / `#1a3a5c` | `OptionBrief` 扩字段（注意防剧透） |
| 5 | 学生推演结果 | 班级均值、标杆路径 | 需聚合接口 |

> 所有 mock 均在代码中有 `TODO` 注释，页面/组件有可见说明文字，**未伪装为真实数据**。

### 4.2 存量 bug（本次改造明确不处理，避免 scope creep）

**D-02（用户可见故障）**：`TeacherRecordsPage.tsx` 版本筛选器失效。
- 根因：前端 `StudentRecord` 声明 16 字段，后端 `schemas.py:381` 只返回 8 个（`student_name`/`student_id`/`attempt_no`/`turns`/`session_id`/`review_id`/`review_status`/`review`）。
- 症状：`TeacherRecordsPage.tsx:31` 版本集合恒为 `['unknown']` → 筛选器只有"全部版本/历史版本未知" → 版本列恒"未记录"。
- 两条修复路径：① 后端补字段（超出"只改 frontend/"边界）② 前端删掉版本列与筛选器。

**D-01（无症状）**：`DecideResult.financial_state` 后端返回但前端 `types.ts` 未声明，靠"提交后重取会话"侥幸正常。

**D-03（契约特性）**：递进模拟接口是唯一 `extra="forbid"` 严格契约，DTO 藏在 `domain/progressive.py` 而非 `schemas.py`。

---

## 五、复核中发现但未改动的三处代码卫生问题

均在阶段 8（FAB）落地时引入，**不影响功能、不影响测试**，为避免 scope creep 未做修改：

| # | 问题 | 位置 | 实际影响 |
|---|---|---|---|
| 1 | `.decision-submit { padding-right: 76px }` 已失效 | `StudentLayout.css:147`；被 `:175` 的 `padding: 12px 0 max(...)` 简写重置为 0 | 无。FAB 在 bottom 80–136px、提交区高 0–70px，几何上不重叠 |
| 2 | `@media (max-width: 800px)` 重复两次 | `:152-154` 与 `:191-205`，前者是后者子集 | 无（CSS 层叠幂等） |
| 3 | `.with-tutor` 死选择器 + 旧列宽残留 | `:152`、`:192` 引用已移除的 class；`:116` 的 `360px` 列宽被 `:158` 覆盖 | 无 |

> 若要清理，约 5 行删除，零行为变更。

---

## 六、环境事实（踩过的坑，后续复用）

1. **后端必须从项目根启动**：`backend/app/main.py` 内部 `from backend.app.*` 导入，从 `backend/` 跑 `uvicorn app.main:app` 会 `ModuleNotFoundError`。
   正确：`cd case_sim- && .venv\Scripts\python.exe -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8110`

2. **pytest 同理**：`backend/` 与 `backend/tests/` 均无 `__init__.py`，无 pytest 配置，测试统一 `from backend.app import ...`。
   从 `backend/` 跑 → **25 个 collection error、仅收集 2 个用例**（实测）。
   正确：`cd case_sim- && .venv\Scripts\python.exe -m pytest`，**收集数 184**。

3. **项目不是 git 仓库**（无 `.git`），`git diff` 不可用；变更审计用 `find src tests -newermt "2026-10-20 00:00" -type f` + 红线文件 SHA256。

4. **ECharts option 字段写错会静默失败**（不报错、不显示），必须人眼在浏览器确认"画出来了"——本次 4 个图表均经 canvas 像素级验证。

---

## 七、建议的后续动作（按优先级）

| 优先级 | 动作 | 说明 |
|---|---|---|
| P1 | 后端补 3 个 dashboard 聚合接口 | 让班级仪表盘从 mock 转真实；接口签名已在阶段 5 报告中列出 |
| P2 | 复盘响应补 `dimension_scores` | 雷达图转真实数据，需定义 5 维评分口径 |
| P3 | 决策 D-02：补字段 or 删列 | 建议先删列止血（纯前端、零风险），后续再补后端字段恢复功能 |
| P4 | 清理阶段 8 的三处死代码 | 可选，5 行删除 |

---

*本报告由执行清单阶段 9 产出，所有数据经独立复跑核实。*
