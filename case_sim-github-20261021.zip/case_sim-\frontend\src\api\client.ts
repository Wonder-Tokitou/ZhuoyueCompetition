import { api } from './transport'
export { api } from './transport'
export type { ApiError } from './transport'
import type {
  CaseListItem,
  CreateCasePayload,
  CreateCaseResponse,
  CreateTeacherAccountPayload,
  DecidePayload,
  DecideResponse,
  GetCaseResponse,
  GenerateNodesPayload,
  AiTaskResponse,
  LoginResponse,
  LibraryScope,
  OkResponse,
  PatchCasePayload,
  PatchNodePayload,
  PlayResponse,
  PublishResponse,
  LeaderboardResponse,
  RegisterTeacherPayload,
  StudentLibraryCase,
  StudentRecord,
  SessionState,
  TeacherAccount,
  TeacherAccountManagePayload,
  TrashCaseItem,
  ClassGroupItem,
  ClassMemberItem,
  ClassQrResponse,
  JoinClassResponse,
  MyClassItem,
} from './types'

/* ---------- 老师端（T1–T9） ---------- */

/** T1 教师登录：用户名+密码（多账号）；不传 username 时按全局口令登录（历史兼容） */
export async function loginTeacher(payload: { username?: string; password: string }): Promise<LoginResponse> {
  const { data } = await api.post<LoginResponse>('/teacher/login', payload)
  return data
}

/** 教师注册（需 TEACHER_PASSWORD 管理口令）：建立多账号体系的第一个账号 */
export async function registerTeacher(payload: RegisterTeacherPayload): Promise<TeacherAccount> {
  const { data } = await api.post<TeacherAccount>('/teacher/register', payload)
  return data
}

/** 当前令牌对应的教师信息；全局口令令牌返回 teacher=null */
export async function getTeacherMe(token: string): Promise<{ teacher: TeacherAccount | null }> {
  const { data } = await api.get<{ teacher: TeacherAccount | null }>('/teacher/me', { params: { token } })
  return data
}

/** 教师账号列表 */
export async function listTeacherAccounts(token: string): Promise<TeacherAccount[]> {
  const { data } = await api.get<TeacherAccount[]>('/teacher/accounts', { params: { token } })
  return data
}

/** 已登录教师为同事创建账号 */
export async function createTeacherAccount(token: string, payload: CreateTeacherAccountPayload): Promise<TeacherAccount> {
  const { data } = await api.post<TeacherAccount>('/teacher/accounts', payload, { params: { token } })
  return data
}

/** 改名 / 停用启用 / 重置密码 */
export async function patchTeacherAccount(token: string, accountId: number, payload: TeacherAccountManagePayload): Promise<TeacherAccount> {
  const { data } = await api.patch<TeacherAccount>(`/teacher/accounts/${accountId}`, payload, { params: { token } })
  return data
}

/** 教师登出：服务端吊销令牌（数据库 + 缓存双清），幂等 */
export async function logoutTeacher(token: string): Promise<OkResponse> {
  const { data } = await api.post<OkResponse>('/teacher/logout', undefined, { params: { token } })
  return data
}

/** T2 创建案例（multipart：file 与 text 必须提供其一；case_type 必填；token 可选，传入则归属到登录教师） */
export async function createCase(payload: CreateCasePayload): Promise<CreateCaseResponse> {
  const form = new FormData()
  form.append('title', payload.title)
  form.append('case_type', payload.case_type)
  if (payload.file) {
    form.append('file', payload.file)
  }
  if (payload.text) {
    form.append('text', payload.text)
  }
  if (payload.framework_id !== undefined) {
    form.append('framework_id', String(payload.framework_id))
  }
  if (payload.token) {
    form.append('token', payload.token)
  }

  // 这里只等待上传/解析与任务入库；模型在后台执行，不随请求结束取消。
  const { data } = await api.post<CreateCaseResponse>('/cases', form, { timeout: 300000 })
  return data
}

/** 持久化 AI 任务状态；教师工作台通常通过案例详情轮询，这个接口供诊断页使用。 */


/** T3 案例列表（响应是裸数组） */
export async function listCases(token: string): Promise<CaseListItem[]> {
  const { data } = await api.get<CaseListItem[]>('/cases', { params: { token } })
  return data
}

/** T4 案例详情（教师端节点的选项带风险等级与后果，供校准） */
export async function getCase(caseId: number, token: string): Promise<GetCaseResponse> {
  const { data } = await api.get<GetCaseResponse>(`/cases/${caseId}`, { params: { token } })
  return data
}

/** T5 修改案例级信息（标题 / 基准数据） */
export async function patchCase(
  caseId: number,
  token: string,
  payload: PatchCasePayload,
): Promise<OkResponse> {
  const { data } = await api.patch<OkResponse>(
    `/cases/${caseId}`,
    payload,
    { params: { token } },
  )
  return data
}

/** T6 修改节点级信息（情境 / 选项） */
export async function patchNode(
  caseId: number,
  nodeId: number,
  token: string,
  payload: PatchNodePayload,
): Promise<OkResponse> {
  const { data } = await api.patch<OkResponse>(
    `/cases/${caseId}/nodes/${nodeId}`,
    payload,
    { params: { token } },
  )
  return data
}

export async function generateCaseNodes(caseId: number, token: string, payload: GenerateNodesPayload): Promise<AiTaskResponse> {
  return (await api.post<AiTaskResponse>(`/cases/${caseId}/generate-nodes`, payload, { params: { token } })).data
}

export async function deleteCase(caseId: number, token: string) {
  return (await api.delete(`/cases/${caseId}`, { params: { token } })).data
}

/** 案例回收站：教师"删除"（软删除）的案例列表 */
export async function listTrashCases(token: string): Promise<TrashCaseItem[]> {
  const { data } = await api.get<TrashCaseItem[]>('/cases/trash', { params: { token } })
  return data
}

/** 从回收站恢复案例（学生端可见性随原案例库范围立即恢复） */
export async function restoreCase(caseId: number, token: string): Promise<OkResponse> {
  const { data } = await api.post<OkResponse>(`/cases/${caseId}/restore`, undefined, { params: { token } })
  return data
}

/** 彻底删除案例（不可撤销，含全部关联记录与 AI 产物） */
export async function purgeCase(caseId: number, token: string): Promise<OkResponse> {
  const { data } = await api.delete<OkResponse>(`/cases/${caseId}/purge`, { params: { token } })
  return data
}

export async function deleteStudentSubmission(token: string, sessionId: number) {
  return (await api.delete(`/play/${encodeURIComponent(token)}/sessions/${sessionId}`)).data
}

export async function resetStudentSubmission(token: string, sessionId: number) {
  return (await api.post<SessionState>(`/play/${encodeURIComponent(token)}/sessions/${sessionId}/reset`)).data
}

export async function rollbackStudentSubmission(token: string, sessionId: number, nodeIdx: number) {
  return (await api.post<SessionState>(`/play/${encodeURIComponent(token)}/sessions/${sessionId}/rollback/${nodeIdx}`)).data
}

/** T7 请求 AI 修正建议（只出建议，不落库） */

/** T8 发布案例（返回学生端链接与二维码地址）；scope 决定进入个人案例库或校案例库 */
export async function publishCase(caseId: number, token: string, scope: LibraryScope = 'school'): Promise<PublishResponse> {
  const { data } = await api.post<PublishResponse>(
    `/cases/${caseId}/publish`,
    undefined,
    { params: { token, scope } },
  )
  return data
}

/** 停止 / 恢复某案例的学生推演；停止后历史记录保留但只读 */
export async function setCasePlayLock(caseId: number, token: string, locked: boolean): Promise<OkResponse> {
  const { data } = await api.post<OkResponse>(
    `/cases/${caseId}/play-lock`,
    { locked },
    { params: { token } },
  )
  return data
}

/** T9 学生推演记录（响应是裸数组，按 session 分组） */
export async function getRecords(caseId: number, token: string): Promise<StudentRecord[]> {
  const { data } = await api.get<StudentRecord[]>(`/cases/${caseId}/records`, {
    params: { token },
  })
  return data
}

/** 学生推演结果排行榜：路径匹配教师推荐路径 + 财务指标（营收/毛利率/市场份额/现金流） */
export async function getLeaderboard(caseId: number, token: string): Promise<LeaderboardResponse> {
  const { data } = await api.get<LeaderboardResponse>(`/cases/${caseId}/leaderboard`, {
    params: { token },
  })
  return data
}

/* ---------- 学生端（S1、S2、S4、S5；S3 问答走 SSE 流，另行实现） ---------- */

/** 学生端「校案例库」：各教师上传的已发布案例（含教师名称、类型、累计推演次数），可按类型筛选 */
export async function getStudentLibraryCases(caseType?: string): Promise<StudentLibraryCase[]> {
  const { data } = await api.get<StudentLibraryCase[]>('/student/cases', { params: { case_type: caseType || undefined } })
  return data
}

/** S1 拉取案例标题与全部节点（选项只有 key/label） */
export async function playGet(studentToken: string): Promise<PlayResponse> {
  const { data } = await api.get<PlayResponse>(`/play/${studentToken}`)
  return data
}

export async function startStudent(token: string, name: string): Promise<SessionState> {
  return (await api.post<SessionState>(`/play/${encodeURIComponent(token)}/sessions`, { student_name: name })).data
}

export async function restoreStudent(token: string, session: number): Promise<SessionState> {
  return (await api.get<SessionState>(`/play/${encodeURIComponent(token)}/sessions/${session}`)).data
}


/** S2 提交一次决策 */
export async function decide(
  studentToken: string,
  payload: DecidePayload,
): Promise<DecideResponse> {
  const { data } = await api.post<DecideResponse>(`/play/${studentToken}/decide`, payload)
  return data
}

/** S4 复盘报告 */

/** S3 学生端 AI 助教：读取 SSE，不把完整上下文暴露给前端日志。 */


/** S5 学生自助试算（临时案例，不入案例库） */

/* ---------- 班级与扫码加入 ---------- */

export async function listTeacherClasses(token: string): Promise<ClassGroupItem[]> {
  const { data } = await api.get<ClassGroupItem[]>('/teacher/classes', { params: { token } })
  return data
}

export async function createClass(token: string, name: string): Promise<ClassGroupItem> {
  const { data } = await api.post<ClassGroupItem>('/teacher/classes', { name }, { params: { token } })
  return data
}

export async function getClassQr(token: string, classId: number): Promise<ClassQrResponse> {
  const { data } = await api.get<ClassQrResponse>(`/teacher/classes/${classId}/qrcode`, { params: { token } })
  return data
}

export async function getClassMembers(token: string, classId: number): Promise<ClassMemberItem[]> {
  const { data } = await api.get<ClassMemberItem[]>(`/teacher/classes/${classId}/members`, { params: { token } })
  return data
}

export async function addClassMember(token: string, classId: number, username: string): Promise<OkResponse> {
  const { data } = await api.post<OkResponse>(`/teacher/classes/${classId}/members`, { username }, { params: { token } })
  return data
}

export async function removeClassMember(token: string, classId: number, studentId: number): Promise<OkResponse> {
  const { data } = await api.delete<OkResponse>(`/teacher/classes/${classId}/members/${studentId}`, { params: { token } })
  return data
}

/** 学生扫码加入班级（幂等：已在班级返回 joined=false） */
export async function joinClass(code: string): Promise<JoinClassResponse> {
  const { data } = await api.post<JoinClassResponse>(`/student/join/${encodeURIComponent(code)}`)
  return data
}

export async function myClasses(): Promise<MyClassItem[]> {
  const { data } = await api.get<MyClassItem[]>('/student/my-classes')
  return data
}
