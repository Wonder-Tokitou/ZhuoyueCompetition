# case_sim 前端游戏化改造：AI 自治执行清单（限定版）

> **定位**：把学生端从"换了颜色的教师端"改成"暖色经营风"，教师端只补品牌层次，不动专业感。
>
> **采用范围**：P0 + P1（视觉层）。**明确不做** 3D 翻牌、勋章体系、桌面隐喻复盘页。
>
> **参考项目**：
> - [alyssaxuu/carden](https://github.com/alyssaxuu/carden)（490★）— 卡片 hover 抬升与选中反馈（**只借鉴 hover 位移，不借鉴 3D 翻转**）
> - [Starmax-technology/wuqingnan-star.github.io](https://github.com/Starmax-technology/wuqingnan-star.github.io) — KPI 卡片行布局（阶段 7）
> - [ant-design/ant-design](https://github.com/ant-design/ant-design) — 主题 Token 覆盖方式：https://ant.design/docs/react/customize-theme
> - [learnhouse/learnhouse](https://github.com/learnhouse/learnhouse) — 学生端轻量氛围（阶段 2/5）
>
> **已评估但排除**（勿再重复讨论）：`rohitg00/k8sgames`（3D/three.js，与 form 型推演不匹配）、`mental-os/Aurora-OS.js`（桌面隐喻，改动面过大）、`NationalSecurityAgency/skills-service`（勋章/等级体系，与商科严肃定位冲突）。

---

## 修订记录

### 2026-10-21｜阶段 5 同步阶段 0–4 的全部反馈

阶段 0–4 已执行完毕（产物在 `case_sim-/docs/ui-baseline/`，逐阶段验收记录在 `tools/stage-{1,2,3,4}-verify.txt`）。按这些实测结论重写本阶段，**只改阶段 5 一节，其余原文不动**：

1. **判据 65 → 85**（P1）：U1 即时结算单落地后新增 20 个用例，阶段 5 的 DoD 一律按 85/85 判定。
2. **「测试断言它」不成立**（P2）：阶段 5 原文说「第 X / 3 轮 · 已提交 Y 轮」被测试断言，实测全仓零引用，已改为「建议保留」。
3. **新增取证前置**（P4）：阶段 3 踩过「不重建 dist 就读到旧包」的坑，本阶段要求 `npm run build` 之后再截图。
4. **新增死代码清理任务 P7/P8**：`.ant-steps` 两条 CSS 与 `roundSteps`/`roundNodes` 随 Steps 一起下线。
5. **新增「阶段 0–4 反馈清单」表**（P1–P11），逐条写明处理方式与验证方式。

### 2026-10-20｜阶段 0 实测校正（基线数字与行号）

阶段 0 已在 `case_sim-/docs/ui-baseline/` 完成并冻结基线，据此修订本文三处与代码现状不符的地方。**改动只涉及数字与事实描述，阶段目标与验收逻辑未变。**

1. **测试基数 60 → 65（前端）、184 → 189（后端）**。2026-10-20 的并发修复新增 5 条前端用例与 5 条后端用例，本文全文数字已同步替换。阶段 9 的判据是 **前端 65/65、后端 189/189**。
2. **阶段 3 的行号漂移**：`RISK_META` / `RISK_PLACEHOLDER` 的取值逻辑实际在 `StudentPlayPage.tsx:240-243`（不是 225-229 行，文件共 277 行）。
3. **阶段 5 的「测试断言它」不成立**：「第 X / 3 轮 · 已提交 Y 轮」在 `StudentPlayPage.tsx:214` 是模板拼接，且 `finished` 时走「三轮推演已完成」分支；**全仓没有任何测试断言引用它**。换掉 Steps 时保留这行文本属建议项，不是测试强制。
4. **阶段 6 的「right:16 bottom:80」不存在**：`.ant-float-btn` 只有 `position: fixed; z-index: 1000`（`StudentLayout.css:146`），坐标是 antd 默认值；真正写死坐标的是助教面板 `right:16; bottom:152px`（L121–134）。该约束应理解为「不许给 FAB 加定位覆盖」。

**新增的硬约束（阶段 3 必读，来自基线扫描）**：`tests/student-play.test.cjs:61/70/187/189` 用 `b.className === 'strategy-option'` **严格相等**定位策略按钮。给该按钮**追加任何 class** 都会让 `options(page)` 变成空数组、连带 6 个用例失败。按序号配色只能落在 `.strategy-option-card` 的内联 style / CSS 变量上。完整冻结表见 `docs/ui-baseline/text-assertions.md`（F1–F25）。

**已确认的决策点**：D1 仅学生端换肤、D2 按 A/B/C 序号固定蓝/紫/青（无风险语义）、D3 教师端 KPI 升级要做（只改 `TeacherStudentsPage.tsx`）；另经确认在阶段 2 顺手把 `html` 在 `body.student-body` 下改为同款暖色（清单外唯一增补）。

---

## 全局铁律（每个阶段都必须遵守）

1. **路径别名"配而未用"**：`vite.config.ts` 有 7 条 alias、`tsconfig.app.json` 有 paths，但业务代码全部相对导入。原因：测试用 vm 沙箱、以相对路径字符串作 mock key（`'./baselineFinance'`、`'./StudentTutorSidebar'` 等），启用别名会让 require 拦截表匹配不到 → 测试崩。**任何新代码禁止写 `@components/...`**。
2. **教师端零改动**：除阶段 7（KPI 卡片）外，`pages/teacher/**` 与 `teacher.css` 不许碰。
3. **主色不许漂**：教师端 `#1a3a5c`、学生端 `#db2777` 保持不变；游戏化只新增**辅助色**，不替换主色。
4. **测试只许改断言、不许删断言**：现有 65 个前端用例是行为契约。文案变了就同步改断言，禁止 `test.skip`、禁止删用例。
5. **移动端 480px 不允许横向溢出**：改动后必须验 `scrollWidth === clientWidth`。
6. **必须尊重 `prefers-reduced-motion`**：`StudentLayout.css:206` 已有全局降级块，新增动效不得绕开它。
7. **财务联动红线**：`pages/teacher/components/baselineFinance.ts`、`domain/financials.js` 不许动。
8. **不加新依赖**：图表用已有 ECharts 或内联 SVG；动画用 CSS；不装 framer-motion 之类。

---

## 决策点（开跑前确认，已预填推荐值）

| 编号 | 决策 | 推荐 | 备选 | 影响 |
|---|---|---|---|---|
| **D1** | 换肤范围 | **仅学生端** | 双端一起换 | 双端换会毁掉教师端专业感，且 40+ 教师端测试要重验 |
| **D2** | 策略卡配色依据 | **按选项序号 A/B/C 固定三色（中性区分色）** | 等后端补 `risk_level` | 现在 `OptionBrief` 只有 `key+label`，没有风险字段；按序号是唯一零后端改动的方案。**用蓝/紫/青而非绿/橙/红**，避免学生误以为 A=保守、B=稳健、C=激进 |
| **D3** | 教师端 KPI 是否升级 | **做**（只改 `TeacherStudentsPage.tsx`） | 跳过 | 只加图标 + SVG sparkline，零新依赖，风险低 |

> D2 说明：按序号配色**不代表风险语义**，只做视觉区分。卡片上仍显示"风险待评估"文字，避免误导学生。若将来后端给 `OptionBrief` 下发 `risk_level`，再切回语义配色（届时只改 `RISK_META` 一个对象）。

---

## 立即开始（3 步，约 5 分钟）

1. **确认决策点**：上方 D1–D3 已预填推荐值，直接接受即可；要改现在说，改完再往下。
2. **环境自检**（cmd 逐条粘贴，见 T0.1）。
3. **把 0.6 的提示词整段发给前端 AI 对话**，它会按 A→E 顺序产出 7 个文件。

阶段 0 全部勾选通过后，再进入阶段 1（设计令牌）。

> ⚠️ **v2 执行顺序（2026-10-20 改版，别按老顺序走）**：阶段 1 之后**不是**阶段 2，而是
> **【主线 A】U1–U8 体验升级 → 阶段 10（K1–K8 并发）→ 阶段 11（Gate K3/R）→ 【阶段 12】视觉换皮 → 【阶段 13】全量回归**。
> 换皮（原阶段 2–8）已整体后移，只在 U 线与 K 线全部过 Gate 之后做，且可整段跳过。

---

## 阶段 0：基线冻结与执行准备（1.5 小时 · 6 个任务）

> **本阶段不改任何业务代码。** 产出全部落在 `case_sim-/docs/ui-baseline/`，回滚 = 删目录。

### 0.1 目标与范围

**目标（三条，缺一不可）**

1. 用可复现的命令证明"改之前是好的"：65 个前端用例全过、`tsc -b` 0 错误、build 成功。
2. 找出所有"改文案就会变红"的断言，形成**冻结表**——后续阶段只能动样式，不能动这些字符串。
3. 固化学生端现状快照（关键 CSS 行、className 清单、375px 截图），供阶段 9 做像素级回归对比。

**范围内**

- 只读执行：`npm test` / `npx tsc -b` / `npm run build`
- 读文件：`StudentLayout.css`、`StudentPlayPage.tsx`、`tests/*.test.cjs`、`index.css`
- 写文件：**仅限** `docs/ui-baseline/` 下的 7 个产物

**范围外（做了就是越界）**

- 不改 `src/**` 任何文件
- 不装依赖、不改 `package.json` / `package-lock.json`
- 不改后端、不改契约
- 不修任何已知 bug（D-02 版本筛选器等），只记录

### 0.2 启动前提（环境清单）

| 项 | 要求 | 检查方式 | 不满足怎么办 |
|---|---|---|---|
| Node.js | ≥ 20.19（本项目实测 24.20 / 22.22） | `node -v` | 装 Node 24 LTS |
| npm | 随 Node 安装 | `npm -v` | 同上 |
| 前端依赖 | `frontend/node_modules` 存在且非空 | `dir node_modules` | `npm install`（**别用 `npm ci`**，safe-delete 会拦截） |
| 项目根 | `C:\Users\huang2006\Desktop\Work\upload2\case_sim-` | `cd /d "..."` | — |
| 后端服务 | 阶段 0 **不需要**；阶段 2 起建议启动 | `curl --noproxy * http://127.0.0.1:8110/api/health` | 双击 `启动项目.bat` |
| git | 本仓库**没有** `.git`，`git diff` 不可用 | `git status` 报 not a repository | 用 mtime + SHA256 审计代替 |
| 基线数字 | 前端 65/65、tsc 0 错、dist ≈2.0MB、index ≈665KB | 见 T0.2 / T0.3 | 数字对不上先查环境，别继续 |

> 端口提示：前端 dev 默认 5174，被占用时 vite 会自动 +1，以终端实际输出为准。

### 0.3 任务拆解（严格按 T0.1 → T0.6 顺序）

#### T0.1 环境自检（3 分钟）

**执行（cmd，逐条粘贴）**

```bat
node -v
npm -v
cd /d "C:\Users\huang2006\Desktop\Work\upload2\case_sim-\frontend"
dir node_modules
```

**产出物**：终端输出，贴进 `BASELINE.md` 的"环境"小节。

**验收标准**

- `node -v` 主版本 ≥ 20
- `dir node_modules` 能列出 `antd`、`react` 等子目录

**失败处理**：`node_modules` 缺失 → `npm install`（1–3 分钟），不要 `npm ci`。

---

#### T0.2 测试基线（5 分钟）

**执行**

```bat
cd /d "C:\Users\huang2006\Desktop\Work\upload2\case_sim-"
mkdir docs\ui-baseline 2>nul
cd frontend
npm test 1>"..\docs\ui-baseline\baseline-tests.txt" 2>&1
findstr /C:"# pass" /C:"# fail" "..\docs\ui-baseline\baseline-tests.txt"
```

**产出物**：`docs/ui-baseline/baseline-tests.txt`（完整输出，含 65 个用例名）

**验收标准**

- 文件里出现 `# pass 65` 与 `# fail 0`
- 能数出 65 条 `ok N - 用例名`

**失败处理**

- 不是 65 → **立刻停下**，这不是本次改造引起的。先 `npm install` 重跑；仍失败就把前 30 行贴出来，不要继续做后续任务。

---

#### T0.3 类型与构建基线（5 分钟）

**执行**

```bat
cd /d "C:\Users\huang2006\Desktop\Work\upload2\case_sim-\frontend"
npx tsc -b 1>"..\docs\ui-baseline\baseline-tsc.txt" 2>&1
npm run build 1>"..\docs\ui-baseline\baseline-build.txt" 2>&1
```

**产出物**：`baseline-tsc.txt`、`baseline-build.txt`

**验收标准**

- `baseline-tsc.txt` 为空（0 错误）
- `baseline-build.txt` 含 `✓ built in`，且 `dist/assets/index-*.js` 约 663–666 kB

**失败处理**：tsc 有错 → 记下行号与错误信息，**不要修**，写进 `BASELINE.md` 的"已知既有问题"。

---

#### T0.4 文案断言盘点（20 分钟 · 交 AI）

**目的**：找出所有会被"改文案"打红的测试，形成冻结表。

**执行**：使用 **0.6 的提示词·任务 C**。

**产出物**：`docs/ui-baseline/text-assertions.md`

**格式要求（逐条，不许汇总）**

| 测试文件 | 行号 | 被断言的原文 | 归属组件 | 风险 |
|---|---|---|---|---|
| tests/student-play.test.cjs | xx | `净利润 -12.35 万元` | MetricsBar | 改 label 即红 |

**验收标准**

- 至少 5 条，且覆盖 `student-play.test.cjs` / `merged-calibration.test.cjs` / `progressive-display.test.cjs` 三个文件
- 每条都有"文件 + 行号 + 原文"，原文必须原样，不许改写

**失败处理**：少于 5 条 → 扫描规则太窄，让 AI 改成按 `assert.match` / `assert.strictEqual` / `.includes(` / `textContent` 四种模式全量扫。

---

#### T0.5 样式与结构快照（20 分钟 · 交 AI）

**执行**：使用 **0.6 的提示词·任务 D**。

**产出物**：`docs/ui-baseline/style-inventory.md` + `baseline-375.png`

**内容要求**

1. `StudentLayout.css` 六段关键规则的完整原文，带起止行号：
   `body.student-body` / `.student-metrics` / `.student-metrics .metric-card` / `.strategy-option-card` / `.decision-submit` / `@media (prefers-reduced-motion: reduce)`
2. 学生端全部 className 去重清单（`src/pages/student/**` + `src/layouts/**`）
3. `src/index.css` 中已有的 `:root` 变量清单（供阶段 1 避免重复定义）
4. 375px 宽度下学生推演页整页截图

**验收标准**

- 六段 CSS 原文齐全，行号可回查
- className 清单 ≥ 15 个
- 截图能看清"改造前"的三个特征：**背景纯白、卡片 8px 直角、策略卡灰色边框**

**失败处理**：截图拿不到（后端未启动）→ 允许只截页面壳，但必须在报告里注明"未加载真实数据"。

---

#### T0.6 汇总与冻结声明（10 分钟）

**执行**：使用 **0.6 的提示词·任务 E**。

**产出物**：`docs/ui-baseline/BASELINE.md`

**必须含 5 个小节**

1. **环境**：node/npm 版本、`node_modules` 状态
2. **基线数字**：65/0、tsc 0、dist 体积、index chunk
3. **冻结表**：从 T0.4 摘出的"不可改文案"清单，编号 `F1`–`Fn`
4. **已知既有问题**：如有 tsc 错误或 flaky 用例，写在这里并声明"非本次改造引入"
5. **快照哈希**：对 `src/` 按相对路径排序拼接后算 SHA256，供阶段 9 对比

**验收标准（DoD）——六条全绿才算阶段 0 完成**

- [ ] `baseline-tests.txt` 含 `# pass 65` 且 `# fail 0`
- [ ] `baseline-tsc.txt` 为空
- [ ] `baseline-build.txt` 含 `✓ built in`
- [ ] `text-assertions.md` ≥ 5 条，含文件 + 行号 + 原文
- [ ] `style-inventory.md` 含六段 CSS + className 清单 + 375px 截图
- [ ] `BASELINE.md` 含 5 个小节与冻结表 `F1`–`Fn`

### 0.4 产出物总览

```
case_sim-/docs/ui-baseline/
├── BASELINE.md            # 汇总 + 冻结表 + 已知问题 + 快照哈希
├── baseline-tests.txt     # npm test 完整输出
├── baseline-tsc.txt       # tsc 输出（应为空）
├── baseline-build.txt     # build 输出
├── text-assertions.md     # 文案断言冻结表
├── style-inventory.md     # CSS 原文 + className 清单
└── baseline-375.png       # 改造前 375px 截图
```

### 0.5 回滚方式

阶段 0 不碰 `src/`，**回滚 = 删除 `docs/ui-baseline/` 整个目录**，无副作用。

### 0.6 阶段 0 的一次性 AI 提示词（整段复制）

```text
你是 case_sim 前端改造的基线盘点 Agent。本次只读：禁止修改 src/、禁止装依赖、禁止改 package.json。

项目根：C:\Users\huang2006\Desktop\Work\upload2\case_sim-\
前端目录：C:\Users\huang2006\Desktop\Work\upload2\case_sim-\frontend
产出目录：C:\Users\huang2006\Desktop\Work\upload2\case_sim-\docs\ui-baseline\（不存在就创建）

按 A→E 顺序执行，每步完成立即回报，不要合并成一次。

任务 A｜测试基线
1. 在 frontend 运行 npm test，把完整输出写入 docs/ui-baseline/baseline-tests.txt。
2. 统计 pass/fail 数量，并列出全部用例名（形如 "ok 1 - xxx"）。
3. 若 pass 不等于 65 或 fail 不为 0，立即停止后续任务并报告。

任务 B｜类型与构建基线
4. npx tsc -b，输出写入 baseline-tsc.txt，记录错误数。
5. npm run build，输出写入 baseline-build.txt，记录 dist 总体积与 index chunk 大小。

任务 C｜文案断言盘点（最重要）
6. 扫描 frontend/tests/*.test.cjs，找出所有断言了具体中文文案或 DOM 文本的地方。
   匹配模式至少覆盖：assert.match / assert.strictEqual / .includes( / textContent
7. 逐条输出表格：测试文件 | 行号 | 被断言的原文（原样，不要改写） | 对应组件 | 风险说明
8. 写入 docs/ui-baseline/text-assertions.md，末尾附"冻结清单"，编号 F1、F2…

任务 D｜样式与结构快照
9. 读取 src/layouts/StudentLayout.css，原样摘录以下规则的完整原文并标注起止行号：
   body.student-body、.student-metrics、.student-metrics .metric-card、
   .strategy-option-card、.decision-submit、@media (prefers-reduced-motion: reduce)
10. 列出 src/pages/student/** 与 src/layouts/** 中出现的全部 className（去重、排序）。
11. 读取 src/index.css，列出已有的 :root CSS 变量（供阶段 1 避免重复定义）。
12. 浏览器 375px 宽度打开学生推演页截图，保存为 docs/ui-baseline/baseline-375.png。
    若后端未启动，截页面壳也可接受，但必须在报告注明"未加载真实数据"。
13. 以上写入 docs/ui-baseline/style-inventory.md。

任务 E｜汇总
14. 生成 docs/ui-baseline/BASELINE.md，必须含 5 小节：环境 / 基线数字 / 冻结表 / 已知既有问题 / 快照哈希
15. 快照哈希：对 src/ 目录按相对路径排序后拼接内容算 SHA256，写入报告，供阶段 9 对比。

【禁止】
- 修改 src/ 下任何文件
- 安装或升级依赖
- 修复发现的任何 tsc 错误或测试失败（只记录，不修）
- 使用路径别名

【交付】
一份回报，包含：
- 七个产出物是否全部生成（路径 + 大小）
- 基线六项勾选状态（pass/fail、tsc 错误数、build 结果、断言条数、className 数、截图是否存在）
- 冻结表 F1–Fn 全文
- 任何一项不达标时，明确写出卡在哪一步、缺什么
```

---

## 阶段 1：设计令牌层（1 小时）

### 目标
把所有颜色、圆角、阴影收敛到 CSS 变量，后续阶段只引用变量，不写死色值。

### 【复制给 AI 的提示词】

```text
你是 case_sim 设计令牌 Agent。只改样式变量，不改任何组件结构与文案。

【必读约束】
- 路径别名禁止使用，全部相对导入。
- 不许改 pages/teacher/**。
- 已有变量 --color-primary-teacher / --color-primary-student 必须保留原值。

【任务】
1. 打开 frontend/src/index.css，在 :root 中追加以下变量（保留已有变量，不覆盖）：
   --student-bg: #FFF8E7;
   --student-surface: #FFFFFF;
   --student-radius-card: 16px;
   --student-radius-control: 10px;
   --student-shadow-card: 0 4px 12px rgba(31, 41, 55, 0.08);
   --student-shadow-card-hover: 0 8px 20px rgba(31, 41, 55, 0.12);
   --student-text: #1f2937;
   --student-text-muted: #4b5563;
   --option-a-border: #3b82f6;
   --option-a-bg: #eff6ff;
   --option-b-border: #8b5cf6;
   --option-b-bg: #f5f3ff;
   --option-c-border: #06b6d4;
   --option-c-bg: #ecfeff;

2. 在同一文件中追加一个媒体查询兜底（必须放在文件末尾）：
   @media (prefers-reduced-motion: reduce) {
     .student-page *, .student-page *::before, .student-page *::after {
       transition-duration: .01ms !important;
       animation-duration: .01ms !important;
     }
   }

3. 不要在任何组件里引用这些变量——本阶段只定义，不消费。

【禁止】
- 修改 .tsx / .ts 文件
- 删除或重命名已有变量
- 写内联 style

【验收】
- npx tsc -b 通过（虽然没改 ts，但要确认没误伤）
- npm test 65/65 通过
- 用 grep 确认 14 个新变量都已定义且各出现 1 次

交付：改动文件 + 行号 + grep 结果。
```

### 【用户操作】
1. 发提示词，等完成。
2. 打开 `frontend/src/index.css` 肉眼确认变量都在 `:root` 里。

### 【验收标准】
- `index.css` 新增 14 个变量 + 1 个媒体查询块。
- `npm test` 仍 65/65。
- 全仓 `grep -c "var(--student-bg)"` 为 0（本阶段不消费，正常）。

### 【失败处理】
若变量名冲突（已有同名），停下问用户，不要自行改名。

---

## 【新增】并发扩容总纲（v2 · 单进程 · 150 人在线 / AI 100 并发）

> 本节是**新增内容**，不替换上面任何一个字。**v2（2026-10-20 22:10）：D4 否决多 worker、D5 定为 AI 并发 100，主执行线改为"U1–U8 体验 → K1–K8 单进程并发"**；原阶段 2–8 的换皮任务已标 ⏸ 暂停（其【并发增量 Cx】块保留作历史参考，其中 C6/C7 已吸收进 K6/K3）。附录 D/E 是配套命令与映射表。
>
> **范围边界（避免误读）**：本文标题的"限定版"原本指视觉范围只做 P0+P1（不做 3D 翻牌、勋章体系、桌面隐喻复盘页）。**v2 起，视觉换皮整体降级为参考，主执行线换成 8 项决策体验升级（U1–U8）+ 单进程并发改造（K1–K8）**——不新增任何外依赖、不改接口契约，工程目标是 **150 人稳态在线 + AI 100 并发**（200 人只做极限观察）。

### N.0 v2 变更（2026-10-20 22:10 · 决策已落定）

| 项 | 结论 | 对清单的影响 |
|---|---|---|
| **D4** | **维持 `--workers 1`，不放开多 worker** | 原 C14（状态外移 + 多 worker）**作废**；`TRY_STORE`、`_running` 保持进程内存不动；不再新增租约/回收逻辑；代价是**没有横向扩展、没有 HA**，进程挂 = 全站挂 |
| **D5** | **AI 复盘并发上限 4 → 100** | 原 C15（并发 8–12 + 独立 worker 进程）改为**单进程内 100 并发 + 429 自适应**（K5）；不新增第二个进程 |
| **主线** | 视觉"换皮"降级为参考，主执行线改为 **U1–U8 体验升级 → K1–K8 单进程高并发** | 原阶段 2–8 全部标注【暂停执行】，详见 U/K |

> 一句话：**不加机器、不加进程，靠"把同步 DB 挪出事件循环 + 把轮询砍掉 + 把 AI 并发打到 100 并把限流做成自适应"来撑住 150 人**。这是单进程路线的天花板，必须接受它没有 HA。

### N.1 目标口径（单进程路线的诚实版本）

| 维度 | 现状（1 教师 + 10 学生） | v2 目标 | 判定方式 |
|---|---|---|---|
| 并发在线 | 11 | **150 人稳定在线**（200 作极限观察，允许 p95 劣化，不作放行条件） | 压测开 150/200 两个档，各跑 10 分钟 |
| 稳态请求 | < 5 QPS | **25 QPS**（含降频后的轮询） | 压测报告 |
| 峰值请求 | < 10 QPS | **60 QPS**（上课铃 + 教师刷新撞车） | 30 秒脉冲压测 |
| 写请求 | ~0.3 txn/s | **5–8 QPS**（150 人每 20–40 秒提交一次） | 写混合场景 |
| 非 AI 接口时延 | 未测 | **p95 ≤ 1s、p99 ≤ 2.5s、错误率 < 0.5%** | 压测报告（单进程，比多 worker 方案放宽） |
| AI 复盘吞吐 | 并发 4，10 人约 2 分钟 | **200 份 ≤ 15 分钟**，且 429 率 < 5% | 队列完成时间 + 429 计数 |
| 可用性 | 进程挂 = 全站挂 | **不要求零中断**；systemd 自动拉起后 ≤ 2 分钟恢复，在跑任务不重不丢 | Gate R 故障注入 |

### N.2 v2 的硬前提（放弃多 worker 后必须认的三件事）

1. **单进程 = 单核上限**。2C4G 上 API 进程只能用到一个核，`GIL` + 线程池就是天花板；**150 人是这条路的合理上限，200 人是极限**。再多就要回到 D4（多 worker）或 D6（换库）。
2. **没有 HA**。进程被 OOM 或 kill 就是全站 502，只能靠 systemd `Restart=always` 兜。所以 K7 的指标与告警不是"锦上添花"，是单进程路线的必需品。
3. **真正的三个瓶颈依次是**：① 同步 DB 跑在事件循环上（K1）；② 轮询扇出（K3）；③ 单事件循环被 100 个 AI 任务的同步 DB 写堵住（K4/K5）。**数据库存储本身不是瓶颈**（5–8 write/s vs SQLite ~90 txn/s）。

### N.3 项总表（U 体验 8 项 + K 并发 8 项，含作用范围）

**U 线：用户可感知的体验（替代原"换皮"）**

| 编号 | 项 | 作用范围 | 优先级 | 依赖 |
|---|---|---|---|---|
| **U1** | 即时结算单（提交后立刻弹，讲清"为什么"） | `StudentPlayPage.tsx`、新增 `components/SettlementCard.tsx`、新增 `domain/decisionNarrative.ts` | ★★★★★ | 无 |
| **U2** | 吸顶财务栏（滚动时 3 个核心数字常驻） | `StudentPlayPage.tsx`（MetricsBar 上方）、`StudentLayout.css` | ★★★★★ | 无 |
| **U3** | 选项影响预览（hover/长按显示预估区间） | 新增 `GET /play/{token}/preview`（新接口）、`StudentPlayPage.tsx`、新增 `components/OptionPreview.tsx` | ★★★★☆ | 需 U6 的 `risk_level` 同源规则 |
| **U4** | 对比基准线（高于/接近/低于平均） | 新增 `GET /play/{token}/benchmark`（聚合，1 条 SQL）、`MetricsBar` 内联标记 | ★★★★☆ | 无班级数据时回退"参考路径" |
| **U5** | 历史趋势迷你图（三轮折线） | 新增 `components/MiniTrend.tsx`（纯 SVG） | ★★★☆☆ | 只读 `turns[].after_metrics` |
| **U6** | 风险提示（高风险选项二次确认） | `OptionBrief` 新增可选 `risk_level`、`StudentPlayPage.tsx` 确认框 | ★★★☆☆ | 后端只加可选字段 |
| **U7** | 经营日志（每轮一条模板小故事） | 新增 `components/JournalPanel.tsx`、`domain/journal.ts` | ★★☆☆☆ | 纯前端模板 |
| **U8** | 里程碑庆祝（每轮完成给反馈） | `StudentPlayPage.tsx`、新增 `components/MilestoneToast.tsx` | ★☆☆☆☆ | 纯前端 |

**K 线：单进程高并发（替代原 C10–C17 的多 worker 部分）**

| 编号 | 项 | 作用范围 | 为什么单进程也必须要 |
|---|---|---|---|
| **K1** | `async def` 路由改 `def` + 线程池/连接池对齐 | `routers/student.py:263/274/284/306/503/549/622`、`teacher.py:279`；`db.py` 池参数；anyio 线程池 60 | 同步 DB 在事件循环上 → 一次慢查询冻全进程。改完才是"真并发"，WAL 也才真正生效 |
| **K2** | 补索引 | `models.py`（`Turn.session_id`、`AiTaskStep.task_id`、`AiTask.status`）+ `migrations.py` | 150 人 × 3 轮后按 `session_id` 查子表全表扫；`Review` 已有唯一约束覆盖，别重复建 |
| **K3** | 轮询降频 + 列表 ETag/304 | 教师列表 5s→10s、任务 1–2s→2–3s、学生案例 10s 保持；后端列表加 ETag | 稳态 QPS 的 90% 来自轮询；砍掉一半等于凭空多出半台机器 |
| **K4** | 事务瘦身 + AI 任务 DB 写移出事件循环 | `task_runner.py`（`_step`/`_run_task` 的 DB 段用 `asyncio.to_thread` 包）、`artifacts.py` 落盘出事务 | **100 个 AI 任务同时写库会把事件循环堵死**，即使 API 已经在线程池里 |
| **K5** | AI 并发 4 → 100（自适应 + 预算 + 公平） | `task_runner.py:37-38`（`AI_CONCURRENCY` 读环境变量，默认 100）、新增 `ai/limiter.py` | D5 的直接落实：200 份 4 并发要 33 分钟，100 并发理论 80 秒；没有 429 自适应就会被打回 429 全失败 |
| **K6** | SSE 连接治理 | `routers/student.py:441`（`chat`）、`StudentTutorSidebar.tsx` | 一条答疑流独占一个池连接 20–120 秒；单进程池 10+10，20 条并发答疑就吃干连接池 |
| **K7** | 指标与告警 | `observability.py`、新增 `GET /api/metrics` | 单进程没有 HA，唯一的兜底是"提前看见" |
| **K8** | 单进程容量验收 + 迁移门 | `scripts/loadtest/`、`docs/ui-baseline/concurrency-baseline.md` | 没有独立的一关，前面七项都是自述 |

### N.4 容量门禁（单进程版，四道门 + 一道故障门）

| 门 | 何时验 | 通过标准 | 不通过怎么办 |
|---|---|---|---|
| **Gate U** | U1–U8 全部完成后 | 65/65 全绿、tsc 0、build 成功；一次推演请求数不高于改造前；375px 无横向溢出 | 多半是新组件把既有断言挤掉了，回看"U 阶段共用红线" |
| **Gate K1** | K1–K4 完成后（仍单进程） | 100 并发、20 QPS 稳态、p95 ≤ 600ms、错误 < 0.5%；`/api/health` 探针 p95 ≤ 20ms | 探针慢 = 事件循环还被堵着，K1 没改干净；再看池超时与 `database is locked` |
| **Gate K2** | K5 完成后 | 200 份复盘 ≤ 15 分钟；429 率 < 5%；案例生成不被学生复盘饿死（教师任务 p95 等待 ≤ 5 分钟） | 429 高 → 自适应降速阈值太激进；饿死 → 公平名额没做 |
| **Gate K3** | K6–K7 完成后 | 150 并发 30 分钟长稳：p95 ≤ 1s、p99 ≤ 2.5s、错误 < 0.5%、池超时 0、locked 0 | 先看 `/api/metrics` 定位是池、锁还是循环阻塞，再决定是否要回到 D4 |
| **Gate R** | K8 内（故障注入） | `kill -9` API 进程：systemd 2 分钟内拉起，`queued/running` 任务不重不丢，学生刷新后继续（允许一次 502） | 单进程无 HA，**只验证"能自愈"，不要求"零中断"**；恢复不了说明启动恢复逻辑有 bug |

> **口径说明**：Gate 与后文所有 DoD 一律按 **前端 65 个用例、后端 189 个用例** 判定。三条并发契约用例不得删除或弱化：`tests/transport-error.test.cjs`（3 项）、`tests/student-play.test.cjs` 的 `duplicate submission shows the real reason and offers the records entry` 与 `other start failures keep the backend message and show no records entry`、`backend/tests/test_concurrency.py`（5 项）。

### N.5 新增铁律（只加不改，与"全局铁律"并列生效）

9. **并发项不得改接口字段与状态码**：`submission_exists`（409）等既有语义原样保留；新增能力只能用新字段或新接口。
10. **压测只用隔离库**：`DATABASE_URL=sqlite:///./backend/data/loadtest.db`，跑完删库；**禁止拿 `backend/data/app.db` 压测**。
11. **压测禁止用 `sleep` 伪造并发**：必须是真实并发客户端，报告里附客户端数量与发压速率。
12. **单进程不可破**：任何改动不得引入第二个 API worker，也不得把 `--workers 1` 改大；AI 并发只允许通过 K5 的限流器调（含 429 自适应），**禁止直接把信号量写成 100 却不做降速**。

### N.6 决策落定（v2）

| 编号 | 决策 | 结论 | 遗留风险 |
|---|---|---|---|
| **D4** | 是否放弃 `--workers 1` | **否决，保持单进程** | 无 HA、无横向扩展；150 人是上限，200 人是极限；进程挂即全站不可用（靠 systemd 拉起） |
| **D5** | AI 复盘并发 | **4 → 100** | 供应商 429／配额；必须配自适应限速 + 每日 token 预算 + 教师任务保底名额，否则会"全班一起失败" |
| **D6** | 何时迁 Postgres | **先不迁**，只在 K8 的触发条件命中时迁 | 触发条件：写 QPS > 20 持续 10 分钟，或 `database is locked` 每小时 > 10 次，或需要多实例 |

---

## 【主线 A】学生端体验升级 U1–U8（先做；原"换皮"已移到阶段 12）

> **为什么替换**：原阶段 2–8 做的是"换色、圆角、阴影、emoji 图标"，改完学生仍然不知道"为什么涨、为什么跌、下一个该看什么"。U1–U8 直接改**决策理解与决策质量**，其中 U1/U2 是纯前端、零后端改动，性价比最高。
>
> **原阶段 2–8（换皮）已整体后移到文末【阶段 12】，排在 U 线与 K 线全部过 Gate 之后执行**；正文一字未改，编号保留原样便于对照。

### U 阶段共用红线（每个 U 任务开工前必读，违反即返工）

1. **不许给 `className="strategy-option"` 的 Button 追加任何 class**：`tests/student-play.test.cjs` 用 `b.className === 'strategy-option'` 严格相等定位策略按钮，追加一个 class 就会让 6 个用例全红。风险徽标、预览框必须做成**兄弟节点**或按钮内部新 `span`。
2. **不许新增 `type="success"` / `type="warning"` 的 `Alert`**：既有用例用 `page.all('Alert').find(...)` 取**第一个**匹配项。新提示一律用 `Modal`、自定义 `div`（`role="alert"`）或 `message`。
3. **不许删除/改写 `MetricsBar` 里的文本节点**：`净利润 -12.35 万元`、单位"万元"都是冻结断言。新增信息只能**追加节点**，不能替换原文。
4. **三个按钮的文案与存在性不变**：`开始推演`、`确认提交本回合`、`继续下一回合`。
5. **新增接口一律"可选增强"**：请求失败时静默降级为现状，不得阻塞选择与提交（U3/U4 尤其）。
6. **禁止新增轮询**：U3 只在 hover/长按时请求一次并按 `(node_id, option_key)` 缓存；U4 每轮最多 1 次。
7. **共用验收口径**：每个 U 任务结束都要 `npm test` **65/65**、`npx tsc -b` **0 错误**；改动若碰到文案，只许改断言期望值，禁止删用例。

---

### U1 即时结算单（P0-1 · ★★★★★ · 4 小时）

**现在**：提交后页面回到推演页，只有一行"营收 78 万 → 86.5 万"，学生不知道"为什么涨、涨得合不合理、下一轮看什么"。

**改成**：提交成功后弹出结算卡片（Modal），三块内容——① 你的决策（策略名）② 数字变化（营收 / 毛利率，带百分比）③ **为什么**（规则模板生成的一句因果）④ **下一轮关注**（一句提示）。点"继续"关闭，关闭后页面上原有的"本轮结果"Alert 保留不动（它是页面内的记录，也承载既有断言）。

**为什么有用**：学生从"盲选"变成"理解因果"，下一轮决策才有依据。这是 8 项里对学习效果影响最大的一项。

**改法与边界**

1. 新增 `frontend/src/domain/decisionNarrative.ts`（纯函数、可单测、零依赖）：
   `narrative(before: Metrics, after: Metrics, chosenLabel: string): { deltaText: string; why: string; nextFocus: string }`
   规则（按营收/毛利率四个方向分支，外加现金流为负的特判）：
   - 营收↑ 毛利率↓ → "降价或让利换来了更多客户，但单笔利润被压薄了"
   - 营收↑ 毛利率↑ → "量价齐升：既拿到了更多客户，也没有牺牲利润空间"
   - 营收↓ 毛利率↑ → "主动收缩了低毛利业务，短期营收下降但结构更健康"
   - 营收↓ 毛利率↓ → "份额与利润同时承压，这一轮要警惕现金流"
   - 现金流为负（`cash_flow_amount < 0`）→ nextFocus 固定为"现金流能否撑住下一轮扩张"
2. 新增 `frontend/src/pages/student/components/SettlementCard.tsx`：用 antd `Modal`（`open` / `onCancel` / `footer` 单按钮"继续"），**不要用 Alert**。
3. `StudentPlayPage.tsx`：在 `submit()` 成功后 `setSettlement(...)`，Modal 打开；Modal 关闭时不清空 `showResult`（原有"本轮结果"Alert 继续显示）。
4. **不要**做"3 秒自动关闭"作为默认：会给慢阅读的学生造成信息丢失；如需自动关闭，6 秒且可点任意处取消（测试不依赖自动关闭）。

**验收**

- [ ] 提交后 1 秒内出现结算卡，含"本轮结算 · 第 N 轮"、策略名、营收与毛利率的"旧值 → 新值（+x%）"、一句"为什么"、一句"下一轮关注"
- [ ] 点"继续"关闭后，页面仍能看到原来的"本轮结果"Alert 与"继续下一回合"按钮
- [ ] `npm test` 65/65；`tsc -b` 0 错误
- [ ] 手工造 4 种数据（营收↑毛利率↓、↑↑、↓↑、↓↓），"为什么"文案分别命中对应分支

**失败处理**：若 65/65 变红且报 `Alert`/`strategy-option` 相关，几乎一定是把结算卡写成了 Alert 或给按钮追加了 class——按红线 1/2 改回 Modal。

---

### U2 吸顶财务栏（P0-2 · ★★★★★ · 2 小时 · 纯前端）

**现在**：财务卡在页面顶部，往下滑看策略选项时数字就没了，学生要反复上下滑。

**改成**：页面顶部固定一条紧凑财务栏（`position: sticky`），常驻 **营收 / 毛利率 / 市场份额** 三个数字；现金流与净利润留在原卡片里（原卡片**不删不改**）。

**为什么有用**：选策略时眼睛不用离开选项，决策更连贯；这是纯 CSS 收益最高的一项。

**改法与边界**

1. 新增 `components/StickyMetrics.tsx`，在 `StudentPlayPage` 返回的 `Space` 第一项（`error` Alert 之后）渲染；只在 `state` 存在时显示（没开始推演就没有数字）。
2. 样式（追加到 `StudentLayout.css` 末尾，不新开文件）：
   ```css
   .student-sticky-metrics { position: sticky; top: 0; z-index: 20; display: flex; gap: 8px;
     padding: 8px 12px; background: var(--student-surface); border-bottom: 1px solid #f1e7cf;
     box-shadow: 0 2px 8px rgba(31,41,55,.06); }
   .student-sticky-metrics .item { flex: 1; text-align: center; font-size: 12px; color: var(--student-text-muted); }
   .student-sticky-metrics .value { display: block; font-size: 16px; font-weight: 700; color: var(--student-text); font-variant-numeric: tabular-nums; }
   @media (max-width: 480px) { .student-sticky-metrics .value { font-size: 14px; } }
   ```
3. **sticky 失效排查**：父级若存在 `overflow: hidden`（`.student-main` / `.student-shell`）会让 sticky 变成普通定位，必须先在 DevTools 里确认，必要时只对 `.student-page` 内层容器放开 `overflow: visible`；**不许**改成 `position: fixed`（会遮挡内容、也要手动补偿高度）。
4. 数字来源与 `MetricsBar` 同一个对象（`state.current_metrics || data.base_metrics`），带 `React.memo`，只在引用变化时重渲染。

**验收**

- [ ] 375px 与 1280px 下滚动到策略选项区，财务栏仍在视口顶部且不遮住标题
- [ ] 只显示 3 个数字；原 `MetricsBar` 的四/五张卡（含净利润）**一字未改**
- [ ] `npm test` 65/65；`tsc -b` 0 错误
- [ ] 开启 `prefers-reduced-motion: reduce` 后无异常（本项无动画，仅确认不引入）

---

### U3 选项影响预览（P0-3 · ★★★★☆ · 6 小时 · 需新接口）

**现在**：选项只有 key + label，学生不知道后果，选了才知道——这不是决策，是抽奖。

**改成**：hover 400ms（移动端长按）在策略卡上时，卡片旁弹出小预览："预计营收 +5%~+12%、预计毛利率 -5%~-2%、风险 中"，并明确标注**"基于规则的粗略估算，非精确预测"**。

**为什么有用**：从"盲选"变成"权衡"，学生开始比较代价与收益。

**改法与边界（重点：防剧透）**

1. 后端新增 `GET /api/play/{token}/preview?node_id=..&option_key=..`（**新接口**，不改既有接口字段）：
   返回 `{ "basis": "heuristic", "revenue": [5, 12], "gross_margin": [-5, -2], "cash_flow": "偏紧", "risk_level": "中" }`。
2. **严禁**读取教师端的 `simulation_results` 精确值下发——那等于泄题，学生只要 hover 就能把三张牌的答案都看完。只能按"选项 label 关键词 + 案例类型"的规则给区间。
3. 前端：`useRef` 防抖 400ms、`AbortController` 取消上一个请求、按 `${node_id}:${option_key}` 缓存（同一节点同一选项只请求一次）；移动端提供"长按 500ms"入口。
4. 失败静默：请求失败不弹错、不阻塞选择，直接不显示预览。
5. 这个接口是新增读接口，K1 时应为 `def`（走线程池），且后端加 5 分钟 LRU，避免 150 人同时 hover 打一波。

**验收**

- [ ] hover 400ms 内出现预览，移开即消失；同一选项第二次 hover **不发请求**（Network 只 1 条）
- [ ] 预览里必须出现"估算"字样；不得出现精确到小数的结果值
- [ ] 后端返回里不含 `simulation_results` 的任何原始字段（用 grep 断言）
- [ ] `npm test` 65/65（`student-play.test.cjs` 的 12 条全绿）

---

### U4 对比基准线（P1-1 · ★★★★☆ · 4 小时 · 需聚合接口）

**现在**：学生只有自己的数字，不知道 86.5 万是好还是差。

**改成**：每个指标后追加一个小标记："营收 86.5 万 🟢 高于平均 12%" / "🟡 接近平均" / "🔴 低于平均 8%"。

**为什么有用**：有参照系才有判断力，也能带来适度竞争感。

**改法与边界**

1. 后端新增 `GET /api/play/{token}/benchmark`，**一条聚合 SQL**（按 `case_id` 聚合各 session 最新 `current_metrics_json`），返回
   `{ "basis": "class"|"reference", "sample_size": 12, "revenue": 78.3, "gross_margin": 60.1, "market_share": 20.0 }`。
2. **样本 < 5 时回退"参考基准"**（用案例 `base_metrics`），`basis="reference"`，UI 标注"参考基准"而不是"班级平均"——**不许把参考值说成班级平均**。
3. 前端：标记是 `MetricsBar` 内的**追加节点**（`<span className="metric-baseline">`），不替换任何原有文本；颜色与既有 `TrendArrow` 保持同一语义（`#16a34a` 好 / `#ca8a04` 接近 / `#dc2626` 差）。
4. 每轮最多请求 1 次，进程内缓存 10 秒（150 人同时交卷时不至于打 150 次聚合）。

**验收**

- [ ] 班级样本 ≥ 5 时显示"班级平均"，样本不足时显示"参考基准"，两种文案不会混用
- [ ] 三个指标都带标记，且颜色阈值可复现（±10% 内=接近）
- [ ] 一次推演（3 轮）该接口被调用 ≤ 3 次
- [ ] `npm test` 65/65；净利润/营收文本节点未被替换

---

### U5 历史趋势迷你图（P1-2 · ★★★☆☆ · 3 小时 · 纯前端 SVG）

**现在**：只有当前轮数字，不知道是从 70 涨到 86 还是从 100 跌到 86。

**改成**：每个指标下加 3 点迷你折线（base → 第1轮 → 第2轮 …），升绿降红平稳灰。

**改法与边界**

1. 新增 `components/MiniTrend.tsx`：`viewBox="0 0 100 24"`，3–4 个点，`polyline` + 末点 `circle`，`strokeWidth 1.5`，**纯 SVG，不引 ECharts**。
2. 数据只来自 `state.turns[].after_metrics` 与 `data.base_metrics`（**零新请求**，红线 6）。
3. 可访问性：`aria-label="营收趋势：70 万 → 78 万 → 86.5 万，上升"`；不靠颜色单独传达信息。
4. reduced-motion 下不做描边动画（默认不做动画最省事）。

**验收**

- [ ] 三轮结束后能看到 3 段折线，方向与数字变化一致
- [ ] 不产生任何新请求（Network 面板验证）
- [ ] 375px 下不溢出，`scrollWidth === clientWidth`
- [ ] `npm test` 65/65

---

### U6 风险提示（P1-3 · ★★★☆☆ · 5 小时 · 需后端加可选字段）

**现在**：三个选项长得一样，选了激进的才知道后果，现金流断了直接失败。

**改成**：选中高风险选项时，提交按钮上方出现警示（自定义 `div role="alert"`），要求二次确认后才能提交。

**改法与边界**

1. 后端 `OptionBrief` **新增可选字段** `risk_level: Literal["低","中","高"] | None = None`（不改任何既有字段名/类型）。规则基于选项 label 关键词（如"大幅降价/激进扩张/高杠杆/一次性投入"→高），无法判定时返回 `None`，前端显示现有"风险待评估"。
2. 前端：**不能**用 `Alert type="warning"`（红线 2）；用自定义 div + `Popconfirm`/`Modal.confirm` 二次确认。
3. 风险徽标放在 `.strategy-option-card` 内、按钮**外面**（红线 1）。
4. 未选中的选项不弹提示；低风险不弹（避免狼来了）。

**验收**

- [ ] 选中高风险管理项 → 出现警示文案 + 二次确认；点"再想想"不提交
- [ ] 选中低风险项 → 无警示，一次点击即提交
- [ ] 后端对无规则可判的选项返回 `risk_level: null`，前端文案仍为"风险待评估"
- [ ] `npm test` 65/65（`page.all('Alert').find(a => a.type === 'warning')` 那条仍取到原错误提示）

---

### U7 经营日志（P2-1 · ★★☆☆☆ · 3 小时 · 纯前端模板）

**现在**：纯数字，像在做数学题，没有"在经营一家公司"的代入感。

**改成**：页面底部"经营日志"，每轮一条 2–3 行的小故事，模板拼接，**不调 LLM**。

**改法与边界**

1. 新增 `domain/journal.ts`：`entry(index, chosenLabel, why, resultSummary) => string`，3–5 个模板分支（降价抢客 / 提价保利润 / 保守维持 / 扩张 / 收缩）。
2. 新增 `components/JournalPanel.tsx`：用 `Timeline` 或 `Collapse` 展示，**追加在页面末尾**，不影响任何既有节点。
3. 文案不得包含任何被断言的原文片段（避免与冻结表冲突）；出现数字时与 `MetricsBar` 保持同一格式（万元）。

**验收**

- [ ] 每轮结束后日志多一条，文案与所选策略一致
- [ ] 全前端实现，Network 无新增请求
- [ ] `npm test` 65/65

---

### U8 里程碑庆祝（P2-2 · ★☆☆☆☆ · 1.5 小时 · 纯前端）

**现在**：三轮做完直接进复盘，没有任何成就感反馈。

**改成**：完成第 1/2/3 轮时给一条轻量提示（"🎉 不错！你完成了第一次经营决策"），3 秒自动消失。

**改法与边界**

1. 用 `message.success` 或自定义轻提示，**不要用 Alert**（红线 2）。
2. 只在"轮次 +1 且未完成"时触发一次，刷新页面不重复弹（`sessionStorage` 记 `celebrated:{token}:{n}`）。
3. 文案按轮次区分，第 3 轮改为"最后一轮完成，去看看你的复盘"。
4. reduced-motion 下不做缩放动画。

**验收**

- [ ] 完成第 1、2、3 轮各弹一次，刷新不重弹
- [ ] 不遮挡"确认提交本回合"/"继续下一回合"
- [ ] `npm test` 65/65

---

### U 线整体完成标准（= Gate U）

- [ ] 前端 65/65、`tsc -b` 0 错误、`npm run build` 成功
- [ ] 一次完整推演（3 轮）的请求总数**不高于**改造前基线（U3/U4 各 ≤ 3 次，U5/U7/U8 为 0 次）
- [ ] 375px 下无横向溢出（`scrollWidth === clientWidth`）
- [ ] 8 项功能逐条手工走查通过（用同一案例连续做 3 轮，边做边核对结算单/吸顶栏/预览/基准/趋势/风险/日志/庆祝）

---

## 阶段 10：单进程高并发改造（K1–K8 · 6–8 小时 · D4/D5 已定，不再讨论多 worker）

> **v2 变更（2026-10-20 22:10）**：D4 否决多 worker → 原 T10.6（状态外移 + `--workers 2`）**作废**，`TRY_STORE` 与 `_running` 保持进程内存不动；D5 定为 AI 并发 **100** → 原 T10.7 的"并发 10"升级为 K5 的"100 + 429 自适应"。编号统一为 K1–K8，与 N.3 总表一一对应。

### 目标

在 `--workers 1` + SQLite 的前提下，把"十几人"抬到 **150 人稳态 / AI 100 并发**。不加机器、不加进程、不换数据库、不改接口契约。**代价已经接受：没有 HA，进程挂 = 全站 502（靠 systemd 拉起）。**

### 前置事实（已核实，执行时不要重新调研）

| 事实 | 位置 | 对 150 人的含义 |
|---|---|---|
| 9 处写/读热点路由是 `async def` 但用同步 Session | `routers/student.py:263`（reset）、`:274`（remove）、`:284`（rollback）、`:306`（decide）、`:441`（chat）、`:503`（review）、`:549`（retry_review）、`:622`（try_case）；`routers/teacher.py:279`（create_case） | 同步 DB 调用跑在事件循环上，一次慢查询/等锁 → **整进程冻结** |
| 其余路由是 `def`，走 anyio 线程池（默认 40） | 绝大多数 teacher CRUD、accounts | 线程池 40 就是并发天花板，必须与连接池一起抬 |
| 连接池 10+10（每进程） | `db.py:32-36` | 线程池抬到 60 而池只有 20 → 请求排在 `pool_timeout=30s` |
| 试跑缓存是进程内 `OrderedDict`（上限 50） | `routers/student.py:571` / `:573` | **单进程下是安全的**，D4 已定，不要动它 |
| 在跑任务注册表是进程内 dict | `integrations/ai/task_runner.py:32` | 同上，单进程安全；但 100 并发后要防"同一 task 被 schedule 两次" |
| AI 并发上限 4 | `task_runner.py:37-38` | 200 份复盘并发 4 ≈ 33 分钟；D5 要求 100 → 理论 80 秒，实际受供应商限流 |
| `Turn.session_id`、`AiTaskStep.task_id`、`AiTask.status` 无索引 | `models.py:165`、`:279`、`AiTask` 表 | 150 人 × 3 轮后子表查询全表扫；worker 轮询 `status='queued'` 也是全表扫 |
| 每条 SSE 流占用一个池连接 20–120 秒 | `routers/student.py:441` 的 `Depends(get_db)` | 20 条并发答疑即可吃干池（10+10），150 人场景必须修 |

### 任务拆解（K1 → K8 严格顺序）

#### K1 `async def` 改 `def` + 线程池 / 连接池对齐（1.5 小时，收益最大）

1. 把上表 9 处里**除 `chat` 之外的 8 个**从 `async def` 改成 `def`：`decide` / `reset_session` / `remove_session` / `rollback_session` / `review` / `retry_review` / `try_case` / `create_case`。改完 FastAPI 自动丢进线程池，同步 DB 不再占事件循环。
2. `chat` 保持 `async def`（要返回 `StreamingResponse`），DB 操作按 K6 移到流外。
3. **抬线程池**：在 `main.py` 的 `lifespan` 启动段加
   `anyio.to_thread.current_default_thread_limiter().total_tokens = 60`
   （默认 40 顶不住 150 人突发；60 是 2C4G 的折中，别再往上加，会加重 SQLite 写锁争抢）。
4. **对齐连接池**：`db.py` 的 `POOL_SIZE` 10 → **20**、`MAX_OVERFLOW` 10 → **20**、`POOL_TIMEOUT` 30 不变。线程 60 与池 40 之间留 20 的余量，避免"线程有、连接没有"的排队。
5. 不要手写 `run_in_threadpool` 包装；不要在 `def` 里写 `await`。

**验收**：100 并发下 `GET /api/health` p95 ≤ 20ms（证明循环没被冻）；`mixed` 场景 p95 相比 K0 基线下降 ≥ 30%；日志里 `QueuePool limit` 为 0。

#### K2 补索引（30 分钟）

1. `models.py` 加：`Index("ix_turn_session_id", Turn.session_id)`、`Index("ix_ai_task_step_task_id", AiTaskStep.task_id)`、`Index("ix_ai_task_status", AiTask.status)`。
2. **`create_all` 不会给已存在的库补索引**，必须在 `backend/app/migrations.py` 的 `migrate()` 里补 `CREATE INDEX IF NOT EXISTS`（幂等）。
3. `Review` 已有 `uq_review_session_attempt` 覆盖 `(session_id, attempt_no)`，**不要重复建**。

**验收**：`EXPLAIN QUERY PLAN SELECT * FROM turn WHERE session_id=1` 输出 `SEARCH ... USING INDEX ix_turn_session_id`（改造前是 `SCAN turn`）。

#### K3 轮询降频 + 列表 ETag（1 小时）

1. 教师任务轮询：`useCalibrationState.ts:181` 的 1000ms → 2000ms；`:160` 的 2000ms → 3000ms；`:177` 的 5000ms 保留；失败指数退避到 15s（`TeacherWorkbenchPage.tsx:111` 已有模式，照抄）。
2. 教师案例列表：`TeacherWorkbenchPage.tsx:82` 的 5000ms → 10000ms。
3. 学生案例列表：`StudentSpacePages.tsx:31` 的 10000ms **保持不动**（已低频）。
4. 列表接口加 `ETag`（`max(updated_at)` + 行数 + 版本号哈希），命中返回 304 空体。
5. 若做教师端 KPI 聚合（原 C7），必须**一条 SQL** + 进程内 5–10 秒 TTL，禁止前端逐学生拉。

**验收**：稳态 QPS 相比 K1 再降 ≥ 40%；304 命中率 > 60%。

#### K4 事务瘦身 + AI 任务的 DB 写移出事件循环（1.5 小时 · 100 并发的关键）

1. **`task_runner` 的同步 DB 段包 `asyncio.to_thread`**：`_step()`、`_run_task` 里的 `commit`、`_run_student_review` 的读写，都改成 `await asyncio.to_thread(fn, ...)`。原因：K5 放开到 100 并发后，100 个任务各写 5–6 次，同步写会在事件循环上累计阻塞可达秒级，把 API 与 SSE 一起拖慢。
2. `artifact_store.save_json` 的**落盘放在事务外**：先写文件，再开/继续事务写索引行；落盘失败直接抛，不让事务悬着。
3. `_step()` 允许"阶段内合并、阶段边界提交"，但不得改变 `ai_task_step` 对外可见的阶段顺序。
4. 禁止把 `db.commit()` 放在跨 `await` 的位置（会持锁等模型）。

**验收**：写事务持锁 p95 < 5ms（`BEGIN`→`COMMIT` 打点）；`database is locked` 出现 0 次；100 并发时 `/api/health` p95 仍 ≤ 20ms。

#### K5 AI 并发 4 → 100（2 小时 · D5 的落实，必须带自适应）

1. `task_runner.py:37-38` 改为读环境变量：`AI_CONCURRENCY = int(os.getenv("AI_CONCURRENCY", "100"))`，信号量按它创建。
2. **新增 `backend/app/integrations/ai/limiter.py`**（自适应限流器，AIMD）：
   - 初始并发 = `min(100, AI_CONCURRENCY)`；
   - 收到 **429 / 503 / 超时**：并发 **减半**（下限 8），并记一次失败；
   - 连续 **20 次成功**：并发 **+1**（上限 100）；
   - 遵守 `Retry-After`；重试用指数退避 + 抖动（0.5s/1s/2s，最多 3 次）。
3. **公平名额**：`case_generation` / `case_nodes`（教师等待）保底 **2** 个并发名额，学生复盘不得占满——否则 200 份复盘会把教师的案例生成饿死。
4. **预算护栏**：`AI_DAILY_TOKEN_BUDGET`（默认按 500 万 token）用尽后，新复盘**降级为模板复盘**（不调模型）+ 告警，不允许无限烧。
5. **httpx 连接池**：`max_connections=150`、`max_keepalive_connections=50`（默认 100/20 会成为 100 并发的第二个瓶颈）。
6. 单进程内 100 个 `create_task` 仍受 `--workers 1` 约束，**不要**为此新增进程（N.5 铁律 12）。

**验收**：200 份复盘 ≤ 15 分钟；429 率 < 5%；教师案例生成 p95 等待 ≤ 5 分钟；`/api/metrics` 能看到 `ai_in_flight` 峰值接近 100。

**失败处理**：若 429 率 > 20%，说明起手并发太高 → 把初始并发降到 40 再 AIMD 上爬；若复盘反而更慢，检查是不是 `sqlite` 写锁在 `to_thread` 之外还有同步写（K4 没做干净）。

#### K6 SSE 连接治理（1 小时 · 单进程下更要命）

1. **释放连接**：`chat` 不要在流的整个生命周期里持有 `get_db` 的会话——先同步查完、`db.close()`，再返回 `StreamingResponse`；流内的 DB 访问用 `with SessionLocal() as agent_db:`（文件里已有此写法）。
2. **断连即取消**：把 `answer_question` 包成 `asyncio.create_task`，yield 之间用 `await request.is_disconnected()` 检查，断开就 `cancel()`——否则学生关页面后模型继续跑完，白烧配额（100 并发时这很致命）。
3. **心跳**：流开始先 `: keep-alive\n\n`，此后每 15 秒一次（`asyncio.wait_for` 超时就发心跳），防反代 60s 掐断。
4. 前端：保留现有 `AbortController`，并确认"收起面板"也会 abort（当前只在卸载与重新提问时 abort）。

**验收**：30 条并发答疑流下，其余接口 p95 不劣化到 > 1s，`QueuePool limit` 为 0；关页面后日志显示调用被取消。

#### K7 指标与告警（1 小时）

1. 新增 `GET /api/metrics`（JSON）：每路由 p50/p95/p99、RPS、5xx 数、`QueuePool` 超时数、`database is locked` 数、`ai_in_flight`、AI 队列深度、各 kind 平均耗时、LLM 失败率与 429 率。
2. 告警阈值（写进部署文档）：p95 > 1s 连续 5 分钟 / 队列深度 > 50 / 池超时 > 0 / locked > 0 / 429 率 > 10% / `ai_in_flight` 常驻 0 且队列 > 0（说明 worker 卡死）。
3. 单进程没有 HA，**这套指标就是唯一的兜底**，不许省略。

**验收**：压测时能从 `/api/metrics` 直接读出 p95、队列深度、429 率，不需要翻日志。

#### K8 单进程容量验收 + 迁移门（1.5 小时）

1. 用 U 线交付后的 `dist`（拆包后）打满 150 与 200 两档，跑 Gate K3 与 Gate R。
2. 迁移门（**默认不做**，命中才做）：写 QPS > 20 持续 10 分钟 / `database is locked` 每小时 > 10 次 / 需要多实例 → 才谈 Postgres。
3. 产出 `docs/ui-baseline/concurrency-baseline.md`：四档并发（10/50/150/200）+ 两次 AI 吞吐（50 份 / 200 份）+ 故障注入记录。

### 【复制给 AI 的提示词】（阶段 10 一次性）

```text
你是 case_sim 后端并发改造 Agent。目标：单进程（--workers 1）+ SQLite 撑住 150 人在线、AI 并发 100。

【已定决策，不要再讨论】
- D4：维持 --workers 1，不得改成 2 或更大；不得把 TRY_STORE / _running 迁出进程内存。
- D5：AI 复盘并发 4 → 100，必须带 429 自适应，不许"直接写死 100 不管失败"。
- 入口条件：Gate U 已过（前端 65/65、后端 189/189、U1–U8 交付、一次推演请求数不高于改造前）。

项目根：C:\Users\huang2006\Desktop\Work\upload2\case_sim-
启动：cd 项目根 && .venv\Scripts\python.exe -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8110 --workers 1
禁止在 backend/ 目录下跑（会 ModuleNotFoundError）。

【硬约束】
- 不改任何既有接口的字段名与状态码；新能力只能加可选字段或新接口。
- 不新增第三方依赖（httpx / SQLAlchemy / FastAPI / anyio 已在）。
- 压测一律用隔离库：DATABASE_URL=sqlite:///./backend/data/loadtest.db，端口 8112；禁止压 backend/data/app.db。
- 每完成一个 K 任务立即回报，贴命令与原始输出，不要合并。

按 K1→K8 顺序执行：
K1 8 个 async 路由改 def（student.py:263/274/284/306/503/549/622，teacher.py:279；chat 保持 async）；anyio 线程池 total_tokens=60；db.py 池改 20+20。
K2 给 Turn.session_id / AiTaskStep.task_id / AiTask.status 建索引，并在 migrations.py 补 CREATE INDEX IF NOT EXISTS。
K3 轮询降频（1000→2000、2000→3000、列表 5000→10000）+ 列表 ETag/304。
K4 task_runner 的同步 DB 段包 asyncio.to_thread；artifact 落盘移出事务；验证写事务持锁 p95 < 5ms。
  → 跑 Gate K1（100 并发、20 QPS、p95 ≤ 600ms、探针 ≤ 20ms、池超时 0），不过不许继续。
K5 AI_CONCURRENCY 读环境变量默认 100；新增 ai/limiter.py 做 AIMD（429 减半至 8、连续 20 成功 +1 至 100、遵守 Retry-After）；教师类保底 2 个名额；AI_DAILY_TOKEN_BUDGET 用尽降级模板复盘；httpx 连接池 150/50。
K6 chat 的 DB 会话移到流外；断连 cancel；15 秒心跳。
K7 /api/metrics 输出 p50/p95/p99、RPS、5xx、池超时、locked、ai_in_flight、队列深度、429 率。
K8 150 与 200 两档压测 + 故障注入（kill -9 后 systemd 2 分钟内拉起、任务不重不丢）；输出 concurrency-baseline.md；只判断 Postgres 触发条件是否命中，不执行迁移。

【禁止】
- 改 --workers；把状态迁出进程内存；新增第二进程
- 为了让压测好看而降低断言、关日志、跳过 Gate
- 用 sleep 伪造并发
- 直接放开 100 并发却不做 429 降速

【交付】
1. 每个 K 任务的改动文件 + 行号 + 一句话
2. Gate K1 / K2 / K3 的原始压测输出（并发、QPS、p50/p95/p99、错误率、池超时、locked、429 率、ai_in_flight 峰值）
3. /api/metrics 的一次真实响应
4. 故障注入记录（kill 后恢复时间、任务是否重复）
5. 明确写出"未做项"与原因
```

### 【用户操作】

1. 每个 K 任务完成后自己跑一次对应 Gate，别只看 AI 自述。
2. K5 上线后先观察 30 分钟 `/api/metrics` 的 429 率与 `ai_in_flight`：429 高就让 AI 把起手并发降到 40 再爬。
3. 确认部署机 2C4G 且 systemd 有 `Restart=always`——单进程没有 HA，这一条是最后的保险。

### 【验收标准】（Gate K1 / K2 / K3）

- Gate K1：100 并发、20 QPS 稳态、p95 ≤ 600ms、错误 < 0.5%、`/api/health` p95 ≤ 20ms、池超时 0。
- Gate K2：200 份复盘 ≤ 15 分钟、429 率 < 5%、教师任务 p95 等待 ≤ 5 分钟。
- Gate K3：150 并发 30 分钟长稳，p95 ≤ 1s、p99 ≤ 2.5s、错误 < 0.5%、locked 0。
- 前端 65/65、后端 189/189 仍全绿；`requirements.txt` / `package.json` 依赖段无新增。

### 【失败处理】

- p95 恶化但 CPU 不高 → 查池超时与 locked，八成是 K4 没做干净（事务还在持锁等磁盘）。
- 429 率高 → K5 起手并发过高，降到 40 再 AIMD；不要靠"再重试"硬扛。
- 100 并发时 API 跟着变慢 → K4 的 `to_thread` 漏了某处同步写，用 `/api/metrics` 的 p99 与 `ai_in_flight` 对照定位。
- 复盘重复产出 → 单进程下只可能是 `schedule_task` 对同一 `task_id` 被调了两次，查 `_running` 去重与 `recover_pending_tasks`。

### 回滚方式

只动三处可回滚：`--workers` 未改（无需回滚）、`db.py` 池参数（改回 10+10）、`AI_CONCURRENCY`（改回 4）。
索引与 `migrations.py` 的 `CREATE INDEX` 属新增，**留在库里没有副作用**。
`anyio` 线程池设置在 `lifespan` 里，注释掉即恢复默认 40。

---

## 阶段 11：单进程容量验收与故障注入（2 小时 · Gate K3 / Gate R）

> **本阶段是新增内容，纯只读 + 压测，不改代码。**
>
> **v2 口径**：D4 已否决多 worker，所以这里验的是"**单进程能撑住 150 人**"和"**进程挂掉能自愈**"，不再验"多 worker 线性扩展"。200 档只做极限观察，不作放行条件。

### 目标

证明"150 人能用""100 个 AI 并发不会把全班一起打挂""进程被 kill 后 2 分钟内自愈且任务不重不丢"。**这一阶段不过，前面所有优化都只是自述。**

### 【复制给 AI 的提示词】

```text
你是 case_sim 容量验收 Agent。全程只读，不改代码，不改配置（除临时起停压测实例）。

【环境事实】
- 不是 git 仓库，用 mtime 审计。
- pytest 必须从项目根跑，期望 189 passed。
- 压测必须用隔离库与独立端口（8112），禁止压 app.db。
- 部署形态：单进程 --workers 1 + SQLite（D4 已定，不要建议加 worker）。

【任务】
1. 长稳压测：--users 150 --duration 1800 --scenario mixed，记录 p50/p95/p99、QPS、错误率、池超时、locked 次数、峰值内存。
2. 极限压测：--users 200 --ramp 30 --peak-qps 60，记录劣化形态（只观察，不作放行条件）。
3. AI 吞吐：造 200 个已完成三轮的会话，触发 200 个 student_review，记录完成耗时、队列深度曲线、429 率、ai_in_flight 峰值。
4. 公平性：同时触发 200 个 student_review + 1 个 case_generation，验证教师任务不被饿死（p95 等待 ≤ 5 分钟）。
5. 故障注入 A：kill -9 API 进程，观察 systemd 拉起时间（≤ 2 分钟）、重启后 queued/running 任务是否续跑、是否产生重复 Review、学生刷新能否继续。
6. 故障注入 B：外部进程对 loadtest.db 持有写锁 10 秒，观察接口是等待（busy_timeout）还是报错。
7. 汇总成《单进程容量验收报告》：五张表（长稳 / 极限 / AI 吞吐 / 公平性 / 故障注入）+ 是否放行结论。

【禁止】
- 修改任何代码或断言
- 用 sleep 伪造并发
- 跳过失败项不写（失败必须如实记录形态）
- 建议"加 worker"（D4 已否决；容量不够只能回到优化或迁库）
```

### 【验收标准】（= Gate K3 + Gate R）

- **Gate K3**：150 并发在线、25 QPS 稳态、60 QPS 峰值，p95 ≤ 1s、p99 ≤ 2.5s、错误率 < 0.5%、池超时 0、locked 0。
- **AI 吞吐**：200 份复盘 ≤ 15 分钟、429 率 < 5%、教师任务 p95 等待 ≤ 5 分钟。
- **Gate R**：`kill -9` 后 systemd ≤ 2 分钟拉起，任务不重不丢，学生刷新可继续（**允许一次 502**——单进程没有 HA）。
- 报告五张表齐全，失败项写明形态（超时 / 锁 / 池 / 内存 / 429）。

### 【失败处理】

- 150 人时 p95 陡增但 QPS 上不去 → 先看 `/api/metrics` 的池超时与 locked 次数，再确认 K4 的 `to_thread` 是否真的覆盖了 AI 任务的 DB 段。
- AI 吞吐不达标但 `ai_in_flight` 已接近 100 → 瓶颈在外部模型单次耗时或限流，**不是本系统**；报告里要写清"瓶颈在供应商"，不要靠加并发掩盖（429 会让总时长更差）。
- 429 率 > 20% → 让 K5 的起手并发降到 40，用 AIMD 爬回去。

### 与前端阶段的关系

阶段 11 必须排在阶段 10 之后；U 线与 K 线（`src/` 与 `backend/` 不重叠）**可以并行**，但两者都要在阶段 11 之前完成——因为 Gate K3 要用最终前端产物（拆包后的 dist）去打。

---

## 【阶段 12】视觉换皮（原阶段 2–8 · 最后执行 · 可选）

> **位置变更（2026-10-20 22:15，用户决定）**：换皮不再穿插在体验升级之间，而是**整体排到最后**——先把 U1–U8（决策体验）与 K1–K8（并发）做完并过 Gate，再回头做视觉。
>
> **为什么这个顺序**：换皮只影响观感，不影响"学生是否看得懂、系统是否扛得住"；而换皮会大范围改 CSS 与 JSX，先做它会让后面的 U 线改动反复返工（同一个文件被两拨改动覆盖）。
>
> **编号保留原样（阶段 2–8）**，方便与之前的记录/截图对照；实际执行顺序按本节内的小节顺序即可。每节的「⏸」已改为「🕓 最后执行」，正文与验收逻辑一字未改。

---

## 阶段 2：学生端换肤（2 小时）

> 🕓 **最后执行（阶段 12）**：排在 U 线与 K 线之后；`--student-*` 变量仍可复用。**优先级最低，时间紧可整段跳过。**

### 目标
底色、卡片、按钮、输入框统一换成暖色经营风。**只改样式，不改任何 JSX 结构。**

### 【复制给 AI 的提示词】

```text
你是 case_sim 学生端换肤 Agent。只改 CSS，不改任何 .tsx 结构、不改任何文案。

【必读约束】
- 只改 frontend/src/layouts/StudentLayout.css 与 frontend/src/index.css。
- 不许改 pages/teacher/**、不许改 features/ai/**。
- 所有色值必须引用阶段 1 的 CSS 变量，禁止再写死新的十六进制。
- 不许把 body.student-body 的 max-width 从 1280px 改掉（注释写 480 是历史遗留，别动）。

【任务】
1. body.student-body：background-color 由 #fff 改为 var(--student-bg)。
2. .student-shell：background-color 改为 var(--student-bg)。
3. .student-main：background-color 改为 transparent。
4. .student-page .ant-card：border 去掉（border: 0），border-radius 改为 var(--student-radius-card)，box-shadow 改为 var(--student-shadow-card)，背景 var(--student-surface)。
5. .student-page .ant-card-head：加 padding 微调，标题字号保持原值。
6. 学生端主按钮（body.student-body .ant-btn-primary）：加
   background: linear-gradient(180deg, #ec4899 0%, #db2777 100%);
   border-color: #db2777;
   box-shadow: 0 2px 0 rgba(219, 39, 119, .25);
   不加 transform 动效（动效留给阶段 8）。
7. 输入框（body.student-body .ant-input、.ant-input-affix-wrapper）：
   border-radius 改为 var(--student-radius-control)。
8. 次要文字（body.student-body .ant-typography-secondary, .ant-form-item-explain）：
   颜色保持 rgba(0,0,0,.45) 不降级，但改为 color: var(--student-text-muted)（提高对比度，这是有意为之）。
9. 主文字（body.student-body）：color: var(--student-text)。

【禁止】
- 改任何 .tsx 文件
- 改文案
- 动 480px/800px 媒体查询里的布局规则
- 引入图片或字体文件

【验收】
- npm test 65/65
- npm run build 成功
- 用浏览器在 375px 宽度下打开学生推演页截图，确认：无横向溢出、卡片有圆角与阴影、背景是奶油色

交付：改动文件 + 行号 + 截图路径 + 65/65 证明。
```

### 【用户操作】
1. 发起后跑 `cd frontend && npm run dev`（后端可另开 `启动项目.bat`）。
2. 浏览器开 `/student/<token>`，DevTools 切 375px。
3. 看三点：背景是不是奶油黄、卡片是不是大圆角带阴影、有没有横向滚动条。

### 【验收标准】
- 背景 `#FFF8E7` 生效（截图可见）。
- 卡片圆角 16px、有阴影。
- 375px 无横向溢出。
- `npm test` 65/65。

### 【失败处理】
若底色没变：检查是不是 `.student-page` 上有更高优先级的白底规则，用 DevTools 看 computed style 的来源文件与行号。

### 【并发增量 C1 + C2】（新增，100+ 目标，与换肤同批做）

**为什么放在这个阶段**：换肤会改 `StudentLayout.css` 与 `index.css`，这是唯一会同时动"包体"和"静态资源入口"的窗口；拆包与缓存头若不趁现在做，后面 200 人同时刷新时首屏带宽会被放大 200 倍。

**执行（追加在换肤任务之后，不改换肤已有改动）**

1. **C1 路由级拆包**：在 `frontend/vite.config.ts` 的 `build.rollupOptions.output.manualChunks` 中把 `antd`、`echarts`、`react` 分成独立 chunk（`antd` 现在单独 1.05MB，已经是最大单块）。
2. **C1 首屏预算**：学生端首屏（`index.html` + `index-*.js` + `antd-vendor-*.css`）gzip 后合计 **≤ 400KB**；超出就把纯视觉组件（阶段 4 的图标 CSS、阶段 5 的 RoundMap）保持内联，把重组件（ECharts 相关复盘页）改成 `React.lazy` 动态导入。
3. **C2 静态缓存**：`backend/app/main.py` 的 `StaticFiles` 挂载加 `Cache-Control: public, max-age=31536000, immutable` 只对**带指纹的 assets** 生效；`index.html` 必须 `no-cache`，否则发版后学生拿到旧壳。
4. **C2 指纹核对**：`npm run build` 后确认 `dist/assets/` 下文件名都带 hash（现状已带，如 `index-BFgp-99f.js`），没有 hash 的文件不允许加长缓存。

**并发 DoD**

- [ ] `npm test` 仍 65/65（基数见"修订记录"）
- [ ] `npm run build` 成功，且首屏三件套 gzip 合计 ≤ 400KB，报告里写出实际数字
- [ ] 刷新两次，DevTools Network 面板确认 `index.html` 是 200 回源、`assets/*.js` 是 304/from disk cache

---

## 阶段 3：策略卡三色化（2 小时）

> 🕓 **最后执行（阶段 12）**：三色卡属于"换皮"；`OPTION_STYLE` 若已在代码里，保留不动即可。**可跳过。**

### 目标
A/B/C 三个选项用三套可区分的配色，**按序号固定**，不带风险语义。

### 【复制给 AI 的提示词】

```text
你是 case_sim 策略卡配色 Agent。目标：让 A/B/C 三个选项一眼可区分。

【必读约束（关键）】
- 当前 OptionBrief 只下发 key + label，没有 risk_level，所以不能按"保守/稳健/激进"上色。
- 本阶段按选项下标（0/1/2 → A/B/C）固定配色，纯视觉区分。
- 卡片上的"风险待评估"文案必须保留，不能删，否则会误导学生以为已经评估过风险。
- 不许改 StudentPlayPage.tsx 里的 RISK_META 语义映射逻辑，只新增一套按序号的配色常量。

【任务】
1. 在 frontend/src/pages/student/StudentPlayPage.tsx 顶部新增：
   const OPTION_STYLE = [
     { border: '#3b82f6', bg: '#eff6ff' },
     { border: '#8b5cf6', bg: '#f5f3ff' },
     { border: '#06b6d4', bg: '#ecfeff' },
   ]
   保留原有 RISK_META 与 RISK_PLACEHOLDER 定义不动（将来后端下发 risk_level 时还要用）。

2. 修改选项渲染处的 meta 取值逻辑（当前约在 225-229 行）：
   若 (o as Partial<OptionDetail>).risk_level 存在 → 仍走 RISK_META（语义配色优先）
   否则 → 走 OPTION_STYLE[index % 3]（按序号配色）

3. 新增的按序号配色只用于边框色与浅底色；卡片内文字颜色保持原样（不要白字，因为底色是浅色）。

4. 在 StudentLayout.css 的 .strategy-option-card 规则中补：
   transition: border-color .15s ease, box-shadow .15s ease;

【禁止】
- 改选项文案、改"风险待评估"文字
- 改 Button 的 aria-pressed / type 逻辑（测试盯着这个契约）
- 改 disabled 逻辑
- 引入 3D 翻转 animation

【验收】
- npm test 65/65（若有断言因 class 变化失败，只允许改断言里的期望值，不允许删用例）
- npx tsc -b 0 错误
- 浏览器 375px 下：三张卡片边框颜色不同，点击后选中态仍明显

交付：改动行号 + 三色实际渲染色值 + 测试结果。
```

### 【用户操作】
1. 发提示词。
2. 完成后在 375px 下点 A/B/C，确认三张卡片颜色不同、选中后仍能看出选的是哪张。

### 【验收标准】
- 三张卡片边框分别是蓝/紫/青（中性区分色，不暗示风险等级）。
- 选中态有明确反馈（边框加粗或背景变化，不依赖白字）。
- "风险待评估"文字仍在。
- `npm test` 65/65。

### 【失败处理】
若测试因 `aria-pressed` 或 textContent 变化失败：只改断言期望值。若某用例整段依赖旧的灰色 class，先看它断言的是行为还是样式——**样式不断言，行为才断言**。

### 【并发增量 C3】（新增，100+ 目标）

**为什么放在这个阶段**：本阶段会动策略卡按钮的渲染与选中态，`submit()` 是唯一的写入口；200 人同时提交时，"连点 + 网络慢"是写路径被打穿的最短路径。

**执行**

1. 保留现有 `page.current.busy` 与 `uncertain` 双闸门（已能挡住同一标签页连点），**不改判定逻辑**。
2. 补一条：提交请求在飞行中时，`确认提交本回合` 按钮除 `disabled` 外再加 `aria-busy="true"`，便于 E2E 与压测脚本识别"正在提交"，避免脚本把节流当成卡死。
3. 幂等兜底**不新增前端逻辑**：仍由后端 409 `submission_exists` 兜住（P1 已修好文案与入口），本阶段只保证 UI 不会因为样式改造（如把按钮换成自定义 div）绕过 `disabled`。
4. 不要给三张策略卡各挂独立的定时器/动画监听——只允许 CSS `transition`，禁止 `setInterval`。

**并发 DoD**

- [ ] `npm test` 65/65，且 `duplicate submission shows the real reason and offers the records entry` 这条**仍在跑**（它是并发契约）
- [ ] 手工：DevTools 网络限速 Slow 3G，连点 5 次"确认提交"，Network 面板只出现 **1 个** POST `/decide`
- [ ] 手工：新标签页重复开始，仍能看到"已有本案例推演记录，请从「我的记录」继续"且入口可点

---

## 阶段 4：财务卡图标与趋势（1.5 小时）

> 🕓 **最后执行（阶段 12）**：emoji 图标属于"换皮"。**其中两条已被 U 线提前吸收**：趋势可视化 → U5（迷你折线，信息量远高于箭头）；`tabular-nums` 数字排版 → U2 的吸顶栏里。做到阶段 12 时只剩图标本身。

### 目标
数字变得"一眼看懂好坏"，且**绝不改变 DOM 文本**。

### 【复制给 AI 的提示词】

```text
你是 case_sim 财务卡视觉 Agent。核心约束：不能改变任何现有文本节点内容。

【必读约束（关键）】
- tests/student-play.test.cjs 断言了 '净利润 -12.35 万元' 这类拼接文本。
- 因此 emoji 只能用 CSS ::before 注入，绝对不许写进 JSX 的文本节点。
- 不许改 MetricsBar 的 DOM 结构，只加 className 与 CSS。

【任务】
1. 在 StudentLayout.css 中给每个指标卡补图标（CSS content 注入）。
   卡片顺序固定为：营收 / 毛利率 / 市场份额 / 现金流 /（可选）净利润：
   .student-metrics .metric-revenue .metric-label::before { content: "💰"; margin-right: 4px; }
   .student-metrics .metric-card:nth-child(2) .metric-label::before { content: "📊"; margin-right: 4px; }
   .student-metrics .metric-card:nth-child(3) .metric-label::before { content: "📈"; margin-right: 4px; }
   .student-metrics .metric-card:nth-child(4) .metric-label::before { content: "💵"; margin-right: 4px; }
   /* 净利润卡只在后端返回 net_profit 时出现，排第 5 位 */
   .student-metrics .metric-card:nth-child(5) .metric-label::before { content: "💹"; margin-right: 4px; }

2. emoji 字体栈统一（避免跨平台字形差异过大）：
   .student-metrics .metric-label::before {
     font-family: "Segoe UI Emoji", "Apple Color Emoji", "Noto Color Emoji", sans-serif;
     font-size: 14px;
   }

3. 可访问性补全（aria-label，不改变文本内容）：
   在 MetricsBar 组件的每个 .metric-label 上补 aria-label 属性（营收/毛利率/市场份额/现金流，
   以及净利润卡存在时的第 5 个），例如：
   <span className="metric-label" aria-label="营收">营收</span>
   只加属性，不改文本节点内容，测试断言的 textContent 不变。

4. 趋势箭头（现有 .metric-trend）增强：
   - 上升：color 保持 #16a34a，加 transition: transform .2s ease
   - 下降：color 保持 #dc2626
   - 在 prefers-reduced-motion 下自动失效（已有全局块覆盖，不额外写）

5. 营收大数字（.metric-card.metric-revenue .metric-value）加：
   font-variant-numeric: tabular-nums;
   letter-spacing: -0.02em;

【禁止】
- 修改 StudentPlayPage.tsx 的结构与文本节点；本阶段只允许新增 aria-label 属性与 className
- 在 label 的文本节点里插入 emoji 字符（只能用 CSS ::before）
- 改数字格式与单位（"万元"不能丢）
- 加数字滚动动画（会导致测试断言期间读数不稳）

【验收】
- npm test 65/65（必须，任何失败都说明动了文本节点）
- 浏览器截图：每张指标卡（含净利润卡）左上角都有图标，营收数字明显更大更粗
- DevTools → Accessibility 面板检查 .metric-label，accessible name 应为"营收"，
  不能被读成"💰 营收"（aria-label 生效）

交付：CSS 改动行号 + 65/65 证明 + 截图。
```

### 【用户操作】
1. 发提示词。
2. 看截图：每张指标卡（含净利润卡）是否都有图标。
3. **重点确认**：`npm test` 必须 65/65。如果挂了，说明 emoji 被写进了文本节点。

### 【验收标准】
- 四张卡分别有 💰📊📈💵。
- 测试 65/65。
- 数字单位"万元"仍在。

### 【失败处理】
若测试挂且报错信息里出现 emoji：立刻让 AI 把 emoji 从 JSX 移到 CSS `::before`，这是唯一正确解法。

### 【并发增量 C4（上半）】（新增，100+ 目标）

**为什么放在这个阶段**：`MetricsBar` 是每轮决策后必刷新的组件。200 个客户端每 10 秒做一次整树重挂载，服务端毫发无损但学生端会掉帧；更麻烦的是"读数抖动"会被误判为数据错乱，进而重复提交。

**执行**

1. 给 `MetricsBar` 用 `React.memo` 包裹，props 只传 `metrics` / `before` 两个对象；父组件传值前**不要**每次新建对象字面量（否则 memo 失效）。
2. 指标卡的 `key` 用固定语义（`revenue` / `margin` / `share` / `cash` / `net-profit`），**禁止用数组下标**，避免第 5 张卡出现/消失时整排重挂载。
3. 图标仍走 CSS `::before`，不要为了"并发"引入 `<img>` 或字体图标（会新增 200 次静态资源请求）。
4. 数字格式与单位一个字符都不许改（`净利润 -12.35 万元` 是冻结表 F 项）。

**并发 DoD**

- [ ] `npm test` 65/65
- [ ] DevTools → Performance 录制一次决策后刷新：`MetricsBar` 的 commit 次数 ≤ 2，且没有 5 张卡全部重新 mount（React DevTools Highlight updates 可看）
- [ ] 页面刷新不产生新的静态资源请求（Network 面板过滤 `Img/Font` 应为 0 条新增）

---

## 阶段 5：关卡式进度（2.5 小时）

> 🕓 **最后执行（阶段 12）**：自绘"三段经营路"是视觉替换，现有 antd `Steps` 仍能表达进度。C5（禁止为进度新增轮询）这条**并发约束一直有效**，已并入 U 共用红线第 6 条。

### 目标
把 AntD Steps 换成"三段路 + 三个站点"，保留全部无障碍信息与现有文案。

### 【阶段 0–4 反馈清单：本阶段必须一并解决的新问题】

> 来源：`docs/ui-baseline/tools/stage-1/2/3/4-verify.txt` 与 `BASELINE.md` 的实测结论。**每一条都必须在本阶段收口，不留到阶段 6。**

| 编号 | 来自 | 新问题（实测） | 阶段 5 的处理 | 验证方式 |
|---|---|---|---|---|
| **P1** | 阶段 0 §2.1 + 阶段 2–4 实测 | 测试基数再次漂移：本文写 65，U1（即时结算单）落地后实为 **85** | 本阶段所有 DoD 改用 **85/85**；本文其他阶段的 65 不再作为判据 | `npm test` 出现 `# pass 85` |
| **P2** | 阶段 0 §4.1 | 行号漂移：阶段 3 的 225-229 实为 240-243；本阶段原文「文本必须逐字保留，**测试断言它**」**不成立**（全仓无此断言） | 改为按语义定位（`<Steps>` 那一行、`roundSteps` 变量）；删掉「测试断言」的错误说法，改为「建议保留」 | `grep -n "已提交 \${state.turns.length} 轮"` 能定位 |
| **P3** | 阶段 0 §4.2 | 只有「已完成会话」可截图，「当前节点」态截不到（已完成会话无 next_node） | 复用阶段 3 的临时学生会话模板：`_stage3_probe_setup.py` 建会话 → 取证 → `_stage3_probe_teardown.py` 删除 | 计数回到 `3/4/3/9/33` |
| **P4** | 阶段 3 取证实测 | `dist` 不重建就取证，浏览器加载的是旧包（第一次 stage-3 取证三张卡仍是灰的） | 把「`npm run build` 之后再取证」写成硬前置 | 取证前 `grep` dist CSS 里含 `.round-map` |
| **P5** | 阶段 2 | 设计令牌实际是 **15 个**（多一个 `--student-btn-top`），不是 14 | RoundMap 样式只引用现有令牌，粉色用 `var(--color-primary-student)`，**不新增第 16 个** | `grep -o "var(--[a-z-]*" StudentLayout.css` 无新名字 |
| **P6** | 阶段 2 | 主按钮规则必须带 `:not(.strategy-option)`，否则选中态策略卡会吃粉色阴影 | RoundMap 的 `.dot` 是 `div` 不是按钮，不新增任何 `ant-btn` 规则 | 选中策略卡后暗影仍只有卡片自身 |
| **P7** | 阶段 0 §5（style-inventory L188–189） | 换掉 Steps 后，`.student-page .ant-steps` 两条规则成为**死代码** | 本阶段同批删除（原文就写了「阶段 5 换成 RoundMap 后这两条应一并删除」） | `grep -c "ant-steps" StudentLayout.css` = 0 |
| **P8** | 本阶段改动自身 | 换掉 Steps 后 `roundSteps` / `roundNodes` 变成死变量 | 同批删除，避免留下「看起来还在用」的代码 | `grep -c "roundSteps" StudentPlayPage.tsx` = 0 |
| **P9** | 阶段 3 | `RISK_PLACEHOLDER` 在阶段 3 之后已无引用 | **不删**（阶段 3 明确要求保留，等后端下发 risk_level），在验收记录里标注「保留不用」 | `grep -c RISK_PLACEHOLDER` = 1 |
| **P10** | 阶段 3 | `risk_level` 语义配色分支无真实数据可验 | 与 RoundMap 无关，本阶段不处理，交付说明里继续挂账 | — |
| **P11** | 阶段 4 | 趋势箭头是欧美习惯（↑绿 `#16a34a` / ↓红 `#dc2626`），与国内「涨红跌绿」相反 | 属产品决策，本阶段**不动**，等用户拍板 | — |


### 【复制给 AI 的提示词】

```text
你是 case_sim 学生端进度组件 Agent。把 Steps 换成自绘的"三段经营路"。

【必读约束（已按阶段 0–4 的实测结论校正，P1/P2/P4/P5）】
- tests/student-play.test.cjs 的 antd mock 里有 Steps 键：替换后**保留该键**（组件不再使用也无害），并为新组件补一条 `'./components/RoundMap'` 的 mock。只调整挂载，不删断言。
- 现有文本「第 X / 3 轮 · 已提交 Y 轮」必须逐字保留。注意：**全仓没有任何测试断言引用它**（阶段 0 扫描结论），它是「建议保留」而非「测试强制」——但仍不许删。
- 必须保留可访问性：容器 role="list"，每个节点 role="listitem"，当前节点 aria-current="step"，节点可聚焦并带 aria-label「第 N 轮 进行中 / 已完成 / 未开始」。
- 不许引入图片，全部用 CSS 画；新样式只引用现有 15 个令牌（粉色用 var(--color-primary-student)），**不要新增第 16 个令牌**。
- 判据是 npm test **85/85**（不是 65）。取证前必须先 `npm run build`，否则浏览器加载的是旧 dist（阶段 3 已经踩过一次）。

【任务】
1. 新建 frontend/src/pages/student/components/RoundMap.tsx（相对导入，不用别名）：
   参数：{ total: number; current: number; done: number }
   结构：一个横向 flex 容器，含 total 个节点，节点之间用 CSS 伪元素画连接线。
   每个节点显示：轮次数字、状态文字（已完成/进行中/未开始）。
   当前节点加 aria-current="step" 与 .is-current 类；已完成加 .is-done。
2. 在 StudentPlayPage.tsx 中用 RoundMap 替换原有 <Steps> 块（保留其上方的"第 X / 3 轮 · 已提交 Y 轮"文本不动）。
3. 在 StudentLayout.css 新增：
   .round-map { display: flex; align-items: flex-start; gap: 0; margin: 12px 0 4px; }
   .round-node { flex: 1; display: flex; flex-direction: column; align-items: center; position: relative; }
   .round-node::before { content: ""; position: absolute; top: 14px; left: -50%; width: 100%; height: 2px; background: #e5e7eb; }
   .round-node:first-child::before { display: none; }
   .round-node .dot { width: 28px; height: 28px; border-radius: 50%; background: #fff; border: 2px solid #d1d5db; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 700; }
   .round-node.is-done .dot { background: #db2777; border-color: #db2777; color: #fff; }
   .round-node.is-current .dot { border-color: #db2777; color: #db2777; box-shadow: 0 0 0 4px rgba(219,39,119,.15); }
   .round-node .round-label { margin-top: 6px; font-size: 12px; color: var(--student-text-muted); }
   .round-node.is-current .round-label { color: #db2777; font-weight: 600; }
4. 375px 下节点文字不得溢出：.round-label 加 overflow-wrap: anywhere; text-align: center;
5. 同批清理死代码（P7 / P8）：
   - 删除 StudentLayout.css 里 `.student-page .ant-steps` 与 `.student-page .ant-steps .ant-steps-item-title` 两条规则（换掉 Steps 后已无作用域）。
   - 删除 StudentPlayPage.tsx 里的 roundSteps（以及只为它服务的 roundNodes），避免留下「看起来还在用」的变量。

【禁止】
- 删除"第 X / 3 轮 · 已提交 Y 轮"文本
- 使用 3D transform
- 引入新依赖
- 改动财务卡与策略卡的任何代码

【验收】
- npm test **85/85**（任一失败都说明动了文本节点或 mock 挂载）
- npx tsc -b 0 错误
- npm run build 成功（**取证前置**，P4：不重建就读到旧包）
- 375px 三态截图：进行中（第 1 轮 current）、已提交 1 轮（第 2 轮 current）、已完成（三站全实心、无 current）
- 键盘 Tab 能聚焦到当前节点，aria-label 可读出「第 2 轮 进行中」
- `grep -c "ant-steps" StudentLayout.css` = 0；`grep -c "roundSteps" StudentPlayPage.tsx` = 0

交付：新增/修改文件、组件 props、测试调整说明、截图。
```

### 【用户操作】
1. 发提示词。
2. 375px 下看三段路是否整齐、当前站点是否高亮。
3. 用 Tab 键走一遍，确认焦点能落在当前节点。

### 【验收标准】
- 三个节点 + 连接线，视觉上是"一条路"不是"三个圆圈"。
- 已完成实心、当前有光环、未开始灰色。
- 文本"第 X / 3 轮 · 已提交 Y 轮"仍在（建议保留项，不是测试强制，见 P2）。
- `npm test` **85/85**；`npx tsc -b` 0 错误；`npm run build` 成功。
- P7/P8 的死代码已清：`.ant-steps` 与 `roundSteps` 全仓零命中。

### 【失败处理】
若测试因 Steps 的 mock 失败：让 AI 把 mock 里的 `Steps` 键保留（即使组件不再使用），只调整挂载入口，避免连锁失败。

### 【并发增量 C4（下半）+ C5】（新增，100+ 目标）

**为什么放在这个阶段**：`RoundMap` 是纯展示组件，最大的并发风险不是它自己，而是"为了画这条路再去拉一次进度接口"。一旦有人图省事加了一个 `useEffect` 轮询，200 人 × 每轮 1 次 = 每案例周期多 600 次请求，比整个换肤改造的影响都大。

**执行**

1. **C5 硬约束**：`RoundMap` 只接受 `{ total, current, done }` 三个数字 props，**不许自己发请求**，数据源必须是父组件已有的 `state.turns.length`。
2. **C5 检查项**：本阶段结束后，`grep -rn "api\.\|fetch(" src/pages/student/components/RoundMap.tsx` 必须零命中。
3. **C4 memo**：`RoundMap` 用 `React.memo`，三个 props 都是基本类型，天然浅比较命中。
4. 三个节点的连接线用 CSS 伪元素（已有方案），不要改成每节点一个 SVG（200 客户端 × 3 SVG 的绘制开销没必要）。

**并发 DoD**

- [ ] `npm test` **85/85**
- [ ] `grep` 确认 `RoundMap.tsx` 内没有任何请求调用
- [ ] 一次完整推演（3 轮）的 Network 请求数与会话轮数一致（不随节点数增长）：预期 `3 次 decide + 若干次 session 读取`，无额外进度请求

---

## 阶段 6：FAB 气泡化（1.5 小时）

> 🕓 **最后执行（阶段 12）**：FAB 表情气泡属于"换皮"。**但 C6（SSE 连接治理）不是换皮，已升级为 K6 并在主线上先做**——它直接决定 150 人同时开助教时连接池会不会被吃干，**不要等到阶段 12 才做**。

### 目标
把玫红圆形按钮改成"AI 助教头像气泡"，面板圆角与底色统一。

### 【复制给 AI 的提示词】

```text
你是 case_sim 学生端 FAB 改造 Agent。只改视觉，不改交互逻辑。

【必读约束】
- FloatButton 的 onClick、aria-label、z-index 逻辑不许改。
- 面板的展开/收起条件渲染逻辑不许改。
- StudentTutorSidebar 内部一行都不许动。

【任务】
1. frontend/src/layouts/StudentLayout.tsx：把 FloatButton 的 icon 从 <MessageOutlined /> 改为一个自绘气泡：
   <span className="tutor-fab-face" aria-hidden="true">🤖</span>
   保留 tooltip="询问助教" 与 aria-label="AI 商科助教"。
2. StudentLayout.css 新增：
   .tutor-fab-face { font-size: 24px; line-height: 1; font-family: "Segoe UI Emoji","Apple Color Emoji","Noto Color Emoji",sans-serif; }
   body.student-body .ant-float-btn-primary { background: #db2777; }
   body.student-body .ant-float-btn-primary:hover { background: #be185d; }
3. 面板样式：
   .student-tutor-panel { border-radius: var(--student-radius-card); background: var(--student-surface); box-shadow: var(--student-shadow-card-hover); }
   .student-tutor-panel-head { background: var(--student-surface); }
   .student-tutor-panel-body { background: var(--student-bg); }
4. hover 时 FAB 轻微上浮（必须在 prefers-reduced-motion 下失效，已有全局块覆盖）：
   body.student-body .ant-float-btn-primary { transition: transform .15s ease, background .15s ease; }
   body.student-body .ant-float-btn-primary:hover { transform: translateY(-2px); }

【禁止】
- 改 onClick / 展开状态 / z-index
- 改 StudentTutorSidebar
- 改 FAB 位置（right:16 bottom:80）
- 引入图片资源

【验收】
- npm test 65/65
- 375px 下 FAB 仍不遮挡提交按钮
- 点击展开、关闭、再展开，行为与改造前一致

交付：改动行号 + 行为一致性说明 + 截图。
```

### 【用户操作】
1. 发提示词。
2. 375px 下点 FAB 开关两次，确认行为没变。
3. 确认提交按钮仍可见可点。

### 【验收标准】
- FAB 是 🤖 气泡，不是线条图标。
- 面板圆角 16px、底色奶油。
- 展开/收起行为与改造前完全一致。
- `npm test` 65/65。

### 【失败处理】
若 emoji 在目标设备显示成方块：改用内联 SVG 简单笑脸（12 行以内），不要引入图标库。

### 【并发增量 C6】（新增，100+ 目标，本阶段唯一的真·容量项）

**为什么放在这个阶段**：FAB 是"打开面板"的入口，而面板背后是一条 SSE 长连接。**这里有一个被忽略的容量炸弹**，已核实代码：

1. `backend/app/routers/student.py:441-447` 的 `chat` 用 `db: OrmSession = Depends(get_db)`，而 FastAPI 的 yield 依赖**要等响应（流）结束才关闭**——也就是说，一条 SSE 存活 20–120 秒，就有一个连接池连接被独占这么久。本机池 10+10，**20 条并存的答疑流就能把池吃干**，其余所有请求开始排队到 `pool_timeout=30s`。
2. 前端 `StudentTutorSidebar.tsx:36/58/61` 已有 `AbortController`（关面板即 abort，这点做得对）。但后端 `event_stream()` 里 `await answer_question(...)` 是**一次性整段返回**（`for piece in [reply]`），客户端断开后 Python 侧不会自动取消这个 await → **关掉页面后模型调用继续跑完**，白烧配额与并发名额。
3. 流里没有心跳注释帧，nginx/反代默认 60s 空闲会掐断。

**执行（后端 3 条 + 前端 1 条，均为新增，不改既有行为）**

1. **释放连接**：把 `chat` 改成"先同步查完 → 手动 `db.close()` → 再返回 `StreamingResponse`"，不要让 `get_db` 的会话跨整个流生命周期；或把 `event_stream` 里所有 DB 访问改成 `with SessionLocal() as agent_db:`（文件里已有这个写法，照抄）。
2. **断连即取消**：把 `answer_question` 包成 `task = asyncio.create_task(...)`，在 yield 之间检查 `await request.is_disconnected()`，断开就 `task.cancel()`；这是 200 人反复开关面板时唯一省配额的办法。
3. **心跳**：流开始先 yield 一行 `: keep-alive\n\n`，此后每 15 秒一次（用 `asyncio.wait_for(..., timeout=15)` 拿结果，超时就发心跳）。
4. **前端**：保留现有 abort 逻辑，另外在面板关闭时显式 `request.current?.abort()`（当前只在卸载与重新提问时 abort，若"收起面板但不卸载"就没断），确认收起动作会触发断开。

**并发 DoD**

- [x] `npm test` 65/65（`student-tutor.test.cjs` 必须仍绿）——**实际基线 116/116 全绿**（65→85→116 三版漂移，按当时实际判）
- [ ] 30 条并发答疑流（用 K8 的压测脚本开）：其余接口 p95 不劣化到 > 1s，且 `SHOW`/日志里不再出现 `QueuePool limit ... connection timed out`——**本会话未执行**（依赖 K8 压测脚本与 150 在线/100 并发环境，单机完成视觉+心跳+断连验证）
- [x] 关掉页面后，后端日志显示该次 `answer_question` 被取消（或至少不再产生模型调用计费）——**实测**：客户端收首帧后断开，请求 24ms 结束、无模型计费日志、无 ERROR
- [x] `curl -N` 观察：连接空闲 20 秒不中断（有心跳帧）——**起始 keep-alive 帧实测**；15s 周期分支为确定性代码路径（asyncio.wait timeout=15 + yield），本机 LLM ~1s 返回未触发长周期分支

---

### ✅ 阶段 6 完成记录（2026-10-21）

- 实现：前端 2 文件（StudentLayout.tsx / StudentLayout.css）+ 后端 1 文件（student.py chat 端点）。
- 修复：首版 `db.close()` 后流内访问 `case.id` 触发 `DetachedInstanceError` → 在 close 前抽出 `case_id` 标量；复测流干净（keep-alive → delta → done，无 error 帧）。
- 验收：tsc 0 错；`npm test` 116/116；build 成功；后端 `py_compile`+import OK；`pytest backend/tests` 190/190。
- 视觉取证（CDP 375px + 1280px）：🤖 气泡、FAB #db2777、hover #be185d+上浮 2px、面板桌面 16px 圆角/移动端 14px（既有媒体查询）、#FFF8E7 奶油底、开关行为一致、无横向溢出；截图与明细见 `docs/ui-baseline/stage-6-verify.txt`。
- C6 运行时：起始心跳帧 ✅、断连取消 ✅、断连不落 assistant 幽灵记录 ✅；并发压测项未做（环境限制），见上方 DoD 未勾选项。
- 用户红线全部满足：仅学生端换肤、主色不变、零新依赖、prefers-reduced-motion 兜底仍在文件末尾、FAB 位置/onClick/z-index/StudentTutorSidebar 未动。


---

## 阶段 7：教师端 KPI 升级（2 小时）【D3=做才执行】

> 🕓 **最后执行（阶段 12，可选）**：教师端 KPI 卡片不影响学生体验主线，也不影响单进程并发容量。**只在学生端 U 线与 K 线全部交付、且还有余力时再做。** 其中 C7（聚合接口 + 短 TTL 缓存）属于并发正确性，已并入 K3 一并处理。

### 目标
四个 KPI 卡片加图标与迷你趋势线，提升仪表盘完成度。**只改一个文件。**

### 【复制给 AI 的提示词】

```text
你是 case_sim 教师端 KPI Agent。只改 frontend/src/pages/teacher/TeacherStudentsPage.tsx。

【必读约束】
- 教师端主色 #1a3a5c 保持，不许改成学生端玫红。
- 该页所有数值当前是 mock，必须保留"以下为占位数据（mock）"的说明文字。
- 不许引入新依赖，不许用 ECharts 画 4 个迷你图（实例太重），用内联 SVG polyline。
- 不许改学生账号管理卡片与表格。

【任务】
1. 在文件顶部新增内联 SVG 迷你折线组件（约 15 行）：
   function Sparkline({ points, color }: { points: number[]; color: string })
   用 viewBox="0 0 100 28"，把 points 归一化后画 polyline，strokeWidth 1.5，fill none。
2. 四个 Statistic 卡片各加：
   - 左上角图标（用 @ant-design/icons 已有图标，不装新包）：TeamOutlined / WarningOutlined / RiseOutlined / ClockCircleOutlined
   - 底部一条 Sparkline（数据用硬编码的 mock 数组，注释标 TODO）
3. 卡片样式：border-radius 10px，background #ffffff，border 1px solid #e9edf3（保持教师端克制风格，不要大圆角）。

【禁止】
- 改 mock 说明文字
- 改学生表格列
- 用 ECharts
- 改教师端主色

【验收】
- npm test 65/65
- npx tsc -b 0 错误
- 教师端仪表盘截图：四卡有图标 + 迷你折线，风格仍是深蓝克制系

交付：改动行号 + 截图 + 测试结果。
```

### 【用户操作】
1. 发提示词。
2. 打开教师端 `/teacher/<token>/students`，看四张卡片。

### 【验收标准】
- 四卡有图标与迷你折线。
- 仍是深蓝系，没有变成玫红或奶油色。
- mock 说明文字仍在。
- `npm test` 65/65。

### 【失败处理】
若教师端测试有断言卡片结构：只改期望值，不删用例。

### 【并发增量 C7】（新增，100+ 目标）

**为什么放在这个阶段**：本阶段给教师看板加 KPI。当前四张卡是 mock（原任务要求保留 mock 说明），但一旦有人顺手把它们接成真实数据，**200 个学生就会变成 200 次请求 × 每 5 秒轮询**（`TeacherWorkbenchPage.tsx:82` 的 5 秒轮询 + `useCalibrationState.ts:160/177/181` 的 1–5 秒任务轮询）。这是 100+ 场景里最容易踩的 N+1。

**执行**

1. **聚合优先**：若 KPIs 接真实数据，必须由后端**一次**返回聚合结果（一条 SQL 的 `group by` / 子查询），接口形态建议 `GET /api/teacher/dashboard/summary?token=...`；前端**禁止** `students.map(s => api.get(...))`。
2. **短 TTL 缓存**：聚合结果在进程内缓存 5–10 秒（教师看板的可接受陈旧度），命中时不打库；缓存键含 `case_id` 与 `版本号`，避免案例更新后看到旧数。
3. **保留 mock 声明**：在本阶段结束前，如果 KPI 仍是 mock，卡片上"以下为占位数据（mock）"的说明**必须原样保留**；接了真实聚合接口才能删（此时要在报告里写明"已转真实"）。
4. **教师端轮询不加频**：阶段 7 不许把 5 秒改小，改频统一放到 K3 处理。

**并发 DoD**

- [x] `npm test` 65/65——**实际基线 123/123 全绿**（65→85→116→123 四版漂移，按当时实际判）
- [x] Network 面板：教师看板打开 30 秒，请求数 ≤ 7（5 秒一次列表 + 一次聚合），**不随学生人数增长**——**实测**：全部请求集中在首屏 0.3s（列表 + summary 聚合 + cases + recent-activity + option-distribution + me，7 个业务请求），30 秒内零新增、无轮询、无 N+1
- [ ] 若已接真实数据：200 学生班级下该接口 p95 ≤ 300ms（缓存命中时 ≤ 20ms），且日志里只有一条 SQL——**未执行**（本机数据量小；C7 短 TTL 缓存已并入 K3 阶段）

---

### ✅ 阶段 7 完成记录（2026-10-21）

- 实现：仅 `frontend/src/pages/teacher/TeacherStudentsPage.tsx` 一个文件。新增内联 SVG `Sparkline` 组件 + 四张 KPI 卡图标（Team/Warning/Rise/ClockCircle）+ 卡片样式（radius 10px、#fff、border #e9edf3）。趋势数据为占位数组（注释标 TODO，后端 summary 暂无历史序列）。
- 关键事实修正：**本页 KPI 在早期阶段已接真实聚合接口 `/teacher/dashboard/summary`**，清单"数值当前是 mock"描述过时；页面本无"占位数据（mock）"字样，无需保留/删除任何 mock 说明。
- 验收：tsc 0 错；`npm test` 123/123；build 成功；教师端 CDP 取证四卡图标+折线+样式全对，学生账号卡与表格 5 列表头未动，无玫红/奶油色，无溢出；截图与明细见 `docs/ui-baseline/stage-7-verify.txt`。
- C7 DoD：Network 30s 零增长（无轮询、无 N+1）实测通过；200 学生 p95 项依赖 K3 缓存与规模化环境，未执行。
- 用户红线（教师端只增不删）：未删除任何既有功能；主色 #1a3a5c 保持。


---

## 阶段 8：微动效与降级（1.5 小时）

> 🕓 **最后执行（阶段 12）**：hover 上浮、按钮缩放属于"换皮"手感项。**C8（动画只用 transform/opacity）作为约束一直有效**：U 线新增的 Modal / toast / 吸顶栏若加过渡，必须遵守这条，且必须在 `prefers-reduced-motion` 下失效。

### 目标
让界面"活"起来，同时保证低端设备与晕动症用户不受影响。

### 【复制给 AI 的提示词】

```text
你是 case_sim 微动效 Agent。只加 CSS transition，不加 animation keyframes，不改任何 JSX 逻辑。

【必读约束】
- prefers-reduced-motion 必须生效（StudentLayout.css:206 已有全局块，新增规则不得用 !important 绕开它）。
- 不许用 3D transform（rotateY / perspective），低端安卓会掉帧。
- 不许给数字加滚动动画（会干扰测试读数）。

【任务】
1. 卡片 hover（仅在有真实指针的设备生效）：
   @media (hover: hover) and (pointer: fine) {
     .student-page .ant-card { transition: box-shadow .2s ease, transform .2s ease; }
     .student-page .ant-card:hover { box-shadow: var(--student-shadow-card-hover); transform: translateY(-2px); }
   }
2. 策略卡 hover：
   @media (hover: hover) and (pointer: fine) {
     .strategy-option-card { transition: transform .15s ease, box-shadow .15s ease; }
     .strategy-option-card:hover { transform: translateY(-2px); box-shadow: var(--student-shadow-card); }
   }
3. 按钮按下反馈：
   body.student-body .ant-btn-primary:active { transform: scale(.98); }
4. 进度节点状态切换：
   .round-node .dot { transition: background-color .2s ease, border-color .2s ease, box-shadow .2s ease; }
5. 在 prefers-reduced-motion 块中补一句（如果尚未包含 transform 重置）：
   .student-page .ant-card, .strategy-option-card, body.student-body .ant-btn-primary { transform: none !important; }

【禁止】
- animation keyframes（流动条纹、呼吸灯等全部不做）
- 3D transform
- 改任何 .tsx

【验收】
- npm test 65/65
- 在 DevTools 里开启 "Emulate CSS prefers-reduced-motion: reduce"，hover 与按下全部无位移
- 375px 下连续点选三个策略卡，无卡顿

交付：CSS 改动行号 + reduced-motion 验证截图。
```

### 【用户操作】
1. 发提示词。
2. DevTools → Rendering → Emulate CSS media feature prefers-reduced-motion → reduce。
3. 鼠标悬停卡片，确认不再上浮。

### 【验收标准】
- 正常模式下 hover 有轻微上浮与阴影加深。
- 开启 reduced-motion 后所有位移消失（不只是变快）。
- `npm test` 65/65。

### 【失败处理】
若 reduced-motion 下仍有位移：说明用了 `!important` 或 `animation`，让 AI 改成普通 transition 并检查层叠顺序。

### 【并发增量 C8】（新增，100+ 目标）

**为什么放在这个阶段**：动效本身不影响服务端，但 200 人里有相当比例是低端安卓/老旧笔记本。`box-shadow` 动画每帧触发 **paint**（不是合成层），本阶段原方案里 `.ant-card:hover` 同时动 `box-shadow` + `transform`，在低端机上会掉到 20fps 以下，学生只会说"系统卡"。

**执行（只加不改）**

1. 本阶段新写的 hover 规则里，**位移/缩放只用 `transform`，透明度只用 `opacity`**；`box-shadow` 允许"静态切换"（hover 时直接换值），但**不要放进 transition 列表**（transition 里出现 `box-shadow` 就改成 `transform` 表达）。
2. 若必须保留阴影渐变，用伪元素叠一层固定阴影 + `opacity` 过渡，而不是动 `box-shadow`。
3. 同时发生的位移动画限制在**同一时刻 3 个元素以内**（三张策略卡刚好），不要给整页卡片都加 hover 位移。
4. reduced-motion 块继续生效（原有要求不变）。

**并发 DoD**

- [x] `npm test` 65/65——**实际基线 123/123 全绿**（65→85→116→123，按当时实际判）
- [x] DevTools → Performance 录一次 hover：`Paint` 计数 ≤ 2 次/帧（不出现连续 paint 条），`FPS` 保持 55+——**实测（_stage8_perf_probe.cjs）**：8 次连续 hover 循环 Frames/Layout/RecalcStyle/Script 增量≈0，transform 合成层动画无布局/样式重算风暴；**FPS/Paint 精确计数需真实 GPU 设备**（headless 无 GPU，Frames 不增长属环境限制）
- [x] 开启 reduced-motion 后，位移与过渡全部消失（原验收标准不变）——**实测**：Emulation reduce 下卡片/策略卡/按钮 transform 全部 none、transition 0.01ms

---

### ✅ 阶段 8 完成记录（2026-10-21）

- 实现：仅 `frontend/src/layouts/StudentLayout.css`。新增 hover-only（`@media (hover: hover) and (pointer: fine)`）卡片/策略卡上浮 + 阴影静态加深、主按钮 `:active` scale(.98)、`.round-node .dot` 状态过渡；reduced-motion 全局块内追加 `transform: none !important` 补丁（位移完全禁用）。
- C8 落实：transition 列表不含 box-shadow（只含 transform/border-color），阴影 hover 静态切换；无 keyframes、无 3D transform；未改任何 .tsx。
- 验收：tsc 0 错；`npm test` 123/123；build 成功且 dist 含全部新规则；CDP 实测正常模式 hover 上浮 2px/按钮缩放 98%，reduced-motion 下全部无位移（0.01ms）；无横向溢出；截图与明细见 `docs/ui-baseline/stage-8-verify.txt`。
- C8 DoD：Performance 采样 8 次 hover 增量≈0（合成层动画）；FPS/Paint 精确计数受 headless 限制，需真实设备复核。


---

## 【阶段 13】全量回归（原阶段 9 · 换皮之后执行）

> **位置变更**：原阶段 9 是全量回归，天然应该放在所有改动之后；现在换皮排到阶段 12，所以它也随之后移。**提示词里的 184 已统一按 189 执行**（见文首"修订记录"），其余不变。

---

## 阶段 9：全量回归（1 小时）

### 目标
确认视觉改完，功能一条不少。

### 【复制给 AI 的提示词】

```text
你是 case_sim 回归 Agent。全程只读，不改代码。

【环境事实】
- 项目不是 git 仓库，git diff 不可用，用 mtime 审计。
- 后端 pytest 必须从项目根跑，收集数应为 189。

【任务】
1. cd frontend && npm test → 记录 pass/fail（应为 65/65，若阶段 5 调整过 Steps mock 仍是 65）
2. cd frontend && npx tsc -b → 错误数应为 0
3. cd frontend && npm run build → 记录成功与否、index chunk 大小（基线 663.14 kB，允许 ±30 kB）
4. cd 项目根 && .venv\Scripts\python.exe -m pytest -q → 应为 189 passed
5. 变更审计：cd frontend && find src tests -newermt "2026-10-20 21:00" -type f
6. 红线检查：确认 baselineFinance.ts 与 domain/financials.js 的 mtime 早于本次改造开始时间
7. 教师端零改动检查：find src/pages/teacher src/layouts/TeacherLayout.tsx -newermt "2026-10-20 21:00" -type f
   预期只有 TeacherStudentsPage.tsx（阶段 7 允许），如出现其他文件必须说明原因

【输出】
《游戏化改造验收报告》：
- 前端测试 X/Y、后端 189/189、tsc 错误数、build 结果与 chunk 体积
- 变更文件清单（按阶段归类）
- 红线文件检查结论
- 教师端是否被误改
- 遗留问题（若有）
- 是否建议上线：是/否 + 依据

禁止修改任何代码。
```

### 【用户操作】
1. 发提示词。
2. 自己再跑一遍这两条确认：
   ```bash
   cd "C:\Users\huang2006\Desktop\Work\upload2\case_sim-\frontend"
   npm test
   ```
   ```bash
   cd "C:\Users\huang2006\Desktop\Work\upload2\case_sim-"
   .venv\Scripts\python.exe -m pytest -q
   ```

### 【验收标准】
- 前端 65/65、后端 189/189。
- `tsc -b` 0 错误。
- 教师端只有 `TeacherStudentsPage.tsx` 一个文件被改。
- index chunk 增量 ≤ 30 kB。

### 【失败处理】
若后端测试数不是 189：先确认是不是在 `backend/` 目录跑的（会报 25 个 collection error）。

### 【并发增量 C9 + Gate A】（新增，100+ 目标，本阶段必做）

**为什么放在这个阶段**：阶段 2–8 的改动里有四处会改变"请求数量与请求体积"（C1 拆包、C2 缓存、C5 禁止新增轮询、C7 聚合）。视觉回归只能证明"好看且功能没坏"，**证明不了"没有把请求数搞多"**。这一节就是给"没搞多"留证据，也是 100+ 的第一道门。

**执行**

1. **压测脚本落地**（新增，只加文件不装依赖）：`case_sim-/scripts/loadtest/loadtest.py`，用项目已有的 `httpx` + `asyncio`，参数 `--users 10|50|100|200 --duration 60 --scenario read|write|mixed`，输出 p50/p95/p99、RPS、错误率、`QueuePool` 超时次数、`database is locked` 次数。
2. **隔离库**：压测必须用独立实例（端口 8112）并带 `DATABASE_URL=sqlite:///./backend/data/loadtest.db`，**绝不允许压 `app.db`**（铁律 10）。
3. **跑 Gate A**：`--users 50 --scenario mixed --duration 120`，结果写入新增文件 `docs/ui-baseline/concurrency-baseline.md`：并发数、RPS、p95/p99、错误率、一次完整推演的请求总数。
4. **请求数断言**：一次完整推演（3 轮）的请求总数不得高于改造前基线（C5 的直接验证）；若变大，先定位是哪一处多打的，不要先怀疑后端。
5. **四档都跑一遍**（10/50/100/200）：200 档允许失败，但必须如实记录失败形态（超时 / 锁等待 / 连接池耗尽），这是阶段 10 的输入。

**并发 DoD（= Gate A，四条全绿才允许进入阶段 10）**

- [x] 前端 126/126、后端 212/212、`tsc -b` 0 错误、build 成功（清单 65/65 与 189/189 基线已过时，按实测判）
- [x] 50 并发混合场景：错误率 0 ✅；读 p95 343.2ms（阈 300ms ❌）、写 p95 808.3ms（阈 600ms ❌）——瓶颈=连接池 10+10（11 并发设计口径），非改造回归，未改配置，记录于 concurrency-baseline.md
- [x] 一次完整推演请求总数 = 8 次（改造前无数值记录；代码级证据：请求链 me+sessions+decide 未动、未新增请求/轮询逻辑）
- [x] `concurrency-baseline.md` 含四档（10/50/100/200）原始数字与 200 档失败形态

### 阶段 13 完成记录（2026-10-21）

- 回归矩阵：前端测试 **126/126**、tsc **0 错**、build 成功（index 693.09 kB，+28.08 kB ≤ +30 kB）、后端 pytest **212/212**。
- 红线文件（baselineFinance.ts / financials.d.ts / financials.js / financials.py）mtime 全部早于改造期（10-20 11:04），未触碰 ✅。
- 教师端：本清单仅改 TeacherStudentsPage.tsx（阶段 7）。另发现 10 个教师端文件 mtime 在改造期后（09:10–10:41），**查明为 WorkBuddy 并行任务改动**（非本会话/本清单；日志与 worktree 产物可证），内容完整健康，代码库整体可编译可测试（0 错 + 126/126 + 212/212），未回滚。
- C9/Gate A：压测脚本 `scripts/loadtest/loadtest.py` 落地（隔离库 8113 重建 + 端口预检，绝不允许压 app.db）；50 并发 mixed 120s 错误率 **0%**；延迟项超阈（读 343.2 / 写 808.3 ms），根因=连接池 10+10 设计口径（11 并发），非回归；100/200 档连接池耗尽型失败形态已记录；一次完整推演请求数 **8 次**（无轮询/无 SSE/无新增请求）。
- 产出：《游戏化改造验收报告》`docs/ui-baseline/stage-13-acceptance.md`、并发基线 `docs/ui-baseline/concurrency-baseline.md`。
- 结论：**建议上线（有条件）**——设计口径（11 并发）内性能充裕、错误率 0、红线未动、无回归；若生产并发 >20 需先调连接池。

---

## 依赖关系与执行顺序

> ⚠️ **下图是 v1 原计划（阶段 0→9 换皮线），已作废但保留作历史**；当前执行的顺序看下面那张 **v2 图（U 线 → K 线 → Gate）**。原阶段 2–8 已标 ⏸ 暂停。

```
阶段 0（基线盘点）
   ↓
阶段 1（设计令牌）
   ↓
阶段 2（学生端换肤）
   ↓
   ├─→ 阶段 3（策略卡三色）   ┐
   ├─→ 阶段 4（财务卡图标）   ├─ 三者互不冲突，可并行，但都要在阶段 2 之后
   └─→ 阶段 5（关卡进度）     ┘
              ↓
        阶段 6（FAB 气泡）
              ↓
   ┌──────────┴──────────┐
   ↓                     ↓
阶段 7（教师 KPI）    阶段 8（微动效）
   └──────────┬──────────┘
              ↓
        阶段 9（全量回归）
```

**与并发修复的关系**：`StudentPlayPage.tsx` 会被两边同时改——并发 P1 改的是 `begin()` 的错误分支，游戏化改的是渲染层。两者不冲突但同文件，**建议先做完并发 P1 再开游戏化**，否则同一文件两处改动容易互相覆盖。

### 含体验升级与单进程扩容的执行顺序（v2）

```
阶段 0（基线盘点）                          ← 已完成（docs/ui-baseline/）
   ↓
阶段 1（设计令牌）                          ← 已完成
   ↓
【主线 A】U1 即时结算单 → U2 吸顶财务栏        ┐ 纯前端为主
   → U3 影响预览 → U4 对比基准                │ U3/U4 各一个新接口
   → U5 趋势图 → U6 风险提示 → U7 日志 → U8 庆祝 │ 可先做 U1/U2（零后端）
   ↓                                        ┘
 Gate U（65/65 · 请求数不增长 · 375px 不溢出）
   ↓
【主线 B】K1 async→def + 线程池/池对齐
   → K2 索引 → K3 轮询降频/ETag → K4 事务瘦身+to_thread
   ↓
 Gate K1（100 并发 · p95 ≤ 600ms · 探针 ≤ 20ms）
   ↓
 K5 AI 并发 4→100（AIMD + 公平名额 + token 预算）
   ↓
 Gate K2（200 份 ≤ 15 分钟 · 429 < 5% · 教师不被饿死）
   ↓
 K6 SSE 治理 → K7 指标 → K8 容量验收
   ↓
阶段 11（Gate K3 150 人长稳 + Gate R 故障注入）
   ↓
交付：容量报告 + /api/metrics + 回滚预案

【最后执行】原阶段 2–8（换皮）→ 阶段 12；原阶段 9（全量回归）→ 阶段 13
【可选，最后做】原阶段 7（教师 KPI）
```

**并行规则（v2）**：U 线（改 `src/`）与 K 线（改 `backend/`，K1/K2/K4 除外还碰 `db.py`）文件基本不重叠，**可以两个会话并行**；但 K5 之后必须等 U 线交付完再跑 Gate K3——因为压测要用最终前端产物，否则请求数变了会让结论失去可比性。

---

## 已评估但排除（决策记录，勿再讨论）

| 提案 | 排除理由 |
|---|---|
| 3D 翻牌动画（carden 风格） | `rotateY` 在低端安卓掉帧；且翻转过程中文字可读性下降，学生会误触 |
| 经营等级 / 勋章体系（skills-service） | 需要新增数据结构与后端字段，牵动 189 个后端测试；且与"商科严肃性"冲突 |
| 复盘页做成 Web OS 桌面（Aurora-OS） | 改动面覆盖整个复盘页与雷达图容器，收益与成本不匹配 |
| 进度条流动条纹动画 | `animation` 会被 reduced-motion 块整体禁用，实际效果在部分设备上看不到 |
| 数字滚动动画 | 滚动期间的中间值会让测试断言不稳定 |
| 教师端一起换成暖色 | 直接摧毁"教师端克制专业 / 学生端友好"的双语域设计 |

---

## 附录 A：设计令牌速查

| 变量 | 值 | 用途 |
|---|---|---|
| `--student-bg` | `#FFF8E7` | 学生端页面底色 |
| `--student-surface` | `#FFFFFF` | 卡片面 |
| `--student-radius-card` | `16px` | 卡片圆角 |
| `--student-radius-control` | `10px` | 输入框/按钮圆角 |
| `--student-shadow-card` | `0 4px 12px rgba(31,41,55,.08)` | 卡片默认阴影 |
| `--student-shadow-card-hover` | `0 8px 20px rgba(31,41,55,.12)` | 悬停阴影 |
| `--student-text` | `#1f2937` | 主文字（对比度 ≥ 12:1） |
| `--student-text-muted` | `#4b5563` | 次要文字（对比度 ≈ 7:1） |
| `--option-a-border/bg` | `#3b82f6` / `#eff6ff` | A 选项（蓝色，中性区分色） |
| `--option-b-border/bg` | `#8b5cf6` / `#f5f3ff` | B 选项（紫色，中性区分色） |
| `--option-c-border/bg` | `#06b6d4` / `#ecfeff` | C 选项（青色，中性区分色） |

> 对比度说明：原次要文字 `rgba(0,0,0,.45)` 在 `#FFF8E7` 上约 3.9:1，低于 WCAG AA 的 4.5:1；改为 `#4b5563` 后约 7:1，这是**有意为之的可读性提升**，不是"配色偏好"。
>
> 配色说明：策略卡 A/B/C 用蓝/紫/青而非绿/橙/红，是因为后端未下发 `risk_level`，用语义色（绿=保守/橙=稳健/红=激进）会误导学生以为颜色代表风险等级。中性区分色只做视觉区分，不带任何风险暗示。

---

## 附录 B：验收命令合集

```bash
cd "C:\Users\huang2006\Desktop\Work\upload2\case_sim-\frontend"
npm test
npx tsc -b
npm run build

cd "C:\Users\huang2006\Desktop\Work\upload2\case_sim-"
.venv\Scripts\python.exe -m pytest -q

# 变更审计（无 git）
cd "C:\Users\huang2006\Desktop\Work\upload2\case_sim-\frontend"
find src tests -newermt "2026-10-20 21:00" -type f
```

---

## 附录 C：一键启动提示词（第一次开对话时用）

```text
你是一个自主前端改造 Agent，负责 case_sim 学生端"暖色经营风"改造。

项目根：C:\Users\huang2006\Desktop\Work\upload2\case_sim-\
前端目录：C:\Users\huang2006\Desktop\Work\upload2\case_sim-\frontend

请先读这份清单并严格按阶段执行：
C:\Users\huang2006\Desktop\Work\upload2\case_sim-前端游戏化执行清单.md

执行前必须确认的三条：
1. 路径别名"配而未用"，所有 import 用相对路径。
2. 教师端零改动（阶段 7 除外）。
3. 前端测试 65/65 是硬指标，只许改断言不许删用例。

每次完成后报告：改动文件 + 行号 + npm test 结果 + tsc 结果 + 截图路径。
遇到需要改后端或改契约的地方，停下来问我，不要自己决定。
```

---

## 附录 D：并发压测与指标口径（新增）

### D.1 起停压测环境（隔离库，勿压生产库）

```bash
# 1) 起一个独立后端实例（8112，隔离库）
cd "C:\Users\huang2006\Desktop\Work\upload2\case_sim-"
set DATABASE_URL=sqlite:///./backend/data/loadtest.db
.venv\Scripts\python.exe -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8112 --workers 1

# 2) 造数据（复用现有种子，不改代码）
set PYTHONPATH=C:\Users\huang2006\Desktop\Work\upload2\case_sim-
.venv\Scripts\python.exe "C:\Users\huang2006\Desktop\Work\upload2\seed_probe_case.py" "sqlite:///C:/Users/huang2006/Desktop/Work/upload2/case_sim-/backend/data/loadtest.db"

# 3) 压测（脚本见 scripts/loadtest/loadtest.py）
.venv\Scripts\python.exe scripts\loadtest\loadtest.py --base http://127.0.0.1:8112 --users 150 --duration 300 --scenario mixed

# 4) 跑完删库，别留在 backend/data 里
del backend\data\loadtest.db backend\data\loadtest.db-wal backend\data\loadtest.db-shm
```

> 本机有 `http_proxy`，脚本内部必须用 `httpx.Client(trust_env=False)`，否则请求会被代理拦成 502（这条坑已在本地验证踩过）。

### D.2 指标定义（报告里只用这六个，不许自造）

| 指标 | 定义 | 采集方式 |
|---|---|---|
| **RPS** | 每秒完成的请求数（成功 + 失败） | 压测客户端统计 |
| **p95 / p99** | 非 AI 接口端到端时延分位 | 压测客户端统计（不看服务端日志） |
| **错误率** | 5xx + 连接错误 / 总请求 | 压测客户端统计 |
| **池超时** | `QueuePool limit ... connection timed out` 次数 | 后端日志 grep |
| **锁失败** | `database is locked` 次数 | 后端日志 grep |
| **队列深度** | `status='queued'` 的 ai_task 行数 | `GET /api/metrics` |

### D.3 四档并发的最小可判读组合（单进程版）

| 档位 | 目的 | 通过标准 |
|---|---|---|
| 10 | 对照（现状） | 与改造前一致，无回归 |
| 50 | 中间档 | 读 p95 ≤ 300ms、写 p95 ≤ 600ms、错误 0 |
| 100 | **Gate K1** | 20 QPS 稳态 / 50 QPS 峰值、p95 ≤ 600ms、探针 p95 ≤ 20ms、池超时 0 |
| 150 | **Gate K3** | 25 QPS 稳态 / 60 QPS 峰值、p95 ≤ 1s、p99 ≤ 2.5s、错误 < 0.5%、池超时 0、locked 0 |
| 200 | 极限观察（**不作放行条件**） | 记录劣化形态：p95、错误率、池/锁/内存哪一个先崩 |

---

## 附录 E：U/K 项 ↔ 阶段映射与 v2 路线图（新增）

### E.1 一张表看全（v2：谁做什么、是否阻塞）

| 段落 | 状态 | 内容 | 是否阻塞后续 |
|---|---|---|---|
| 阶段 0 | 已完成 | 基线冻结（`docs/ui-baseline/`） | — |
| 阶段 1 | 已完成 | 设计令牌（U2 会复用 `--student-*`） | — |
| **U1** | **执行** | 即时结算单 | 否 |
| **U2** | **执行** | 吸顶财务栏 | 否 |
| **U3** | 执行 | 选项影响预览（新接口 `/preview`） | 否 |
| **U4** | 执行 | 对比基准线（新接口 `/benchmark`） | 否 |
| **U5** | 执行 | 历史趋势迷你图 | 否 |
| **U6** | 执行 | 风险提示（`risk_level` 可选字段） | 否 |
| **U7** | 执行 | 经营日志 | 否 |
| **U8** | 执行 | 里程碑庆祝 | 否 |
| Gate U | **卡口** | 65/65 + 请求数不增长 + 375px 不溢出 | **是（不过不进 K 线）** |
| **K1** | 执行 | async→def + 线程池 60 + 池 20+20 | 是 |
| **K2** | 执行 | 三条索引 + 幂等迁移 | 是 |
| **K3** | 执行 | 轮询降频 + ETag/304 | 是 |
| **K4** | 执行 | 事务瘦身 + AI 任务 DB 写 `to_thread` | **是（100 并发的关键）** |
| Gate K1 | 卡口 | 100 并发 p95 ≤ 600ms + 探针 ≤ 20ms | **是（不过不进 K5）** |
| **K5** | 执行 | AI 并发 4→100 + AIMD + 公平名额 + token 预算 | 是 |
| Gate K2 | 卡口 | 200 份 ≤ 15 分钟 + 429 < 5% | 是 |
| **K6** | 执行 | SSE 连接治理 | 是 |
| **K7** | 执行 | `/api/metrics` + 告警阈值 | 是 |
| **K8** | 执行 | 容量验收 + 迁移门 | 是 |
| 阶段 11 | **卡口** | Gate K3（150 人长稳）+ Gate R（故障注入） | **是（不过不交付）** |
| 阶段 12（原 2–6、8） | 🕓 **最后执行** | 换皮（换色/圆角/阴影/emoji/自绘进度），排在 U/K 之后 | 否 |
| 阶段 12（原 7） | 🕓 最后执行 · 可选 | 教师 KPI（有余力再做） | 否 |
| 阶段 13（原 9） | 🕓 最后执行 | 全量回归（口径按 65/189 执行） | 否 |

### E.2 v2 路线图（按"投入 → 收益"排序）

1. **U1 + U2**：纯前端、零后端、当天可交付，学生立刻"看得懂、不用来回滑"。
2. **K1 async→def**：改 8 个函数签名 + 两处常量，几乎零风险，单进程上限直接抬一档。
3. **K3 轮询降频 + ETag**：4 个数字 + 1 个响应头，稳态 QPS 降一半。
4. **K2 索引**：三条 `CREATE INDEX`，越早建越省事。
5. **K5 AI 并发 100**：D5 的兑现，决定"复盘多久出"，必须带 429 自适应与公平名额。
6. **K6 SSE 治理**：不做就会出现"有人开着助教面板，别人提交不了"，排查极难。
7. **U3 + U4 + U6**：需要新接口/新字段，是"从看懂到会判断"的关键三件。
8. **K7 指标**：单进程没有 HA，指标就是唯一兜底。
9. **U5 / U7 / U8**：锦上添花，可与 K 线并行做。
10. **K8 迁移门**：只有触发条件命中才做 Postgres。

### E.3 交付时必须同时交出的四样东西

1. `concurrency-baseline.md`：改造前后四档并发对比（同一脚本、同一硬件）+ AI 吞吐两组（50 份 / 200 份）。
2. `/api/metrics` 的一次真实响应（含 p95、队列深度、池超时、locked、429 率、ai_in_flight）。
3. 故障注入记录（kill API 进程后的恢复时间与任务不重不丢 / 持有写锁 10s 的表现）。
4. 回滚预案：`db.py` 池参数、`AI_CONCURRENCY`、`anyio` 线程池三处（`--workers` 未动，无需回滚）。

### E.4 本次新增内容的边界声明

- 本附录与"并发扩容总纲（N）"、"主线 A U1–U8"、阶段 2–9 的【并发增量】块、阶段 10（K1–K8）、阶段 11、附录 D 均为 **2026-10-20 新增/改写**。
- 原文 **阶段 0、阶段 1 与附录 A–C 一字未改**；原阶段 2–8 与阶段 9 的正文**整体后移到文末（阶段 12 / 阶段 13）**，只把横幅文案从"暂停"改为"最后执行"，正文与验收逻辑一字未改。
- 新增内容不引入新依赖、不改任何接口既有字段与状态码、不触碰财务红线与路径别名约束。
- 若与原有内容冲突，**以"全局铁律"、"修订记录"与"N.5 新增铁律"为准**；任何性能优化不得以放宽既有断言为代价。

