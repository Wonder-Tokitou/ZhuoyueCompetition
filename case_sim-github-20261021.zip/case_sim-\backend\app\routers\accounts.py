"""Student personal space and teacher-managed real-name accounts."""
import secrets
from datetime import datetime, timedelta
from typing import Literal, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel, Field
from sqlalchemy import delete, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from backend.app import models
from backend.app import schemas
from backend.app.db import get_db
from backend.app.services.student_auth import bearer
from backend.app.services.student_auth import current_student
from backend.app.services.student_auth import hash_password
from backend.app.services.student_auth import token_hash
from backend.app.services.student_auth import verify_password
from backend.app.routers.teacher import is_valid_teacher_token
from backend.app.routers.teacher import _qr_code_url
from backend.app.domain.student_choices import choice_receipt

router = APIRouter(prefix="/api", tags=["学生账号与管理"])


class LoginInput(BaseModel):
    username: str = Field(min_length=1, max_length=64, pattern=r"^[A-Za-z0-9_.-]+$")
    password: str = Field(min_length=1, max_length=128)


class CreateInput(LoginInput):
    real_name: str = Field(min_length=1, max_length=64)
    password: str = Field(min_length=8, max_length=128)
    # 班级分组（选填）：教师建号时可指定；学生自行注册一般留空
    class_name: str = Field(default="", max_length=64)


class ManageInput(BaseModel):
    real_name: str | None = Field(default=None, min_length=1, max_length=64)
    status: Literal["active", "disabled"] | None = None
    password: str | None = Field(default=None, min_length=8, max_length=128)
    # 班级调整：空串 = 移出班级（未分班）
    class_name: str | None = Field(default=None, max_length=64)


class PasswordInput(BaseModel):
    current_password: str = Field(min_length=1, max_length=128)
    new_password: str = Field(min_length=8, max_length=128)


class ClassCreateInput(BaseModel):
    name: str = Field(min_length=1, max_length=64)


class ClassMemberInput(BaseModel):
    username: str = Field(min_length=1, max_length=64, pattern=r"^[A-Za-z0-9_.-]+$")


def view(row):
    return {"id": row.id, "username": row.username, "real_name": row.real_name,
            "status": row.status, "created_at": row.created_at, "class_name": row.class_name}


def require_teacher(token: str = Query(...), db: Session = Depends(get_db)):
    # 令牌以数据库为准：多 worker 下任一进程都能校验通过，不再出现「登录即被踢出」。
    if not is_valid_teacher_token(db, token):
        raise HTTPException(403, "教师登录已失效")


def _add_member(db: Session, group: models.ClassGroup, student: models.StudentAccount) -> bool:
    """把学生加入班级；已在班级里则幂等跳过。返回 True 表示新加入。"""
    existing = db.scalar(select(models.ClassMembership).where(
        models.ClassMembership.class_id == group.id, models.ClassMembership.student_id == student.id))
    if existing is not None:
        return False
    db.add(models.ClassMembership(class_id=group.id, student_id=student.id))
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        return False
    return True


@router.post("/student/register")
def register(payload: CreateInput, db: Session = Depends(get_db)):
    """Local teaching pilot: students fill in their own name; no teacher provisioning needed."""
    create_student(payload, db)
    return login(LoginInput(username=payload.username, password=payload.password), db)


@router.post("/student/login")
def login(payload: LoginInput, db: Session = Depends(get_db)):
    row = db.scalar(select(models.StudentAccount).where(models.StudentAccount.username == payload.username.lower()))
    now = datetime.now()
    if row and row.locked_until and row.locked_until > now:
        raise HTTPException(429, "登录失败次数过多，请十五分钟后重试")
    # Also perform a password derivation for unknown accounts.
    valid = verify_password(payload.password, row.password_hash if row else
                            "pbkdf2_sha256$600000$unknown-account$" + "0" * 64)
    if not row or not valid or row.status != "active":
        if row:
            row.failed_logins += 1
            if row.failed_logins >= 5:
                row.locked_until = now + timedelta(minutes=15)
                row.failed_logins = 0
            db.commit()
        raise HTTPException(401, "账号或密码错误，或账号已停用")
    row.failed_logins = 0
    row.locked_until = None
    token = secrets.token_urlsafe(32)
    db.execute(delete(models.StudentLogin).where(models.StudentLogin.expires_at <= now))
    db.add(models.StudentLogin(token_hash=token_hash(token), student_id=row.id, expires_at=now + timedelta(hours=12)))
    db.commit()
    return {"access_token": token, "student": view(row)}


@router.get("/student/me")
def me(student=Depends(current_student)):
    return view(student)


@router.post("/student/logout")
def logout(student=Depends(current_student), credentials=Depends(bearer), db: Session = Depends(get_db)):
    db.execute(delete(models.StudentLogin).where(models.StudentLogin.token_hash == token_hash(credentials.credentials)))
    db.commit()
    return {"ok": True}


@router.post("/student/password")
def change_password(payload: PasswordInput, student=Depends(current_student), db: Session = Depends(get_db)):
    if not verify_password(payload.current_password, student.password_hash):
        raise HTTPException(400, "当前密码错误")
    student.password_hash = hash_password(payload.new_password)
    db.execute(delete(models.StudentLogin).where(models.StudentLogin.student_id == student.id))
    db.commit()
    return {"ok": True}


@router.get("/student/cases")
def cases(student=Depends(current_student), db: Session = Depends(get_db),
          case_type: Optional[str] = Query(None, description="按案例类型筛选：战略决策类/市场营销类/财务管理类")):
    """学生端「校案例库」：各教师上传到校案例库的已发布案例。

    每个案例展示上传教师名称、案例类型与累计推演次数（该案例 session 数）。
    教师发布到个人案例库（personal）的案例不在此列表，学生只经教师分发的
    链接/二维码进入。可选 `case_type` 按类型筛选。
    """
    query = select(models.Case).where(
        models.Case.status == "published",
        models.Case.owner_type == "teacher",
        models.Case.library_scope == "school",
        models.Case.deleted_at.is_(None),
    )
    if case_type:
        try:
            schemas.CaseType(case_type)
        except ValueError:
            raise HTTPException(400, "案例类型不合法，可选：战略决策类、市场营销类、财务管理类")
        query = query.where(models.Case.case_type == case_type)
    rows = db.scalars(query.order_by(models.Case.published_at.desc(), models.Case.id.desc())).all()

    from sqlalchemy import func
    teacher_ids = {r.teacher_id for r in rows if r.teacher_id is not None}
    teachers = {t.id: t for t in db.scalars(
        select(models.TeacherAccount).where(models.TeacherAccount.id.in_(teacher_ids))).all()} if teacher_ids else {}
    counts = dict(db.execute(
        select(models.Session.case_id, func.count(models.Session.id))
        .where(models.Session.case_id.in_([r.id for r in rows]))
        .group_by(models.Session.case_id)
    ).all()) if rows else {}
    return [{
        "id": r.id, "title": r.title, "case_type": r.case_type,
        "student_token": r.student_token, "version": r.version or 1,
        "background": r.background, "play_locked": bool(r.play_locked),
        "teacher_id": r.teacher_id,
        "teacher_name": teachers[r.teacher_id].real_name if r.teacher_id in teachers else "平台管理员",
        "play_count": counts.get(r.id, 0),
    } for r in rows]


@router.get("/student/records")
def records(student=Depends(current_student), db: Session = Depends(get_db)):
    rows = db.scalars(select(models.Session).where(models.Session.student_id == student.id)
                      .order_by(models.Session.created_at.desc(), models.Session.id.desc())).all()
    # Listing is read-only. Never delete historical submissions as a side effect
    # of refreshing this page. Return all legacy rows so students can explicitly
    # delete duplicates rather than hiding them while the teacher still sees them.
    result = []
    for r in rows:
        review = next((v for v in r.reviews if v.attempt_no == r.attempt_no), None)
        result.append({"session_id": r.id, "case_id": r.case_id,
            "case_title": r.case_snapshot_json.get("title", r.case.title), "student_token": r.case.student_token,
            "case_version": r.case_version, "attempt_no": r.attempt_no, "created_at": r.created_at,
            "finished_at": r.finished_at, "turn_count": len(r.turns), "available": r.case.status == "published" and r.case.deleted_at is None,
            "turns": [{"node_id": t.node_id, "chosen_option": t.chosen_option, "input_text": t.input_text,
                       **choice_receipt(r, t.node_id, t.chosen_option),
                       "result": t.result_json} for t in r.turns],
            "review": {"dimensions": review.dimensions_json, "conclusion": review.conclusion} if review else None})
    return result


@router.get("/teacher/students", dependencies=[Depends(require_teacher)])
def students(db: Session = Depends(get_db)):
    rows = db.scalars(select(models.StudentAccount).order_by(models.StudentAccount.id.desc())).all()
    # 每个学生加入的班级名列表（扫码加入，可多个），供教师端名单分组展示
    by_student: dict[int, list[str]] = {}
    for m in db.scalars(select(models.ClassMembership)).all():
        name = m.class_group.name if m.class_group else ""
        if name:
            by_student.setdefault(m.student_id, []).append(name)
    return [{**view(row), "classes": by_student.get(row.id, [])} for row in rows]


@router.post("/teacher/students", dependencies=[Depends(require_teacher)])
def create_student(payload: CreateInput, db: Session = Depends(get_db)):
    if not payload.real_name.strip():
        raise HTTPException(400, "真实姓名不能为空")
    row = models.StudentAccount(username=payload.username.lower(), real_name=payload.real_name.strip(),
                                password_hash=hash_password(payload.password),
                                class_name=payload.class_name.strip())
    db.add(row)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "学生账号已存在")
    return view(row)


@router.patch("/teacher/students/{student_id}", dependencies=[Depends(require_teacher)])
def manage_student(student_id: int, payload: ManageInput, db: Session = Depends(get_db)):
    row = db.get(models.StudentAccount, student_id)
    if row is None:
        raise HTTPException(404, "学生账号不存在")
    if payload.real_name is not None:
        if not payload.real_name.strip():
            raise HTTPException(400, "真实姓名不能为空")
        row.real_name = payload.real_name.strip()
    if payload.status is not None:
        row.status = payload.status
    if payload.class_name is not None:
        row.class_name = payload.class_name.strip()
    if payload.password is not None:
        row.password_hash = hash_password(payload.password)
        row.failed_logins = 0
        row.locked_until = None
    if payload.password or payload.status == "disabled":
        db.execute(delete(models.StudentLogin).where(models.StudentLogin.student_id == row.id))
    db.commit()
    return view(row)


# ─────────────────────── 班级与扫码加入 ───────────────────────

@router.get("/teacher/classes", dependencies=[Depends(require_teacher)])
def teacher_classes(db: Session = Depends(get_db)):
    """教师侧班级列表：含成员数与加入码（二维码前端按需请求）。"""
    groups = db.scalars(select(models.ClassGroup).order_by(models.ClassGroup.id.desc())).all()
    return [{"id": g.id, "name": g.name, "join_code": g.join_code,
             "member_count": len(g.members), "created_at": g.created_at} for g in groups]


@router.post("/teacher/classes", dependencies=[Depends(require_teacher)])
def create_class(payload: ClassCreateInput, db: Session = Depends(get_db)):
    name = payload.name.strip()
    if not name:
        raise HTTPException(400, "班级名称不能为空")
    join_code = secrets.token_hex(8)
    while db.scalar(select(models.ClassGroup).where(models.ClassGroup.join_code == join_code)):
        join_code = secrets.token_hex(8)
    group = models.ClassGroup(name=name, join_code=join_code)
    db.add(group)
    db.commit()
    return {"id": group.id, "name": group.name, "join_code": group.join_code,
            "member_count": 0, "created_at": group.created_at}


@router.get("/teacher/classes/{class_id}/qrcode", dependencies=[Depends(require_teacher)])
def class_qrcode(class_id: int, request: Request, db: Session = Depends(get_db)):
    """班级加入二维码：内容 = {PUBLIC_BASE_URL}/student/join/{join_code}。"""
    group = db.get(models.ClassGroup, class_id)
    if group is None:
        raise HTTPException(404, "班级不存在")
    qr_url = _qr_code_url(request, "class-%s" % group.join_code, "/student/join/%s" % group.join_code)
    return {"qr_url": qr_url, "join_url": "/student/join/%s" % group.join_code}


@router.get("/teacher/classes/{class_id}/members", dependencies=[Depends(require_teacher)])
def class_members(class_id: int, db: Session = Depends(get_db)):
    group = db.get(models.ClassGroup, class_id)
    if group is None:
        raise HTTPException(404, "班级不存在")
    return [{"student_id": m.student_id, "username": m.student.username, "real_name": m.student.real_name,
             "status": m.student.status, "joined_at": m.joined_at}
            for m in sorted(group.members, key=lambda m: m.id)]


@router.post("/teacher/classes/{class_id}/members", dependencies=[Depends(require_teacher)])
def add_class_member(class_id: int, payload: ClassMemberInput, db: Session = Depends(get_db)):
    """教师手动添加成员（按账号名）——学生没扫码时的兜底入口。"""
    group = db.get(models.ClassGroup, class_id)
    if group is None:
        raise HTTPException(404, "班级不存在")
    row = db.scalar(select(models.StudentAccount).where(models.StudentAccount.username == payload.username.lower()))
    if row is None:
        raise HTTPException(404, "学生账号不存在")
    _add_member(db, group, row)
    return {"ok": True, "member_count": len(group.members)}


@router.delete("/teacher/classes/{class_id}/members/{student_id}", dependencies=[Depends(require_teacher)])
def remove_class_member(class_id: int, student_id: int, db: Session = Depends(get_db)):
    group = db.get(models.ClassGroup, class_id)
    if group is None:
        raise HTTPException(404, "班级不存在")
    row = db.scalar(select(models.ClassMembership).where(
        models.ClassMembership.class_id == class_id, models.ClassMembership.student_id == student_id))
    if row is None:
        raise HTTPException(404, "该学生不在此班级")
    db.delete(row)
    db.commit()
    return {"ok": True, "member_count": len(group.members)}


@router.post("/student/join/{join_code}")
def join_class(join_code: str, db: Session = Depends(get_db), student=Depends(current_student)):
    """学生扫码加入班级；重复加入幂等（不报错，只标记 joined=False）。"""
    group = db.scalar(select(models.ClassGroup).where(models.ClassGroup.join_code == join_code))
    if group is None:
        raise HTTPException(404, "邀请码无效或班级不存在")
    return {"ok": True, "joined": _add_member(db, group, student), "class": {"id": group.id, "name": group.name}}


@router.get("/student/my-classes")
def my_classes(db: Session = Depends(get_db), student=Depends(current_student)):
    rows = db.scalars(select(models.ClassMembership).where(models.ClassMembership.student_id == student.id)).all()
    return [{"id": m.class_id, "name": m.class_group.name if m.class_group else "", "joined_at": m.joined_at}
            for m in rows]
