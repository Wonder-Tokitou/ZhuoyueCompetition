/**
 * 选项面板（阶段 4 实现）。
 * 三项竖排，A/B/C 字母 + 原始 label（不得改写）；点击仅选中（高亮 #db2777），
 * 未选中时「就这么定」按钮 disabled；不加风险色（米色边框）；
 * 附「查看本轮经营数据」折叠区，展示当前 current_metrics。
 */
import { useState } from 'react'
import type { Metrics, OptionBrief } from '../../../api/types'

export interface ChoiceButtonsProps {
  options: OptionBrief[]
  disabled: boolean
  onConfirm: (key: string) => void
  metrics: Metrics | null
}

export default function ChoiceButtons({ options, disabled, onConfirm, metrics }: ChoiceButtonsProps) {
  const [selectedKey, setSelectedKey] = useState<string | null>(null)

  return (
    <div className="galgame-choices">
      {options.map((o, index) => {
        const isSelected = selectedKey === o.key
        return (
          <button
            key={`${o.key}`}
            type="button"
            className={`galgame-choice${isSelected ? ' is-selected' : ''}`}
            disabled={disabled}
            aria-pressed={isSelected}
            onClick={() => setSelectedKey(o.key)}
          >
            <span className="galgame-choice-letter" aria-hidden="true">{String.fromCharCode(65 + index)}</span>
            <span className="galgame-choice-label">{o.label}</span>
          </button>
        )
      })}
      <details className="galgame-metrics-fold">
        <summary>查看本轮经营数据</summary>
        <dl className="galgame-metrics-grid">
          <div><dt>营收</dt><dd>{metrics?.revenue ?? '—'} 万元</dd></div>
          <div><dt>毛利率</dt><dd>{metrics?.gross_margin ?? '—'}</dd></div>
          <div><dt>市场份额</dt><dd>{metrics?.market_share ?? '—'}</dd></div>
          <div><dt>现金流</dt><dd>{metrics?.cash_flow ?? '—'}</dd></div>
        </dl>
      </details>
      <button
        type="button"
        className="galgame-confirm"
        disabled={!selectedKey || disabled}
        onClick={() => { if (selectedKey) onConfirm(selectedKey) }}
      >
        就这么定
      </button>
    </div>
  )
}
