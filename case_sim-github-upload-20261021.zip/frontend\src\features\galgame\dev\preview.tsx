/**
 * galgame 支线零接缝预览入口（仅开发期）。
 * 走 MemoryRouter，路由树与正式路由完全一致；不修改 App.tsx / vite.config.ts。
 * 访问：http://localhost:5174/galgame.html?token=<真实 studentToken>
 */
import { createRoot } from 'react-dom/client'
import { MemoryRouter, Route, Routes } from 'react-router-dom'
import { StudentTokenProvider } from '../../../context/StudentTokenContext'
import StudentLayout from '../../../layouts/StudentLayout'
import GalgamePlayPage from '../GalgamePlayPage'
import StudentReviewPage from '../../../pages/student/StudentReviewPage'

const token = new URLSearchParams(window.location.search).get('token') ?? ''

createRoot(document.getElementById('root')!).render(
  <MemoryRouter initialEntries={['/play-galgame/' + token]}>
    <Routes>
      <Route
        path="/play-galgame/:studentToken"
        element={
          <StudentTokenProvider>
            <StudentLayout />
          </StudentTokenProvider>
        }
      >
        <Route index element={<GalgamePlayPage />} />
      </Route>
      {/* 结局页「查看 AI 复盘」跳转目标（主线既有路由，仅用于预览联调） */}
      <Route
        path="/student/:studentToken/review"
        element={
          <StudentTokenProvider>
            <StudentLayout />
          </StudentTokenProvider>
        }
      >
        <Route index element={<StudentReviewPage />} />
      </Route>
    </Routes>
  </MemoryRouter>,
)
