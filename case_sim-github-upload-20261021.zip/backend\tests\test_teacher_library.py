"""多教师账号 + 双案例库（个人库 / 校案例库）契约测试。

覆盖：
- 教师账号：注册（管理口令）、登录（用户名+密码 / 历史全局口令）、me、同事账号管理；
- 案例归属：创建案例绑定教师，教师间互不可见，历史无归属案例对所有人可见；
- 发布范围：publish scope=personal 不进学生端案例库，scope=school 进校案例库；
- 学生端校案例库：展示上传教师名称、案例类型、累计推演次数，支持按类型筛选；
- 案例库范围调整（PATCH library_scope）不递增版本号。
"""
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker

from backend.app import models
from backend.app.db import Base
from backend.app.db import get_db
from backend.app.main import app
from backend.app.routers import teacher
from backend.app.seed import seed_demo_case


@pytest.fixture()
def env(tmp_path, monkeypatch):
    engine = create_engine(f"sqlite:///{tmp_path / 'lib.db'}", connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine)
    factory = sessionmaker(bind=engine, autoflush=False, autocommit=False)

    def override_db():
        with factory() as db:
            yield db

    app.dependency_overrides[get_db] = override_db
    monkeypatch.setenv("TEACHER_PASSWORD", "admin-secret")
    monkeypatch.setattr(teacher, "schedule_task", lambda _: None)  # 不让 AI 后台任务真实运行
    monkeypatch.setattr(teacher, "QRCODE_DIR", tmp_path / "qrcode")
    client = TestClient(app)
    from backend.tests.account_helpers import login_student
    login_student(client, factory)
    yield client, factory
    app.dependency_overrides.clear()
    client.close()
    engine.dispose()


def _register(client, username="teacher_a", real_name="张老师", password="teacher-pass", admin="admin-secret"):
    return client.post("/api/teacher/register", json={
        "username": username, "real_name": real_name, "password": password, "admin_password": admin,
    })


def _login(client, username="teacher_a", password="teacher-pass"):
    return client.post("/api/teacher/login", json={"username": username, "password": password})


def _token(client, username="teacher_a", password="teacher-pass"):
    response = _login(client, username, password)
    assert response.status_code == 200, response.text
    return response.json()["teacher_token"]


def _make_publishable(factory, scope="school", teacher_id=None, status="ready"):
    """建一个可直接发布的案例（复用标杆案例的节点/选项结构）。"""
    with factory() as db:
        case = seed_demo_case(db)
        case.status = status
        case.published_at = None
        case.library_scope = scope
        case.teacher_id = teacher_id
        db.commit()
        return case.id, case.student_token


def _student_play(client, student_token):
    started = client.post(f"/api/play/{student_token}/sessions", json={"student_name": "student"})
    assert started.status_code == 200, started.text
    return started.json()


# ─────────────────────────── 教师账号体系 ───────────────────────────

def test_teacher_account_register_login_me_and_lockout(env, monkeypatch):
    client, _ = env
    # 管理口令错误 -> 403；重复注册 -> 409
    assert _register(client, admin="wrong").status_code == 403
    assert _register(client).status_code == 200
    assert _register(client).status_code == 409

    # 用户名 + 密码登录，返回令牌与账号信息
    login = _login(client)
    assert login.status_code == 200, login.text
    body = login.json()
    assert body["teacher"]["username"] == "teacher_a" and body["teacher"]["real_name"] == "张老师"
    assert "password_hash" not in body["teacher"]

    # /teacher/me 返回当前账号；密码错误 401；连续 5 次错误后锁定 429
    assert client.get("/api/teacher/me", params={"token": body["teacher_token"]}).json()["teacher"]["username"] == "teacher_a"
    assert _login(client, password="wrong-pass").status_code == 401
    for _ in range(4):
        assert _login(client, password="bad").status_code == 401
    assert _login(client, password="teacher-pass").status_code == 429

    # 历史全局口令登录仍可用（兼容），其令牌 teacher 为 None
    legacy = client.post("/api/teacher/login", json={"password": "admin-secret"})
    assert legacy.status_code == 200, legacy.text
    assert client.get("/api/teacher/me", params={"token": legacy.json()["teacher_token"]}).json()["teacher"] is None


def test_teacher_colleague_account_management(env):
    client, _ = env
    _register(client)
    token = _token(client)
    params = {"token": token}
    created = client.post("/api/teacher/accounts", params=params,
                          json={"username": "teacher_b", "real_name": "李老师", "password": "colleague-pass"})
    assert created.status_code == 200, created.text
    listed = client.get("/api/teacher/accounts", params=params).json()
    assert {row["username"] for row in listed} == {"teacher_a", "teacher_b"}
    # 同事可独立登录，且令牌带各自身份
    b_token = _token(client, "teacher_b", "colleague-pass")
    assert client.get("/api/teacher/me", params={"token": b_token}).json()["teacher"]["real_name"] == "李老师"
    # 改名 / 停用 / 重置密码
    assert client.patch(f"/api/teacher/accounts/{created.json()['id']}", params=params,
                        json={"real_name": "李教授"}).status_code == 200
    assert _login(client, "teacher_b", "colleague-pass").json()["teacher"]["real_name"] == "李教授"
    assert client.patch(f"/api/teacher/accounts/{created.json()['id']}", params=params,
                        json={"status": "disabled"}).status_code == 200
    assert _login(client, "teacher_b", "colleague-pass").status_code == 401
    assert client.patch(f"/api/teacher/accounts/{created.json()['id']}", params=params,
                        json={"status": "active", "password": "new-pass-123"}).status_code == 200
    assert _login(client, "teacher_b", "new-pass-123").status_code == 200


# ─────────────────────────── 案例归属隔离 ───────────────────────────

def test_case_ownership_isolation_between_teachers(env):
    client, factory = env
    _register(client)
    _register(client, "teacher_b", "李老师", "colleague-pass")
    token_a = _token(client)
    token_b = _token(client, "teacher_b", "colleague-pass")

    # 教师 A 的案例：B 不可见、不可编辑；B 的列表里没有它
    case_id, student_token = _make_publishable(factory, scope="school", teacher_id=1)
    assert client.get(f"/api/cases/{case_id}", params={"token": token_b}).status_code == 404
    assert {row["id"] for row in client.get("/api/cases", params={"token": token_b}).json()} != {case_id}
    assert {row["id"] for row in client.get("/api/cases", params={"token": token_a}).json()} == {case_id}

    # 历史无归属案例（teacher_id 为 NULL）：任何有效令牌都能看到与编辑
    legacy_id, _ = _make_publishable(factory, scope="school", teacher_id=None)
    assert {row["id"] for row in client.get("/api/cases", params={"token": token_b}).json()} == {legacy_id}
    assert client.get(f"/api/cases/{legacy_id}", params={"token": token_b}).status_code == 200


def test_create_case_with_token_binds_teacher(env):
    client, _ = env
    _register(client)
    token = _token(client)
    created = client.post("/api/cases", data={
        "title": "咖啡连锁扩张", "case_type": "战略决策类", "text": "连锁品牌市场扩张", "token": token,
    })
    assert created.status_code == 200, created.text
    case_id = created.json()["case_id"]
    detail = client.get(f"/api/cases/{case_id}", params={"token": token}).json()["case"]
    assert detail["teacher_id"] == 1


# ─────────────────────────── 双案例库与发布范围 ───────────────────────────

def test_publish_personal_case_hidden_from_student_library(env):
    client, factory = env
    _register(client)
    token = _token(client)
    case_id, _ = _make_publishable(factory, scope="school", teacher_id=1, status="ready")

    # 发布到个人案例库：学生端校案例库不可见
    response = client.post(f"/api/cases/{case_id}/publish", params={"token": token, "scope": "personal"})
    assert response.status_code == 200, response.text
    with factory() as db:
        assert db.get(models.Case, case_id).library_scope == "personal"
    assert client.get("/api/student/cases").json() == []

    # 从个人库移入校库（PATCH library_scope）：学生端可见
    before_version = client.get(f"/api/cases/{case_id}", params={"token": token}).json()["case"]["version"]
    moved = client.patch(f"/api/cases/{case_id}", params={"token": token}, json={"library_scope": "school"})
    assert moved.status_code == 200, moved.text
    listed = client.get("/api/student/cases").json()
    assert len(listed) == 1 and listed[0]["id"] == case_id
    # 案例库范围调整不是内容修改：版本号不变
    after_version = client.get(f"/api/cases/{case_id}", params={"token": token}).json()["case"]["version"]
    assert after_version == before_version


def test_school_library_shows_teacher_name_type_and_play_count(env):
    client, factory = env
    _register(client, "teacher_a", "张老师")
    token = _token(client, "teacher_a")
    case_id, student_token = _make_publishable(factory, scope="school", teacher_id=1, status="ready")

    assert client.post(f"/api/cases/{case_id}/publish", params={"token": token, "scope": "school"}).status_code == 200

    # 学生推演一次后，累计推演次数 = 1
    _student_play(client, student_token)

    listed = client.get("/api/student/cases").json()
    assert len(listed) == 1
    row = listed[0]
    assert row["teacher_name"] == "张老师" and row["case_type"] == "市场营销类"
    assert row["play_count"] == 1 and "teacher_token" not in row and "source_text" not in row

    # 按类型筛选
    matched = client.get("/api/student/cases", params={"case_type": "市场营销类"}).json()
    assert len(matched) == 1 and matched[0]["id"] == case_id
    assert client.get("/api/student/cases", params={"case_type": "财务管理类"}).json() == []
    assert client.get("/api/student/cases", params={"case_type": "不存在的类型"}).status_code == 400


def test_publish_default_scope_keeps_legacy_visibility(env):
    """历史调用（不带 scope）仍默认发布到校案例库，老行为不变。"""
    client, factory = env
    _register(client)
    token = _token(client)
    case_id, _ = _make_publishable(factory, scope="school", teacher_id=1, status="ready")
    assert client.post(f"/api/cases/{case_id}/publish", params={"token": token}).status_code == 200
    assert len(client.get("/api/student/cases").json()) == 1
