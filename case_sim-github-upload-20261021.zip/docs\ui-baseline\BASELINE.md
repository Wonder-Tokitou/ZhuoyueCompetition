# 改造前基线（阶段 0 汇总 · T0.6）

> **冻结时间**：2026-10-20 21:45–21:57
> **冻结人**：AI（只读执行，未改 `src/**`、未装依赖、未改 `package.json`、未改后端与契约）
> **产出目录**：`case_sim-/docs/ui-baseline/`
> **回滚方式**：删除整个 `docs/ui-baseline/` 目录即可，无任何副作用（`src/` 未被触碰，已用 mtime 与哈希双重证明）

---

## 1. 环境

| 项 | 实测值 | 结论 |
|---|---|---|
| OS | Windows（win32），Git Bash 执行 | — |
| Node.js | `v22.22.2`（managed） | ✅ 满足 ≥ 20.19（vite 8 / Rolldown 要求） |
| npm | `10.9.7` | ✅ |
| 项目根 | `C:\Users\huang2006\Desktop\Work\upload2\case_sim-` | ✅ |
| 前端目录 | `case_sim-\frontend` | ✅ |
| `node_modules` | 113 个顶层包，非空 | ✅ 无需 `npm install` |
| 关键依赖 | `antd 5.29.3` / `react 18.3.1` / `vite 8.3.0` / `echarts 6.1.0` | ✅ 与清单一致（ECharts 已存在，阶段 7 仍按清单用内联 SVG） |
| git | 无 `.git`（`git status` 报 not a repository） | ✅ 与清单一致，变更审计用 mtime + SHA256 |
| 后端服务 | 阶段 0 不依赖；截图时临时启动 `127.0.0.1:8110`（`--workers 1`），截图后已停止 | ✅ `/api/health` 返回 `{"status":"ok"}` |
| 代理干扰 | 本机存在 `http_proxy`，`curl 127.0.0.1:8110` 会 502 | 已绕开：Python `ProxyHandler({})` + Chrome `--no-proxy-server` |

---

## 2. 基线数字

### 2.1 前端测试

| 指标 | 值 |
|---|---|
| 用例总数 | **65** |
| 通过 | **65** |
| 失败 | **0** |
| skip / todo / cancelled | 0 / 0 / 0 |
| 命令 | `cd frontend && npm test`（`node --test tests/*.test.cjs`） |
| 原始输出 | `baseline-tests.txt`（13.9 KB，65 条 `ok N - 用例名`） |

65 个用例按文件分布：`student-play 12`、`teacher-background 9`、`impact-rules 5`、`student-review 5`、`baseline-finance 4`、`student-tutor 4`、`student-library 3`、`task-workspace 3`、`teacher-token-guard 3`、`transport-error 3`、`financials 2`、`merged-calibration 2`、`presentation 2`、`progressive-display 2`、`reference-path 2`、`review-layout 2`、`architecture 1`、`idempotency 1`。

> ⚠️ **与执行清单不符**：清单全文写「60 个前端用例」（阶段 9 也要求 `60/60`）。实测是 **65**。差异来自 2026-10-20 的并发修复（新增 `transport-error.test.cjs` 等 5 条），不是环境问题。本基线以 **65/65** 为准，是否同步修订清单见第 6 节待确认项 Q1。

### 2.2 类型检查

| 指标 | 值 |
|---|---|
| 命令 | `npx tsc -b` |
| 退出码 | 0 |
| 输出 | **空文件**（0 字节，0 错误） |
| 原始输出 | `baseline-tsc.txt` |

### 2.3 生产构建

| 指标 | 值 |
|---|---|
| 命令 | `npm run build`（= `tsc -b && vite build`） |
| 结果 | ✅ `✓ built in 18.99s` |
| 模块数 | 3783 modules transformed |
| `dist` 总体积 | **2,006,996 字节（2.0 MB）** |
| 主 chunk | `dist/assets/index-BFgp-99f.js` = **665.01 kB**（665,013 B，gzip 223.63 kB） |
| 其他 chunk | `antd-vendor 1,052.33 kB`、`antd-icons 118.32 kB`、`react-vendor 95.20 kB`、`axios 49.95 kB`、`rolldown-runtime 0.71 kB` |
| CSS | `index-BP6pNjIC.css 11.86 kB`、`antd-vendor-Tu04tXLf.css 3.06 kB` |
| 原始输出 | `baseline-build.txt` |

> 清单预期「`dist ≈2.0MB`、`index ≈665KB`、允许 663–666 kB」——**三项全部吻合**。

### 2.4 后端测试（清单未列入阶段 0，此处仅记录基准，供阶段 9 用）

| 指标 | 值 |
|---|---|
| 命令 | `cd case_sim- && .venv\Scripts\python.exe -m pytest -q`（**必须从项目根跑**） |
| 收集/通过 | **189 / 189**，0 失败 |
| 计数方式 | `-q` 的汇总行被 safe-delete 警告截断，改用进度点计数：72 + 72 + 45 = 189 |
| 耗时 | 47 s |

> ⚠️ **与执行清单不符**：清单阶段 9 写「应为 184 passed」。实测 **189**（同样是并发修复带来的 +5）。见待确认项 Q1。

### 2.5 结构与样式计数

| 指标 | 值 |
|---|---|
| `src/pages/student/**` + `src/layouts/**` 的 className 去重数 | **34**（要求 ≥ 15） |
| `src/index.css` 的 `:root` 自定义属性 | **2**（`--color-primary-teacher` / `--color-primary-student`） |
| 375px 横向溢出 | `scrollWidth 375` = `clientWidth 375`（无溢出） |
| 文案断言条数 | **38**（另 8 条类名/结构契约）→ 归并 F1–F25 |

---

## 3. 冻结表（F1–F25）

> 完整证据（文件 + 行号 + 原文 + 组件 + 风险）见 `text-assertions.md`。这里只列「不许改」的字符串，供阶段 2–8 快速对照。

| 编号 | 冻结内容 | 出处 |
|---|---|---|
| F1 | `开始推演` | StudentPlayPage 开始按钮 |
| F2 | `确认提交本回合` | 提交区按钮 |
| F3 | `继续下一回合` | 已提交后的继续按钮 |
| F4 | `核对已保存进度` | 网络不确定态核对按钮 |
| F5 | `我的记录` | 409 提示里的记录入口 |
| F6 | `你提交的策略` | 结果 Alert 前缀 |
| F7 | `已有本案例推演记录，请从「我的记录」继续` | `SUBMISSION_EXISTS`（含 `「」`） |
| F8 | `另一页面提交` | 冲突 Alert |
| F9 | `案例已下架` | 后端 message 原样透传 |
| F10 | `净利润 -12.35 万元` 这种拼接格式（label 内含尾随空格 + 2 位小数 + ` 万元`） | MetricsBar 净利润卡 |
| F11 | `本期现金净流量 0.00 万元` | MetricsBar 现金流 `metric-note` |
| F12 | `现金流改善。` / `利润改善。` | AI 复盘文本清洗 |
| F13 | `AI 正在生成复盘分析`（或 `正在生成复盘，请稍候。`） | 复盘 loading |
| F14 | `综合结论`（且必须在 `我的方案：</strong>` 之前） | 复盘结论区顺序 |
| F15 | `请求参数不符合要求，请检查输入内容` | 422 兜底文案 |
| F16 | `请求失败（HTTP 500）` | 状态码兜底文案 |
| F17 | `无法连接后端服务，请确认本地后端端口已启动` | 网络错误文案 |
| F18 | `-2.00 万元` / `0.00 万元` / `+2.00 个百分点` / `—` | `metricChange` 四种格式 |
| F19 | `教师案例` | 学生案例库 Card 标题 |
| F20 | `V2: 节点不完整` | 教师端 AI 失败 Alert |
| F21 | `AI草稿已填入`（中间无空格）/ `未覆盖` | 教师端规则草稿提示 |
| F22 | `财务基准与案例信息` | 教师端脏标记 |
| **F23** | 策略卡 `Button` 的 `className` 必须**严格等于** `strategy-option`（`===` 比较，禁止追加 class） | student-play 6 个用例的取元素入口 |
| **F24** | 策略卡 `Button` 的 `aria-pressed` 语义必须保留 | 6 处断言 |
| **F25** | 教师端选项表列数必须 6，且不含 `financial_assumptions` 列 | merged-calibration |

**F23 是阶段 3 的头号风险**：`tests/student-play.test.cjs:70` 用 `b.className === 'strategy-option'` 精确定位策略按钮；只要给按钮追加任何 class（如 `strategy-option option-a`），`options(page)` 立刻变空数组，连带 6 个用例炸掉。**按序号配色只能落在 `.strategy-option-card` 的内联 style / CSS 变量上，不能打在按钮 class 上。**

---

## 4. 已知既有问题（均**非本次改造引入**，只记录不修）

| 编号 | 问题 | 证据 | 影响本次改造？ |
|---|---|---|---|
| K1 | **版本筛选器失效（D-02）**：`TeacherRecordsPage` 版本集合恒为 `['unknown']`，后端 `StudentRecord` 只返 8 个字段、前端声明 16 个 | `task-workspace.test.cjs` 用 mock 数据测 `filterRecords`，掩盖了接口层缺字段 | 否（教师端零改动），但阶段 9 回归会看到它 |
| K2 | **`DecideResult.financial_state` 前端未声明（D-01）**：靠提交后重新 `restoreStudent` 侥幸正确 | `api/types.ts` 无该字段 | 否（阶段 3 只改渲染层，不动提交链） |
| K3 | **递进模拟 DTO 不在 `schemas.py` 而在 `domain/progressive.py`（D-03）**，且是全仓唯一 `extra="forbid"` 契约 | — | 否 |
| K4 | **`#root` 之外无重置**：`html` 背景 `#f0f2f5`，`body.student-body` 用 `max-width:1280px + margin:auto` 居中，桌面端两侧露出灰底 | 实测截图 375px 看不出来 | ⚠️ 相关：阶段 2 改 `body.student-body` 背景为 `#FFF8E7` 后，桌面端两侧仍是 `#f0f2f5` 灰底，视觉上会出现「奶油色卡片浮在灰底上」，属预期还是缺陷需确认（Q3） |
| K5 | **`.decision-submit` 的 `padding-right: 76px`（L147）被 L175 的 `padding: 12px 0 …` 简写重置** | 375px 实测提交按钮占满整行，没有 76px 让位 | ⚠️ 阶段 6/8 若要让 FAB 不压提交按钮，改 L147 无效，必须改 L175 |
| K6 | **`prefers-reduced-motion` 块只压 `duration`，不重置 `transform`**（L206–208） | 阶段 8 提示词自己也补了 `transform: none !important`，说明已知 | ⚠️ 阶段 8 必须补，否则 hover 位移在降级模式下仍会「瞬移」而非消失 |
| K7 | **无 flaky 用例**：本次 65 个用例单次全绿，无重试 | `baseline-tests.txt` | 否 |
| K8 | **tsc 0 错误**：不存在「既有类型错误」 | 空文件 | 否 |

### 4.1 清单与代码的三处行号/事实漂移（不改代码，只备案）

| 清单原文 | 实际 | 处置 |
|---|---|---|
| 阶段 3：「meta 取值逻辑当前约在 225-229 行」 | 实际在 `StudentPlayPage.tsx:240-243`（文件 277 行） | 按语义定位，别按行号改 |
| 阶段 5：「现有文本『第 2 / 3 轮 · 已提交 1 轮』必须逐字保留，测试断言它」 | 文案在 `StudentPlayPage.tsx:214`，是模板拼接；`finished` 时走另一分支「三轮推演已完成」；**全仓无任何断言引用它** | 保留属「建议」，不是测试强制 |
| 阶段 6：「不许改 FAB 位置（right:16 bottom:80）」 | `.ant-float-btn` 只声明了 `position: fixed; z-index: 1000`（L146），right/bottom 是 antd 默认值；真正写死坐标的是面板 `right:16; bottom:152px`（L121–134） | 理解为「不许给 FAB 加定位覆盖」 |

---

## 5. 快照哈希

### 5.1 `src/` 内容哈希（阶段 9 对比用）

```
FILES=56
SRC_SHA256=4d0adb97893f5ffc30bfe28404ee41e72bfa7b996e33cebd364e90583f5ea48e
```

**算法（阶段 9 必须完全一致，否则哈希不可比）**：

1. 取 `frontend/src/` 下所有文件（递归，56 个）；
2. 按相对 `frontend/` 的 POSIX 路径字典序升序排序；
3. 逐个文件依次喂入：相对路径（UTF-8）+ `\n` + 文件原始字节 + `\n`；
4. 全量 SHA256，小写十六进制。

复算命令：`python docs/ui-baseline/tools/_snapshot_hash.py`（加 `--list` 可输出逐文件哈希）。

> **哈希演进**：阶段 1 改过 `src/index.css` 后，快照哈希变为 `e0b05ebd269373d575178212b69cb734dfe5f96599a1c403b793244cfd78f2cf`（仍 56 文件，唯一变更是 index.css）。本文的 `4d0adb97…` 是**改造前**基线，阶段 9 做回归对比时必须以它为准；两次快照的对照记录在 `tools/_src-hash.txt`。

### 5.2 红线文件哈希（`baselineFinance.ts` / `financials.js`）

```
7f3b094edd33148fc10e7711992d6556e260cae5d8449aaa647ed160aa39228a  src/pages/teacher/components/baselineFinance.ts
40e4b91ad430bced01408f0aa4a931afccdf134813fa33f50de4372a0d3cc597  src/domain/financials.js
```

两者 mtime 均为 `2026-10-20 11:04:59`（早于本次改造开始时间 21:43），**未被触碰**。

### 5.3 `src/` 未被改动的证明

```
find src -newermt "2026-10-20 21:43" -type f   → 无输出
```

---

## 6. 阶段 0 完成度（DoD 六条）

| # | 判据 | 状态 | 证据 |
|---|---|---|---|
| 1 | `baseline-tests.txt` 含 `# pass 60` 且 `# fail 0` | ✅（数字为 **65**） | 65 pass / 0 fail，见 §2.1 |
| 2 | `baseline-tsc.txt` 为空 | ✅ | 0 字节 |
| 3 | `baseline-build.txt` 含 `✓ built in` | ✅ | `✓ built in 18.99s`，index 665.01 kB |
| 4 | `text-assertions.md` ≥ 5 条，含文件 + 行号 + 原文 | ✅ 远超 | 38 条文案 + 8 条结构，F1–F25 |
| 5 | `style-inventory.md` 含六段 CSS + className 清单 + 375px 截图 | ✅（策略卡以代码取证） | 六段齐全带行号；className 34 个；`baseline-375.png` |
| 6 | `BASELINE.md` 含 5 小节与冻结表 `F1`–`Fn` | ✅ | 本文 |

**结论：阶段 0 六条判据全部达成，可以进入阶段 1。** 两处与清单字面不符（65 vs 60、189 vs 184）属已查明的数字漂移，不影响「改之前是好的」这一核心结论。

---

## 7. 决策确认结果（2026-10-20 21:58 由用户确认）

| 编号 | 事项 | 结果 |
|---|---|---|
| **Q0** | D1 / D2 / D3 三个决策点 | ✅ **全部按预填推荐值执行**：D1 仅学生端换肤；D2 按 A/B/C 序号固定蓝/紫/青（无风险语义）；D3 教师端 KPI 升级要做（只改 `TeacherStudentsPage.tsx`） |
| **Q1** | 测试基数 60/184 → 65/189 | ✅ 已按实测修正执行清单全文（见清单顶部「修订记录」），阶段 9 判据改为 65/189 |
| **Q2** | 策略卡 375px 截图缺口 | ✅ **选①接受现状**：策略卡用代码取证（2px 实线灰边 `#d1d5db` + 12px 圆角），阶段 9 不对比策略卡区域；阶段 3 用「点 A/B/C 看三色」直接验证 |
| **Q3** | 桌面端 1280px 以外露出 `html #f0f2f5` 灰底 | ✅ **阶段 2 一起改暖色**（`html` 在 `body.student-body` 下同色，纯 CSS）——属清单外增补，只做这一条 |
| **Q4** | 辅助脚本是否移到 `tools/` | ✅ 已移入 `docs/ui-baseline/tools/`，根目录严格保留 7 个产物 |

---

## 8. 产物清单

### 8.1 清单要求的 7 个产物（根目录，已被 DoD 逐条核验）

| 文件 | 大小 | 说明 |
|---|---|---|
| `BASELINE.md` | 本文 | 汇总 + 冻结表 + 已知问题 + 快照哈希 |
| `baseline-tests.txt` | 13,935 B | `npm test` 完整输出，65 条用例名 |
| `baseline-tsc.txt` | 0 B | tsc 无错误（空文件即证据） |
| `baseline-build.txt` | 1,319 B | build 完整输出 |
| `text-assertions.md` | 12,494 B | 38 条文案断言 + 8 条结构契约 + F1–F25 |
| `style-inventory.md` | 15,069 B | 六段 CSS 原文 + 34 个 className + `:root` 变量 |
| `baseline-375.png` | 240,309 B | 375px 整页截图（真实数据，2 倍屏） |

### 8.2 `tools/`（辅助脚本与附加证据，非清单要求）

| 文件 | 用途 |
|---|---|
| `tools/baseline-375-presession.png` | 未开始会话态（4 张指标卡 + 「开始推演」），补充对比 |
| `tools/baseline-375.probe.json` | 截图的 computed style 取证（圆角/底色/边框/阴影 + 溢出检测） |
| `tools/_shot.cjs` | 375px 截图脚本（Chrome CDP，Node 内置 WebSocket，不需 playwright） |
| `tools/_scan-classnames.cjs` | className 复算脚本（输出 `TOTAL=34`） |
| `tools/_snapshot_hash.py` | `src/` 快照哈希复算脚本 |
| `tools/_temp_login.py` | 截图用的临时登录凭据签发/回收脚本（**已回收，当前库中无残留**） |
| `tools/_src-hash.txt` | 哈希演进留档（阶段 0 基线 `4d0adb97…` / 阶段 1 后 `e0b05ebd…`） |

> 脚本相对路径已随迁移修正（`__dirname` 层级 +1），迁移后复跑结果与迁移前一致：className `TOTAL=34`、哈希可复算、令牌脚本可只读查询。

### 8.3 数据未被污染的证明

截图过程只用「插入临时 `student_login` 行 → 截图 → 删除该行」的方式拿登录态，**没有新建学生账号、没有新建推演会话**。截图前后计数一致：

```
case=1  session=3  turn=9  student_account=3  student_login=4
```
