"""数据库连接层：engine / SessionLocal / get_db。

初赛用 SQLite 单文件零运维，库文件固定在 backend/data/app.db。
建表用 SQLAlchemy 的 create_all()，不引入 alembic。

并发口径（1 教师 + 10 学生同时在线）：单进程 uvicorn + SQLite 的瓶颈是写锁，
不是连接数。因此每个连接开 WAL（读不阻塞写、写不阻塞读）、synchronous=NORMAL
（WAL 下仍然崩溃安全，只是少一次 fsync）、busy_timeout=10s（等锁而不是立刻报
database is locked）。连接池放大到 10+10，覆盖 11 个并发请求各占一条连接。
"""
import os
from pathlib import Path
from typing import Any, Dict

from dotenv import load_dotenv
from sqlalchemy import create_engine, event
from sqlalchemy.engine import Engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker

# backend/app/db.py -> 上溯两级即 backend/
BACKEND_DIR = Path(__file__).resolve().parents[1]
# 让迁移、seed、测试脚本与 uvicorn 使用同一份本地配置。
# main.py 也会加载一次 .env；load_dotenv 默认不会覆盖调用方显式设置的环境变量。
load_dotenv(BACKEND_DIR / ".env")
DATA_DIR = BACKEND_DIR / "data"
# 必须先把目录建出来，否则 SQLite 首次建库会直接失败
DATA_DIR.mkdir(parents=True, exist_ok=True)

DB_PATH = DATA_DIR / "app.db"
DATABASE_URL = os.getenv("DATABASE_URL") or "sqlite:///%s" % DB_PATH.as_posix()

# pool_size=10：1 名教师 + 10 名学生各占一条连接时仍有余量。
POOL_SIZE = 10
MAX_OVERFLOW = 10
POOL_TIMEOUT = 30
BUSY_TIMEOUT_MS = 10000


def _install_sqlite_pragmas(target: Engine, memory: bool) -> None:
    """每个新建的 DBAPI 连接执行一次 PRAGMA。

    journal_mode 是写进库文件头的持久设置（只需成功执行一次），但每条连接都要
    重新设置 busy_timeout / synchronous——它们是连接级参数，不随文件保存。
    内存库（:memory:，测试用）没有 WAL 概念，设置 journal_mode 无意义，
    一律跳过，避免测试环境报错。
    """
    if memory:
        return

    @event.listens_for(target, "connect")
    def _set_pragmas(dbapi_connection, _connection_record):  # noqa: ANN001 - DBAPI 连接
        cursor = dbapi_connection.cursor()
        try:
            cursor.execute("PRAGMA journal_mode=WAL")
            cursor.execute("PRAGMA synchronous=NORMAL")
            cursor.execute("PRAGMA busy_timeout=%d" % BUSY_TIMEOUT_MS)
        finally:
            cursor.close()


def _is_memory_url(url: str) -> bool:
    """内存库：`:memory:`，或 sqlite 空路径（`sqlite://`，SQLAlchemy 同样视为内存库）。

    内存库默认用 SingletonThreadPool，且没有 WAL 概念。
    """
    return ":memory:" in url or url.rstrip("/") in ("sqlite:", "sqlite+pysqlite:")


def build_engine(url: str) -> Engine:
    """按 DATABASE_URL 造 engine；测试直接复用此函数验证 PRAGMA 是否真的生效。"""
    memory = _is_memory_url(url)
    options: Dict[str, Any] = {"connect_args": {"check_same_thread": False}}
    if not memory:
        # 内存库用的是 SingletonThreadPool，不接受 pool_size/max_overflow/pool_timeout。
        options.update(pool_size=POOL_SIZE, max_overflow=MAX_OVERFLOW, pool_timeout=POOL_TIMEOUT)
    engine = create_engine(url, **options)
    _install_sqlite_pragmas(engine, memory)
    return engine


# check_same_thread=False：FastAPI 的依赖注入会跨线程复用连接
engine = build_engine(DATABASE_URL)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)


class Base(DeclarativeBase):
    """所有模型的基类。"""


def get_db():
    """FastAPI 依赖：每个请求一个会话，请求结束必定关闭。"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
