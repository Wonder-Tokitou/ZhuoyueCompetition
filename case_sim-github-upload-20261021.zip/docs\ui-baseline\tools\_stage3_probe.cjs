/**
 * 阶段 3（策略卡三色化）取证脚本。
 *
 * 在 375px 下打开学生推演页（未作答 → 渲染 A/B/C 三张策略卡），取证：
 *   1. 三张卡片的真实 computed borderColor / backgroundColor 是否两两不同
 *   2. 点击 B 后选中态是否有外扩 outline（不依赖白字）、文字是否仍为深色
 *   3. 「风险待评估」是否仍在
 *   4. 375px 是否无横向溢出（outline 不参与布局，验证它没顶出滚动条）
 *
 * 用法：
 *   node _stage3_probe.cjs --token <token> --session <id> [--outdir ..]
 */
const { spawn } = require('node:child_process')
const fs = require('node:fs')
const os = require('node:os')
const path = require('node:path')

const CHROME = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
const PORT = 9335
const BASE = 'http://127.0.0.1:8110'
const CASE_TOKEN = 'benchmark-demo-v4'

function arg(name, fallback) {
  const i = process.argv.indexOf(`--${name}`)
  return i >= 0 && process.argv[i + 1] ? process.argv[i + 1] : fallback
}

const TOKEN = arg('token')
const SESSION = arg('session')
const OUTDIR = path.resolve(arg('outdir', path.join(__dirname, '..')))
if (!TOKEN) { console.error('missing --token'); process.exit(2) }

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

async function browserWs() {
  for (let i = 0; i < 60; i++) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/version`)
      const json = await res.json()
      if (json.webSocketDebuggerUrl) return json.webSocketDebuggerUrl
    } catch { /* 未就绪 */ }
    await sleep(250)
  }
  throw new Error('chrome 调试端口未就绪')
}

function client(ws, onEvent) {
  let id = 0
  const waiting = new Map()
  ws.addEventListener('message', (ev) => {
    const msg = JSON.parse(ev.data)
    if (msg.id && waiting.has(msg.id)) {
      const { resolve, reject } = waiting.get(msg.id)
      waiting.delete(msg.id)
      msg.error ? reject(new Error(JSON.stringify(msg.error))) : resolve(msg.result)
      return
    }
    if (msg.method && onEvent) onEvent(msg)
  })
  return (method, params = {}, sessionId) => new Promise((resolve, reject) => {
    const mid = ++id
    waiting.set(mid, { resolve, reject })
    ws.send(JSON.stringify({ id: mid, method, params, ...(sessionId ? { sessionId } : {}) }))
  })
}

const CARDS = `(() => {
  const cards = [...document.querySelectorAll('.strategy-option-card')]
  return {
    count: cards.length,
    overflow: {
      scrollWidth: document.documentElement.scrollWidth,
      clientWidth: document.documentElement.clientWidth,
    },
    cards: cards.map((el) => {
      const cs = getComputedStyle(el)
      const letter = el.querySelector('.strategy-letter')?.textContent || ''
      const name = el.querySelector('.strategy-name')?.textContent || ''
      const risk = el.querySelector('.strategy-risk')?.textContent || ''
      const btn = el.querySelector('button')
      const btnCs = btn ? getComputedStyle(btn) : null
      return {
        letter, name, risk,
        borderColor: cs.borderTopColor,
        borderWidth: cs.borderTopWidth,
        background: cs.backgroundColor,
        outline: cs.outlineStyle + ' ' + cs.outlineWidth + ' ' + cs.outlineColor + ' offset ' + cs.outlineOffset,
        transition: cs.transitionProperty,
        ariaPressed: btn?.getAttribute('aria-pressed'),
        textColor: btnCs?.color,
        btnClassName: btn?.className,
      }
    }),
    status: document.querySelector('[role="status"]')?.textContent || '',
    submitDisabled: !!document.querySelector('.decision-submit button')?.disabled,
  }
})()`

;(async () => {
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'stage3-chrome-'))
  const chrome = spawn(CHROME, [
    '--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
    '--no-proxy-server', '--hide-scrollbars', '--force-device-scale-factor=2',
    `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`, 'about:blank',
  ], { stdio: 'ignore' })

  try {
    const wsUrl = await browserWs()
    const ws = new WebSocket(wsUrl)
    await new Promise((res, rej) => { ws.addEventListener('open', res); ws.addEventListener('error', rej) })
    const events = []
    const send = client(ws, (m) => events.push(m))
    const { targetId } = await send('Target.createTarget', { url: 'about:blank' })
    const { sessionId } = await send('Target.attachToTarget', { targetId, flatten: true })
    const call = (m, p) => send(m, p, sessionId)

    await call('Page.enable')
    await call('Runtime.enable')
    await call('Emulation.setDeviceMetricsOverride', { width: 375, height: 812, deviceScaleFactor: 2, mobile: true })

    await call('Page.addScriptToEvaluateOnNewDocument', {
      source: [
        `try { sessionStorage.setItem('student_access_token', ${JSON.stringify(TOKEN)}) } catch (e) {}`,
        SESSION ? `try { sessionStorage.setItem('student_session:${CASE_TOKEN}', ${JSON.stringify(SESSION)}) } catch (e) {}` : '',
      ].join('\n'),
    })
    await call('Page.navigate', { url: `${BASE}/student/${CASE_TOKEN}` })
    await sleep(4500)

    const shoot = async (name) => {
      const shot = await call('Page.captureScreenshot', { format: 'png', captureBeyondViewport: true, fromSurface: true })
      const file = path.join(OUTDIR, `${name}.png`)
      fs.writeFileSync(file, Buffer.from(shot.data, 'base64'))
      return `SAVED=${file} BYTES=${fs.statSync(file).size}`
    }
    const probe = async () => {
      const raw = await call('Runtime.evaluate', { expression: CARDS, returnByValue: true })
      if (raw.exceptionDetails) throw new Error(JSON.stringify(raw.exceptionDetails))
      return raw.result.value
    }

    const idle = await probe()
    const shotIdle = await shoot('stage-3-cards-idle')

    // 点第二张（B）→ 选中态
    await call('Runtime.evaluate', { expression: "document.querySelectorAll('.strategy-option-card button')[1]?.click()" })
    await sleep(600)
    const selectedB = await probe()
    const shotB = await shoot('stage-3-cards-selected-b')

    // 再点第一张（A）→ 确认选中态会迁移，不同时高亮两张
    await call('Runtime.evaluate', { expression: "document.querySelectorAll('.strategy-option-card button')[0]?.click()" })
    await sleep(600)
    const selectedA = await probe()

    // 视口截图（不做 captureBeyondViewport）：sticky 提交栏只会在整页截图里「浮到中间」，
    // 这里补一张真实视口，证明它不是布局缺陷。
    await call('Runtime.evaluate', { expression: "document.querySelector('.strategy-option-card')?.scrollIntoView({block:'center'})" })
    await sleep(400)
    const viewportShot = await call('Page.captureScreenshot', { format: 'png', fromSurface: true })
    const viewportFile = path.join(OUTDIR, 'stage-3-cards-viewport.png')
    fs.writeFileSync(viewportFile, Buffer.from(viewportShot.data, 'base64'))

    // C3 验收：提交闸门。开 Network 域，连点 5 次「确认提交本回合」，数 POST /decide 的条数。
    await call('Network.enable')
    events.length = 0
    const clickResult = await call('Runtime.evaluate', {
      awaitPromise: true,
      expression: `(async () => {
        const clicks = []
        for (let i = 0; i < 5; i++) {
          const btn = document.querySelector('.decision-submit button')
          if (btn) btn.click()
          clicks.push(!!btn)
          await new Promise((r) => setTimeout(r, 60))
        }
        return clicks.length
      })()`,
    })
    await sleep(3000)
    const decideRequests = events
      .filter((m) => m.method === 'Network.requestWillBeSent' && /\/decide$/.test(m.params?.request?.url || ''))
      .map((m) => ({ method: m.params.request.method, url: m.params.request.url }))
    const decideFailures = events
      .filter((m) => m.method === 'Network.loadingFailed')
      .map((m) => m.params?.errorText)
    const submitState = (await call('Runtime.evaluate', {
      expression: `JSON.stringify({
        busyAttr: document.querySelector('.decision-submit button')?.getAttribute('aria-busy'),
        disabled: !!document.querySelector('.decision-submit button')?.disabled,
        hasContinue: [...document.querySelectorAll('button')].some((b) => b.textContent.trim() === '继续下一回合'),
      })`,
      returnByValue: true,
    })).result.value

    console.log(JSON.stringify({
      idle, selectedB, selectedA,
      c3: {
        clicks: clickResult.result.value,
        decideRequestCount: decideRequests.length,
        decideRequests,
        loadingFailures: decideFailures,
        submitState: JSON.parse(submitState),
      },
      saved: { idle: shotIdle, selectedB: shotB, viewport: `SAVED=${viewportFile} BYTES=${fs.statSync(viewportFile).size}` },
    }, null, 2))
    ws.close()
  } finally {
    chrome.kill()
  }
})().catch((e) => { console.error('FAILED:', e.message); process.exit(1) })
