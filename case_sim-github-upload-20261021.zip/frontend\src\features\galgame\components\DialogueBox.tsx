/**
 * 对话框（阶段 3 实现）。
 * 底部固定、深色半透明 rgba(17,24,39,.92)、圆角 14px、max-height 38%；
 * 左上角说话人 emoji + 名字（旁白不显示名字、用斜体）；
 * 右下角 ▼ 指示器（done 才闪，reduce 下常显）；
 * 整块可点击推进：打字未完成先 skip 打完当前句，完成后再点击才进下一句；
 * role="button" + tabIndex=0 + Enter/Space 推进（键盘可达）；
 * 文字区 aria-live="polite"、min-height 3.6em 防跳动。
 */
import type { KeyboardEvent } from 'react'
import { useTypewriter } from '../engine/typewriter'

export interface DialogueBoxProps {
  speaker: string | null
  avatar: string
  text: string
  onAdvance: () => void
}

export default function DialogueBox({ speaker, avatar, text, onAdvance }: DialogueBoxProps) {
  const { shown, done, skip } = useTypewriter(text)

  const advance = () => {
    if (!done) {
      skip() // 第一次点击：先打完当前句
    } else {
      onAdvance() // done 后再点击：进下一句
    }
  }

  const handleKeyDown = (e: KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault()
      advance()
    }
  }

  return (
    <div
      className="galgame-dialogue"
      role="button"
      tabIndex={0}
      aria-label={speaker ? `${speaker}：${text}` : text}
      onClick={advance}
      onKeyDown={handleKeyDown}
    >
      <div className="galgame-dialogue-head">
        {speaker ? (
          <>
            <span className="galgame-dialogue-avatar" aria-hidden="true">{avatar}</span>
            <span className="galgame-dialogue-speaker">{speaker}</span>
          </>
        ) : (
          <span className="galgame-dialogue-speaker is-narrator" aria-hidden="true">{avatar}</span>
        )}
      </div>
      <p className="galgame-dialogue-text" aria-live="polite">{shown}</p>
      <span className={`galgame-dialogue-pointer${done ? ' is-done' : ''}`} aria-hidden="true">▼</span>
    </div>
  )
}
