"""阶段 3 取证辅助：临时学生 → 临时会话（用于看到未作答的策略卡）。

背景：策略卡只在「未完成的会话」里渲染；库里 3 个会话都已结束，
      直接复用会把既有 3 轮记录改坏。故新建一个**临时**学生账号并开始一次会话，
      取证后由 _stage3_probe_teardown.py 逐表删除（含 AI 制品文件与目录）。

用法：
  python _stage3_probe_setup.py           # 建账号 + 令牌 + 会话，打印 TOKEN/SESSION_ID
  python _stage3_probe_setup.py --status  # 只打印各表计数
"""
import hashlib
import json
import secrets
import sqlite3
import sys
import urllib.request
from datetime import datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
DB = ROOT / "backend" / "data" / "app.db"
BASE = "http://127.0.0.1:8110"
CASE_TOKEN = "benchmark-demo-v4"
TAG_PREFIX = "stage3-probe-"
REAL_NAME = "换肤取证"

TABLES = ["student_account", "student_login", "session", "turn", "ai_artifact"]


def counts(conn):
    return {t: conn.execute(f"select count(*) from {t}").fetchone()[0] for t in TABLES}


def main() -> None:
    conn = sqlite3.connect(DB)
    if "--status" in sys.argv:
        print(json.dumps(counts(conn), ensure_ascii=False))
        return

    before = counts(conn)
    username = TAG_PREFIX + secrets.token_hex(6)
    cur = conn.execute(
        "insert into student_account (username, real_name, password_hash, status, failed_logins, created_at)"
        " values (?, ?, ?, 'active', 0, ?)",
        (username, REAL_NAME, "probe-no-login", datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")),
    )
    student_id = cur.lastrowid

    token = TAG_PREFIX + secrets.token_hex(16)
    digest = hashlib.sha256(token.encode()).hexdigest()
    expires = (datetime.now() + timedelta(hours=2)).strftime("%Y-%m-%d %H:%M:%S.%f")
    conn.execute(
        "insert into student_login (token_hash, student_id, expires_at) values (?, ?, ?)",
        (digest, student_id, expires),
    )
    conn.commit()

    req = urllib.request.Request(
        f"{BASE}/api/play/{CASE_TOKEN}/sessions",
        data=json.dumps({"student_name": REAL_NAME}).encode(),
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {token}"},
        method="POST",
    )
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(req, timeout=15) as resp:
        body = json.loads(resp.read().decode())

    print(f"STUDENT_ID={student_id}")
    print(f"USERNAME={username}")
    print(f"TOKEN={token}")
    print(f"SESSION_ID={body['session_id']}")
    print(f"BEFORE={json.dumps(before, ensure_ascii=False)}")
    print(f"AFTER={json.dumps(counts(conn), ensure_ascii=False)}")
    conn.close()


if __name__ == "__main__":
    main()
