import { useState } from 'react'
import { Link } from 'react-router-dom'
import type { PlayResponse, SessionState } from '../../../api/types'
import { endingOf } from '../engine/dialogueEngine'
import type { GalgameSave } from '../engine/persistence'
import type { GameMode } from '../engine/session'
import { ENDINGS } from '../data/endings'

/** 经营日记键（P1-F2：localStorage["galgame_diary:<token>:<session_id>:<mode>"]，≤12 条截断）。 */
const DIARY_KEY = (token: string, mode: GameMode, sessionId: number | null) => `galgame_diary:${token}:${sessionId ?? 'none'}:${mode}`

export interface DiaryEntry {
  round: number
  title: string
  label: string
  summary: string
  revenueDelta: number | null
  cashFlow: number
  events: string[]
}

function loadDiary(token: string, mode: GameMode, sessionId: number | null): DiaryEntry[] {
  try {
    const raw = globalThis.localStorage?.getItem(DIARY_KEY(token, mode, sessionId))
    const arr = raw ? JSON.parse(raw) : []
    return Array.isArray(arr) ? arr : []
  } catch {
    return []
  }
}

/** 结局页（T5.2 + T6.3）：结局名 + 台词 + CG 占位 + 总分 + 经营日记（localStorage 优先）+ AI 复盘跳转；P1-F3：practice 显示「再来一局」。 */
export default function EndingView({
  token,
  save,
  turns,
  data,
  mode,
  onRestart,
}: {
  token: string
  save: GalgameSave | null
  turns: SessionState['turns']
  data: PlayResponse | null
  mode: GameMode
  onRestart: () => void
}) {
  const [showDiary, setShowDiary] = useState(false)
  const kind = endingOf(save?.score ?? 50)
  const ending = ENDINGS.find((e) => e.id === `end.${kind}`) ?? ENDINGS[1]
  const diary = loadDiary(token, mode, save?.session_id ?? null)
  const diaryEntries = diary.length > 0
    ? diary
    : turns.map((turn, i) => ({
        round: i + 1,
        title: data?.nodes.find((n) => n.id === turn.node_id)?.title ?? '决策',
        label: turn.chosen_label ?? '已保存',
        summary: turn.summary,
        revenueDelta: null,
        cashFlow: 0,
        events: [],
      }))
  return (
    <div className="galgame-finished">
      <p className="galgame-finished-title">{ending.title}</p>
      <div className={`galgame-cg-placeholder is-${kind}`} role="img" aria-label={`${ending.title} 结局画面`}>
        <span>{ending.cgId}</span>
      </div>
      <ul className="galgame-ending-lines">
        {ending.lines.map((line) => <li key={line}>{line}</li>)}
      </ul>
      <p className="galgame-final-score">
        总分 {Math.round(save?.score ?? 50)}
      </p>
      <div className="galgame-finished-actions">
        <button type="button" className="galgame-confirm" onClick={() => setShowDiary((v) => !v)}>
          查看经营日记
        </button>
        {mode === 'formal' && (
          <Link
            className="galgame-review-link"
            to={`/student/${token}/review?session=${save?.session_id ?? ''}`}
          >
            查看 AI 复盘
          </Link>
        )}
        {mode === 'practice' && (
          <button type="button" className="galgame-confirm" onClick={onRestart}>
            再来一局
          </button>
        )}
      </div>
      {showDiary && (
        <ol className="galgame-diary">
          {diaryEntries.length === 0 && <li>暂无经营记录。</li>}
          {diaryEntries.map((entry, i) => (
            <li key={i}>
              <strong>第 {entry.round} 轮 · {entry.title}</strong>
              <span>选了「{entry.label}」</span>
              <span>{entry.summary}</span>
              {entry.revenueDelta != null && <span>营收 {entry.revenueDelta > 0 ? '+' : ''}{entry.revenueDelta} 万元</span>}
              {entry.events.length > 0 && <span className="galgame-diary-event">事件：{entry.events.join('、')}</span>}
            </li>
          ))}
        </ol>
      )}
    </div>
  )
}
