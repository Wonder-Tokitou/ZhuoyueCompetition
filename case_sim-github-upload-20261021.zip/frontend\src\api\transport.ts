import axios from 'axios'
import type { AxiosError, AxiosInstance } from 'axios'
import { showError } from '../utils/feedback'

/** 统一的失败对象：message 即后端返回的中文说明，status 为 HTTP 状态码 */
export interface ApiError extends Error {
  status?: number
  /** 后端结构化 detail 里的业务码（如 409 submission_exists），供页面做分支判断 */
  code?: string
  /** 后端结构化 detail 原始载荷（含 session_id 等字段），未结构化时为 undefined */
  detail?: unknown
}

/** 结构化 detail 无法给出可读文案时的兜底（422 校验错误的 detail 是数组，也走这里） */
const GENERIC_DETAIL = '请求参数不符合要求，请检查输入内容'

function toApiError(message: string, status?: number, extra?: { code?: string; detail?: unknown }): ApiError {
  const error = new Error(message) as ApiError
  error.name = 'ApiError'
  error.status = status
  if (extra?.code) error.code = extra.code
  if (extra?.detail !== undefined) error.detail = extra.detail
  return error
}

export const api: AxiosInstance = axios.create({
  baseURL: '/api',
  // 生成类接口（创建案例、AI 修正）要等模型，超时给足；开发期也经 Vite 代理转发
  timeout: 120000,
})

api.interceptors.request.use((config) => {
  if (/^\/(student(?:\/|$)|play\/)/.test(config.url || '')) {
    const token = sessionStorage.getItem('student_access_token')
    if (token) config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// 任何失败都在这里统一转成中文提示并抛出，页面 catch 后渲染错误态，绝不白屏。
api.interceptors.response.use(
  (response) => response,
  (error: AxiosError<{ detail?: unknown }>) => {
    if (axios.isCancel(error)) return Promise.reject(error)
    const status = error.response?.status
    const payload = error.response?.data?.detail
    let detail: string | undefined
    let code: string | undefined
    let structured: unknown
    if (typeof payload === 'string') {
      detail = payload
    } else if (Array.isArray(payload)) {
      // FastAPI 请求体校验失败：detail 是错误数组，没有给终端用户看的文案。
      detail = GENERIC_DETAIL
    } else if (payload && typeof payload === 'object') {
      // 后端用结构化 detail 表达业务冲突（409 submission_exists）。原先这里整块丢成
      // 通用文案，导致"已有推演记录"的真实原因无法识别；现在把 code 与原始载荷带给
      // 页面，文案优先用后端 message。
      const body = payload as { code?: unknown; message?: unknown }
      structured = payload
      if (typeof body.code === 'string') code = body.code
      detail = typeof body.message === 'string' ? body.message : GENERIC_DETAIL
    } else if (payload) {
      detail = GENERIC_DETAIL
    }

    if (!detail) {
      if (error.code === 'ECONNABORTED') {
        detail = '请求超时，请稍后重试'
      } else if (!error.response) {
        detail = '无法连接后端服务，请确认本地后端端口已启动'
      } else {
        detail = `请求失败（HTTP ${status}）`
      }
    }

    // Review polling renders its own reconnect notice rather than repeated toast errors.
    if (!error.config?.signal) showError(detail)
    if ((status === 401 || status === 403) && window.location.pathname.startsWith('/student') && !window.location.pathname.startsWith('/student/login')) {
      sessionStorage.removeItem('student_access_token')
      window.location.href = '/student/login?next=' + encodeURIComponent(window.location.pathname + window.location.search)
    }
    if ((status === 401 || status === 403) && typeof window !== 'undefined' && window.location.pathname.startsWith('/teacher')) {
      sessionStorage.removeItem('teacher_token')
      if (!window.location.pathname.startsWith('/teacher/login')) window.location.href = '/teacher/login'
    }
    return Promise.reject(toApiError(detail, status, { code, detail: structured }))
  },
)
