import type { Metrics } from '../api/types'

type DisplayMetrics = Metrics & { net_profit?: number; cash_flow_amount?: number }
const fields: [keyof DisplayMetrics, string][] = [
  ['revenue', '营收（万元）'], ['gross_margin', '毛利率'],
  ['market_share', '市场份额'], ['cash_flow', '现金流'],
  ['net_profit', '净利润（万元）'], ['cash_flow_amount', '现金净流量（万元）'],
]

export function metricChange(before: unknown, after: unknown, percentage = false): string {
  const numeric = (value: unknown) => typeof value === 'number' ? value : percentage && typeof value === 'string' && /^-?\d+(?:\.\d+)?%$/.test(value.trim()) ? Number(value.trim().slice(0, -1)) : NaN
  const a = numeric(before), b = numeric(after)
  if (!Number.isFinite(a) || !Number.isFinite(b)) return '—'
  const delta = b - a
  return `${delta > 0 ? '+' : ''}${delta.toFixed(2)}${percentage ? ' 个百分点' : ' 万元'}`
}

export default function MetricComparison({ before, after }: { before?: DisplayMetrics | null; after?: DisplayMetrics | null }) {
  const cell = { padding: '8px 12px', borderBottom: '1px solid #eee', textAlign: 'left' as const, verticalAlign: 'top' as const, overflowWrap: 'anywhere' as const }
  const value = (metrics: DisplayMetrics | null | undefined, key: keyof DisplayMetrics) => metrics?.[key] ?? '未记录'
  return <div style={{ overflowX: 'auto' }}><table aria-label="决策前后指标对比" style={{ width: '100%', tableLayout: 'fixed', borderCollapse: 'collapse' }}>
    <thead><tr><th style={{ ...cell, width: '24%' }}>经营指标</th><th style={cell}>决策前</th><th style={cell}>决策后</th><th style={cell}>变化</th></tr></thead>
    <tbody>{fields.filter(([key]) => key !== 'net_profit' && key !== 'cash_flow_amount' || before?.[key] != null || after?.[key] != null).map(([key, label]) => <tr key={key}><th scope="row" style={cell}>{label}</th><td style={cell}>{value(before, key)}</td><td style={cell}>{value(after, key)}</td><td style={cell}>{metricChange(before?.[key], after?.[key], key === 'gross_margin' || key === 'market_share')}</td></tr>)}</tbody>
  </table></div>
}
