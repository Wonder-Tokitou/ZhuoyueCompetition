@echo off
chcp 65001 >nul 2>&1
cd /d "%~dp0"
set PYTHONUTF8=1

echo ==========================================
echo   case_sim - one click start (dev mode)
echo ==========================================
echo.

if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" -u scripts\quick_start.py
) else (
  python -u scripts\quick_start.py
)

if errorlevel 1 (
  echo.
  echo [ERROR] startup failed. Press any key to exit...
  pause >nul
)
