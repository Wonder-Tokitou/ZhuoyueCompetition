"""case_sim 压测脚本（阶段 13 · C9 / Gate A）

只加文件、不装依赖：复用项目已有的 httpx（backend 依赖）与标准库。

用法（在项目根）：
  .venv\\Scripts\\python.exe scripts\\loadtest\\loadtest.py --users 50 --duration 60 --scenario mixed

行为：
  1. 若 backend/data/loadtest.db 不存在，用 sqlite3 backup API 从 app.db 克隆（隔离库，
     绝不允许压 app.db —— 铁律 10）。
  2. 在 loadtest.db 创建 users 个压测学生（student_account + student_login，TAG_PREFIX=loadtest-）。
  3. 用独立 uvicorn 实例（默认端口 8113，DATABASE_URL 指向 loadtest.db）承载。
  4. 并发 users 跑 duration 秒：
       read  = GET  /api/play/{token}            （学生推演页读，真实读路径）
       write = POST /api/play/{token}/sessions 首建会话，之后 POST /sessions/{id}/reset（真实写路径）
       mixed = 3:1 混合
  5. 输出 p50/p95/p99、RPS、错误率、QueuePool timeout / database is locked 计数。

  安全：启动前预检端口，端口被占立即中止（防止误压其它实例 / app.db）。
"""
import argparse
import asyncio
import hashlib
import json
import os
import secrets
import sqlite3
import subprocess
import time
from datetime import datetime, timedelta
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parents[2]
PYTHON = ROOT / ".venv" / "Scripts" / "python.exe"
DB_SRC = ROOT / "backend" / "data" / "app.db"
DB_LOAD = ROOT / "backend" / "data" / "loadtest.db"
PORT = int(os.getenv("LOADTEST_PORT", "8113"))  # 8112 可能被其它实例占用；压测实例必须独享端口
BASE = f"http://127.0.0.1:{PORT}"
CASE_TOKEN = "benchmark-demo-v4"
TAG_PREFIX = "loadtest-"


def ensure_port_free(port: int) -> None:
    """启动前预检端口；被占用则中止，绝不允许压测打到其它实例（尤其 app.db 实例）。"""
    import socket
    s = socket.socket()
    s.settimeout(0.5)
    try:
        busy = s.connect_ex(("127.0.0.1", port)) == 0
    finally:
        s.close()
    if busy:
        raise SystemExit(
            f"[loadtest] 端口 {port} 已被占用，拒绝启动（防止误压其它实例/库）。\n"
            f"请释放该端口，或改用其它端口：LOADTEST_PORT=8114 .venv\\Scripts\\python.exe scripts\\loadtest\\loadtest.py …")


def ensure_load_db(users: int) -> list[str]:
    """重建 loadtest.db（删除→从 app.db 克隆→建 users 个压测学生），返回明文令牌列表。

    每次运行重建，保证各档压测互不污染；令牌由用户名确定性派生，幂等可复现。
    """
    if DB_LOAD.exists():
        DB_LOAD.unlink()
    src = sqlite3.connect(DB_SRC)
    dst = sqlite3.connect(DB_LOAD)
    with dst:
        src.backup(dst)
    src.close()
    dst.close()
    conn = sqlite3.connect(DB_LOAD)
    tokens = []
    now = datetime.now()
    expires = (now + timedelta(hours=6)).strftime("%Y-%m-%d %H:%M:%S.%f")
    for i in range(users):
        username = f"{TAG_PREFIX}u{i}"
        token = f"{TAG_PREFIX}{username}.token"
        digest = hashlib.sha256(token.encode()).hexdigest()
        cur = conn.execute(
            "insert into student_account (username, real_name, class_name, password_hash, status, failed_logins, created_at) "
            "values (?, ?, ?, ?, 'active', 0, ?)",
            (username, username, "loadtest", "!placeholder!", now.strftime("%Y-%m-%d %H:%M:%S.%f")),
        )
        sid = cur.lastrowid
        conn.execute(
            "insert into student_login (token_hash, student_id, expires_at) values (?, ?, ?)",
            (digest, sid, expires),
        )
        tokens.append(token)
    conn.commit()
    rows = conn.execute("select count(*) from student_login").fetchone()[0]
    conn.close()
    print(f"[loadtest] loadtest.db rebuilt, users={len(tokens)}, login_rows={rows}")
    return tokens


def start_server() -> subprocess.Popen:
    """独立实例：端口 PORT + DATABASE_URL 指向 loadtest.db。"""
    env = dict(os.environ)
    env["DATABASE_URL"] = f"sqlite:///{DB_LOAD.as_posix()}"
    env["APP_PORT"] = str(PORT)
    proc = subprocess.Popen(
        [str(PYTHON), "-m", "uvicorn", "backend.app.main:app",
         "--host", "127.0.0.1", "--port", str(PORT), "--workers", "1"],
        cwd=str(ROOT), env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    return proc


async def wait_ready(timeout=30) -> bool:
    t0 = time.time()
    async with httpx.AsyncClient(timeout=3) as c:
        while time.time() - t0 < timeout:
            try:
                r = await c.get(f"{BASE}/api/health")
                if r.status_code == 200:
                    return True
            except Exception:
                pass
            await asyncio.sleep(0.4)
    return False


def classify(r: httpx.Response | None, exc: Exception | None) -> str | None:
    """返回错误标记: pool_timeout|locked|http5xx|http4xx|timeout|exc:*|None"""
    if exc is not None:
        return f"exc:{type(exc).__name__}"
    assert r is not None
    if r.status_code >= 500:
        body = r.text[:300].lower()
        if "queuepool" in body or "queue pool" in body or "timeout" in body:
            return "pool_timeout"
        if "database is locked" in body or "locked" in body:
            return "locked"
        return "http5xx"
    if r.status_code >= 400:
        return f"http{r.status_code}"
    return None


async def worker(client: httpx.AsyncClient, idx: int, token: str, scenario: str,
                 stats: dict, stop: asyncio.Event, session_ids: dict) -> None:
    sid = session_ids.get(idx)
    while not stop.is_set():
        kind = "read" if scenario == "read" else ("write" if scenario == "write" else
                                                  ("read" if secrets.randbelow(4) else "write"))
        t0 = time.perf_counter()
        try:
            if kind == "read":
                r = await client.get(f"{BASE}/api/play/{CASE_TOKEN}",
                                     headers={"Authorization": f"Bearer {token}"})
                dur = time.perf_counter() - t0
                err = classify(r, None)
                await asyncio.sleep(0.02)
            else:
                if sid is None:
                    r = await client.post(f"{BASE}/api/play/{CASE_TOKEN}/sessions",
                                          headers={"Authorization": f"Bearer {token}"},
                                          json={"student_name": token[:24]})
                    dur = time.perf_counter() - t0
                    err = classify(r, None)
                    if r.status_code == 201 or r.status_code == 200:
                        data = r.json()
                        sid = data.get("session_id") or data.get("id")
                        session_ids[idx] = sid
                else:
                    r = await client.post(f"{BASE}/api/play/{CASE_TOKEN}/sessions/{sid}/reset",
                                          headers={"Authorization": f"Bearer {token}"})
                    dur = time.perf_counter() - t0
                    err = classify(r, None)
                    if r.status_code >= 500:
                        session_ids.pop(idx, None)
                        sid = None
        except Exception as e:
            dur = time.perf_counter() - t0
            err = classify(None, e)
        stats["lat"].append(dur)
        stats["req"] += 1
        if err:
            stats["errs"][err] = stats["errs"].get(err, 0) + 1


async def run(users: int, duration: int, scenario: str, tokens: list[str]) -> dict:
    stats = {"lat": [], "req": 0, "errs": {}}
    stop = asyncio.Event()
    session_ids: dict = {}
    async with httpx.AsyncClient(timeout=30) as client:
        tasks = [asyncio.create_task(worker(client, i, tokens[i % len(tokens)], scenario,
                                            stats, stop, session_ids))
                 for i in range(users)]
        await asyncio.sleep(duration)
        stop.set()
        await asyncio.gather(*tasks, return_exceptions=True)
    lat = sorted(stats["lat"])
    n = len(lat)
    p = lambda q: (lat[int(q * (n - 1))] if n else 0)
    return {
        "users": users, "duration_s": duration, "scenario": scenario,
        "requests": n, "rps": round(n / duration, 2),
        "p50_ms": round(p(0.50) * 1000, 1), "p95_ms": round(p(0.95) * 1000, 1),
        "p99_ms": round(p(0.99) * 1000, 1),
        "error_rate_pct": round(sum(stats["errs"].values()) / n * 100, 2) if n else 0,
        "errors": stats["errs"],
    }


def main() -> None:
    ap = argparse.ArgumentParser(description="case_sim 压测（独立库 8113）")
    ap.add_argument("--users", type=int, required=True)
    ap.add_argument("--duration", type=int, default=60)
    ap.add_argument("--scenario", choices=["read", "write", "mixed"], default="mixed")
    args = ap.parse_args()

    tokens = ensure_load_db(args.users)
    ensure_port_free(PORT)
    proc = start_server()
    try:
        if not asyncio.run(wait_ready()):
            raise SystemExit("[loadtest] 压测实例未就绪")
        if proc.poll() is not None:
            raise SystemExit(f"[loadtest] 压测实例启动后即退出 rc={proc.returncode}")
        print(f"[loadtest] start users={args.users} duration={args.duration} scenario={args.scenario}")
        result = asyncio.run(run(args.users, args.duration, args.scenario, tokens))
        print(json.dumps(result, ensure_ascii=False, indent=2))
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
        print("[loadtest] instance stopped")


if __name__ == "__main__":
    main()
