"""One-click dev launcher: prepare env, build frontend if stale, start backend, open browser.

Keeps the backend process as a child of this terminal: close the window -> server stops.
"""
import hashlib
import os
import shutil
import socket
import subprocess
import sys
import time
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP_PORT = 8110
APP_URL = f"http://127.0.0.1:{APP_PORT}/"


def run(args, cwd=ROOT, check=True):
    return subprocess.run([str(x) for x in args], cwd=str(cwd), check=check)


def frontend_digest():
    """Same digest logic as scripts/bootstrap.py to decide whether dist is stale."""
    h = hashlib.sha256()
    for base, dirs, files in os.walk(ROOT / "frontend"):
        dirs[:] = sorted(d for d in dirs if d not in {"node_modules", "dist", ".git"})
        for name in sorted(files):
            p = Path(base) / name
            if p.suffix == ".tsbuildinfo":
                continue
            h.update(p.relative_to(ROOT).as_posix().encode())
            h.update(p.read_bytes())
    return h.hexdigest()


def wait_for_port(port, timeout=30):
    """Wait until the backend port is accepting connections."""
    for _ in range(timeout * 2):
        s = socket.socket()
        s.settimeout(0.5)
        try:
            if s.connect_ex(("127.0.0.1", port)) == 0:
                return True
        finally:
            s.close()
        time.sleep(0.5)
    return False


def open_browser(url):
    """Best-effort browser open; don't fail in headless/automation environments."""
    try:
        webbrowser.open(url, new=2)
    except Exception:
        pass


def listen_pids(port):
    """Return PIDs actually LISTENING on the port (Windows). Empty list otherwise."""
    if os.name != "nt":
        return []
    ps = subprocess.run(
        [
            "powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command",
            f"Get-NetTCPConnection -LocalPort {port} -State Listen -ErrorAction SilentlyContinue | "
            "Select-Object -ExpandProperty OwningProcess -Unique",
        ],
        capture_output=True, text=True,
    )
    pids = set()
    for line in ps.stdout.splitlines():
        line = line.strip()
        if line.isdigit() and int(line) > 0:
            pids.add(int(line))
    return sorted(pids)


def kill_port(port):
    """Kill processes LISTENING on the port. Returns the PIDs we tried to kill."""
    pids = listen_pids(port)
    for pid in pids:
        subprocess.run(["taskkill", "/F", "/PID", str(pid)], capture_output=True)
    return pids


def main():
    print("=" * 50)
    print("case_sim 一键启动（开发模式）")
    print("=" * 50)

    # 1. Python virtualenv
    python = ROOT / ".venv" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    if not python.exists():
        py = shutil.which("python") or sys.executable
        print("创建 Python 虚拟环境...")
        run([py, "-m", "venv", ROOT / ".venv"])

    # 2. .env
    config = ROOT / "backend/.env"
    if not config.exists():
        shutil.copy2(ROOT / "backend/.env.example", config)
        print("已生成 backend/.env（首次启动）")
        print("  默认端口 8110，教师密码 local-dev-only，AI 功能需配置 LLM_API_KEY")

    # 3. Python dependencies
    requirements = ROOT / "backend/requirements.txt"
    marker = ROOT / ".venv/requirements.sha256"
    expected = hashlib.sha256(requirements.read_bytes()).hexdigest()
    if not marker.exists() or marker.read_text() != expected:
        print("安装/更新 Python 依赖...")
        run([python, "-m", "pip", "install", "-r", requirements])
        marker.write_text(expected)
    else:
        print("Python 依赖已是最新")

    # 4. Database init/migrations/seed
    print("初始化数据库（如需要）...")
    run([
        python, "-c",
        "from backend.app import models; "
        "from backend.app.db import Base, engine; Base.metadata.create_all(engine); "
        "from backend.app.migrations import migrate; migrate(); "
        "from backend.app.seed import main; main()",
    ])

    # 5. Frontend build if stale
    stamp = ROOT / "frontend/dist/source.sha256"
    wanted = frontend_digest()
    dist_index = ROOT / "frontend/dist/index.html"
    if not dist_index.exists() or not stamp.exists() or stamp.read_text() != wanted:
        print("构建前端...")
        npm = shutil.which("npm.cmd") or shutil.which("npm")
        if not npm:
            raise SystemExit("错误：需要 Node.js + npm（≥20.19）。请安装后重试。")
        if not (ROOT / "frontend/node_modules").exists():
            print("首次启动：安装前端依赖（npm install）...")
            run([npm, "install"], cwd=ROOT / "frontend")
        run([npm, "run", "build"], cwd=ROOT / "frontend")
        stamp.write_text(wanted)
        print("前端构建完成")
    else:
        print("前端 dist 已是最新，跳过构建")

    # 6. Make sure the port is free
    pids = listen_pids(APP_PORT)
    if pids:
        print(f"端口 {APP_PORT} 已被占用（PID: {', '.join(map(str, pids))}），尝试清理残留进程...")
        killed = kill_port(APP_PORT)
        if killed:
            print(f"  已结束 PID: {', '.join(map(str, killed))}")
        time.sleep(1.5)
        still = listen_pids(APP_PORT)
        if still:
            raise SystemExit(
                f"错误：端口 {APP_PORT} 仍被占用（PID: {', '.join(map(str, still))}）。\n"
                "请双击 停止项目.bat，或手动 taskkill /F /PID <PID> 后重试。"
            )
        print("端口已清理")

    # 7. Start backend as a child process
    print(f"启动后端服务，监听 {APP_PORT}...")
    proc = subprocess.Popen(
        [str(python), "scripts/run_server.py", "--no-log-window"],
        cwd=str(ROOT),
    )

    try:
        print("等待服务就绪...")
        if wait_for_port(APP_PORT):
            print(f"服务已就绪：{APP_URL}")
            open_browser(APP_URL)
            print("浏览器已打开（若未自动打开，请手动访问上方链接）")
            print("提示：")
            print("  - 教师端登录：/teacher/login，密码 local-dev-only")
            print("  - 学生端入口：由教师端创建案例后获取")
            print("  - 关闭本窗口即可停止服务")
            print("-" * 50)
            proc.wait()
        else:
            print(f"错误：服务未在 30 秒内就绪，请检查 logs/ 目录", file=sys.stderr)
            proc.terminate()
            sys.exit(1)
    except KeyboardInterrupt:
        print("收到中断信号，正在停止服务...")
    finally:
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
        print("服务已停止")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n已取消")
    except subprocess.CalledProcessError as exc:
        print(f"启动失败：{exc}", file=sys.stderr)
        sys.exit(exc.returncode)
