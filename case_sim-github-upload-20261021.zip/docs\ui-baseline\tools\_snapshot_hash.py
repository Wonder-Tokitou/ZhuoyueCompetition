"""阶段 0 · T0.6 辅助脚本：src/ 快照哈希

算法（阶段 9 复算时必须完全一致）：
1. 取 frontend/src/ 下所有文件（递归，不含空目录）；
2. 按 POSIX 相对路径（相对 frontend/）字典序升序排序；
3. 对每个文件依次喂入：相对路径（UTF-8）+ "\\n" + 文件原始字节 + "\\n"；
4. 全量 SHA256，十六进制小写输出。

用法：
  python _snapshot_hash.py            # 打印哈希 + 文件数
  python _snapshot_hash.py --list     # 附带逐文件 SHA256
"""
import hashlib
import sys
from pathlib import Path

FRONTEND = Path(__file__).resolve().parents[3] / "frontend"
SRC = FRONTEND / "src"

files = sorted(
    (p for p in SRC.rglob("*") if p.is_file()),
    key=lambda p: p.relative_to(FRONTEND).as_posix(),
)

total = hashlib.sha256()
per_file = []
for p in files:
    rel = p.relative_to(FRONTEND).as_posix()
    data = p.read_bytes()
    total.update(rel.encode("utf-8"))
    total.update(b"\n")
    total.update(data)
    total.update(b"\n")
    per_file.append((rel, hashlib.sha256(data).hexdigest(), len(data)))

print(f"FILES={len(files)}")
print(f"SRC_SHA256={total.hexdigest()}")
if "--list" in sys.argv:
    for rel, digest, size in per_file:
        print(f"{digest}  {size:>8}  {rel}")
