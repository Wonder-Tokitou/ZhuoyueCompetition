# galgame 支线 · 基线记录

> 本文记录执行当次前端测试的基线，供支线各阶段验收对照。基线数字一律以**执行当次 `npm test` 实测值**为准，验收只认 `# fail 0` 与"总数不减少"。

| 项 | 值 | 备注 |
|---|---|---|
| 基线 N（# tests） | 85 | 2026-10-21 执行于 `Desktop/Work/upload2/case_sim-/frontend` |
| # pass | 85 | |
| # fail | 0 | 验收硬标准 |
| tsc -b | 0 错误（tsc.txt 0 字节） | |
| node 版本 | v22.23.2 | 要求 ≥ 20 |

原始输出：`docs/galgame-baseline/tests.txt`、`docs/galgame-baseline/tsc.txt`。

**用法**：此后所有"基线 N"均指本表数值 85。支线新增用例后，`npm test` 的 `# tests` 应 ≥ 85 + 新增数，且 `# fail 0`。
