/**
 * 阶段 7（教师端 KPI 升级）取证脚本：验证四卡图标 + 内联 SVG 迷你折线 + 教师端克制样式。
 *
 * 用法：
 *   node _stage7_probe.cjs --token <teacher_token> [--name stage-7] [--outdir ..]
 *
 * 取证点：
 *   1. 四张 KPI 卡存在（班级仪表盘 Row 内前 4 个 .ant-card）
 *   2. 每卡有对应图标（.anticon-team / .anticon-warning / .anticon-rise / .anticon-clock-circle）
 *   3. 每卡有 <polyline>（内联 SVG 迷你折线，共 4 个）
 *   4. 卡片样式：border-radius 10px、bg #ffffff、border #e9edf3
 *   5. 无玫红/奶油色（教师端主色 #1a3a5c 体系）
 *   6. mock 相关：本页 KPI 已接真实 /teacher/dashboard/summary，无"占位数据（mock）"字样属预期
 *   7. 学生账号卡与表格未被改动（表头仍在）
 */
const { spawn } = require('node:child_process')
const fs = require('node:fs')
const os = require('node:os')
const path = require('node:path')

const CHROME = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
const PORT = 9339
const BASE = 'http://127.0.0.1:8110'

function arg(name, fallback) {
  const i = process.argv.indexOf(`--${name}`)
  return i >= 0 && process.argv[i + 1] ? process.argv[i + 1] : fallback
}
const TOKEN = arg('token')
const NAME = arg('name', 'stage-7')
const OUTDIR = path.resolve(arg('outdir', path.join(__dirname, '..')))
if (!TOKEN) { console.error('missing --token'); process.exit(2) }

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

async function browserWs() {
  for (let i = 0; i < 60; i++) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/version`)
      const json = await res.json()
      if (json.webSocketDebuggerUrl) return json.webSocketDebuggerUrl
    } catch { /* 未就绪 */ }
    await sleep(250)
  }
  throw new Error('chrome 调试端口未就绪')
}

function client(ws) {
  let id = 0
  const waiting = new Map()
  ws.addEventListener('message', (ev) => {
    const msg = JSON.parse(ev.data)
    if (msg.id && waiting.has(msg.id)) {
      const { resolve, reject } = waiting.get(msg.id)
      waiting.delete(msg.id)
      msg.error ? reject(new Error(JSON.stringify(msg.error))) : resolve(msg.result)
      return
    }
  })
  return (method, params = {}, sessionId) => new Promise((resolve, reject) => {
    const mid = ++id
    waiting.set(mid, { resolve, reject })
    ws.send(JSON.stringify({ id: mid, method, params, ...(sessionId ? { sessionId } : {}) }))
  })
}

const PROBE = `(() => {
  // 四张 KPI 卡是"班级仪表盘"外层卡内的嵌套卡；图表两张卡紧随其后，取前 4 张嵌套卡即可
  const cards = [...document.querySelectorAll('.ant-card .ant-card')].slice(0, 4)
  const icons = ['anticon-team', 'anticon-warning', 'anticon-rise', 'anticon-clock-circle']
  const kpi = cards.map((card, i) => {
    const cs = getComputedStyle(card)
    return {
      icon: !!card.querySelector('.' + icons[i]),
      iconClass: icons[i],
      title: (card.querySelector('.ant-statistic-title')?.textContent || '').trim(),
      value: (card.querySelector('.ant-statistic-content-value')?.textContent || '').trim(),
      polyline: card.querySelectorAll('polyline').length,
      polylinePoints: card.querySelector('polyline')?.getAttribute('points')?.slice(0, 60) || null,
      radius: cs.borderTopLeftRadius,
      bg: cs.backgroundColor,
      border: cs.borderTopColor + ' ' + cs.borderTopWidth,
      color: cs.color,
    }
  })
  const mockText = [...document.querySelectorAll('p, span, .ant-card-body *')]
    .map((el) => el.textContent || '')
    .find((t) => t.includes('占位数据')) || null
  const studentCardTitle = [...document.querySelectorAll('.ant-card-head-title')]
    .map((el) => el.textContent || '').find((t) => t.includes('学生账号')) || null
  const tableHeaders = [...document.querySelectorAll('th')].map((th) => th.textContent.trim()).filter(Boolean)
  return {
    kpi,
    totalPolylines: document.querySelectorAll('polyline').length,
    mockText,
    studentCardTitle,
    tableHeaders,
    overflow: { scrollWidth: document.documentElement.scrollWidth, clientWidth: document.documentElement.clientWidth },
    bodyBg: getComputedStyle(document.body).backgroundColor,
  }
})()`

;(async () => {
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'stage7-chrome-'))
  const chrome = spawn(CHROME, [
    '--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
    '--no-proxy-server', '--hide-scrollbars', '--force-device-scale-factor=2',
    `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`, 'about:blank',
  ], { stdio: 'ignore' })

  try {
    const wsUrl = await browserWs()
    const ws = new WebSocket(wsUrl)
    await new Promise((res, rej) => { ws.addEventListener('open', res); ws.addEventListener('error', rej) })
    const send = client(ws)
    const { targetId } = await send('Target.createTarget', { url: 'about:blank' })
    const { sessionId } = await send('Target.attachToTarget', { targetId, flatten: true })
    const call = (m, p) => send(m, p, sessionId)

    await call('Page.enable')
    await call('Runtime.enable')
    await call('Emulation.setDeviceMetricsOverride', { width: 1280, height: 900, deviceScaleFactor: 2, mobile: false })
    await call('Page.navigate', { url: `${BASE}/teacher/${TOKEN}/students` })
    await sleep(5000)

    const raw = await call('Runtime.evaluate', { expression: PROBE, returnByValue: true })
    if (raw.exceptionDetails) throw new Error(JSON.stringify(raw.exceptionDetails))

    const shot = await call('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false, fromSurface: true })
    const file = path.join(OUTDIR, `${NAME}-kpi.png`)
    fs.writeFileSync(file, Buffer.from(shot.data, 'base64'))

    console.log(JSON.stringify({ ...raw.result.value, saved: `SAVED=${file} BYTES=${fs.statSync(file).size}` }, null, 2))
    ws.close()
  } finally {
    chrome.kill()
  }
})().catch((e) => { console.error('FAILED:', e.message); process.exit(1) })
