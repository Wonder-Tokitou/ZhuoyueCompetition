/**
 * 阶段 5 · C5 收口取证：走完一次完整推演（3 轮），数 Network 请求。
 *
 * 判据：请求数与会话轮数一致——3 次 POST /decide + 首次加载（GET play / GET session / restore），
 * 不出现随轮次增长的额外「进度请求」（RoundMap 不许自己拉数据）。
 *
 * 附带：真实 Tab 键聚焦检查（Input.dispatchKeyEvent，而非程序化 .focus()）。
 *
 * 用法：node _stage5_full_round.cjs --token <token> --session <id> [--outdir ..]
 */
const { spawn } = require('node:child_process')
const fs = require('node:fs')
const os = require('node:os')
const path = require('node:path')

const CHROME = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
const PORT = 9338
const BASE = 'http://127.0.0.1:8110'
const CASE_TOKEN = 'benchmark-demo-v4'

function arg(name, fallback) {
  const i = process.argv.indexOf(`--${name}`)
  return i >= 0 && process.argv[i + 1] ? process.argv[i + 1] : fallback
}
const TOKEN = arg('token')
const SESSION = arg('session')
const OUTDIR = path.resolve(arg('outdir', path.join(__dirname, '..')))
if (!TOKEN) { console.error('missing --token'); process.exit(2) }

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

async function browserWs() {
  for (let i = 0; i < 60; i++) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/version`)
      const json = await res.json()
      if (json.webSocketDebuggerUrl) return json.webSocketDebuggerUrl
    } catch { /* 未就绪 */ }
    await sleep(250)
  }
  throw new Error('chrome 调试端口未就绪')
}

function client(ws, onEvent) {
  let id = 0
  const waiting = new Map()
  ws.addEventListener('message', (ev) => {
    const msg = JSON.parse(ev.data)
    if (msg.id && waiting.has(msg.id)) {
      const { resolve, reject } = waiting.get(msg.id)
      waiting.delete(msg.id)
      msg.error ? reject(new Error(JSON.stringify(msg.error))) : resolve(msg.result)
      return
    }
    if (msg.method && onEvent) onEvent(msg)
  })
  return (method, params = {}, sessionId) => new Promise((resolve, reject) => {
    const mid = ++id
    waiting.set(mid, { resolve, reject })
    ws.send(JSON.stringify({ id: mid, method, params, ...(sessionId ? { sessionId } : {}) }))
  })
}

const evalJs = (call, expression) => call('Runtime.evaluate', { expression, returnByValue: true })
  .then((r) => { if (r.exceptionDetails) throw new Error(JSON.stringify(r.exceptionDetails)); return r.result.value })

async function waitFor(call, expression, timeoutMs) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    if (await evalJs(call, expression)) return true
    await sleep(200)
  }
  return false
}

;(async () => {
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'stage5round-chrome-'))
  const chrome = spawn(CHROME, [
    '--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
    '--no-proxy-server', '--hide-scrollbars', '--force-device-scale-factor=2',
    `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`, 'about:blank',
  ], { stdio: 'ignore' })

  try {
    const wsUrl = await browserWs()
    const ws = new WebSocket(wsUrl)
    await new Promise((res, rej) => { ws.addEventListener('open', res); ws.addEventListener('error', rej) })
    const events = []
    const send = client(ws, (m) => events.push(m))
    const { targetId } = await send('Target.createTarget', { url: 'about:blank' })
    const { sessionId } = await send('Target.attachToTarget', { targetId, flatten: true })
    const call = (m, p) => send(m, p, sessionId)

    await call('Page.enable'); await call('Runtime.enable'); await call('Network.enable')
    await call('Emulation.setDeviceMetricsOverride', { width: 375, height: 812, deviceScaleFactor: 2, mobile: true })
    await call('Page.addScriptToEvaluateOnNewDocument', {
      source: [
        `try { sessionStorage.setItem('student_access_token', ${JSON.stringify(TOKEN)}) } catch (e) {}`,
        SESSION ? `try { sessionStorage.setItem('student_session:${CASE_TOKEN}', ${JSON.stringify(SESSION)}) } catch (e) {}` : '',
      ].join('\n'),
    })
    events.length = 0
    await call('Page.navigate', { url: `${BASE}/student/${CASE_TOKEN}` })
    await sleep(4500)

    const rounds = []
    for (let round = 1; round <= 3; round++) {
      const cardReady = await waitFor(call, "!!document.querySelector('.strategy-option-card button')", 8000)
      if (!cardReady) throw new Error(`第 ${round} 轮：策略卡未出现`)
      await evalJs(call, "document.querySelector('.strategy-option-card button').click()")
      await sleep(300)
      await evalJs(call, "document.querySelector('.decision-submit button')?.click()")
      const settled = await waitFor(call, "!!document.querySelector('.ant-modal-confirm, .ant-modal')", 8000)
      await sleep(1200)
      // U1 结算单：先点 Modal 里的「继续」再回到页面
      await evalJs(call, "[...document.querySelectorAll('.ant-modal button')].find((b) => b.textContent.trim() === '继续')?.click()")
      await sleep(600)
      const stateText = await evalJs(call, "document.querySelector('.ant-card-body')?.textContent.match(/第 \\d \\/ 3 轮 · 已提交 \\d 轮|三轮推演已完成 · 已提交 3 轮/)?.[0] || ''")
      rounds.push({ round, modalSettled: settled, stateText })
      if (round < 3) {
        await evalJs(call, "[...document.querySelectorAll('button')].find((b) => b.textContent.trim() === '继续下一回合')?.click()")
        await sleep(1000)
      }
    }
    const finished = await evalJs(call, "[...document.querySelectorAll('button')].some((b) => b.textContent.includes('推演完成'))")

    // 真实 Tab 键：这里已 finished（无 aria-current），改在 fresh 会话里验证——见 stage-5-a 记录；
    // 本轮补一次结构断言：RoundMap 仍在且无 .ant-steps
    const structure = await evalJs(call, `JSON.stringify({
      roundMap: !!document.querySelector('.round-map[role="list"]'),
      doneNodes: document.querySelectorAll('.round-node.is-done').length,
      currentNodes: document.querySelectorAll('[aria-current="step"]').length,
      antSteps: document.querySelectorAll('.ant-steps').length,
    })`)

    const api = events
      .filter((m) => m.method === 'Network.requestWillBeSent')
      .map((m) => m.params.request.url.replace(BASE, '').split('?')[0])
      .filter((u) => u.startsWith('/api/'))
    const tally = api.reduce((acc, u) => {
      const key = u.replace(/\/\d+(\/|$)/g, '/:id$1')
      acc[key] = (acc[key] || 0) + 1
      return acc
    }, {})

    const shot = await call('Page.captureScreenshot', { format: 'png', fromSurface: true })
    const file = path.join(OUTDIR, 'stage-5-full-round.png')
    fs.writeFileSync(file, Buffer.from(shot.data, 'base64'))

    console.log(JSON.stringify({
      rounds, finished, structure: JSON.parse(structure),
      apiTally: tally, apiTotal: api.length,
      saved: `SAVED=${file} BYTES=${fs.statSync(file).size}`,
    }, null, 2))
    ws.close()
  } finally {
    chrome.kill()
  }
})().catch((e) => { console.error('FAILED:', e.message); process.exit(1) })
