import type { Metrics } from '../api/types'

/**
 * U1 即时结算单的文案生成（纯函数、零依赖、可单测）。
 *
 * 只做「规则模板」的因果解释，不调用模型，也不读取教师端的精确测算结果。
 * 数据全部来自学生本轮已经拿到的 before / after 指标，因此不产生剧透。
 *
 * 现金流不在 Metrics 里（它在 SessionState.financial_state 上），
 * 所以用第 4 个可选参数传入，缺省时不做现金流特判。
 */

export interface DecisionNarrative {
  /** 营收与毛利率的「旧值 → 新值（±变化）」，无法对比时用 — 占位，绝不编造数字 */
  deltaText: string
  /** 一句因果解释：为什么涨、为什么跌 */
  why: string
  /** 一句下一轮该关注什么 */
  nextFocus: string
}

/** 现金流为负时，下一轮关注点固定为这一句（清单 U1 规则）。 */
const CASH_FOCUS = '现金流能否撑住下一轮扩张'

/** 与 MetricComparison.metricChange 同一套解析口径：只认 "60.0%" 这类规范百分比串。 */
function parsePercent(value: unknown): number | null {
  if (typeof value === 'number') return Number.isFinite(value) ? value : null
  if (typeof value === 'string' && /^-?\d+(?:\.\d+)?%$/.test(value.trim())) return Number(value.trim().slice(0, -1))
  return null
}

function revenueOf(metrics: Metrics | null | undefined): number | null {
  if (!metrics) return null
  const value = metrics.revenue
  return typeof value === 'number' && Number.isFinite(value) ? value : null
}

/** 返回 'up' / 'down' / 'flat'；任一侧缺失或不可解析时返回 null（不猜方向）。 */
function direction(before: number | null, after: number | null): 'up' | 'down' | 'flat' | null {
  if (before === null || after === null) return null
  if (after > before) return 'up'
  if (after < before) return 'down'
  return 'flat'
}

const signed = (value: number) => `${value > 0 ? '+' : ''}${value.toFixed(2)}`

/** 「营收 78.00 → 86.50 万元（+10.90%）；毛利率 60.0% → 55.0%（-5.00 个百分点）」 */
function deltaText(before: Metrics | null | undefined, after: Metrics | null | undefined): string {
  const bRev = revenueOf(before), aRev = revenueOf(after)
  let revenue: string
  if (bRev !== null && aRev !== null) {
    revenue = `营收 ${bRev.toFixed(2)} → ${aRev.toFixed(2)} 万元`
    // 基准为 0 时百分比无意义（会得到 Infinity），此时只给绝对变化，不硬算比率。
    if (bRev !== 0) revenue += `（${signed((aRev - bRev) / bRev * 100)}%）`
    else revenue += `（${signed(aRev - bRev)} 万元）`
  } else if (bRev !== null) revenue = `营收 ${bRev.toFixed(2)} → — 万元`
  else if (aRev !== null) revenue = `营收 — → ${aRev.toFixed(2)} 万元`
  else revenue = '营收 —'

  const bMargin = before ? parsePercent(before.gross_margin) : null
  const aMargin = after ? parsePercent(after.gross_margin) : null
  let margin: string
  if (bMargin !== null && aMargin !== null) {
    margin = `毛利率 ${before!.gross_margin} → ${after!.gross_margin}（${signed(aMargin - bMargin)} 个百分点）`
  } else if (bMargin !== null) margin = `毛利率 ${before!.gross_margin} → —`
  else if (aMargin !== null) margin = `毛利率 — → ${after!.gross_margin}`
  else margin = '毛利率 —'

  return `${revenue}；${margin}`
}

/** 四个方向分支 + 持平 / 无基准两种兜底（清单 U1 规则）。 */
function story(revenueDir: 'up' | 'down' | 'flat' | null, marginDir: 'up' | 'down' | 'flat' | null): string {
  if (revenueDir === null && marginDir === null) return '本轮缺少可对比的基准数据，暂时无法判断量价关系，请结合案例资料核对。'
  const flat = (revenueDir === 'flat' || revenueDir === null) && (marginDir === 'flat' || marginDir === null)
  if (flat) return '营收与毛利率基本持平，这一轮没有明显换来增量，也没有失血。'
  if (revenueDir === 'up' && marginDir === 'down') return '降价或让利换来了更多客户，但单笔利润被压薄了。'
  if (revenueDir === 'down' && marginDir === 'up') return '主动收缩了低毛利业务，短期营收下降但结构更健康。'
  if (revenueDir === 'down' || marginDir === 'down') return '份额与利润同时承压，这一轮要警惕现金流。'
  return '量价齐升：既拿到了更多客户，也没有牺牲利润空间。'
}

function focus(revenueDir: 'up' | 'down' | 'flat' | null, marginDir: 'up' | 'down' | 'flat' | null, cashFlowAmount?: number | null): string {
  if (typeof cashFlowAmount === 'number' && Number.isFinite(cashFlowAmount) && cashFlowAmount < 0) return CASH_FOCUS
  if (revenueDir === null && marginDir === null) return '下一轮关注：先补齐可比数据，再判断该扩张还是收缩'
  if (revenueDir === 'up' && marginDir === 'down') return '下一轮关注：在保住客户的同时，能否把单笔利润提回来'
  if (revenueDir === 'down' && marginDir === 'up') return '下一轮关注：收缩之后，营收缺口靠什么补上'
  if (revenueDir === 'down' || marginDir === 'down') return '下一轮关注：先稳住哪一块，避免继续双降'
  if ((revenueDir === 'flat' || revenueDir === null) && (marginDir === 'flat' || marginDir === null)) return '下一轮关注：哪一项投入能打破当前的平台期'
  return '下一轮关注：这个量价齐升能否再持续一轮'
}

export function narrative(
  before: Metrics | null | undefined,
  after: Metrics | null | undefined,
  chosenLabel: string,
  cashFlowAmount?: number | null,
): DecisionNarrative {
  const revenueDir = direction(revenueOf(before), revenueOf(after))
  const marginDir = direction(before ? parsePercent(before.gross_margin) : null, after ? parsePercent(after.gross_margin) : null)
  return {
    deltaText: deltaText(before, after),
    why: `你选择了「${chosenLabel}」：${story(revenueDir, marginDir)}`,
    nextFocus: focus(revenueDir, marginDir, cashFlowAmount),
  }
}
