// 响应拦截器契约：结构化 detail（409 submission_exists）不能丢业务码，
// 422 的数组 detail 与字符串 detail 维持原有中文提示。
const { test } = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const vm = require('node:vm')
const ts = require('typescript')

function loadTransport() {
  let onRejected
  const instance = {
    interceptors: {
      request: { use() { return 0 } },
      response: { use(_ok, fail) { onRejected = fail; return 0 } },
    },
  }
  const mocks = {
    axios: { __esModule: true, default: { create: () => instance, isCancel: () => false } },
    '../utils/feedback': { showError() {} },
  }
  const code = ts.transpileModule(
    fs.readFileSync(path.resolve(__dirname, '../src/api/transport.ts'), 'utf8'),
    { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } },
  ).outputText
  const exports = {}
  vm.runInNewContext(code, {
    exports,
    require: (name) => { if (name in mocks) return mocks[name]; throw new Error(`Unexpected import ${name}`) },
    Promise, Error, encodeURIComponent,
    window: { location: { pathname: '/student/case-demo', search: '', href: '' } },
    sessionStorage: { getItem: () => null, setItem() {}, removeItem() {} },
  })
  assert.equal(typeof exports.api, 'object', 'transport must export the axios instance')
  assert.equal(typeof onRejected, 'function', 'response interceptor must register a rejection handler')
  return (error) => onRejected(error).then(
    () => { throw new Error('interceptor must reject the failure') },
    (rejected) => rejected,
  )
}

const failure = (status, detail, extra = {}) => ({ response: { status, data: { detail } }, config: {}, ...extra })

test('409 submission_exists keeps the backend business code and message', async () => {
  const intercept = loadTransport()
  const detail = { code: 'submission_exists', session_id: 42, message: '已有本案例推演记录，请从提交记录继续，或选择覆盖原记录后重做。' }
  const error = await intercept(failure(409, detail))
  assert.equal(error.status, 409)
  assert.equal(error.code, 'submission_exists')
  assert.equal(error.detail.code, 'submission_exists')
  assert.equal(error.detail.session_id, 42, 'payload fields must survive for the page to resume the record')
  assert.match(error.message, /已有本案例推演记录/)
})

test('422 array detail still falls back to the generic Chinese message', async () => {
  const intercept = loadTransport()
  const error = await intercept(failure(422, [{ loc: ['body', 'student_name'], msg: 'field required' }]))
  assert.equal(error.status, 422)
  assert.equal(error.code, undefined, 'validation errors carry no business code')
  assert.equal(error.message, '请求参数不符合要求，请检查输入内容')
})

test('string detail and network failures keep their previous copy', async () => {
  const intercept = loadTransport()
  assert.equal((await intercept(failure(409, '案例已下架'))).message, '案例已下架')
  assert.equal((await intercept(failure(500, undefined))).message, '请求失败（HTTP 500）')
  assert.equal((await intercept({ config: {} })).message, '无法连接后端服务，请确认本地后端端口已启动')
})
