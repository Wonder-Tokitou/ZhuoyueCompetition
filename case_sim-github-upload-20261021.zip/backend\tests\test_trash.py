"""案例回收站契约测试：软删除 / 恢复 / 彻底删除 / 学生端可见性 / 归属隔离。"""
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker

from backend.app import models
from backend.app.db import Base
from backend.app.db import get_db
from backend.app.main import app
from backend.app.routers import teacher
from backend.app.seed import seed_demo_case


@pytest.fixture()
def env(tmp_path, monkeypatch):
    engine = create_engine(f"sqlite:///{tmp_path / 'trash.db'}", connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine)
    factory = sessionmaker(bind=engine, autoflush=False, autocommit=False)

    def override_db():
        with factory() as db:
            yield db

    app.dependency_overrides[get_db] = override_db
    monkeypatch.setenv("TEACHER_PASSWORD", "admin-secret")
    monkeypatch.setattr(teacher, "schedule_task", lambda _: None)
    monkeypatch.setattr(teacher, "QRCODE_DIR", tmp_path / "qrcode")
    client = TestClient(app)
    from backend.tests.account_helpers import login_student
    login_student(client, factory)
    yield client, factory
    app.dependency_overrides.clear()
    client.close()
    engine.dispose()


def _register(client, username="teacher_a", real_name="张老师"):
    resp = client.post("/api/teacher/register", json={
        "username": username, "real_name": real_name, "password": "teacher-pass", "admin_password": "admin-secret",
    })
    assert resp.status_code == 200, resp.text


def _login(client, username="teacher_a", password="teacher-pass"):
    return client.post("/api/teacher/login", json={"username": username, "password": password})


def _token(client, username="teacher_a", password="teacher-pass"):
    resp = _login(client, username, password)
    assert resp.status_code == 200, resp.text
    return resp.json()["teacher_token"]


def _make_publishable(factory, teacher_id=1, status="ready"):
    with factory() as db:
        case = seed_demo_case(db)
        case.status = status
        case.published_at = None
        case.library_scope = "school"
        case.teacher_id = teacher_id
        db.commit()
        return case.id, case.student_token


def _publish(client, token, case_id):
    resp = client.post(f"/api/cases/{case_id}/publish", params={"token": token, "scope": "school"})
    assert resp.status_code == 200, resp.text


def test_delete_moves_to_trash_and_hides_from_all_lists(env):
    client, factory = env
    _register(client)
    token = _token(client)
    case_id, student_token = _make_publishable(factory)
    _publish(client, token, case_id)

    # 发布后学生端可见、推演链接可用
    assert client.get("/api/student/cases").json()[0]["id"] == case_id
    assert client.get(f"/api/play/{student_token}").status_code == 200
    # 学生推演一次，留下记录
    started = client.post(f"/api/play/{student_token}/sessions", json={"student_name": "student"})
    assert started.status_code == 200

    # 删除 → 移入回收站
    assert client.delete(f"/api/cases/{case_id}", params={"token": token}).status_code == 200
    trash = client.get("/api/cases/trash", params={"token": token}).json()
    assert [row["id"] for row in trash] == [case_id]
    assert [row["id"] for row in client.get("/api/cases", params={"token": token}).json()] == []
    # 学生端：校案例库不含、推演链接失效、历史记录不可继续
    assert client.get("/api/student/cases").json() == []
    assert client.get(f"/api/play/{student_token}").status_code == 404
    record = client.get("/api/student/records").json()[0]
    assert record["available"] is False


def test_restore_brings_case_back_fully(env):
    client, factory = env
    _register(client)
    token = _token(client)
    case_id, student_token = _make_publishable(factory)
    _publish(client, token, case_id)
    assert client.delete(f"/api/cases/{case_id}", params={"token": token}).status_code == 200

    assert client.post(f"/api/cases/{case_id}/restore", params={"token": token}).status_code == 200
    assert client.get("/api/cases/trash", params={"token": token}).json() == []
    assert [row["id"] for row in client.get("/api/cases", params={"token": token}).json()] == [case_id]
    # 恢复后学生端立即可见、推演链接恢复
    assert client.get("/api/student/cases").json()[0]["id"] == case_id
    assert client.get(f"/api/play/{student_token}").status_code == 200
    with factory() as db:
        assert db.get(models.Case, case_id).deleted_at is None


def test_purge_hard_deletes_case_and_related_rows(env):
    client, factory = env
    _register(client)
    token = _token(client)
    case_id, _ = _make_publishable(factory)
    _publish(client, token, case_id)
    assert client.delete(f"/api/cases/{case_id}", params={"token": token}).status_code == 200

    assert client.delete(f"/api/cases/{case_id}/purge", params={"token": token}).status_code == 200
    assert client.get("/api/cases/trash", params={"token": token}).json() == []
    with factory() as db:
        assert db.get(models.Case, case_id) is None
        assert db.scalars(select(models.Node).where(models.Node.case_id == case_id)).all() == []
    # 彻底删除后再次恢复/访问一律 404
    assert client.post(f"/api/cases/{case_id}/restore", params={"token": token}).status_code == 404
    assert client.delete(f"/api/cases/{case_id}/purge", params={"token": token}).status_code == 404


def test_trash_respects_teacher_ownership(env):
    client, factory = env
    _register(client)
    _register(client, "teacher_b", "李老师")
    token_a = _token(client)
    token_b = _token(client, "teacher_b")
    case_id, _ = _make_publishable(factory, teacher_id=1)
    assert client.delete(f"/api/cases/{case_id}", params={"token": token_a}).status_code == 200

    # 教师 B 看不到 A 回收站里的案例，也不能恢复/彻底删除
    assert client.get("/api/cases/trash", params={"token": token_b}).json() == []
    assert client.post(f"/api/cases/{case_id}/restore", params={"token": token_b}).status_code == 404
    assert client.delete(f"/api/cases/{case_id}/purge", params={"token": token_b}).status_code == 404
    # 教师 A 仍可恢复
    assert client.post(f"/api/cases/{case_id}/restore", params={"token": token_a}).status_code == 200


def test_legacy_global_token_operates_trash(env):
    """历史全局口令令牌可查看/操作回收站（含无归属案例）。"""
    client, factory = env
    _register(client)
    case_id, _ = _make_publishable(factory, teacher_id=1)
    legacy = client.post("/api/teacher/login", json={"password": "admin-secret"})
    legacy_token = legacy.json()["teacher_token"]
    assert client.delete(f"/api/cases/{case_id}", params={"token": legacy_token}).status_code == 200
    assert [row["id"] for row in client.get("/api/cases/trash", params={"token": legacy_token}).json()] == [case_id]
    assert client.post(f"/api/cases/{case_id}/restore", params={"token": legacy_token}).status_code == 200
