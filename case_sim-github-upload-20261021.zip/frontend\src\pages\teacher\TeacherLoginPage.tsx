import { useState } from 'react'
import { Alert, Button, Card, Form, Input, Typography } from 'antd'
import { useNavigate } from 'react-router-dom'
import { loginTeacher } from '../../api/client'

/**
 * 教师登录：不同教师使用各自的用户名 + 密码。
 * 留空用户名时按历史全局口令（TEACHER_PASSWORD）登录，兼容旧部署。
 */
export default function TeacherLoginPage() {
  const navigate = useNavigate()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  async function submit(values: { username?: string; password: string }) {
    setLoading(true); setError('')
    try {
      const result = await loginTeacher(values.username?.trim() ? { username: values.username.trim(), password: values.password } : { password: values.password })
      sessionStorage.setItem('teacher_token', result.teacher_token)
      navigate('/teacher', { replace: true })
    } catch (e) { setError(e instanceof Error ? e.message : '登录失败') }
    finally { setLoading(false) }
  }
  return <Card title="教师登录" style={{ maxWidth: 420, margin: '80px auto' }}>
    <Form onFinish={submit} layout="vertical">
      <Form.Item label="用户名" name="username" tooltip="多教师账号模式下使用各自的账号；留空则按全局访问口令登录">
        <Input autoComplete="username" placeholder="教师账号（可留空）" />
      </Form.Item>
      <Form.Item label="密码 / 访问口令" name="password" rules={[{ required: true, message: '请输入密码' }]}>
        <Input.Password autoFocus autoComplete="current-password" />
      </Form.Item>
      {error && <Typography.Text type="danger">{error}</Typography.Text>}
      <Button type="primary" htmlType="submit" loading={loading} block>登录</Button>
    </Form>
    <Typography.Paragraph type="secondary" style={{ marginTop: 12, marginBottom: 0 }}>
      首次启用多教师账号：请联系管理员用管理口令创建账号后，使用用户名登录。
    </Typography.Paragraph>
  </Card>
}
