/**
 * CG 演出（阶段 6 实现）。
 * 淡入 300ms → 停留 2s → 淡出 300ms；点击任意位置立即结束（300ms 淡出）。
 * prefers-reduced-motion：直接显示 1s 后切走（无动画）。
 * 用 CSS 渐变 + 标题模拟 CG 画面（项目无真实 CG 素材）。
 */
import { useEffect, useRef, useState } from 'react'

export interface CGOverlayProps {
  /** 短 id：'opening' | 'rush' | 'ending.success' … */
  cgId: string
  label: string
  onDone: () => void
}

const reduce =
  typeof window !== 'undefined' && !!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches

export default function CGOverlay({ cgId, label, onDone }: CGOverlayProps) {
  const [visible, setVisible] = useState(false)
  const [fading, setFading] = useState(false)
  const doneRef = useRef(false)

  useEffect(() => {
    if (reduce) {
      const t = window.setTimeout(() => {
        if (!doneRef.current) {
          doneRef.current = true
          onDone()
        }
      }, 1000)
      return () => window.clearTimeout(t)
    }
    const raf = requestAnimationFrame(() => setVisible(true))
    const t1 = window.setTimeout(() => setFading(true), 2300)
    const t2 = window.setTimeout(() => {
      if (!doneRef.current) {
        doneRef.current = true
        onDone()
      }
    }, 2600)
    return () => {
      cancelAnimationFrame(raf)
      window.clearTimeout(t1)
      window.clearTimeout(t2)
    }
  }, [onDone])

  function skip() {
    if (doneRef.current) return
    doneRef.current = true
    setFading(true)
    window.setTimeout(onDone, 300)
  }

  return (
    <div
      className={`galgame-cg is-${cgId.replace(/\./g, '-')}${visible ? ' is-visible' : ''}${fading ? ' is-fading' : ''}`}
      onClick={skip}
      role="img"
      aria-label={`${label}，点击任意位置跳过`}
    >
      <span className="galgame-cg-label">{label}</span>
    </div>
  )
}
