/**
 * 阶段 6（FAB 气泡化）取证脚本：验证 🤖 气泡、FAB 主色/hover、面板圆角底色、开关行为一致。
 *
 * 用法：
 *   node _stage6_probe.cjs --token <token> --session <id> [--name stage-6] [--outdir ..]
 *
 * 取证点：
 *   1. FAB 是否为 🤖 气泡（.tutor-fab-face）、背景 #db2777、位置 right16/bottom80、56×56、aria-label
 *   2. hover：背景 #be185d + translateY(-2px)
 *   3. 面板：圆角 16px、底色 #FFFFFF、阴影 var(--student-shadow-card-hover)、head/body 底色
 *   4. 展开 → 关闭 → 再展开，行为与改造前一致
 *   5. 375px 无横向溢出；decision-submit 不被 FAB 遮挡
 */
const { spawn } = require('node:child_process')
const fs = require('node:fs')
const os = require('node:os')
const path = require('node:path')

const CHROME = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
const PORT = 9338
const BASE = 'http://127.0.0.1:8110'
const CASE_TOKEN = 'benchmark-demo-v4'

function arg(name, fallback) {
  const i = process.argv.indexOf(`--${name}`)
  return i >= 0 && process.argv[i + 1] ? process.argv[i + 1] : fallback
}
const TOKEN = arg('token')
const SESSION = arg('session')
const NAME = arg('name', 'stage-6')
const WIDTH = Number(arg('width', 375))
const HEIGHT = Number(arg('height', 812))
const OUTDIR = path.resolve(arg('outdir', path.join(__dirname, '..')))
if (!TOKEN) { console.error('missing --token'); process.exit(2) }

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

async function browserWs() {
  for (let i = 0; i < 60; i++) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/version`)
      const json = await res.json()
      if (json.webSocketDebuggerUrl) return json.webSocketDebuggerUrl
    } catch { /* 未就绪 */ }
    await sleep(250)
  }
  throw new Error('chrome 调试端口未就绪')
}

function client(ws) {
  let id = 0
  const waiting = new Map()
  ws.addEventListener('message', (ev) => {
    const msg = JSON.parse(ev.data)
    if (msg.id && waiting.has(msg.id)) {
      const { resolve, reject } = waiting.get(msg.id)
      waiting.delete(msg.id)
      msg.error ? reject(new Error(JSON.stringify(msg.error))) : resolve(msg.result)
      return
    }
  })
  return (method, params = {}, sessionId) => new Promise((resolve, reject) => {
    const mid = ++id
    waiting.set(mid, { resolve, reject })
    ws.send(JSON.stringify({ id: mid, method, params, ...(sessionId ? { sessionId } : {}) }))
  })
}

const PROBE_FAB = `(() => {
  const fab = document.querySelector('.ant-float-btn-primary')
  const rect = fab ? fab.getBoundingClientRect() : null
  const face = fab ? fab.querySelector('.tutor-fab-face') : null
  const cs = fab ? getComputedStyle(fab) : null
  const submit = document.querySelector('.decision-submit')
  const sr = submit ? submit.getBoundingClientRect() : null
  let overlap = null
  if (fab && rect && sr) {
    overlap = !(rect.right < sr.left || rect.left > sr.right || rect.bottom < sr.top || rect.top > sr.bottom)
  }
  return {
    found: !!fab,
    hasFace: !!face,
    faceText: face ? face.textContent : null,
    faceFontSize: face ? getComputedStyle(face).fontSize : null,
    bg: cs ? cs.backgroundColor : null,
    transform: cs ? cs.transform : null,
    width: rect ? Math.round(rect.width) : null,
    height: rect ? Math.round(rect.height) : null,
    distRight: rect ? Math.round(window.innerWidth - rect.right) : null,
    distBottom: rect ? Math.round(window.innerHeight - rect.bottom) : null,
    ariaLabel: fab ? fab.getAttribute('aria-label') : null,
    tooltip: fab ? fab.getAttribute('aria-describedby') || fab.getAttribute('title') : null,
    submitRect: sr ? { top: Math.round(sr.top), bottom: Math.round(sr.bottom) } : null,
    fabOverlapsSubmit: overlap,
    overflow: { scrollWidth: document.documentElement.scrollWidth, clientWidth: document.documentElement.clientWidth },
  }
})()`

const PROBE_PANEL = `(() => {
  const panel = document.querySelector('.student-tutor-panel')
  const head = panel ? panel.querySelector('.student-tutor-panel-head') : null
  const body = panel ? panel.querySelector('.student-tutor-panel-body') : null
  const cs = panel ? getComputedStyle(panel) : null
  const hcs = head ? getComputedStyle(head) : null
  const bcs = body ? getComputedStyle(body) : null
  return {
    panelFound: !!panel,
    role: panel ? panel.getAttribute('role') : null,
    radiusTL: cs ? cs.borderTopLeftRadius : null,
    radiusTR: cs ? cs.borderTopRightRadius : null,
    radiusBL: cs ? cs.borderBottomLeftRadius : null,
    radiusBR: cs ? cs.borderBottomRightRadius : null,
    bg: cs ? cs.backgroundColor : null,
    shadow: cs ? cs.boxShadow : null,
    headBg: hcs ? hcs.backgroundColor : null,
    bodyBg: bcs ? bcs.backgroundColor : null,
  }
})()`

const CLICK_FAB = `(() => { const b = document.querySelector('.ant-float-btn-primary'); if (b) { b.click(); return true } return false })()`
const CLICK_CLOSE = `(() => { const b = document.querySelector('.student-tutor-panel-head .ant-btn'); if (b) { b.click(); return true } return false })()`

;(async () => {
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'stage6-chrome-'))
  const chrome = spawn(CHROME, [
    '--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
    '--no-proxy-server', '--hide-scrollbars', '--force-device-scale-factor=2',
    `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`, 'about:blank',
  ], { stdio: 'ignore' })

  try {
    const wsUrl = await browserWs()
    const ws = new WebSocket(wsUrl)
    await new Promise((res, rej) => { ws.addEventListener('open', res); ws.addEventListener('error', rej) })
    const send = client(ws)
    const { targetId } = await send('Target.createTarget', { url: 'about:blank' })
    const { sessionId } = await send('Target.attachToTarget', { targetId, flatten: true })
    const call = (m, p) => send(m, p, sessionId)

    await call('Page.enable')
    await call('Runtime.enable')
    await call('Emulation.setDeviceMetricsOverride', { width: WIDTH, height: HEIGHT, deviceScaleFactor: 2, mobile: WIDTH < 500 })
    await call('Page.addScriptToEvaluateOnNewDocument', {
      source: [
        `try { sessionStorage.setItem('student_access_token', ${JSON.stringify(TOKEN)}) } catch (e) {}`,
        SESSION ? `try { sessionStorage.setItem('student_session:${CASE_TOKEN}', ${JSON.stringify(SESSION)}) } catch (e) {}` : '',
      ].join('\n'),
    })
    await call('Page.navigate', { url: `${BASE}/student/${CASE_TOKEN}` })
    await sleep(4500)

    const ev = async (expr) => {
      const raw = await call('Runtime.evaluate', { expression: expr, returnByValue: true })
      if (raw.exceptionDetails) throw new Error(JSON.stringify(raw.exceptionDetails))
      return raw.result.value
    }
    const shot = async (name) => {
      const s = await call('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false, fromSurface: true })
      const file = path.join(OUTDIR, `${name}.png`)
      fs.writeFileSync(file, Buffer.from(s.data, 'base64'))
      return `${file} BYTES=${fs.statSync(file).size}`
    }

    const idle = await ev(PROBE_FAB)
    const shotIdle = await shot(`${NAME}-fab-idle`)

    // hover：移到 FAB 中心
    let hover = null
    if (idle.found && idle.width && idle.height) {
      const r = await ev(`(() => { const b = document.querySelector('.ant-float-btn-primary').getBoundingClientRect(); return { x: Math.round(b.left + b.width / 2), y: Math.round(b.top + b.height / 2) } })()`)
      await call('Input.dispatchMouseEvent', { type: 'mouseMoved', x: r.x, y: r.y })
      await sleep(400)
      hover = await ev(`(() => { const b = document.querySelector('.ant-float-btn-primary'); const cs = getComputedStyle(b); return { bg: cs.backgroundColor, transform: cs.transform } })()`)
    }

    // 展开面板
    const opened = await ev(CLICK_FAB)
    await sleep(1200)
    const panel = await ev(PROBE_PANEL)
    const shotOpen = await shot(`${NAME}-fab-open`)

    // 关闭 → 面板消失
    const closed = await ev(CLICK_CLOSE)
    await sleep(800)
    const panelAfterClose = await ev(PROBE_PANEL)

    // 再展开 → 行为一致
    const reopened = await ev(CLICK_FAB)
    await sleep(1200)
    const panelAfterReopen = await ev(PROBE_PANEL)

    console.log(JSON.stringify({
      idle, hover, opened, panel, closed, panelAfterClose, reopened, panelAfterReopen,
      shots: { idle: shotIdle, open: shotOpen },
    }, null, 2))
    ws.close()
  } finally {
    chrome.kill()
  }
})().catch((e) => { console.error('FAILED:', e.message); process.exit(1) })
