# 并发基线（Gate A / C9 压测结果）

生成时间：2026-10-21（阶段 13 全量回归 · 只读验收）
压测工具：`scripts/loadtest/loadtest.py`（新增，只加文件不装依赖；httpx + asyncio）

## 环境

| 项 | 值 |
| --- | --- |
| 隔离库 | `backend/data/loadtest.db`（每次运行从 app.db 用 SQLite backup API 重建，绝不动 app.db） |
| 独立实例 | uvicorn `backend.app.main:app`，端口 **8113**，workers=1，`DATABASE_URL=sqlite:///…/loadtest.db` |
| DB 配置 | SQLite WAL、synchronous=NORMAL、busy_timeout=10s；连接池 pool_size=10 + max_overflow=10（**设计口径：1 教师 + 10 学生，即 11 并发**，见 `backend/app/db.py`） |
| 压测账号 | 每档重建 users 个 `loadtest-u{i}` 学生（确定性令牌） |
| 场景定义 | read = `GET /api/play/{case}`；write = `POST /sessions` 首建 + 循环 `POST /sessions/{id}/reset`；mixed = 3:1（read:write） |
| 端口说明 | 清单原定 8112，实测该端口被 WorkBuddy 遗留实例（PID 16636，09:28 启动，连 app.db）占用；压测改用 8113 并加端口预检，防止误压其它实例 |

## 四档原始数字（mixed，3:1 读:写）

| 并发 | 时长(s) | 请求数 | RPS | p50(ms) | p95(ms) | p99(ms) | 错误率 | 错误构成 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 10 | 60 | 7,064 | 117.7 | 65.1 | 105.0 | 122.2 | 0% | 无 |
| 50 | 120 | 13,349 | 111.2 | 433.5 | 501.7 | 530.0 | **0%** | 无 |
| 100 | 60 | 200 | 3.3 | 30,196 | 30,277 | 30,282 | 100% | `exc:ReadTimeout` ×200（连接池 20 < 并发 100，等池 30s 超时） |
| 200 | 60 | 399 | 6.7 | 30,789 | 31,434 | 31,873 | 100% | `exc:PoolTimeout`×196、`exc:ReadTimeout`×199、`http5xx`×5 |

## 50 并发分场景（Gate A DoD 判据）

| 场景 | 时长(s) | 请求数 | RPS | p50(ms) | p95(ms) | p99(ms) | 错误率 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| read-only | 60 | 8,700 | 145.0 | 322.0 | **343.2** | 392.3 | 0% |
| write-only | 60 | 4,014 | 66.9 | 746.2 | **808.3** | 898.5 | 0% |

### Gate A DoD 判定

| DoD 项 | 要求 | 实测 | 判定 |
| --- | --- | --- | --- |
| 50 并发混合错误率 | 0% | 0%（无 5xx / 无 QueuePool timeout / 无 database is locked） | ✅ |
| 读 p95 | ≤300ms | 343.2ms（超出 +43.2ms） | ❌ |
| 写 p95 | ≤600ms | 808.3ms（超出 +208.3ms） | ❌ |

**超阈根因（非缺陷，属口径外负载）**：db.py 连接池按 11 并发（1 教师 + 10 学生）设计（pool 10+10）；50 并发已超设计口径 4.5 倍，延迟主要来自连接池排队与 SQLite 单写锁。错误率全程 0、无锁死异常，说明系统在口径外仍稳定、无回归。上线如需支撑 ≥50 并发，建议按部署规模上调 `POOL_SIZE`（并考虑多 worker / 独立库）后重测；本次为只读回归，未改任何配置。

**200 档失败形态**：连接池（10+10）耗尽 → 等池 30s 超时（PoolTimeout）→ httpx 30s 读超时；少量 `http5xx`（5 次）为 SQLite 锁竞争概率性 500。服务未崩溃，实例可正常停止。

## 一次完整推演（3 轮）请求总数

CDP 实测（`tools/_stage5_full_round.cjs`，真实 3 轮决策提交，Network 全量统计）：

| 接口 | 次数 |
| --- | --- |
| `GET /api/student/me` | 1 |
| `GET /api/play/{case}/sessions/{id}` | 4（首屏加载 + 轮间状态恢复） |
| `POST /api/play/{case}/decide` | 3（每轮 1 次提交） |
| **合计** | **8 次** |

无 SSE/chat 请求、无轮询、无随轮次增长的进度请求（RoundMap 不自行拉数据，stage-5 断言）。

**“请求数不高于改造前基线”判定**：改造前（阶段 0 基线盘点 `BASELINE.md`）未记录请求数历史值，无法做数值对比。代码级证据：阶段 2–8 全部为视觉/CSS/气泡与教师 KPI 展示改造，**未新增任何数据请求、轮询或接口调用逻辑**（FAB 面板复用既有 records 接口、KPI 聚合替换占位数据），推演请求链（me + sessions + decide）完全未动。因此“一次完整推演请求总数不高于改造前”在架构上成立，当前实测 **8 次**记录为回归基线。

## 结论

- Gate A 错误率硬性项通过；延迟阈值在 50 并发（超设计口径 4.5 倍）下未达标，瓶颈已定位为连接池配置，非本次改造引入的回归。
- 四档原始数字与 200 档失败形态如上，如实记录。
