/**
 * 学生端复盘可视化：5 维度雷达图 + 3 轮净利润对比折线图。
 * ECharts 按需引入：只注册用到的图表、组件与 Canvas 渲染器，禁止 `import * as echarts from 'echarts'` 全量引入。
 * 轻量封装模式与 src/pages/teacher/components/OptionDistributionChart.tsx 一致（init / setOption / resize / dispose）。
 * 数据来源：
 *  - 折线图：优先使用复盘接口 path_comparison.rounds 中每轮 student_metrics / reference_metrics 的 net_profit（真实数据）；
 *    缺失或非数字时回退 mock（见 NET_PROFIT_MOCK_*，已标注 TODO）。
 *  - 雷达图：ReviewResponse 暂无维度分数字段，使用 mock 占位（见 DIMENSION_SCORES_MOCK，已标注 TODO），
 *    待后端在复盘响应中下发 dimension_scores 后接入。
 */
import { useEffect, useRef } from 'react'
import * as echarts from 'echarts/core'
import { LineChart, RadarChart } from 'echarts/charts'
import { GridComponent, LegendComponent, TitleComponent, TooltipComponent } from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'
import type { EChartsOption } from 'echarts'
import type { ReviewResponse } from '../../api/types'

echarts.use([RadarChart, LineChart, GridComponent, TooltipComponent, LegendComponent, TitleComponent, CanvasRenderer])

/** 轻量 ECharts React 封装：挂载时 init，option 变化时 setOption，卸载时 dispose，窗口 resize 时自适应。 */
function EChart({ option, height }: { option: EChartsOption; height: number }) {
  const elRef = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const el = elRef.current
    if (!el) return
    const chart = echarts.init(el)
    chart.setOption(option)
    const onResize = () => chart.resize()
    window.addEventListener('resize', onResize)
    return () => {
      window.removeEventListener('resize', onResize)
      chart.dispose()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- 仅在挂载时 init 一次
  }, [])
  useEffect(() => {
    const el = elRef.current
    if (!el) return
    const chart = echarts.getInstanceByDom(el)
    if (chart) chart.setOption(option)
  }, [option])
  return <div ref={elRef} style={{ height, width: '100%' }} />
}

// TODO: 待后端在复盘响应增加维度分数（如 dimension_scores: { name, score }[]），以下为 mock 占位数据。
export const DIMENSION_SCORES_MOCK = [
  { name: '营收能力', value: 82 },
  { name: '市场份额', value: 75 },
  { name: '成本控制', value: 68 },
  { name: '风险应对', value: 90 },
  { name: '战略执行', value: 78 },
]

export interface RadarScoreChartProps {
  /** 后端下发维度分数后传入；缺省用 mock（TODO）。 */
  scores?: { name: string; value: number }[]
  height?: number
}

/** 5 维度综合能力雷达图：营收能力 / 市场份额 / 成本控制 / 风险应对 / 战略执行，每维 max=100。 */
export function RadarScoreChart({ scores = DIMENSION_SCORES_MOCK, height = 280 }: RadarScoreChartProps) {
  const option: EChartsOption = {
    tooltip: {},
    legend: { data: ['综合得分'], bottom: 0, itemWidth: 14, itemHeight: 10 },
    radar: {
      indicator: scores.map((s) => ({ name: s.name, max: 100 })),
      // 修复：窄容器下 5 个 4 字维度名在圆周上相邻标签（顶部 90° 与 18°/162°）会水平重叠。
      // ① radius 由 62% 缩至 55%，外圈标签留出更多空间；
      // ② axisName.formatter 把 4 字维度名拆成 2+2 两行（如"营收能力"→"营收/能力"），
      //    水平跨度减半且纵向错开，相邻标签不再互相挤压。
      radius: '55%',
      axisName: {
        color: '#1a3a5c',
        fontSize: 11,
        formatter: (name?: string) => {
          const n = name ?? ''
          return n.length > 3 ? `${n.slice(0, 2)}\n${n.slice(2)}` : n
        },
      },
      splitLine: { lineStyle: { color: '#dbe4ee' } },
      splitArea: { areaStyle: { color: ['rgba(26, 58, 92, 0.03)', 'rgba(26, 58, 92, 0.07)'] } },
      axisLine: { lineStyle: { color: '#dbe4ee' } },
    },
    series: [
      {
        type: 'radar',
        data: [
          {
            value: scores.map((s) => s.value),
            name: '综合得分',
            areaStyle: { color: 'rgba(26, 58, 92, 0.25)' },
            lineStyle: { color: '#1a3a5c', width: 2 },
            itemStyle: { color: '#1a3a5c' },
          },
        ],
      },
    ],
  }
  return (
    <div style={{ width: '100%' }}>
      <EChart option={option} height={height} />
    </div>
  )
}

// TODO: 待后端在复盘接口补齐每轮净利润时自动切换真实数据；以下为 mock 占位数据（万元）。
export const NET_PROFIT_MOCK_MINE = [12, 18, 26]
export const NET_PROFIT_MOCK_REF = [15, 20, 24]

export interface RoundLineChartProps {
  /** 复盘接口的路径对比（含每轮学生/参考指标）；缺省或数据不全时回退 mock（TODO）。 */
  pathComparison?: ReviewResponse['path_comparison']
  height?: number
}

/** 3 轮净利润对比折线图：我的路径（深蓝 #1a3a5c）vs 标杆路径（玫红 #db2777）。 */
export function RoundLineChart({ pathComparison, height = 220 }: RoundLineChartProps) {
  const rounds = pathComparison?.rounds ?? []
  const mine = rounds.map((r) => Number(r.student_metrics.net_profit)).filter((n) => Number.isFinite(n))
  const ref = rounds.map((r) => Number(r.reference_metrics.net_profit)).filter((n) => Number.isFinite(n))
  const useReal = rounds.length > 0 && mine.length === rounds.length && ref.length === rounds.length
  const labels = useReal ? rounds.map((r) => `第 ${r.round} 轮`) : ['第 1 轮', '第 2 轮', '第 3 轮']
  const mineData = useReal ? mine : NET_PROFIT_MOCK_MINE
  const refData = useReal ? ref : NET_PROFIT_MOCK_REF
  const option: EChartsOption = {
    tooltip: { trigger: 'axis' },
    // 修复：图例原先 bottom:0 与 X 轴"第 N 轮"标签在同一高度水平重叠（"我的路径/标杆路径"挤成一团）。
    // 改为置顶（top:4, left:center）+ 圆点图例图标，X 轴标签独占底部，两条折线的标识互不遮挡。
    legend: { data: ['我的路径', '标杆路径'], top: 4, left: 'center', icon: 'circle', itemWidth: 14, itemHeight: 10, itemGap: 28 },
    grid: { left: 8, right: 8, top: 40, bottom: 8, containLabel: true },
    xAxis: { type: 'category', boundaryGap: false, data: labels },
    yAxis: { type: 'value', name: '净利润（万元）', nameTextStyle: { color: 'rgba(0,0,0,0.45)', fontSize: 11 }, splitLine: { lineStyle: { color: '#eef2f6' } } },
    series: [
      { name: '我的路径', type: 'line', smooth: true, symbol: 'circle', symbolSize: 6, data: mineData, lineStyle: { color: '#1a3a5c', width: 2 }, itemStyle: { color: '#1a3a5c' } },
      { name: '标杆路径', type: 'line', smooth: true, symbol: 'circle', symbolSize: 6, data: refData, lineStyle: { color: '#db2777', width: 2 }, itemStyle: { color: '#db2777' } },
    ],
  }
  return (
    <div style={{ width: '100%' }}>
      <EChart option={option} height={height} />
    </div>
  )
}

export default RadarScoreChart
