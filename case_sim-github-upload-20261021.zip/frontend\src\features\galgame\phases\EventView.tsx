import RandomEventPopup from '../components/RandomEventPopup'
import CGOverlay from '../components/CGOverlay'
import type { RandomEvent } from '../data/randomEvents'

/** 覆盖层：随机事件弹窗 / CG 演出 / 成就提示条。 */
export default function EventView({
  eventPopup,
  cg,
  toast,
  onCloseEvent,
  onDoneCg,
}: {
  eventPopup: RandomEvent | null
  cg: { id: string; label: string } | null
  toast: string
  onCloseEvent: () => void
  onDoneCg: () => void
}) {
  return (
    <>
      {eventPopup && (
        <RandomEventPopup title={eventPopup.title} text={eventPopup.text} onClose={onCloseEvent} />
      )}
      {cg && <CGOverlay cgId={cg.id} label={cg.label} onDone={onDoneCg} />}
      {toast && <div className="galgame-toast" role="status">{toast}</div>}
    </>
  )
}
