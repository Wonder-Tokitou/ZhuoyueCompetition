/**
 * galgame · practice 模式隔离单测（P0-fix 配套）。
 * 覆盖：modeFromUrl 回落、session 键隔离（practice 不碰 sessionStorage）、
 *       formal 写 sessionStorage、EndingView 复盘链接仅 formal 可见、门禁存在。
 * 可单独运行：node --test tests/galgame-practice.test.cjs
 */
const { test } = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const vm = require('node:vm')
const ts = require('typescript')

function makeStorage() {
  const m = new Map()
  return {
    getItem: (k) => (m.has(k) ? m.get(k) : null),
    setItem: (k, v) => { m.set(k, String(v)) },
    removeItem: (k) => { m.delete(k) },
    _map: m,
  }
}

/** 加载 engine/session.ts，注入可替换的 localStorage / sessionStorage / window.location.search。 */
function loadSessionModule(search) {
  const exports = {}
  const source = fs.readFileSync(path.resolve(__dirname, '../src/features/galgame/engine/session.ts'), 'utf8')
  const localStorage = makeStorage()
  const sessionStorage = makeStorage()
  const window = { location: { search } }
  vm.runInNewContext(
    ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText,
    { exports, require: () => ({}), localStorage, sessionStorage, window, URLSearchParams }
  )
  return { exports, localStorage, sessionStorage }
}

// a. modeFromUrl：?mode=practice → practice；空 / bogus → formal
test('modeFromUrl: ?mode=practice 返回 practice；空与 ?mode=bogus 返回 formal', () => {
  assert.equal(loadSessionModule('?mode=practice').exports.modeFromUrl(), 'practice')
  assert.equal(loadSessionModule('').exports.modeFromUrl(), 'formal')
  assert.equal(loadSessionModule('?mode=bogus').exports.modeFromUrl(), 'formal')
})

// b. readSessionId(practice) 只读 localStorage 专用键
test('readSessionId(practice) 只读 localStorage[galgame_session:<token>:practice]，键缺失返回 null', () => {
  const { exports, localStorage, sessionStorage } = loadSessionModule('')
  assert.equal(exports.readSessionId('tok1', 'practice'), null)
  localStorage.setItem('galgame_session:tok1:practice', '123')
  assert.equal(exports.readSessionId('tok1', 'practice'), 123)
  // sessionStorage 里的 student_session 不应影响 practice 读取
  sessionStorage.setItem('student_session:tok1', '999')
  assert.equal(exports.readSessionId('tok1', 'practice'), 123)
})

// c. persistSessionId(practice) 写 localStorage，绝不碰 sessionStorage
test('persistSessionId(practice) 写 localStorage 专用键，sessionStorage.student_session 仍为 null', () => {
  const { exports, localStorage, sessionStorage } = loadSessionModule('')
  exports.persistSessionId('tok2', 'practice', 123)
  assert.equal(localStorage.getItem('galgame_session:tok2:practice'), '123')
  assert.equal(sessionStorage.getItem('student_session:tok2'), null)
})

// d. persistSessionId(formal) 写 sessionStorage 两个键
test('persistSessionId(formal,456,"某同学") 写 sessionStorage 的 student_session 与 student_name', () => {
  const { exports, sessionStorage } = loadSessionModule('')
  exports.persistSessionId('tok3', 'formal', 456, '某同学')
  assert.equal(sessionStorage.getItem('student_session:tok3'), '456')
  assert.equal(sessionStorage.getItem('student_name:tok3'), '某同学')
})

// e. 静态断言：EndingView 里"查看 AI 复盘"必须出现在 mode === 'formal' 守卫之后
test('EndingView: "查看 AI 复盘" 首次出现位置在 mode === "formal" 之后', () => {
  const src = fs.readFileSync(path.resolve(__dirname, '../src/features/galgame/phases/EndingView.tsx'), 'utf8')
  const iGuard = src.indexOf("mode === 'formal'")
  const iReview = src.indexOf('查看 AI 复盘')
  assert.ok(iGuard >= 0, '源码必须包含 mode === "formal" 守卫')
  assert.ok(iReview >= 0, '源码必须包含"查看 AI 复盘"')
  assert.ok(iGuard < iReview, '"查看 AI 复盘" 必须被 mode === "formal" 条件包住（守卫在前）')
})

// f. 静态断言：useGalgameFlow 同时包含 unlockedRounds 与 act > unlockedRounds
test('useGalgameFlow: 同时包含 unlockedRounds 与 act > unlockedRounds 门禁判断', () => {
  const src = fs.readFileSync(path.resolve(__dirname, '../src/features/galgame/engine/useGalgameFlow.ts'), 'utf8')
  assert.ok(src.includes('unlockedRounds'), '必须包含 unlockedRounds')
  assert.ok(src.includes('act > unlockedRounds'), '必须包含 act > unlockedRounds 门禁')
})
