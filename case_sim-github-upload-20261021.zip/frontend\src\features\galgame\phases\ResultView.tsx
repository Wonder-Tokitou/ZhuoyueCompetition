import type { Metrics } from '../../../api/types'
import type { Affection } from '../engine/dialogueEngine'
import type { GameMode } from '../engine/session'

export interface SettlementData {
  round: number
  chosenLabel: string
  before: Metrics | null
  after: Metrics | null
  summary: string
  score: number
  breakdown: string[]
  deltas: Affection
  profitValue: number | null
  profitNote?: string
}

/** 结算卡：本轮结果 + 分项文案 + 分数 + 下一幕/查看结局按钮；P1-F3：practice 显示「练习局」角标。 */
export default function ResultView({
  settlement,
  finished,
  mode,
  onNext,
}: {
  settlement: SettlementData
  finished: boolean
  mode: GameMode
  onNext: () => void
}) {
  return (
    <div className="galgame-settlement">
      {mode === 'practice' && <p className="galgame-practice-badge">练习局</p>}
      <p className="galgame-settlement-title">第 {settlement.round} 轮结果 · {settlement.chosenLabel}</p>
      <p className="galgame-settlement-summary">{settlement.summary}</p>
      {settlement.after && (
        <dl className="galgame-metrics-grid">
          <div><dt>营收</dt><dd>{settlement.after.revenue} 万元</dd></div>
          <div><dt>毛利率</dt><dd>{settlement.after.gross_margin}</dd></div>
          <div><dt>市场份额</dt><dd>{settlement.after.market_share}</dd></div>
          <div><dt>现金流</dt><dd>{settlement.after.cash_flow}</dd></div>
          <div>
            <dt>净利润</dt>
            <dd>{settlement.profitValue === null ? '—' : `${settlement.profitValue.toFixed(2)} 万元`}</dd>
          </div>
        </dl>
      )}
      {settlement.profitNote && <p className="galgame-profit-note">{settlement.profitNote}</p>}
      <div className="galgame-settle-score">
        <span className="galgame-settle-score-label">本局分数</span>
        <span className="galgame-settle-score-value">{settlement.score}</span>
      </div>
      {settlement.breakdown.length > 0 && (
        <ul className="galgame-breakdown">
          {settlement.breakdown.map((line) => <li key={line}>{line}</li>)}
        </ul>
      )}
      <button type="button" className="galgame-confirm" onClick={onNext}>
        {finished ? '查看结局' : '进入下一幕'}
      </button>
    </div>
  )
}
