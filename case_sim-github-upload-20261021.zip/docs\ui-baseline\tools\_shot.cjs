/**
 * 阶段 0 · T0.5 辅助脚本：375px 宽度学生推演页截图 + 关键 computed style 取证
 * 只读：不写数据库、不改源码，产物只有传入的 png 与 stdout 的 JSON。
 *
 * 用法：
 *   node _shot.cjs --token <student_access_token> --session <session_id> --out baseline-375.png [--url ...]
 *
 * 依赖：Node 22 自带 WebSocket；本机 Chrome（--headless=new）。不需要 playwright。
 */
const { spawn } = require('node:child_process')
const fs = require('node:fs')
const os = require('node:os')
const path = require('node:path')

const CHROME = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
const PORT = 9333
const BASE = 'http://127.0.0.1:8110'
const CASE_TOKEN = 'benchmark-demo-v4'
const WIDTH = 375
const HEIGHT = 812

function arg(name, fallback) {
  const i = process.argv.indexOf(`--${name}`)
  return i >= 0 && process.argv[i + 1] ? process.argv[i + 1] : fallback
}

const TOKEN = arg('token')
const SESSION = arg('session')
const OUT = path.resolve(arg('out', 'baseline-375.png'))
const URL_ = arg('url', `${BASE}/student/${CASE_TOKEN}`)

if (!TOKEN) {
  console.error('missing --token')
  process.exit(2)
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

async function browserWs() {
  for (let i = 0; i < 60; i++) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/version`)
      const json = await res.json()
      if (json.webSocketDebuggerUrl) return json.webSocketDebuggerUrl
    } catch { /* 还没起来 */ }
    await sleep(250)
  }
  throw new Error('chrome 调试端口未就绪')
}

function client(ws) {
  let id = 0
  const waiting = new Map()
  ws.addEventListener('message', (ev) => {
    const msg = JSON.parse(ev.data)
    if (msg.id && waiting.has(msg.id)) {
      const { resolve, reject } = waiting.get(msg.id)
      waiting.delete(msg.id)
      msg.error ? reject(new Error(JSON.stringify(msg.error))) : resolve(msg.result)
    }
  })
  return (method, params = {}, sessionId) => new Promise((resolve, reject) => {
    const mid = ++id
    waiting.set(mid, { resolve, reject })
    ws.send(JSON.stringify({ id: mid, method, params, ...(sessionId ? { sessionId } : {}) }))
  })
}

;(async () => {
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'ui-baseline-chrome-'))
  const chrome = spawn(CHROME, [
    '--headless=new',
    '--disable-gpu',
    '--no-first-run',
    '--no-default-browser-check',
    '--no-proxy-server',
    '--hide-scrollbars',
    '--force-device-scale-factor=2',
    `--remote-debugging-port=${PORT}`,
    `--user-data-dir=${profile}`,
    'about:blank',
  ], { stdio: 'ignore' })

  try {
    const wsUrl = await browserWs()
    const ws = new WebSocket(wsUrl)
    await new Promise((res, rej) => { ws.addEventListener('open', res); ws.addEventListener('error', rej) })
    const send = client(ws)

    const { targetId } = await send('Target.createTarget', { url: 'about:blank' })
    const { sessionId } = await send('Target.attachToTarget', { targetId, flatten: true })
    const call = (m, p) => send(m, p, sessionId)

    await call('Page.enable')
    await call('Runtime.enable')
    await call('Emulation.setDeviceMetricsOverride', {
      width: WIDTH, height: HEIGHT, deviceScaleFactor: 2, mobile: true,
    })

    // 应用脚本读取 sessionStorage 里的登录令牌与会话号；在新文档最早时机注入
    const boot = [
      `try { sessionStorage.setItem('student_access_token', ${JSON.stringify(TOKEN)}) } catch (e) {}`,
      SESSION ? `try { sessionStorage.setItem('student_session:${CASE_TOKEN}', ${JSON.stringify(SESSION)}) } catch (e) {}` : '',
    ].join('\n')
    await call('Page.addScriptToEvaluateOnNewDocument', { source: boot })

    await call('Page.navigate', { url: URL_ })
    await sleep(4500)

    const probe = `(() => {
      const pick = (sel) => {
        const el = document.querySelector(sel)
        if (!el) return null
        const cs = getComputedStyle(el)
        return {
          radius: cs.borderTopLeftRadius,
          bg: cs.backgroundColor,
          border: cs.borderTopWidth + ' ' + cs.borderTopStyle + ' ' + cs.borderTopColor,
          shadow: cs.boxShadow,
          color: cs.color,
        }
      }
      const text = document.body.innerText.replace(/\\s+/g, ' ').slice(0, 600)
      return JSON.stringify({
        viewport: { width: innerWidth, height: innerHeight },
        overflow: { scrollWidth: document.documentElement.scrollWidth, clientWidth: document.documentElement.clientWidth },
        bodyClass: document.body.className,
        cardCount: document.querySelectorAll('.ant-card').length,
        metricsCount: document.querySelectorAll('.metric-card').length,
        optionCardCount: document.querySelectorAll('.strategy-option-card').length,
        styles: {
          body: pick('body.student-body'),
          header: pick('.student-header'),
          antCard: pick('.ant-card'),
          metricCard: pick('.metric-card'),
          metricValue: pick('.metric-value'),
          optionCard: pick('.strategy-option-card'),
          steps: pick('.ant-steps'),
          submit: pick('.decision-submit'),
          fab: pick('.ant-float-btn'),
        },
        text,
      })
    })()`
    const raw = await call('Runtime.evaluate', { expression: probe, returnByValue: true })
    const report = JSON.parse(raw.result.value)
    report.url = URL_
    report.authenticated = !report.text.includes('请先登录学生账号')
    report.hasNetProfit = report.text.includes('净利润')
    report.hasRiskPlaceholder = report.text.includes('风险待评估')
    report.hasRoundText = /第 \d+ \/ 3 轮|三轮推演已完成/.test(report.text)
    console.log(JSON.stringify(report, null, 2))

    const shot = await call('Page.captureScreenshot', {
      format: 'png', captureBeyondViewport: true, fromSurface: true,
    })
    fs.writeFileSync(OUT, Buffer.from(shot.data, 'base64'))
    console.log(`SAVED=${OUT} BYTES=${fs.statSync(OUT).size}`)
    ws.close()
  } finally {
    chrome.kill()
  }
})().catch((e) => { console.error('FAILED:', e.message); process.exit(1) })
