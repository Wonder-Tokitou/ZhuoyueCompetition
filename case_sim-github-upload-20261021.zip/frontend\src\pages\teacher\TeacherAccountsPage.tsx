import { useEffect, useState } from 'react'
import { Alert, App as AntdApp, Button, Card, Form, Input, Modal, Popconfirm, Space, Spin, Table, Tag, Typography } from 'antd'
import { createTeacherAccount, listTeacherAccounts, patchTeacherAccount } from '../../api/client'
import type { TeacherAccount } from '../../api/types'
import { useTeacherToken } from '../../context/TeacherTokenContext'

/**
 * 教师账号管理：不同教师各有独立账号（多账号体系）。
 * 已登录教师可为同事创建账号、改名、停用/启用、重置密码。
 */
export default function TeacherAccountsPage() {
  const teacherToken = useTeacherToken()
  const { message } = AntdApp.useApp()
  const [rows, setRows] = useState<TeacherAccount[] | null>(null)
  const [error, setError] = useState('')
  const [creating, setCreating] = useState(false)
  const [editing, setEditing] = useState<TeacherAccount | null>(null)
  const [resetTarget, setResetTarget] = useState<TeacherAccount | null>(null)

  const load = () => listTeacherAccounts(teacherToken)
    .then(setRows).catch((e) => setError(e instanceof Error ? e.message : '账号列表加载失败'))

  useEffect(() => {
    let active = true
    listTeacherAccounts(teacherToken).then((data) => { if (active) setRows(data) })
      .catch((e) => { if (active) setError(e instanceof Error ? e.message : '账号列表加载失败') })
    return () => { active = false }
  }, [teacherToken])

  return <Space direction="vertical" style={{ width: '100%' }}>
    <div className="teacher-page-head">
      <div>
        <Typography.Title level={3} style={{ margin: 0 }}>教师账号</Typography.Title>
        <Typography.Text type="secondary">每位教师使用独立账号登录；创建的案例归属到本人，发布时可选进入个人案例库或校案例库。</Typography.Text>
      </div>
      <Button type="primary" onClick={() => setCreating(true)}>新建教师账号</Button>
    </div>
    {error && <Alert type="error" message={error} />}
    {!rows && !error && <Spin />}
    {rows && <Card size="small">
      <Table<TeacherAccount> rowKey="id" dataSource={rows} pagination={false} size="middle"
        columns={[
          { title: '用户名', dataIndex: 'username', key: 'username' },
          { title: '姓名', dataIndex: 'real_name', key: 'real_name' },
          { title: '状态', dataIndex: 'status', key: 'status',
            render: (status: string) => status === 'active' ? <Tag color="green">启用</Tag> : <Tag color="red">停用</Tag> },
          { title: '创建时间', dataIndex: 'created_at', key: 'created_at',
            render: (value: string) => value.replace('T', ' ').slice(0, 16) },
          { title: '操作', key: 'actions',
            render: (_, row) => <Space>
              <Button size="small" onClick={() => setEditing(row)}>改名</Button>
              <Button size="small" onClick={() => setResetTarget(row)}>重置密码</Button>
              <Popconfirm title={row.status === 'active' ? `停用账号「${row.real_name}」？` : `启用账号「${row.real_name}」？`}
                description={row.status === 'active' ? '停用后该教师将无法登录。' : '启用后该教师可重新登录。'}
                okText={row.status === 'active' ? '停用' : '启用'} cancelText="取消" okButtonProps={{ danger: row.status === 'active' }}
                onConfirm={async () => {
                  try { await patchTeacherAccount(teacherToken, row.id, { status: row.status === 'active' ? 'disabled' : 'active' }); message.success('已更新'); await load() }
                  catch (e) { message.error(e instanceof Error ? e.message : '操作失败') }
                }}>
                <Button size="small" danger={row.status === 'active'}>{row.status === 'active' ? '停用' : '启用'}</Button>
              </Popconfirm>
            </Space> },
        ]} />
    </Card>}

    <Modal title="新建教师账号" open={creating} onCancel={() => setCreating(false)} footer={null} destroyOnClose>
      <Form layout="vertical" onFinish={async (values: { username: string; real_name: string; password: string }) => {
        try {
          await createTeacherAccount(teacherToken, values)
          message.success(`已创建账号 ${values.username}`)
          setCreating(false); await load()
        } catch (e) { message.error(e instanceof Error ? e.message : '创建失败') }
      }}>
        <Form.Item name="username" label="用户名" rules={[{ required: true, message: '请输入用户名' }, { pattern: /^[A-Za-z0-9_.-]+$/, message: '仅支持字母、数字、下划线、点、短横线' }]}>
          <Input placeholder="如 teacher_wang" autoComplete="off" />
        </Form.Item>
        <Form.Item name="real_name" label="姓名" rules={[{ required: true, message: '请输入真实姓名' }]}>
          <Input placeholder="如 王老师" />
        </Form.Item>
        <Form.Item name="password" label="初始密码" rules={[{ required: true, min: 8, message: '密码至少 8 位' }]}>
          <Input.Password autoComplete="new-password" />
        </Form.Item>
        <Button type="primary" htmlType="submit" block>创建账号</Button>
      </Form>
    </Modal>

    <Modal title={`修改姓名：${editing?.username ?? ''}`} open={editing !== null} onCancel={() => setEditing(null)} footer={null} destroyOnClose>
      <Form layout="vertical" onFinish={async (values: { real_name: string }) => {
        if (!editing) return
        try {
          await patchTeacherAccount(teacherToken, editing.id, { real_name: values.real_name })
          message.success('姓名已更新'); setEditing(null); await load()
        } catch (e) { message.error(e instanceof Error ? e.message : '修改失败') }
      }}>
        <Form.Item name="real_name" label="姓名" initialValue={editing?.real_name} rules={[{ required: true, message: '请输入姓名' }]}>
          <Input />
        </Form.Item>
        <Button type="primary" htmlType="submit" block>保存</Button>
      </Form>
    </Modal>

    <Modal title={`重置密码：${resetTarget?.username ?? ''}`} open={resetTarget !== null} onCancel={() => setResetTarget(null)} footer={null} destroyOnClose>
      <Form layout="vertical" onFinish={async (values: { password: string }) => {
        if (!resetTarget) return
        try {
          await patchTeacherAccount(teacherToken, resetTarget.id, { password: values.password })
          message.success('密码已重置'); setResetTarget(null)
        } catch (e) { message.error(e instanceof Error ? e.message : '重置失败') }
      }}>
        <Form.Item name="password" label="新密码" rules={[{ required: true, min: 8, message: '密码至少 8 位' }]}>
          <Input.Password autoComplete="new-password" />
        </Form.Item>
        <Typography.Text type="secondary">重置后该教师需使用新密码重新登录。</Typography.Text>
        <div style={{ marginTop: 12 }}><Button type="primary" htmlType="submit" block>确认重置</Button></div>
      </Form>
    </Modal>
  </Space>
}
