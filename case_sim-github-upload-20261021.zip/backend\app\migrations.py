"""幂等 SQLite 增量迁移。只追加列，不删除或重建业务数据。"""
import re
import shutil
from pathlib import Path
from sqlalchemy import inspect, text
from backend.app.observability import event
from backend.app.db import engine

def migrate() -> None:
    # Back up the database actually being migrated, never the default production
    # path when a test or deployment supplied DATABASE_URL.
    if engine.dialect.name == "sqlite" and engine.url.database not in (None, "", ":memory:"):
        db_path = Path(engine.url.database).resolve()
        backup = Path(str(db_path) + ".bak-v5")
        if db_path.exists() and not backup.exists():
            shutil.copy2(db_path, backup)
    insp = inspect(engine)
    additions = {
        "case": {"version": "INTEGER NOT NULL DEFAULT 1", "input_filename": "VARCHAR(255)", "input_mime": "VARCHAR(128)", "input_size": "INTEGER", "base_net_profit": "FLOAT", "financial_assumptions_json": "JSON", "play_locked": "BOOLEAN NOT NULL DEFAULT 0", "teacher_id": "INTEGER REFERENCES teacher_account(id)", "library_scope": "VARCHAR(16) NOT NULL DEFAULT 'school'", "deleted_at": "DATETIME"},
        "option_result": {"net_profit": "FLOAT", "financial_basis_json": "JSON"},
        "session": {"student_id": "INTEGER REFERENCES student_account(id)", "case_version": "INTEGER NOT NULL DEFAULT 1", "case_snapshot_json": "JSON NOT NULL DEFAULT '{}'", "current_metrics_json": "JSON NOT NULL DEFAULT '{}'", "kind": "VARCHAR(16) NOT NULL DEFAULT 'formal'"},
        "student_account": {"class_name": "VARCHAR(64) NOT NULL DEFAULT ''"},
        "teacher_session": {"teacher_id": "INTEGER REFERENCES teacher_account(id)"},
        "turn": {"before_metrics_json": "JSON", "after_metrics_json": "JSON", "delta_metrics_json": "JSON", "result_source": "VARCHAR(32)"},
    }
    with engine.begin() as conn:
        for table, cols in additions.items():
            if not insp.has_table(table):
                continue
            existing = {c["name"] for c in inspect(conn).get_columns(table)}
            for name, ddl in cols.items():
                if name not in existing:
                    conn.execute(text('ALTER TABLE "%s" ADD COLUMN "%s" %s' % (table, name, ddl)))
        if insp.has_table("case"):
            conn.execute(text('UPDATE "case" SET version=1 WHERE version IS NULL'))
        if insp.has_table("session"):
            conn.execute(text('UPDATE "session" SET case_version=1 WHERE case_version IS NULL'))
            conn.execute(text("UPDATE \"session\" SET case_snapshot_json='{}' WHERE case_snapshot_json IS NULL"))
            conn.execute(text("UPDATE \"session\" SET current_metrics_json='{}' WHERE current_metrics_json IS NULL"))
            conn.execute(text("UPDATE \"session\" SET kind='formal' WHERE kind IS NULL"))
            # Keep legacy submissions intact. Add a DB-level one-run constraint
            # only when existing logged-in records are already unambiguous.
            duplicates = conn.execute(text(
                'SELECT COUNT(*) FROM (SELECT case_id, student_id FROM "session" '
                'WHERE student_id IS NOT NULL GROUP BY case_id, student_id HAVING COUNT(*) > 1)'
            )).scalar_one()
            if not duplicates:
                conn.execute(text('DROP INDEX IF EXISTS uq_session_case_student'))
            else:
                event("未创建学生案例唯一索引：保留了历史重复提交，需由学生或教师确认清理",
                      level=30, duplicate_groups=int(duplicates))
        # ── 班级成员关系：把 student_account.class_name 的历史数据转成多对多成员 ──
        # create_all 先于 migrate() 执行，所以 class_group / class_membership 此时已存在。
        if insp.has_table("class_group") and insp.has_table("student_account"):
            import hashlib
            legacy = conn.execute(text(
                "SELECT DISTINCT class_name FROM student_account WHERE class_name <> ''"
            )).fetchall()
            for (name,) in legacy:
                gid = conn.execute(text("SELECT id FROM class_group WHERE name = :n"), {"n": name}).scalar()
                if gid is None:
                    join_code = "class-" + hashlib.sha1(name.encode()).hexdigest()[:12]
                    conn.execute(text(
                        "INSERT INTO class_group (name, join_code, created_at) VALUES (:n, :c, CURRENT_TIMESTAMP)"),
                        {"n": name, "c": join_code})
                    gid = conn.execute(text("SELECT id FROM class_group WHERE name = :n"), {"n": name}).scalar()
                conn.execute(text(
                    "INSERT OR IGNORE INTO class_membership (class_id, student_id, joined_at) "
                    "SELECT :g, id, CURRENT_TIMESTAMP FROM student_account WHERE class_name = :n"),
                    {"g": gid, "n": name})
            if legacy:
                event("班级成员关系迁移完成", legacy_classes=len(legacy))
    # ── P0：practice 模式 ──────────────────────────────────────────────
    # 旧模型的 UniqueConstraint(case_id, student_id) 在 SQLite 里是表级 UNIQUE
    # （sqlite_autoindex_session_1），命名索引 DROP 删不掉它，practice 行会撞它。
    # SQLite 不支持删表级约束，只能重建表：拷数据 → 换新结构（无表级 UNIQUE）→ 建 3 元组唯一索引。
    with engine.raw_connection() as raw:
        cur = raw.cursor()
        cur.execute("PRAGMA foreign_keys=OFF")
        try:
            has_session = cur.execute(
                "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='session'"
            ).fetchone()[0]
            if has_session:
                sql = cur.execute(
                    "SELECT sql FROM sqlite_master WHERE type='table' AND name='session'"
                ).fetchone()[0] or ""
                # 只重建"旧表级 UNIQUE(case_id, student_id)"；3 元组（含 kind）或部分索引的新结构跳过
                if re.search(r"UNIQUE\s*\(\s*case_id\s*,\s*student_id\s*\)", sql):
                    cur.execute('ALTER TABLE "session" RENAME TO session_legacy')
                    cur.execute('''
                        CREATE TABLE "session" (
                            id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                            case_id INTEGER NOT NULL REFERENCES case(id),
                            kind VARCHAR(16) NOT NULL DEFAULT 'formal',
                            student_name VARCHAR(64) NOT NULL,
                            student_id INTEGER REFERENCES student_account(id),
                            created_at DATETIME NOT NULL,
                            finished_at DATETIME,
                            attempt_no INTEGER NOT NULL DEFAULT 1,
                            case_version INTEGER NOT NULL DEFAULT 1,
                            case_snapshot_json JSON NOT NULL,
                            current_metrics_json JSON NOT NULL
                        )''')
                    cols = ("id, case_id, kind, student_name, student_id, created_at, finished_at, "
                            "attempt_no, case_version, case_snapshot_json, current_metrics_json")
                    cur.execute(
                        f'INSERT INTO "session" ({cols}) SELECT {cols} FROM session_legacy')
                    cur.execute('DROP TABLE session_legacy')
                    event("session 表已重建：移除表级 UNIQUE(case_id, student_id)，改为 3 元组唯一索引（practice 模式）")
                cur.execute(
                    'CREATE UNIQUE INDEX IF NOT EXISTS uq_session_case_student_kind '
                    'ON "session" (case_id, student_id, kind) WHERE student_id IS NOT NULL')
        finally:
            cur.execute("PRAGMA foreign_keys=ON")
            raw.commit()

    # ── P0 迁移结束 ──────────────────────────────────────────────────────
