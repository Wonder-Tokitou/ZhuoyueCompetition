// 阶段 0 · T0.5 辅助脚本：统计 src/pages/student/** 与 src/layouts/** 中出现的 className
// 只读：不修改任何源码，输出到 stdout
const fs = require('node:fs')
const path = require('node:path')

const ROOT = path.resolve(__dirname, '../../../frontend')
const DIRS = ['src/pages/student', 'src/layouts']

const files = []
function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, entry.name)
    if (entry.isDirectory()) walk(p)
    else if (/\.(tsx|ts)$/.test(entry.name)) files.push(p)
  }
}
for (const d of DIRS) walk(path.join(ROOT, d))

const hits = new Map()
const re = /className=(?:"([^"]*)"|\{([^}]*)\})/g

for (const file of files) {
  const text = fs.readFileSync(file, 'utf8')
  const rel = path.relative(ROOT, file).split(path.sep).join('/')
  let m
  while ((m = re.exec(text))) {
    const raw = m[1] !== undefined ? m[1] : m[2]
    const line = text.slice(0, m.index).split('\n').length
    // 字面量写法 directly 就是类名；表达式写法要再抽引号内的字面量（含模板串）
    const tokens = m[1] !== undefined ? [`"${raw}"`] : (raw.match(/'[^']*'|"[^"]*"|`[^`]*`/g) || [])
    for (const tk of tokens) {
      const value = tk.slice(1, -1)
      for (const piece of value.split(/\s+/)) {
        const clean = piece.replace(/[${}]/g, '').trim()
        if (!clean) continue
        if (!hits.has(clean)) hits.set(clean, [])
        hits.get(clean).push(`${rel}:${line}`)
      }
    }
  }
}

const keys = [...hits.keys()].sort()
console.log(`TOTAL=${keys.length}`)
for (const k of keys) {
  const where = [...new Set(hits.get(k))]
  console.log(`${k}\t${where.length}\t${where.slice(0, 3).join(' , ')}`)
}
