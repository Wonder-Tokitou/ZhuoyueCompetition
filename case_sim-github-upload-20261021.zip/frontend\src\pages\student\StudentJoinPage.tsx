/** 学生扫码加入班级页：二维码内容 = /student/join/{join_code}。
 *
 * 进入即自动尝试加入（幂等：已在班级返回 joined=false，不报错）。
 * 一个学生可以加入多个班级（多门课），这里同时展示已加入的全部班级。
 */
import { useEffect, useState } from 'react'
import { Alert, Button, Card, List, Space, Typography } from 'antd'
import { joinClass, myClasses } from '../../api/client'
import type { JoinClassResponse, MyClassItem } from '../../api/types'

export default function StudentJoinPage() {
  const code = window.location.pathname.split('/').pop() || ''
  const [result, setResult] = useState<JoinClassResponse | null>(null)
  const [classes, setClasses] = useState<MyClassItem[]>([])
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(true)

  async function load() {
    setBusy(true); setError('')
    try {
      const res = await joinClass(code)
      setResult(res)
      setClasses(await myClasses())
    } catch (e) {
      setError(e instanceof Error ? e.message : '加入失败，请确认二维码是否有效')
    } finally { setBusy(false) }
  }

  useEffect(() => { if (code) void load(); else setError('链接缺少班级邀请码') }, [code])

  return <Space direction="vertical" size={16} style={{ width: '100%' }}>
    <div><Typography.Title level={3} style={{ margin: 0 }}>加入班级</Typography.Title>
      <Typography.Text type="secondary">扫描老师出示的班级二维码即可加入；一门课一个班，多个班互不影响。</Typography.Text></div>
    {busy && <Card loading title="正在处理" />}
    {!busy && error && <>
      <Alert type="error" showIcon message={error} />
      <Button type="primary" onClick={() => void load()}>重试</Button>
    </>}
    {!busy && result && <Card title={result.joined ? '加入成功' : '你已在该班级'}>
      <Typography.Paragraph>
        {result.joined
          ? `已加入班级「${result.class.name}」。`
          : `你已经在班级「${result.class.name}」中，无需重复加入。`}
      </Typography.Paragraph>
      <Typography.Text type="secondary">返回学生首页即可开始该课程老师发布的案例推演。</Typography.Text>
      <Button type="primary" style={{ marginTop: 12 }} onClick={() => { window.location.href = '/student/cases' }}>前往案例库</Button>
    </Card>}
    {classes.length > 0 && <Card title={`我的班级（${classes.length}）`}>
      <List
        dataSource={classes}
        renderItem={(c) => <List.Item><Typography.Text>{c.name}</Typography.Text>
          <Typography.Text type="secondary">加入于 {new Date(c.joined_at).toLocaleString()}</Typography.Text></List.Item>}
      />
    </Card>}
  </Space>
}
