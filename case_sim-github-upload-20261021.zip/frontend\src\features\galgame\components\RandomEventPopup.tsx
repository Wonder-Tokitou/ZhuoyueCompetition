/**
 * 随机事件弹窗（阶段 6 实现）。
 * 居中卡片 + 遮罩 rgba(0,0,0,.45) + 一个"知道了"按钮；事件不改数值、不改选项，
 * 只负责展示与写一条日记（once 记账在页面层 flags['ev:r{n}']）。关闭后流程继续。
 */
export interface RandomEventPopupProps {
  title: string
  text: string
  onClose: () => void
}

export default function RandomEventPopup({ title, text, onClose }: RandomEventPopupProps) {
  return (
    <div className="galgame-event-mask" role="dialog" aria-modal="true" aria-label={title}>
      <div className="galgame-event-card">
        <p className="galgame-event-title">{title}</p>
        <p className="galgame-event-text">{text}</p>
        <button type="button" className="galgame-confirm" autoFocus onClick={onClose}>
          知道了
        </button>
      </div>
    </div>
  )
}
