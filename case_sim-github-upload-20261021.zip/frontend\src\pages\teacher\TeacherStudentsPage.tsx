import { useEffect, useState } from 'react'
import { Alert, Button, Card, Col, Form, Input, Modal, Popover, Row, Select, Space, Statistic, Table, Tag, Typography } from 'antd'
import { ClockCircleOutlined, RiseOutlined, TeamOutlined, WarningOutlined } from '@ant-design/icons'
import { api, addClassMember, createClass, getClassMembers, getClassQr, getRecords, listTeacherClasses, removeClassMember } from '../../api/client'
import { useTeacherToken } from '../../context/TeacherTokenContext'
import type { StudentAccount } from '../../context/StudentAccountContext'
import type { CaseListItem, ClassGroupItem, ClassMemberItem, StudentRecord } from '../../api/types'
import { classifyRisk } from '../../features/galgame/engine/dialogueEngine'
import { OptionDistributionChart, RecentActivityChart } from './components/OptionDistributionChart'
import type { RecentActivityPoint } from './components/OptionDistributionChart'

interface PracticeStat {
  count: number
  dominantRisk: string
  dominantCount: number
  lastDate: string
  lastLabel: string
}
const RISK_LABEL: Record<string, string> = { conservative: '保守', balanced: '稳健', aggressive: '激进' }

/** 内联 SVG 迷你折线：把 points 归一化到 100×28 画布，教师端克制风格（1.5px 细线、无填充）。 */
function Sparkline({ points, color }: { points: number[]; color: string }) {
  const min = Math.min(...points)
  const max = Math.max(...points)
  const span = max - min || 1
  const step = points.length > 1 ? points.length - 1 : 1
  const coords = points
    .map((v, i) => `${((i / step) * 100).toFixed(1)},${(28 - ((v - min) / span) * 26).toFixed(1)}`)
    .join(' ')
  return (
    <svg viewBox="0 0 100 28" style={{ width: '100%', height: 28, display: 'block' }} aria-hidden="true">
      <polyline points={coords} fill="none" stroke={color} strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

const KPI_CARD_STYLE = { borderRadius: 10, background: '#ffffff', border: '1px solid #e9edf3' } as const
const KPI_ICON_STYLE = { fontSize: 16, color: '#1a3a5c', marginRight: 8 } as const
// 迷你趋势线为装饰性占位数据（TODO：后续由后端 dashboard/summary 提供历史序列后替换）
const TREND_COMPLETED = [12, 15, 14, 19, 23, 27]
const TREND_STUCK = [9, 7, 8, 6, 5, 4]
const TREND_REVENUE = [4.2, 4.6, 4.4, 5.0, 5.3, 5.7]
const TREND_DURATION = [23, 25, 22, 26, 24, 27]


interface DashboardSummary {
  total: number
  completed: number
  stuck_node2: number
  avg_revenue: number | null
  avg_duration: number | null
}

interface OptionDistributionResponse {
  case_id: number
  case_title: string
  case_version: number
  options: { name: string; count: number }[]
}

interface RecentActivityResponse {
  items: RecentActivityPoint[]
}

export default function TeacherStudentsPage() {
  const token = useTeacherToken()
  const [rows, setRows] = useState<StudentAccount[]>([]), [error, setError] = useState('')
  const [editing, setEditing] = useState<StudentAccount | null>(null), [busy, setBusy] = useState(false)
  // 班级分组：学生扫码加入班级（可多班）；'' sentinel 表示未加入任何班级
  const [classFilter, setClassFilter] = useState<string>('all')
  const [form] = Form.useForm(), [editForm] = Form.useForm()
  // 班级仪表盘：真实聚合统计（后端 /teacher/dashboard/*）
  const [summary, setSummary] = useState<DashboardSummary | null>(null)
  const [cases, setCases] = useState<{ id: number; title: string; version?: number }[]>([])
  const [caseId, setCaseId] = useState<number | null>(null)
  const [optionData, setOptionData] = useState<{ name: string; value: number }[] | null>(null)
  const [activityData, setActivityData] = useState<RecentActivityPoint[] | null>(null)
  const [practiceStats, setPracticeStats] = useState<Record<number, PracticeStat>>({})
  async function load() { try { setRows((await api.get('/teacher/students', { params: { token } })).data) } catch (e) { setError(e instanceof Error ? e.message : '加载失败') } }
  useEffect(() => { void load() }, [token])
  useEffect(() => {
    let active = true
    Promise.all([
      api.get<DashboardSummary>('/teacher/dashboard/summary', { params: { token } }),
      api.get<CaseListItem[]>('/cases', { params: { token } }),
      api.get<RecentActivityResponse>('/teacher/dashboard/recent-activity', { params: { token } }),
    ]).then(([sum, list, act]) => {
      if (!active) return
      setSummary(sum.data); setCases(list.data)
      setCaseId((v) => v ?? list.data[0]?.id ?? null)
      setActivityData(act.data.items.length ? act.data.items : null)
    }).catch((e) => { if (active) setError(e instanceof Error ? e.message : '仪表盘统计加载失败') })
    return () => { active = false }
  }, [token])
  useEffect(() => {
    if (caseId === null) return
    let active = true
    api.get<OptionDistributionResponse>('/teacher/dashboard/option-distribution', { params: { case_id: caseId, token } })
      .then(({ data }) => { if (active) setOptionData(data.options.length ? data.options.map((o) => ({ name: o.name, value: o.count })) : null) })
      .catch((e) => { if (active) setError(e instanceof Error ? e.message : '选项分布加载失败') })
    // P3：练习局摘要（只读展示，不进班级均值/排名/进度）
    getRecords(caseId, token, 'practice').then((records: StudentRecord[]) => {
      if (!active) return
      const byStudent: Record<number, { count: number; riskCount: Record<string, number>; last: string; lastLabel: string }> = {}
      for (const r of records) {
        const sid = r.student_id
        if (typeof sid !== 'number') continue
        const acc = byStudent[sid] ??= { count: 0, riskCount: {}, last: '', lastLabel: '' }
        acc.count += 1
        for (const t of r.turns) {
          const label = t.chosen_label ?? t.chosen_option
          if (label) {
            const risk = classifyRisk(label)
            acc.riskCount[risk] = (acc.riskCount[risk] ?? 0) + 1
            acc.lastLabel = label
          }
        }
        const d = r.created_at ?? ''
        if (d > acc.last) acc.last = d
      }
      const out: Record<number, PracticeStat> = {}
      for (const [sid, v] of Object.entries(byStudent)) {
        const risks = Object.entries(v.riskCount).sort((a, b) => b[1] - a[1])
        out[Number(sid)] = {
          count: v.count,
          dominantRisk: risks.length ? RISK_LABEL[risks[0][0]] ?? risks[0][0] : '',
          dominantCount: risks.length ? risks[0][1] : 0,
          lastDate: v.last.slice(5, 10),
          lastLabel: v.lastLabel,
        }
      }
      setPracticeStats(out)
    }).catch(() => {})
    return () => { active = false }
  }, [caseId, token])
  async function save(id: number, values: object) {
    await api.patch('/teacher/students/' + id, values, { params: { token } }); await load()
  }
  // ── 班级与扫码加入 ──
  const [groups, setGroups] = useState<ClassGroupItem[]>([])
  const [groupDetails, setGroupDetails] = useState<Record<number, { qr?: string; members: ClassMemberItem[] }>>({})
  const [newClassName, setNewClassName] = useState('')
  const [classBusy, setClassBusy] = useState(false)
  const [memberDraft, setMemberDraft] = useState<Record<number, string>>({})
  async function loadClasses() {
    try {
      const gs = await listTeacherClasses(token)
      setGroups(gs)
      const details = await Promise.all(gs.map(async (g) => {
        const [qr, members] = await Promise.all([getClassQr(token, g.id), getClassMembers(token, g.id)])
        return [g.id, { qr: qr.qr_url, members }] as const
      }))
      setGroupDetails(Object.fromEntries(details))
    } catch (e) { setError(e instanceof Error ? e.message : '班级加载失败') }
  }
  useEffect(() => { void loadClasses() }, [token]) // eslint-disable-line react-hooks/exhaustive-deps
  async function handleCreateClass() {
    if (!newClassName.trim()) return
    setClassBusy(true); setError('')
    try {
      await createClass(token, newClassName.trim())
      setNewClassName(''); await loadClasses()
    } catch (e) { setError(e instanceof Error ? e.message : '创建班级失败') } finally { setClassBusy(false) }
  }
  async function handleAddMember(classId: number) {
    const username = (memberDraft[classId] || '').trim()
    if (!username) return
    setClassBusy(true); setError('')
    try { await addClassMember(token, classId, username); setMemberDraft((m) => ({ ...m, [classId]: '' })); await Promise.all([loadClasses(), load()]) }
    catch (e) { setError(e instanceof Error ? e.message : '添加成员失败') } finally { setClassBusy(false) }
  }
  async function handleRemoveMember(classId: number, studentId: number) {
    setClassBusy(true); setError('')
    try { await removeClassMember(token, classId, studentId); await Promise.all([loadClasses(), load()]) }
    catch (e) { setError(e instanceof Error ? e.message : '移除成员失败') } finally { setClassBusy(false) }
  }
  // 班级选项：全部班级 + 学生已加入的各班 + 未加入班级（'' sentinel）
  const classNames = [...new Set(rows.flatMap((r) => r.classes ?? []))]
  const NONE = '__none__'
  const classFilterOptions = [
    { value: 'all', label: '全部班级' },
    ...classNames.map((c) => ({ value: c, label: c })),
    { value: NONE, label: '未加入班级' },
  ]
  const visibleRows = classFilter === 'all' ? rows
    : classFilter === NONE ? rows.filter((r) => !(r.classes?.length))
    : rows.filter((r) => r.classes?.includes(classFilter))
  return <Space direction="vertical" style={{ width: '100%' }}>
    {error && <Alert type="error" message={error} closable onClose={() => setError('')} />}
    <Card title="班级仪表盘">
      {/* KPI 卡片行：4 个 Statistic，窄屏自动换行（xs 单列 → sm 双列 → lg 四列） */}
      <Row gutter={[16, 16]} style={{ marginTop: 12 }}>
        <Col xs={24} sm={12} lg={6}>
          <Card size="small" style={KPI_CARD_STYLE}>
            <Space align="start" size={0}><TeamOutlined style={KPI_ICON_STYLE} /><Statistic title="已完成人数 / 总人数" value={summary ? summary.completed : '--'} suffix={summary ? ` / ${summary.total}` : ` / ${rows.length}`} /></Space>
            <Sparkline points={TREND_COMPLETED} color="#1a3a5c" />
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <Card size="small" style={KPI_CARD_STYLE}>
            <Space align="start" size={0}><WarningOutlined style={KPI_ICON_STYLE} /><Statistic title="卡在节点 2 的人数" value={summary ? summary.stuck_node2 : '--'} /></Space>
            <Sparkline points={TREND_STUCK} color="#b45309" />
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <Card size="small" style={KPI_CARD_STYLE}>
            <Space align="start" size={0}><RiseOutlined style={KPI_ICON_STYLE} /><Statistic title="人均营收" value={summary?.avg_revenue ?? '--'} suffix="万" /></Space>
            <Sparkline points={TREND_REVENUE} color="#1a3a5c" />
          </Card>
        </Col>
        <Col xs={24} sm={12} lg={6}>
          <Card size="small" style={KPI_CARD_STYLE}>
            <Space align="start" size={0}><ClockCircleOutlined style={KPI_ICON_STYLE} /><Statistic title="平均时长" value={summary?.avg_duration ?? '--'} suffix="分钟" /></Space>
            <Sparkline points={TREND_DURATION} color="#1a3a5c" />
          </Card>
        </Col>
      </Row>
      <Row gutter={[16, 16]} style={{ marginTop: 16 }}>
        <Col xs={24} lg={12}>
          <Card size="small" title="选项分布（最近一次推演）" extra={
            <Select
              aria-label="选择案例"
              value={caseId ?? undefined}
              onChange={setCaseId}
              style={{ minWidth: 160 }}
              options={cases.map((c) => ({ value: c.id, label: c.title }))}
              placeholder="选择案例"
            />
          }><OptionDistributionChart data={optionData ?? []} /></Card>
        </Col>
        <Col xs={24} lg={12}>
          <Card size="small" title="最近活跃趋势（近 7 次推演）"><RecentActivityChart data={activityData ?? []} /></Card>
        </Col>
      </Row>
    </Card>
    <Card title="学生账号（学生可自行注册，也可在此添加）">
      <Form form={form} layout="inline" onFinish={async (values) => { setBusy(true); setError(''); try { await api.post('/teacher/students', values, { params: { token } }); form.resetFields(); await load() } catch (e) { setError(e instanceof Error ? e.message : '创建失败') } finally { setBusy(false) } }}>
        <Form.Item name="username" label="账号" rules={[{ required: true, pattern: /^[A-Za-z0-9_.-]{1,64}$/, message: '使用英文、数字、点、短横线或下划线' }]}><Input autoComplete="off" /></Form.Item>
        <Form.Item name="real_name" label="真实姓名" rules={[{ required: true, whitespace: true, max: 64 }]}><Input /></Form.Item>
        <Form.Item name="password" label="初始密码" rules={[{ required: true, min: 8, max: 128 }]}><Input.Password autoComplete="new-password" /></Form.Item>
        <Button htmlType="submit" type="primary" loading={busy}>创建账号</Button>
      </Form>
      <p>将账号与初始密码单独发给学生。密码不在列表展示；停用或重置密码将撤销现有登录。学生扫码加入班级后，名单会自动归组。</p>
    </Card>
    <Card title="班级与加入二维码">
      <Space direction="vertical" style={{ width: '100%' }} size={12}>
        <Space wrap>
          <Input aria-label="班级名称" placeholder="新班级名称，如：一班" style={{ width: 220 }}
            value={newClassName} onChange={(e) => setNewClassName(e.target.value)} maxLength={64} />
          <Button type="primary" loading={classBusy} disabled={!newClassName.trim()} onClick={() => void handleCreateClass()}>创建班级</Button>
          <Typography.Text type="secondary">创建后出示二维码，学生注册后扫码加入；一名学生可加入多个班级。</Typography.Text>
        </Space>
        {groups.length === 0 && <Typography.Text type="secondary">还没有班级，先创建一个。</Typography.Text>}
        {groups.map((g) => {
          const detail = groupDetails[g.id] ?? { members: [] as ClassMemberItem[] }
          return <Card key={g.id} type="inner" size="small" title={`${g.name}（${g.member_count} 人）`}
            extra={<Button size="small" onClick={() => window.open(detail.qr, '_blank')} disabled={!detail.qr}>放大二维码</Button>}>
            <Space align="start" wrap size={16}>
              {detail.qr && <img src={detail.qr} alt={`加入 ${g.name} 的二维码`} width={128} height={128} />}
              <div style={{ minWidth: 240 }}>
                <Typography.Paragraph copyable={{ text: window.location.origin + '/student/join/' + g.join_code }}>
                  加入链接：/student/join/{g.join_code}
                </Typography.Paragraph>
                <Space wrap>
                  <Input aria-label={`添加成员到 ${g.name}`} placeholder="按账号添加成员" style={{ width: 180 }}
                    value={memberDraft[g.id] ?? ''} onChange={(e) => setMemberDraft((m) => ({ ...m, [g.id]: e.target.value }))} />
                  <Button size="small" loading={classBusy} disabled={!(memberDraft[g.id] ?? '').trim()} onClick={() => void handleAddMember(g.id)}>添加成员</Button>
                </Space>
                <Table<ClassMemberItem> rowKey="student_id" size="small" style={{ marginTop: 8 }}
                  dataSource={detail.members} pagination={false} locale={{ emptyText: '暂无成员，等待学生扫码' }}
                  columns={[
                    { title: '姓名', render: (_, m) => `${m.real_name}（${m.username}）` },
                    { title: '加入时间', render: (_, m) => new Date(m.joined_at).toLocaleString() },
                    { title: '操作', render: (_, m) => <Button size="small" danger loading={classBusy}
                      onClick={() => void handleRemoveMember(g.id, m.student_id)}>移出班级</Button> },
                  ]} />
              </div>
            </Space>
          </Card>
        })}
      </Space>
    </Card>
    <Card title="学生名单">
      <Space wrap style={{ marginBottom: 12 }}>
        <Select aria-label="按班级筛选" style={{ minWidth: 160 }} value={classFilter} onChange={setClassFilter}
          options={classFilterOptions} />
        <Typography.Text type="secondary">
          {classFilter === 'all' ? `共 ${visibleRows.length} 名学生`
            : `${classFilterOptions.find((o) => o.value === classFilter)?.label ?? classFilter}：${visibleRows.length} 名学生`}
        </Typography.Text>
      </Space>
      <Table rowKey="id" dataSource={visibleRows} columns={[
      { title: '账号', dataIndex: 'username' },
      { title: '真实姓名', render: (_, r) => {
        const ps = practiceStats[r.id]
        return (
          <div>
            <div>{r.real_name}</div>
            {ps && ps.count > 0 && (
              <Popover
                trigger="click"
                content={`练习 ${ps.count} 次 · 偏${ps.dominantRisk} ${ps.dominantCount} 次 · 最近 ${ps.lastDate} · 理由：「${ps.lastLabel}」`}
              >
                <Button type="link" size="small" style={{ padding: 0, height: 'auto', fontSize: 12 }}>
                  沉浸复盘 {ps.count} 次 · 偏{ps.dominantRisk} · 最近 {ps.lastDate || '--'}
                </Button>
              </Popover>
            )}
          </div>
        )
      } },
      { title: '班级', render: (_, r) => r.classes?.length
        ? <Space wrap size={4}>{r.classes.map((c) => <Tag key={c} color="blue">{c}</Tag>)}</Space>
        : <Typography.Text type="secondary">未加入班级</Typography.Text> },
      { title: '状态', render: (_, r) => <Tag color={r.status === 'active' ? 'green' : 'red'}>{r.status === 'active' ? '正常' : '已停用'}</Tag> },
      { title: '管理', render: (_, r) => <Space><Button onClick={() => { setEditing(r); editForm.setFieldsValue({ real_name: r.real_name, class_name: r.class_name ?? '', password: '' }) }}>修改 / 重置密码</Button><Button danger={r.status === 'active'} onClick={() => Modal.confirm({ title: `${r.status === 'active' ? '停用' : '启用'} ${r.real_name}？`, onOk: async () => { await save(r.id, { status: r.status === 'active' ? 'disabled' : 'active' }) } })}>{r.status === 'active' ? '停用' : '启用'}</Button></Space> },
    ]} />
    </Card>
    <Modal title={`管理 ${editing?.username || ''}`} open={!!editing} onCancel={() => setEditing(null)} onOk={() => editForm.submit()} confirmLoading={busy}>
      <Form form={editForm} layout="vertical" onFinish={async (values) => { if (!editing) return; setBusy(true); try { await save(editing.id, { real_name: values.real_name, ...(values.password ? { password: values.password } : {}) }); setEditing(null) } catch (e) { setError(e instanceof Error ? e.message : '保存失败') } finally { setBusy(false) } }}>
        <Form.Item name="real_name" label="真实姓名" rules={[{ required: true, whitespace: true, max: 64 }]}><Input /></Form.Item>
        <Form.Item name="password" label="重置密码（留空则不变）" rules={[{ min: 8, max: 128 }]}><Input.Password autoComplete="new-password" /></Form.Item>
      </Form>
    </Modal>
  </Space>
}
