"""阶段 3 取证辅助：删除 _stage3_probe_setup.py 建出来的临时数据。

按外键顺序删除：ai_artifact → turn → session → student_login → student_account，
再删掉该学生的 AI 制品目录（backend/data/artifacts/cases/<case>/students/<id>）。

用法：
  python _stage3_probe_teardown.py <student_id>
"""
import json
import shutil
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
DB = ROOT / "backend" / "data" / "app.db"
ARTIFACTS = ROOT / "backend" / "data" / "artifacts"
TABLES = ["student_account", "student_login", "session", "turn", "ai_artifact"]


def counts(conn):
    return {t: conn.execute(f"select count(*) from {t}").fetchone()[0] for t in TABLES}


def main() -> None:
    student_id = int(sys.argv[1])
    conn = sqlite3.connect(DB)
    conn.execute("PRAGMA foreign_keys=ON")
    session_ids = [r[0] for r in conn.execute("select id from session where student_id = ?", (student_id,))]
    case_ids = {r[0] for r in conn.execute("select case_id from session where student_id = ?", (student_id,))}

    deleted = {}
    if session_ids:
        marks = ",".join("?" * len(session_ids))
        # 依赖顺序：step → artifact → task → review/message → turn（ai_artifact 同时挂在 ai_task 上）
        deleted["ai_task_step"] = conn.execute(
            f"delete from ai_task_step where task_id in (select id from ai_task where session_id in ({marks}))", session_ids).rowcount
        deleted["ai_artifact"] = conn.execute(
            f"delete from ai_artifact where session_id in ({marks})", session_ids).rowcount
        deleted["ai_task"] = conn.execute(
            f"delete from ai_task where session_id in ({marks})", session_ids).rowcount
        deleted["review"] = conn.execute(
            f"delete from review where session_id in ({marks})", session_ids).rowcount
        deleted["message"] = conn.execute(
            f"delete from message where session_id in ({marks})", session_ids).rowcount
        deleted["turn"] = conn.execute(
            f"delete from turn where session_id in ({marks})", session_ids).rowcount
    deleted["session"] = conn.execute("delete from session where student_id = ?", (student_id,)).rowcount
    deleted["student_login"] = conn.execute("delete from student_login where student_id = ?", (student_id,)).rowcount
    deleted["student_account"] = conn.execute("delete from student_account where id = ?", (student_id,)).rowcount
    conn.commit()

    removed = []
    for case_id in case_ids:
        folder = ARTIFACTS / "cases" / str(case_id) / "students" / str(student_id)
        if folder.exists():
            shutil.rmtree(folder)
            removed.append(str(folder))

    print(f"DELETED={json.dumps(deleted, ensure_ascii=False)}")
    print(f"REMOVED_DIRS={removed}")
    print(f"AFTER={json.dumps(counts(conn), ensure_ascii=False)}")
    conn.close()


if __name__ == "__main__":
    main()
