# 学生端样式与结构快照（阶段 0 · T0.5）

> **生成时间**：2026-10-20 21:55
> **快照对象**：`frontend/src/layouts/StudentLayout.css`（208 行）、`frontend/src/index.css`（34 行）、`frontend/src/pages/student/**`、`frontend/src/layouts/**`
> **截图**：`baseline-375.png`（375 CSS px 宽，deviceScaleFactor=2，整页）
> **用途**：阶段 9 做像素级回归对比；阶段 2–8 改动前先确认「改的是哪一段、会不会被后面的同选择器规则覆盖」。

---

## 1. 六段关键 CSS 原文（带起止行号）

`StudentLayout.css` 的两个特点会直接影响后续阶段，先说清楚：

1. **同选择器出现两次是常态**：文件前半段是「移动优先初版」，后半段（L156 之后）是「覆盖版」。同一个 `.student-metrics` 在 L100 和 L163 各写了一次，**生效的是 L163**。改 L100 不会有效果。
2. 文件末尾没有分层的 `@layer`，全靠书写顺序与优先级；新增规则若加在 L163 之前，会被覆盖。

### 1.1 `body.student-body` — L4–11

```css
body.student-body {
  max-width: 1280px;
  margin: 0 auto;
  min-height: 100vh;
  overflow-x: hidden; /* 768px 以下绝不出现横向滚动条 */
  background-color: #fff;
  box-shadow: 0 0 24px rgba(0, 0, 0, 0.05);
}
```

- 实测计算值（375px 视口）：`background-color: rgb(255,255,255)`、`box-shadow: rgba(0,0,0,0.05) 0px 0px 24px 0px`。
- ⚠️ L3 的注释写「body 限宽 480px」，但代码是 `1280px`。**注释是历史遗留**，阶段 2 明文要求不许改 `max-width`，也不要顺手把注释当真去改成 480。

### 1.2 `.student-metrics` — L100–107（原始）与 L163（实际生效）

```css
/* L100–107：初版，横向滚动单行 */
.student-metrics {
  display: flex;
  gap: 12px;
  overflow-x: auto;
  padding: 10px 0;
  white-space: nowrap;
  border-top: 1px solid #f0f0f0;
}
/* L108 */
.student-metrics span { flex: 0 0 auto; }
```

```css
/* L163：覆盖版，两列网格，实际生效 */
.student-metrics { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); white-space: normal; overflow: visible; border: 0; gap: 8px; }
```

- 结论：**375px 下是 2×2 网格**（截图可见），不是横向滚动。阶段 4 给卡片加 `::before` 图标时要按网格布局考虑，不要按单行布局设计。

### 1.3 `.student-metrics .metric-card` — L164（另有 L198 在 800px 媒体查询内）

```css
/* L164–169：指标卡本体 + 内部元素 */
.student-metrics .metric-card { display: flex; flex-direction: column; gap: 2px; background: #f5f7fa; border: 1px solid #e9edf3; border-radius: 10px; padding: 10px 12px; min-width: 0; overflow-wrap: anywhere; }
.student-metrics .metric-label { font-size: 12px; color: rgba(0, 0, 0, 0.55); }
.student-metrics .metric-value { font-size: 18px; font-weight: 700; font-variant-numeric: tabular-nums; line-height: 1.4; display: flex; align-items: center; gap: 4px; flex-wrap: wrap; }
.student-metrics .metric-card.metric-revenue .metric-value { font-size: 26px; }
.student-metrics .metric-trend { font-size: 14px; font-weight: 700; }
.student-metrics .metric-note { font-size: 12px; color: rgba(0, 0, 0, 0.55); overflow-wrap: anywhere; }
```

```css
/* L198–200：≤800px 时缩小 */
  .student-metrics .metric-card { padding: 8px; }
  .student-metrics .metric-value { font-size: 16px; }
  .student-metrics .metric-card.metric-revenue .metric-value { font-size: 22px; }
```

- 实测 375px：`border-radius: 10px`、`background: rgb(245,247,250)`、`border: 1px solid rgb(233,237,243)`、无阴影。
- 注意：指标卡是**灰底 10px 圆角**，和清单里说的「卡片 8px 直角」不是同一个东西——8px 指的是 antd `<Card>`（`.ant-card`，实测 `border-radius: 8px`、`border: 1px solid rgb(240,240,240)`、无阴影）。两者都要在阶段 2 分别处理。

### 1.4 `.strategy-option-card` — L180（配套 L181–182、L109–113、L177–178）

```css
/* L179–182：策略选项卡片本体 */
/* 策略选项卡片：垂直堆叠，边框色=风险色（保守绿/稳健黄/激进红，内联 style 提供），选中填充对应色+白字 */
.strategy-option-card { border: 2px solid; border-radius: 12px; overflow: hidden; background: #fff; }
.strategy-option-card .strategy-option.ant-btn { display: flex; align-items: flex-start; justify-content: flex-start; text-align: left; width: 100%; height: auto; white-space: normal; padding: 14px 16px; border: 0; background: transparent; border-radius: 0; }
.strategy-option-card .strategy-option.ant-btn[aria-pressed="true"] { background: transparent; }
```

```css
/* L109–113、L177–178：按钮级规则（被上面 L181 覆盖 border/background） */
.strategy-option.ant-btn { height: auto; white-space: normal; text-align: left; padding: 12px; line-height: 1.6; }
.strategy-option.ant-btn[aria-pressed="true"],
.strategy-option.ant-btn[aria-pressed="true"]:disabled { color: #fff; background: #0958d9; border: 2px solid #003eb3; }
.strategy-option.ant-btn:focus-visible { outline: 3px solid #69b1ff; outline-offset: 2px; }
.strategy-option.ant-btn > span { min-width: 0; overflow-wrap: anywhere; }
.strategy-option.ant-btn { border-radius: 10px; padding: 16px; }
.strategy-option.ant-btn[aria-pressed="true"], .strategy-option.ant-btn[aria-pressed="true"]:disabled { background: #edf4ff; color: #173f79; border: 2px solid #1677ff; }
```

**关键结构性事实（阶段 3 必读）**：

- `.strategy-option-card` 的 `border: 2px solid` **没有写颜色**，颜色由 JSX 内联 `style={{ borderColor: meta.border }}` 提供（`StudentPlayPage.tsx:246`）。
- `meta.border` 的取值：有 `risk_level` → `RISK_META[risk]`；无 → `RISK_PLACEHOLDER.border`。当前后端不下发 `risk_level`，所以**改前策略卡边框恒为灰色 `#d1d5db`**（`StudentPlayPage.tsx:17`）。这正是清单里「策略卡灰色边框」的实际来源。
- 选中态背景同样是内联 style（`background: meta.fill`，占位值 `#1a3a5c` 深蓝，`StudentPlayPage.tsx:17/246`），CSS 里 L182 又把按钮背景置为透明——**所以改选中色只能改 JS，改 CSS 无效**。D2 的三色方案必须落在 `OPTION_STYLE` 常量 + 内联 style 上。
- 文字颜色：CSS 从未给 `.strategy-letter/.strategy-name/.strategy-desc` 设过白字，只有 `.strategy-risk` 在选中时被内联设为 `#fff`。若按 D2 改成浅色底（`#eff6ff` 等），恰好解决「深底+黑字」的隐患，不需要额外处理。

### 1.5 `.decision-submit` — L147（补丁）与 L175（本体）

```css
/* L145–147：FAB 避让补丁 */
/* FAB 悬浮在右下角，避开 decision-submit（底部粘性提交区） */
body.student-body .ant-float-btn { position: fixed; z-index: 1000; }
.decision-submit { padding-right: 76px; }
```

```css
/* L175–176：粘性提交区本体 */
.decision-submit { position: sticky; bottom: 0; z-index: 10; background: #fff; padding: 12px 0 max(12px, env(safe-area-inset-bottom)); border-top: 1px solid #e9edf3; margin-top: 20px; box-shadow: 0 -8px 16px rgba(255,255,255,.94); }
.decision-submit p { margin: 0 0 8px; }
```

- 注意 `padding-right: 76px` 在 L147，`padding: 12px 0 ...` 在 L175 —— **L175 的简写会重置 padding-right**。实际 375px 下提交按钮右侧没有 76px 留白（截图中按钮占满整行）。若阶段 8 要让 FAB 不压按钮，得改 L175 而不是 L147。

### 1.6 `@media (prefers-reduced-motion: reduce)` — L206–208

```css
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after { animation-duration: .01ms !important; transition-duration: .01ms !important; scroll-behavior: auto !important; }
}
```

- 选择器是 `*`，不只学生端，覆盖全站。清单里「`StudentLayout.css:206` 已有全局降级块」— **行号准确**。
- 它只压制 `animation-duration` / `transition-duration`，**不重置 `transform`**。阶段 8 若用 `transform: translateY(-2px)` 做 hover 位移，光靠这块不会让位移消失（只是瞬间完成），必须按阶段 8 提示词第 5 条额外补 `transform: none !important`。

---

## 2. 学生端 className 清单（去重、排序，共 34 个）

> 扫描范围：`src/pages/student/**`（含 `components/`）+ `src/layouts/**`；只统计源码里写的 class，不含 antd 运行时追加的 `ant-*`。

| # | className | 出现处 |
|---|---|---|
| 1 | `decision-history` | StudentPlayPage.tsx:226 |
| 2 | `decision-reason-label` | StudentPlayPage.tsx:263 |
| 3 | `decision-submit` | StudentPlayPage.tsx:265 |
| 4 | `metric-card` | StudentPlayPage.tsx:44–48（5 处） |
| 5 | `metric-label` | StudentPlayPage.tsx:44–48（5 处） |
| 6 | `metric-note` | StudentPlayPage.tsx:47 |
| 7 | `metric-revenue` | StudentPlayPage.tsx:44 |
| 8 | `metric-trend` | StudentPlayPage.tsx:29 |
| 9 | `metric-value` | StudentPlayPage.tsx:44–48（5 处） |
| 10 | `strategy-body` | StudentPlayPage.tsx:254 |
| 11 | `strategy-desc` | StudentPlayPage.tsx:256 |
| 12 | `strategy-letter` | StudentPlayPage.tsx:253 |
| 13 | `strategy-name` | StudentPlayPage.tsx:255 |
| 14 | `strategy-option` | StudentPlayPage.tsx:247（**测试用 `===` 精确比较，F23**） |
| 15 | `strategy-option-card` | StudentPlayPage.tsx:246 |
| 16 | `strategy-risk` | StudentPlayPage.tsx:257 |
| 17 | `student-hint` | StudentLandingPage.tsx:70 |
| 18 | `student-metrics` | StudentPlayPage.tsx:43 |
| 19 | `student-shell` | StudentLayout.tsx:54 |
| 20 | `student-header` | StudentLayout.tsx:55 |
| 21 | `student-title` | StudentLayout.tsx:59 |
| 22 | `student-main` | StudentLayout.tsx:64 |
| 23 | `student-page` | StudentLayout.tsx:65 |
| 24 | `student-tutor-panel` | StudentLayout.tsx:70 |
| 25 | `student-tutor-panel-head` | StudentLayout.tsx:71 |
| 26 | `student-tutor-panel-body` | StudentLayout.tsx:74 |
| 27 | `tutor-fab-face` | **不存在**（阶段 6 新增） |
| 28 | `teacher-brand` | TeacherLayout.tsx:70（教师端，零改动） |
| 29 | `teacher-sider` | TeacherLayout.tsx:63 |
| 30 | `teacher-shell` | TeacherLayout.tsx:61 |
| 31 | `teacher-logout` | TeacherLayout.tsx:78 |
| 32 | `teacher-main` | TeacherLayout.tsx:88 |
| 33 | `teacher-narrow-alert` | TeacherLayout.tsx:91 |
| 34 | `teacher-content-scroll` | TeacherLayout.tsx:99 |
| 35 | `teacher-content` | TeacherLayout.tsx:100 |

> 上表 27 号 `tutor-fab-face` 是为阶段 6 预留的占位行，**当前代码里不存在**（不计入 34 个实测值）。实测去重后为 34 个，其中学生端 26 个、教师布局 8 个。
>
> 复算命令：`node docs/ui-baseline/tools/_scan-classnames.cjs`（输出 `TOTAL=34`）。

---

## 3. `src/index.css` 已有的 `:root` 变量（阶段 1 避免重复定义）

```css
/* src/index.css L3–7 */
:root {
  /* 教师端主色（/teacher/*）与学生端主色（/student/*），与 main.tsx 的 antd ConfigProvider 对齐 */
  --color-primary-teacher: #1a3a5c;
  --color-primary-student: #db2777;
}
```

- 全文件只有 **2 个** 自定义属性，都带 `--color-primary-` 前缀。
- 阶段 1 要加的 14 个变量全部是 `--student-*` / `--option-*` 前缀，**与现有 2 个无任何重名**，不会触发清单里的「变量名冲突」失败分支。
- `index.css` 其余内容：`html` 背景 `#f0f2f5`、`body` 字号 14px / 颜色 `rgba(0,0,0,.88)`、`#root` 最小高度、`.entry-hint`（只与入口页有关，学生端不使用）。

---

## 4. 375px 截图与实测数据

**文件**：`baseline-375.png`（240 KB，750×3218 物理像素 = 375×1609 CSS px）

**截图状态**：真实后端（`127.0.0.1:8110`）+ 真实案例「研咖咖啡·高校市场扩张与定价决策」+ 已完成的 3 轮会话（学生「蔡徐坤」），**已加载真实数据**，非页面壳。

**取证方式**：`node docs/ui-baseline/tools/_shot.cjs --token <temp> --session 3 --out baseline-375.png`
（Chrome headless + CDP，注入 `sessionStorage` 后导航；原始取证 JSON 见 `tools/baseline-375.probe.json`）

### 4.1 页面特征（改造前基线）

| 特征 | 实测值 | 来源 |
|---|---|---|
| 页面底色 | `rgb(255,255,255)` 纯白 | `body.student-body` |
| antd 卡片圆角 | `8px`，边框 `1px solid rgb(240,240,240)`，无阴影 | `.ant-card` |
| 指标卡 | 圆角 `10px`，底色 `rgb(245,247,250)`，边框 `1px solid rgb(233,237,243)`，2×2 网格 | `.metric-card` |
| 指标卡数量 | 4 张（营收/毛利率/市场份额/现金流）；本案例后端未下发 `net_profit`，**没有第 5 张净利润卡** | `.metric-card` 计数 |
| 进度组件 | antd `<Steps size="small">`，3 个 ✓ 节点 + 文字「三轮推演已完成 · 已提交 3 轮」 | `.ant-steps` |
| FAB | 玫红 `rgb(219,39,119)` 圆形（`border-radius: 50%`） | `.ant-float-btn` |
| 横向溢出 | `scrollWidth=375` / `clientWidth=375` → **无溢出** | `document.documentElement` |
| 主按钮渐变/阴影 | 无（当前是 antd 默认实心 `#db2777`） | 阶段 2 待加 |

### 4.2 截图没能覆盖的一处：策略卡

`optionCardCount = 0` —— 截图里**没有策略卡**，因为：

- 该学生（id=3）在本案例下已有提交记录，`POST /sessions` 直接 409，无法新建进行中的会话；
- 已完成会话的 `next_node_id` 为空，页面只渲染结果对比，不渲染待选策略卡。

**「策略卡灰色边框」改用代码取证**（比截图更可核）：`.strategy-option-card { border: 2px solid; }` + 内联 `borderColor: #d1d5db`（`StudentPlayPage.tsx:17,246`），即 2px 实线灰边 + 12px 圆角 + 白底。

> 若阶段 9 需要策略卡的像素级对比，需先解决「从哪来一个进行中的会话」——见 `BASELINE.md` 的待确认项。

### 4.3 截图方法的一个已知假象

整页截图（`captureBeyondViewport`）时，`position: fixed` 的 FAB 按首屏位置落点，因此它在长图里出现在中部、压住了「营收冲高但费用侵蚀利润」这一行的右侧。**这是截图方式造成的，不是页面缺陷**——首屏实机上 FAB 在右下角。

---

## 5. 相关但未纳入六段的结构参考（阶段 5/6 会用到）

```css
/* L188–189：Steps 现有样式，阶段 5 换成 RoundMap 后这两条应一并删除 */
.student-page .ant-steps { margin: 12px 0 4px; }
.student-page .ant-steps .ant-steps-item-title { font-size: 12px; white-space: normal; overflow-wrap: anywhere; }
```

```css
/* L121–134：AI 助教悬浮面板（阶段 6 改圆角/底色） */
.student-tutor-panel {
  position: fixed;
  right: 16px;
  bottom: 152px;
  width: 360px;
  height: 480px;
  display: flex;
  flex-direction: column;
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.18);
  z-index: 1000;
  overflow: hidden;
}
```

- 阶段 6 说「不许改 FAB 位置（right:16 bottom:80）」：`.ant-float-btn` 在 CSS 里只有 `position: fixed; z-index: 1000;`（L146），`right/bottom` 并没有声明，是 antd 默认值。真正写死坐标的是**面板**（L121–134，`right:16; bottom:152px`）。改面板圆角/底色不会影响 FAB 落点。
