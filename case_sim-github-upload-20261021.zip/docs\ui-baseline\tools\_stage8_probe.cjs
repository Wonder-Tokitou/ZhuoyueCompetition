/**
 * 阶段 8（微动效与降级）取证脚本：
 *  - 正常模式：卡片/策略卡 hover 上浮 2px + 阴影静态加深；主按钮按下 scale(.98)
 *  - reduced-motion 模拟：hover/按下全部无位移（transform none、transition 0.01ms）
 *
 * 用法：
 *   node _stage8_probe.cjs --token <token> --session <id> [--name stage-8] [--outdir ..]
 */
const { spawn } = require('node:child_process')
const fs = require('node:fs')
const os = require('node:os')
const path = require('node:path')

const CHROME = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
const PORT = 9341
const BASE = 'http://127.0.0.1:8110'
const CASE_TOKEN = 'benchmark-demo-v4'

function arg(name, fallback) {
  const i = process.argv.indexOf(`--${name}`)
  return i >= 0 && process.argv[i + 1] ? process.argv[i + 1] : fallback
}
const TOKEN = arg('token')
const SESSION = arg('session')
const NAME = arg('name', 'stage-8')
const OUTDIR = path.resolve(arg('outdir', path.join(__dirname, '..')))
if (!TOKEN) { console.error('missing --token'); process.exit(2) }

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

async function browserWs() {
  for (let i = 0; i < 60; i++) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/version`)
      const json = await res.json()
      if (json.webSocketDebuggerUrl) return json.webSocketDebuggerUrl
    } catch { /* 未就绪 */ }
    await sleep(250)
  }
  throw new Error('chrome 调试端口未就绪')
}
function client(ws) {
  let id = 0
  const waiting = new Map()
  ws.addEventListener('message', (ev) => {
    const msg = JSON.parse(ev.data)
    if (msg.id && waiting.has(msg.id)) {
      const { resolve, reject } = waiting.get(msg.id)
      waiting.delete(msg.id)
      msg.error ? reject(new Error(JSON.stringify(msg.error))) : resolve(msg.result)
      return
    }
  })
  return (method, params = {}, sessionId) => new Promise((resolve, reject) => {
    const mid = ++id
    waiting.set(mid, { resolve, reject })
    ws.send(JSON.stringify({ id: mid, method, params, ...(sessionId ? { sessionId } : {}) }))
  })
}

const SNAP = `(sel) => {
  const el = document.querySelector(sel)
  if (!el) return null
  const cs = getComputedStyle(el)
  return { transform: cs.transform, boxShadow: cs.boxShadow, transitionDuration: cs.transitionDuration }
}`
const RECT = `(sel) => {
  const el = document.querySelector(sel)
  if (!el) return null
  const r = el.getBoundingClientRect()
  return { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) }
}`

;(async () => {
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'stage8-chrome-'))
  const chrome = spawn(CHROME, [
    '--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
    '--no-proxy-server', '--hide-scrollbars', '--force-device-scale-factor=2',
    `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`, 'about:blank',
  ], { stdio: 'ignore' })
  try {
    const wsUrl = await browserWs()
    const ws = new WebSocket(wsUrl)
    await new Promise((res, rej) => { ws.addEventListener('open', res); ws.addEventListener('error', rej) })
    const send = client(ws)
    const { targetId } = await send('Target.createTarget', { url: 'about:blank' })
    const { sessionId } = await send('Target.attachToTarget', { targetId, flatten: true })
    const call = (m, p) => send(m, p, sessionId)

    await call('Page.enable')
    await call('Runtime.enable')
    await call('Emulation.setDeviceMetricsOverride', { width: 375, height: 812, deviceScaleFactor: 2, mobile: false })
    await call('Emulation.setEmulatedMedia', { features: [{ name: 'prefers-reduced-motion', value: 'no-preference' }] })
    await call('Page.addScriptToEvaluateOnNewDocument', {
      source: [
        `try { sessionStorage.setItem('student_access_token', ${JSON.stringify(TOKEN)}) } catch (e) {}`,
        `try { sessionStorage.setItem('student_session:${CASE_TOKEN}', ${JSON.stringify(SESSION)}) } catch (e) {}`,
      ].join('\n'),
    })
    await call('Page.navigate', { url: `${BASE}/student/${CASE_TOKEN}` })
    await sleep(5000)

    const ev = async (expr) => {
      const raw = await call('Runtime.evaluate', { expression: expr, returnByValue: true })
      if (raw.exceptionDetails) throw new Error(JSON.stringify(raw.exceptionDetails))
      return raw.result.value
    }
    const shot = async (name) => {
      const s = await call('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false, fromSurface: true })
      const file = path.join(OUTDIR, `${name}.png`)
      fs.writeFileSync(file, Buffer.from(s.data, 'base64'))
      return `${file} BYTES=${fs.statSync(file).size}`
    }
    const hover = async (sel) => {
      // 先滚动到视口内，再取中心点做真实指针 hover
      await ev(`(() => { const el = document.querySelector(${JSON.stringify(sel)}); if (el) el.scrollIntoView({ block: 'center' }); })()`)
      await sleep(400)
      const r = await ev(`(${RECT})(${JSON.stringify(sel)})`)
      if (!r) return null
      await call('Input.dispatchMouseEvent', { type: 'mouseMoved', x: r.x, y: r.y })
      await sleep(450)
      return ev(`(${SNAP})(${JSON.stringify(sel)})`)
    }
    const release = async (sel) => {
      const r = await ev(`(${RECT})(${JSON.stringify(sel)})`)
      if (r) await call('Input.dispatchMouseEvent', { type: 'mouseMoved', x: 5, y: 5 })
    }

    const hasStrategy = await ev(`!!document.querySelector('.strategy-option-card')`)
    const hasCard = await ev(`!!document.querySelector('.student-page .ant-card')`)
    const hasBtn = await ev(`!!document.querySelector('body.student-body .ant-btn-primary')`)

    // 1. 正常模式 hover
    const strategyIdle = await ev(`(${SNAP})('.strategy-option-card')`)
    const strategyHover = hasStrategy ? await hover('.strategy-option-card') : null
    if (hasStrategy) await release('.strategy-option-card')
    const cardHover = hasCard ? await hover('.student-page .ant-card') : null
    if (hasCard) await release('.student-page .ant-card')
    // 2. 按钮按下
    let btnActive = null
    if (hasBtn) {
      const r = await ev(`(${RECT})('.ant-btn-primary')`)
      await call('Input.dispatchMouseEvent', { type: 'mouseMoved', x: r.x, y: r.y })
      await call('Input.dispatchMouseEvent', { type: 'mousePressed', x: r.x, y: r.y, button: 'left', clickCount: 1 })
      await sleep(300)
      btnActive = await ev(`(${SNAP})('.ant-btn-primary')`)
      await call('Input.dispatchMouseEvent', { type: 'mouseReleased', x: r.x, y: r.y, button: 'left', clickCount: 1 })
    }
    const shotNormal = await shot(`${NAME}-normal`)

    // 3. reduced-motion 模式：所有位移必须消失
    await call('Emulation.setEmulatedMedia', { features: [{ name: 'prefers-reduced-motion', value: 'reduce' }] })
    await sleep(600)
    const rmStrategyHover = hasStrategy ? await hover('.strategy-option-card') : null
    if (hasStrategy) await release('.strategy-option-card')
    const rmCardHover = hasCard ? await hover('.student-page .ant-card') : null
    if (hasCard) await release('.student-page .ant-card')
    let rmBtnActive = null
    if (hasBtn) {
      const r = await ev(`(${RECT})('.ant-btn-primary')`)
      await call('Input.dispatchMouseEvent', { type: 'mouseMoved', x: r.x, y: r.y })
      await call('Input.dispatchMouseEvent', { type: 'mousePressed', x: r.x, y: r.y, button: 'left', clickCount: 1 })
      await sleep(300)
      rmBtnActive = await ev(`(${SNAP})('.ant-btn-primary')`)
      await call('Input.dispatchMouseEvent', { type: 'mouseReleased', x: r.x, y: r.y, button: 'left', clickCount: 1 })
    }
    const shotReduced = await shot(`${NAME}-reduced`)

    console.log(JSON.stringify({
      selectors: { hasStrategy, hasCard, hasBtn },
      normal: { strategyIdle, strategyHover, cardHover, btnActive },
      reducedMotion: { strategyHover: rmStrategyHover, cardHover: rmCardHover, btnActive: rmBtnActive },
      overflow: await ev(`({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth })`),
      shots: { normal: shotNormal, reduced: shotReduced },
    }, null, 2))
    ws.close()
  } finally {
    chrome.kill()
  }
})().catch((e) => { console.error('FAILED:', e.message); process.exit(1) })
