/** 封面阶段「开始营业」按钮（仅在台词播完后露出）；P1-F3：practice 时顶部标注「练习模式 · 本次不计入成绩」。 */
import type { GameMode } from '../engine/session'

export default function CoverView({
  visible,
  disabled,
  mode,
  note,
  onStart,
}: {
  visible: boolean
  disabled: boolean
  mode: GameMode
  note?: string
  onStart: () => void
}) {
  if (!visible) return null
  return (
    <div className="galgame-cover-actions">
      {mode === 'practice' && (
        <p className="galgame-practice-tag" role="status">
          练习模式 · 本次不计入成绩
          <span className="galgame-practice-note">练习记录老师可查看</span>
        </p>
      )}
      {note && <p className="galgame-practice-note" role="status">{note}</p>}
      <button type="button" className="galgame-start" disabled={disabled} onClick={onStart}>
        开始营业
      </button>
    </div>
  )
}
