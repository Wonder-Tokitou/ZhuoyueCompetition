import type { StudentRecord } from '../api/types'

export const participantKey = (record: StudentRecord) => record.student_id != null ? `account:${record.student_id}` : `legacy:${record.student_name}`
export const recordKey = (record: StudentRecord) => `${participantKey(record)}:${record.session_id ?? 'legacy'}:${record.attempt_no ?? 1}`
export const recordFinished = (record: StudentRecord) => !!record.finished_at || new Set(record.turns.map(t => t.idx)).size >= 3

export function filterRecords(records: StudentRecord[], name: string, status: string, version: string) {
  return records.filter(record => record.student_name.toLocaleLowerCase().includes(name.trim().toLocaleLowerCase())
    && (status === 'all' || recordFinished(record) === (status === 'finished'))
    && (version === 'all' || String(record.case_version ?? 'unknown') === version))
}

export function summarizeRecords(records: StudentRecord[]) {
  const people = (rows: StudentRecord[]) => new Set(rows.map(participantKey)).size
  return { participants: people(records), completed: people(records.filter(recordFinished)),
    rounds: [1, 2, 3].map(idx => people(records.filter(r => r.turns.some(t => t.idx === idx)))) }
}
