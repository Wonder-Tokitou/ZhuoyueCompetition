import type { Metrics, OptionBrief } from '../../../api/types'
import type { RiskBranch } from '../engine/dialogueEngine'
import ChoiceButtons from '../components/ChoiceButtons'
import { REASON_PHRASES } from '../data/dialogueTree'

/** 选项面板（phase=choice）与财务追问表单（phase=reason）。 */
export default function ChoiceView({
  phase,
  options,
  metrics,
  disabled,
  onConfirm,
  pendingRisk,
  reasonPhrase,
  reasonExtra,
  onReasonPhrase,
  onReasonExtra,
  onSubmit,
}: {
  phase: 'choice' | 'reason'
  options: OptionBrief[]
  metrics: Metrics | null
  disabled: boolean
  onConfirm: (key: string) => void
  pendingRisk: RiskBranch | null
  reasonPhrase: string | null
  reasonExtra: string
  onReasonPhrase: (phrase: string) => void
  onReasonExtra: (value: string) => void
  onSubmit: () => void
}) {
  if (phase === 'choice') {
    return (
      <ChoiceButtons
        options={options}
        disabled={disabled}
        onConfirm={onConfirm}
        metrics={metrics}
      />
    )
  }
  return (
    <div className="galgame-reason">
      <p className="galgame-reason-hint">财务总监在等你的账：挑一句，或直接「就这样定」</p>
      <div className="galgame-reason-phrases">
        {(pendingRisk ? REASON_PHRASES[pendingRisk] : REASON_PHRASES.balanced).map((phrase) => (
          <button
            key={phrase}
            type="button"
            className={`galgame-reason-phrase${reasonPhrase === phrase ? ' is-selected' : ''}`}
            disabled={disabled}
            onClick={() => onReasonPhrase(phrase)}
          >
            {phrase}
          </button>
        ))}
      </div>
      <label className="galgame-reason-extra">
        补充说明（选填，≤100 字）
        <input
          type="text"
          maxLength={100}
          value={reasonExtra}
          disabled={disabled}
          onChange={(e) => onReasonExtra(e.target.value)}
        />
      </label>
      <button
        type="button"
        className="galgame-confirm"
        disabled={disabled}
        onClick={onSubmit}
      >
        就这样定
      </button>
    </div>
  )
}
