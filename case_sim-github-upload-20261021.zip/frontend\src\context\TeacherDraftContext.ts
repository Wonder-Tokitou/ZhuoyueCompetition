import { createContext } from 'react'

/** Layout-level warning for navigation away from the in-memory editor. */
export const TeacherDraftContext = createContext<(dirty: boolean) => void>(() => {})
