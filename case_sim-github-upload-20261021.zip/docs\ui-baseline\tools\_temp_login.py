"""阶段 0 · T0.5 辅助脚本（临时登录凭据）

用途：T0.5 要求 375px 截图，但 /api/play/* 全部挂在 current_student 依赖下，
没有登录令牌就只看到 401 提示，无法截到真实卡片。

做法：为已有学生账号（默认 id=3 蔡徐坤）插入一条**临时** student_login 记录，
令牌明文由脚本自己生成（库表只存 sha256），截图结束后由 logout 接口删除该行。
不新建账号、不改任何业务数据。

用法：
  python _temp_login.py issue            # 插入并打印令牌与哈希
  python _temp_login.py revoke <token>   # 删除该令牌对应记录
  python _temp_login.py status           # 打印当前 student_login 行数
"""
import hashlib
import secrets
import sqlite3
import sys
from datetime import datetime, timedelta
from pathlib import Path

DB = Path(__file__).resolve().parents[3] / "backend" / "data" / "app.db"
STUDENT_ID = 3
TTL_HOURS = 2
TAG_PREFIX = "baseline-screenshot-"


def connect():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn


def issue() -> str:
    token = TAG_PREFIX + secrets.token_hex(16)
    digest = hashlib.sha256(token.encode()).hexdigest()
    expires = (datetime.now() + timedelta(hours=TTL_HOURS)).strftime("%Y-%m-%d %H:%M:%S.%f")
    with connect() as conn:
        conn.execute(
            "insert into student_login (token_hash, student_id, expires_at) values (?, ?, ?)",
            (digest, STUDENT_ID, expires),
        )
        conn.commit()
        total = conn.execute("select count(*) from student_login").fetchone()[0]
    print(f"TOKEN={token}")
    print(f"HASH={digest}")
    print(f"EXPIRES={expires}")
    print(f"LOGIN_ROWS={total}")
    return token


def revoke(token: str) -> None:
    digest = hashlib.sha256(token.encode()).hexdigest()
    with connect() as conn:
        cur = conn.execute("delete from student_login where token_hash = ?", (digest,))
        conn.commit()
        total = conn.execute("select count(*) from student_login").fetchone()[0]
    print(f"DELETED={cur.rowcount}")
    print(f"LOGIN_ROWS={total}")


def status() -> None:
    with connect() as conn:
        rows = conn.execute("select token_hash, student_id, expires_at from student_login").fetchall()
    print(f"LOGIN_ROWS={len(rows)}")
    for r in rows:
        print(dict(r))


if __name__ == "__main__":
    action = sys.argv[1] if len(sys.argv) > 1 else "status"
    if action == "issue":
        issue()
    elif action == "revoke":
        revoke(sys.argv[2])
    else:
        status()
