/**
 * galgame 支线 · 纯函数单测（阶段 1，G1 门禁用）。
 * 覆盖：分类器（含真实 label 预检）/ 好感度 / 评分 / 结局 / 注册表 / 支线优先级 /
 *       台词库 / 事件哈希 / 成就 / 存档重建。
 * 可单独运行：node --test tests/galgame-branch.test.cjs
 */
const { test } = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const vm = require('node:vm')
const ts = require('typescript')

function loadModule(file, mocks = {}, ctx = {}) {
  const exports = {}
  const source = fs.readFileSync(path.resolve(__dirname, '../src', file), 'utf8')
  vm.runInNewContext(ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, jsx: ts.JsxEmit.ReactJSX, target: ts.ScriptTarget.ES2022 } }).outputText, { exports, require: (n) => mocks[n] || {}, ...ctx })
  return exports
}

// vm.runInNewContext 创建独立 realm，deepStrictEqual 会因原型不同误报
// "same structure but not reference-equal"；用 JSON 比较（键序稳定的字面量）。
function same(actual, expected) {
  assert.equal(JSON.stringify(actual), JSON.stringify(expected))
}

const dialogueEngine = loadModule('features/galgame/engine/dialogueEngine.ts')
const branchRegistry = loadModule('features/galgame/data/branchRegistry.ts', { '../engine/dialogueEngine': dialogueEngine })
const dialogueTree = loadModule('features/galgame/data/dialogueTree.ts', { '../engine/dialogueEngine': dialogueEngine })
const randomEvents = loadModule('features/galgame/data/randomEvents.ts')
const achievements = loadModule('features/galgame/data/achievements.ts')
const endings = loadModule('features/galgame/data/endings.ts')
const persistence = loadModule('features/galgame/engine/persistence.ts', { './dialogueEngine': dialogueEngine })

const { classifyRisk, affectionDelta, applyAffection, moodOf, scoreRound, endingOf } = dialogueEngine
const { BRANCH_REGISTRY, resolveSideStories, assertRegistry } = branchRegistry

/* ================= 分类器（5+ 条） ================= */

test('classifyRisk：保守/激进/兜底基础断言', () => {
  assert.equal(classifyRisk('压缩成本，保住现金流'), 'conservative')
  assert.equal(classifyRisk('加大投放，抢占校园市场'), 'aggressive')
  assert.equal(classifyRisk('方案 B'), 'balanced')
  assert.equal(classifyRisk('随便', '激进'), 'aggressive')
  assert.equal(classifyRisk(''), 'balanced')
})

test('classifyRisk：否定语境「暂不扩张」按扩词后判保守', () => {
  assert.equal(classifyRisk('暂不扩张，深耕现有校区，聚焦复购与运营提效'), 'conservative')
})

test('classifyRisk：riskLevel 参数优先于关键词', () => {
  assert.equal(classifyRisk('加大投放', '稳健'), 'balanced')
  assert.equal(classifyRisk('随便写', '保守'), 'conservative')
})

/* ================= 真实 label 预检（T1.2 第 0 步抄入） ================= */

// 来源：docs/galgame-baseline/play-labels.txt（benchmark-demo-v4，3 节点 × 3 选项）
const REAL_LABELS = [
  '半年内同时进入3所新高校，开设5家新店，快速抢占市场', // aggressive
  '拓展1所新高校，开设2家新店，稳步扩大品牌覆盖', // balanced
  '深耕现有校区，暂不扩张，聚焦提升单店复购率与运营效率', // conservative
  '全线提价10%—15%，定位高端精品咖啡，强化品牌溢价', // aggressive
  '维持现有定价体系（美式12元/杯），小幅优化产品与控制成本', // conservative
  '推出12—18元中端新品系列，升级核心产品品质，保持价格竞争力', // balanced
  '以口碑营销为主，依靠学生自发传播与会员复购，营销预算占营收5%', // conservative
  '大规模广告投放与高频促销补贴，营销预算占营收20%', // aggressive
  '校园活动赞助、社交媒体种草与会员优惠组合推广，营销预算占营收10%', // balanced
]

test('真实 label 预检：balanced 占比 ≤ 1/3', () => {
  const results = REAL_LABELS.map((l) => classifyRisk(l))
  const balanced = results.filter((r) => r === 'balanced').length
  assert.ok(balanced / REAL_LABELS.length <= 1 / 3, `balanced ${balanced}/${REAL_LABELS.length}`)
})

test('真实 label 抽验：激进/保守/稳健各一条', () => {
  assert.equal(classifyRisk(REAL_LABELS[0]), 'aggressive')
  assert.equal(classifyRisk(REAL_LABELS[2]), 'conservative')
  assert.equal(classifyRisk(REAL_LABELS[8]), 'balanced')
})

/* ================= 好感度（4+ 条） ================= */

test('affectionDelta：三分支增量与 D5 表一致', () => {
  same(affectionDelta('conservative'), { manager: 0, cfo: 10, cmo: -10 })
  same(affectionDelta('balanced'), { manager: 6, cfo: 2, cmo: 2 })
  same(affectionDelta('aggressive'), { manager: 0, cfo: -10, cmo: 10 })
})

test('applyAffection：保守一轮 70/60/65 → 70/70/55', () => {
  same(applyAffection({ manager: 70, cfo: 60, cmo: 65 }, 'conservative'), { manager: 70, cfo: 70, cmo: 55 })
})

test('applyAffection：clamp 不越界（0–100）', () => {
  same(applyAffection({ manager: 0, cfo: 95, cmo: 5 }, 'aggressive'), { manager: 0, cfo: 85, cmo: 15 })
  same(applyAffection({ manager: 99, cfo: 0, cmo: 100 }, 'balanced'), { manager: 100, cfo: 2, cmo: 100 })
})

test('moodOf：≥75 warm / 45–74 neutral / <45 cold', () => {
  assert.equal(moodOf(75), 'warm')
  assert.equal(moodOf(74), 'neutral')
  assert.equal(moodOf(45), 'neutral')
  assert.equal(moodOf(44), 'cold')
})

/* ================= 评分（D5，4+ 条） ================= */

test('scoreRound：盈利 + 正现金流 = +15（50 → 65）', () => {
  const r = scoreRound({ score: 50, breakdown: [] }, { netProfitDelta: 10, cashFlowAmount: 5, shareDelta: 0, risk: 'conservative' })
  assert.equal(r.score, 65)
  assert.equal(r.breakdown.length, 2)
})

test('scoreRound：亏损 + 净流出 + 激进错配 = 50−8−5−6 = 31', () => {
  assert.equal(scoreRound({ score: 50, breakdown: [] }, { netProfitDelta: -10, cashFlowAmount: -8, shareDelta: 0, risk: 'aggressive' }).score, 31)
})

test('scoreRound：现金流紧张 + 保守匹配 = 50−8−5+5 = 42', () => {
  assert.equal(scoreRound({ score: 50, breakdown: [] }, { netProfitDelta: -3, cashFlowAmount: -2, shareDelta: 0, risk: 'conservative' }).score, 42)
})

test('scoreRound：份额上涨 + 激进匹配 = 50+5+5 = 60', () => {
  assert.equal(scoreRound({ score: 50, breakdown: [] }, { netProfitDelta: 0, cashFlowAmount: 0, shareDelta: 2, risk: 'aggressive' }).score, 60)
})

test('scoreRound：clamp 上限 100', () => {
  assert.equal(scoreRound({ score: 95, breakdown: [] }, { netProfitDelta: 5, cashFlowAmount: 5, shareDelta: 0, risk: 'balanced' }).score, 100)
})

/* ================= 结局（3 条） ================= */

test('endingOf：>80 success / 50–80 normal / <50 fail', () => {
  assert.equal(endingOf(81), 'success')
  assert.equal(endingOf(80), 'normal')
  assert.equal(endingOf(50), 'normal')
  assert.equal(endingOf(49), 'fail')
})

test('endings.ts：3 条且 id 与注册表 end.* 一致', () => {
  assert.equal(endings.ENDINGS.length, 3)
  same(endings.ENDINGS.map((e) => e.id), ['end.success', 'end.normal', 'end.fail'])
  for (const e of endings.ENDINGS) {
    assert.ok(e.lines.length >= 3 && e.lines.length <= 5, `${e.id} 台词 3–5 句`)
    assert.ok(e.title.length > 0)
  }
})

/* ================= 注册表（2+ 条） ================= */

test('assertRegistry：ID 唯一且匹配正则', () => {
  same(assertRegistry(), [])
})

test('BRANCH_REGISTRY：节点数 23/4/5/5/3 共 40', () => {
  const count = {}
  for (const n of BRANCH_REGISTRY) count[n.layer] = (count[n.layer] || 0) + 1
  assert.equal(count.main, 23)
  assert.equal(count.side, 4)
  assert.equal(count.ev, 5)
  assert.equal(count.cg, 5)
  assert.equal(count.end, 3)
  assert.equal(BRANCH_REGISTRY.length, 40)
})

/* ================= 支线优先级（2+ 条） ================= */

function baseCtx(overrides = {}) {
  return {
    turnsLength: 0, finished: false, risk: null,
    affection: { manager: 70, cfo: 60, cmo: 65 },
    cashFlowAmount: 0, shareDelta: 0, revenueDelta: 0,
    score: 50, ending: null, nextNodeId: null,
    seenCg: [], seenSide: [], eventHit: false,
    ...overrides,
  }
}

test('resolveSideStories：warning(40) 优先于 manager.trust(20)', () => {
  const ctx = baseCtx({ turnsLength: 3, affection: { manager: 85, cfo: 30, cmo: 65 }, cashFlowAmount: -1 })
  same(resolveSideStories(ctx, []), ['side.cfo.warning'])
})

test('resolveSideStories：audit(30) 优先于 viral(25)，seen 后换下一条', () => {
  const ctx = baseCtx({ affection: { manager: 70, cfo: 75, cmo: 75 }, cashFlowAmount: -1, shareDelta: 2 })
  same(resolveSideStories(ctx, []), ['side.cfo.audit'])
  same(resolveSideStories(ctx, ['side.cfo.audit']), ['side.cmo.viral'])
})

test('resolveSideStories：条件不满足不选中，全 seen 返回空', () => {
  const ctx = baseCtx({ affection: { manager: 70, cfo: 40, cmo: 60 }, cashFlowAmount: 2, shareDelta: 0 })
  same(resolveSideStories(ctx, []), [])
  const ctx2 = baseCtx({ affection: { manager: 85, cfo: 75, cmo: 75 }, turnsLength: 3, cashFlowAmount: -1, shareDelta: 2 })
  same(resolveSideStories(ctx2, ['side.cfo.warning', 'side.cfo.audit', 'side.cmo.viral', 'side.manager.trust']), [])
})

/* ================= 台词库（3 条） ================= */

test('actOpening(2)：三分支第一句各不相同', () => {
  const c = dialogueTree.actOpening(2, 'conservative')
  const b = dialogueTree.actOpening(2, 'balanced')
  const a = dialogueTree.actOpening(2, 'aggressive')
  assert.notEqual(c[0].text, b[0].text)
  assert.notEqual(b[0].text, a[0].text)
  assert.notEqual(c[0].text, a[0].text)
})

test('reactionScene：cold 与 warm 的财务台词不同字', () => {
  const warm = dialogueTree.reactionScene(1, 'conservative', 85)
  const cold = dialogueTree.reactionScene(1, 'conservative', 30)
  const warmCfo = warm.find((l) => l.speaker === '财务').text
  const coldCfo = cold.find((l) => l.speaker === '财务').text
  assert.notEqual(warmCfo, coldCfo)
})

test('台词库：每句 ≤40 字、每组 ≤6 句', () => {
  const groups = [
    dialogueTree.coverLines(),
    dialogueTree.actOpening(1, null),
    dialogueTree.actOpening(2, 'conservative'),
    dialogueTree.actOpening(3, 'aggressive'),
    dialogueTree.reactionScene(2, 'aggressive', 20),
    dialogueTree.reactionScene(3, 'balanced', 60),
    dialogueTree.resumeScene(),
  ]
  for (const group of groups) {
    assert.ok(group.length <= 6, `句数超限: ${group.map((l) => l.text).join('|')}`)
    for (const line of group) assert.ok(line.text.length <= 40, `超长句: ${line.text}`)
  }
})

/* ================= 随机事件（2 条） ================= */

test('pickEvent：同一 session 恒定 + 1000 个 session 命中率 20%–40%', () => {
  const first = randomEvents.pickEvent(1, 1)
  for (let i = 0; i < 10; i++) same(randomEvents.pickEvent(1, 1), first)
  let hits = 0
  for (let i = 0; i < 1000; i++) if (randomEvents.pickEvent(i, 1)) hits++
  assert.ok(hits >= 200 && hits <= 400, `命中率 ${hits / 1000}`)
})

test('pickEvent：返回的事件 id 均在注册表 ev.* 中', () => {
  const evIds = new Set(BRANCH_REGISTRY.filter((n) => n.layer === 'ev').map((n) => n.id))
  for (let i = 0; i < 200; i++) {
    const e = randomEvents.pickEvent(i, 2)
    if (e) assert.ok(evIds.has(e.id), `未知事件 id: ${e.id}`)
  }
})

/* ================= 成就（2 条） ================= */

test('成就 id 固定 6 条', () => {
  same(achievements.ACHIEVEMENTS.map((a) => a.id), ['first_decision', 'conservative', 'adventurer', 'treasurer', 'social', 'tycoon'])
})

test('evaluate：第 1 轮 + 选保守 恰好返回 first_decision', () => {
  const save = {
    v: 1, session_id: 1, round: 2, finished: false, score: 55,
    affection: { manager: 70, cfo: 70, cmo: 55 },
    history: [{ round: 1, risk: 'conservative', cashFlowAmount: 3 }],
    flags: {}, seenCg: [], seenSide: [],
  }
  same(achievements.evaluate(save), ['first_decision'])
})

test('evaluate：激进行为与高分分别解锁对应成就', () => {
  const save = {
    v: 1, session_id: 2, round: 3, finished: true, score: 85,
    affection: { manager: 70, cfo: 40, cmo: 85 },
    history: [
      { round: 1, risk: 'aggressive', cashFlowAmount: 2 },
      { round: 2, risk: 'aggressive', cashFlowAmount: 1 },
      { round: 3, risk: 'balanced', cashFlowAmount: 0 },
    ],
    flags: {}, seenCg: [], seenSide: [],
  }
  const unlocked = achievements.evaluate(save)
  assert.ok(unlocked.includes('adventurer'))
  assert.ok(unlocked.includes('treasurer'))
  assert.ok(unlocked.includes('tycoon'))
  assert.ok(unlocked.includes('first_decision'))
})

/* ================= 存档重建（2 条） ================= */

test('rebuildFromSession：round/history/好感度按 turns 重建', () => {
  const session = {
    session_id: 7, student_name: '学生', case_version: 1,
    current_metrics: null, next_node_id: null, finished: false, play: null,
    turns: [
      { node_id: 1, chosen_option: 'A', chosen_label: '维持现有定价体系（美式12元/杯），小幅优化产品与控制成本', after_metrics: null, summary: '' },
      { node_id: 2, chosen_option: 'C', chosen_label: '大规模广告投放与高频促销补贴，营销预算占营收20%', after_metrics: null, summary: '' },
    ],
  }
  const rebuilt = persistence.rebuildFromSession(session)
  assert.equal(rebuilt.round, 3)
  assert.equal(rebuilt.history.length, 2)
  assert.equal(rebuilt.history[0].risk, 'conservative')
  assert.equal(rebuilt.history[1].risk, 'aggressive')
  // 初始 70/60/65 → 保守(0,+10,-10) → 70/70/55 → 激进(0,-10,+10) → 70/60/65
  same(rebuilt.affection, { manager: 70, cfo: 60, cmo: 65 })
})

test('rebuildFromSession：首轮亏损不扣 profit（I.3-10），只按现金流给分', () => {
  const session = {
    session_id: 8, student_name: '学生', case_version: 1,
    current_metrics: null, next_node_id: null, finished: false,
    play: { base_metrics: { revenue: 12, gross_margin: '60.0%', market_share: '20.0%', cash_flow: '持平' } },
    turns: [
      { node_id: 1, chosen_option: 'A', chosen_label: '半年内同时进入3所新高校，开设5家新店，快速抢占市场', after_metrics: { revenue: 10.5, gross_margin: '60.0%', market_share: '35.0%', cash_flow: '大幅流出' }, summary: '' },
    ],
  }
  const rebuilt = persistence.rebuildFromSession(session)
  // 首轮营收 12→10.5 为负，但 I.3-10 要求 profit 项恒 0；现金项 +5 + 激进匹配(份额涨) +5 → 60
  assert.equal(rebuilt.score, 60)
  assert.equal(rebuilt.history[0].risk, 'aggressive')
})

test('saveSave/loadSave：localStorage 往返，损坏数据返回 null', () => {
  const store = new Map()
  const localStorageMock = {
    getItem: (k) => store.get(k) ?? null,
    setItem: (k, v) => store.set(k, v),
  }
  // vm 是独立 realm，localStorage 需注入模块执行上下文
  const p = loadModule('features/galgame/engine/persistence.ts', { './dialogueEngine': dialogueEngine }, { localStorage: localStorageMock })
  const save = {
    v: 1, session_id: 9, round: 1, finished: false, score: 50,
    affection: { manager: 70, cfo: 60, cmo: 65 },
    history: [], flags: {}, seenCg: [], seenSide: [],
  }
  p.saveSave('tok-test', 'formal', save)
  const loaded = p.loadSave('tok-test', 'formal')
  assert.equal(loaded.session_id, 9)
  same(loaded.affection, { manager: 70, cfo: 60, cmo: 65 })
  assert.equal(p.loadSave('missing-token', 'formal'), null)
  store.set('galgame_save:bad:formal', '{"v":2}')
  assert.equal(p.loadSave('bad', 'formal'), null)
})

// P2-D2：三角色表情按财数动态切换
const linesView = loadModule('features/galgame/phases/LinesView.tsx', {
  '../components/SceneBackground': {},
  '../components/CharacterSprite': {},
  '../components/DialogueBox': {},
  '../components/MoodBar': {},
})

test('P2-D2 manager：净利<0 或份额环比<0 → worried；双正 → happy；否则 calm', () => {
  assert.equal(linesView.managerExpression(-10, 1.5), 'worried')
  assert.equal(linesView.managerExpression(10, -0.5), 'worried')
  assert.equal(linesView.managerExpression(10, 1.5), 'happy')
  assert.equal(linesView.managerExpression(0, 0), 'calm')
  assert.equal(linesView.managerExpression(10, 0), 'calm')
})

test('P2-D2 cmo：份额环比 >0 excited / <0 worried / =0 calm', () => {
  assert.equal(linesView.cmoExpression(1.5), 'excited')
  assert.equal(linesView.cmoExpression(-0.5), 'worried')
  assert.equal(linesView.cmoExpression(0), 'calm')
})

test('P2-D2 cfo：现金流<0 anxious；净利>0 excited；否则 calm', () => {
  assert.equal(linesView.cfoExpression(-5, 10), 'anxious')
  assert.equal(linesView.cfoExpression(0, 10), 'excited')
  assert.equal(linesView.cfoExpression(5, -10), 'calm')
  assert.equal(linesView.cfoExpression(null, 0), 'calm')
})
