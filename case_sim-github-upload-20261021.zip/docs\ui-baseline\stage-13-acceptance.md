# 游戏化改造验收报告（阶段 13 · 全量回归）

生成时间：2026-10-21 11:4x（本地）
性质：只读回归，未修改任何业务代码（仅新增压测脚本 `scripts/loadtest/loadtest.py` 与本报告/基线文档）

---

## 1. 回归矩阵

| 项 | 结果 | 说明 |
| --- | --- | --- |
| 前端测试 `npm test` | **126/126 通过** | 清单基线 65/65 已过时；实测 126（65→85→116→123→126 逐阶段漂移，按实际判） |
| 类型检查 `npx tsc -b` | **0 错误** | |
| 构建 `npm run build` | **成功** | `dist/assets/index-*.js` = **693.09 kB**；基线 665.01 kB（BASELINE.md）→ 增量 **+28.08 kB ≤ +30 kB** ✅（对清单基线 663.14 kB 为 +29.95 kB，贴边通过） |
| 后端 `pytest -q`（项目根） | **212 passed**（62.06s） | 清单基线 189 已过时（189→190→212 漂移）；非在 `backend/` 目录误跑（无 collection error） |

## 2. 变更文件清单（按阶段归类，mtime 审计）

### 学生端（本清单改造，全部确认）
| 文件 | 阶段 | 内容 |
| --- | --- | --- |
| `frontend/src/index.css` 等换肤面 | 1–5 | 设计令牌/换肤/策略卡/财务卡/关卡进度（历史阶段验收） |
| `frontend/src/layouts/StudentLayout.tsx` | 6 | FAB 气泡化（🤖 图标、去 MessageOutlined、去内联背景色） |
| `frontend/src/layouts/StudentLayout.css` | 6+8 | FAB/面板变量化 + #db2777 主色；微动效（hover-only 上浮、:active 缩放、reduced-motion 全局兜底） |
| `backend/app/routers/student.py` | 6（C6） | SSE 连接治理（keep-alive 心跳、断连取消、请求级 DB 释放） |
| `frontend/src/pages/teacher/TeacherStudentsPage.tsx` | 7 | KPI 卡片 + Sparkline 迷你趋势线（仅此一处为教师端清单改动，用户红线允许新增） |

### 教师端其它（非本清单改动，原因已查明）
| 文件 | mtime | 原因 |
| --- | --- | --- |
| `TeacherLoginPage.tsx`、`TeacherAccountsPage.tsx`、`teacher.css`、`PublishPanel.tsx`、`TeacherRecordsPage.tsx`、`ProgressivePanel.tsx`、`OptionDistributionChart.tsx`、`TeacherWorkbenchPage.tsx`、`TeacherLayout.tsx`、`TeacherTrashPage.tsx` | 2026-10-21 09:10–10:41 | **WorkBuddy 并行任务**改动（非本会话、非本清单）。证据：① WorkBuddy 会话日志显示 09:22–09:45 仍有 Bash 操作桌面项目；② worktree 含《教师端登录问题-差异分析与修改计划.md》等并行产物；③ 内容抽查完整健康（教师登录多账号逻辑、阶段3 确认框样式等均为正常功能代码） |

## 3. 红线文件检查

| 文件 | mtime | 结论 |
| --- | --- | --- |
| `frontend/src/pages/teacher/components/baselineFinance.ts` | 2026-10-20 11:04:59 | ✅ 早于改造期（10-20 21:00） |
| `frontend/src/domain/financials.d.ts` | 2026-10-20 11:04:59 | ✅ |
| `frontend/src/domain/financials.js` | 2026-10-20 11:04:59 | ✅ |
| `backend/app/domain/financials.py` | 2026-10-20 11:04:58 | ✅ |

**结论：红线文件未被触碰。**

## 4. 教师端是否被误改

- 清单预期"只有 TeacherStudentsPage.tsx"：✅ 本会话/本清单只改了它。
- 另发现 10 个教师端文件 mtime 在改造期后（09:10–10:41），**来源为 WorkBuddy 并行任务，非本清单回归范围**。内容抽查完整、无破坏性改动；且当前代码库 `tsc 0 错误 + 前端 126/126 + build 成功 + 后端 212/212`，证明并行改动未引入回归。
- 未做回滚（用户红线：不得删除教师端已有功能；并行任务改动属用户其它工作流产物，无权擅动）。

## 5. C9 + Gate A（并发增量）

详见 `docs/ui-baseline/concurrency-baseline.md`。要点：

| DoD 项 | 要求 | 实测 | 判定 |
| --- | --- | --- | --- |
| 50 并发混合错误率 | 0% | **0%**（无 5xx / 无 QueuePool 超时 / 无 database is locked） | ✅ |
| 读 p95 | ≤300ms | 343.2ms | ❌ |
| 写 p95 | ≤600ms | 808.3ms | ❌ |
| 一次推演请求数 | ≤ 改造前 | **8 次**（me×1 + sessions×4 + decide×3，无轮询/无 SSE/无进度请求） | ✅（改造前无数值记录，代码级证据：请求链未动，未新增任何请求逻辑） |
| concurrency-baseline.md | 四档原始数字 + 200 档失败形态 | 已含 | ✅ |

- 四档 mixed：10 档 RPS 117.7 错误率 0；50 档 RPS 111.2 错误率 0；100 档全 ReadTimeout（连接池 20 < 100，等池 30s 超时）；200 档 PoolTimeout×196 + ReadTimeout×199 + http5xx×5。
- **超阈根因**：db.py 连接池按 11 并发（1 教师 + 10 学生）设计（pool 10+10）；50 并发超设计口径 4.5 倍，延迟来自连接池排队与 SQLite 单写锁。错误率全程 0、无锁死异常 → **非改造引入的回归，属口径外负载**。
- **遗留**：50 并发延迟阈值未达标；如需支撑 ≥50 并发，上线前应上调 POOL_SIZE / 多 worker / 独立库并重测（本次只读未改）。

## 6. 遗留问题（非阻塞）

1. Gate A 延迟项超阈（见上，瓶颈=连接池配置，非本次改造）。
2. 教师端并行改动（WorkBuddy 任务）与清单回归范围无关，未纳入本报告验收，建议用户知悉来源。
3. 后端测试数/前端测试数/主 chunk 基线在清单中均过时（189/65/663.14），本项目已按"实测为准"原则逐步修正，建议后续任务更新清单基线。

## 7. 是否建议上线

**建议：是（有条件）。**

依据：
- 视觉改造目标全部达成（阶段 6/7/8 各自 DoD 通过 + 本回归 126/126、0 错、build 成功、212/212）。
- 红线（财务口径文件）未触碰；教师端仅新增 KPI 展示，未删任何功能（用户红线满足）。
- 并发方面：设计口径（11 并发）内性能充裕（10 档 p95 105ms），错误率在所有档位达标前的档位均为 0，无锁死/无回归。
- 条件：若生产预期并发 >20（超过 pool 10+10），需先按部署规模调整连接池后上线；Gate A 延迟阈值以调整后重测为准。
