// 教师"停止推演"（play_locked）的页面级行为契约：
// 没有记录 → 不能开始，显示提示；有记录 → 只读保留；未锁 → 一切照旧。
const { test } = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const vm = require('node:vm')
const ts = require('typescript')

function loadModule(file, mocks = {}) {
  const exports = {}
  const source = fs.readFileSync(path.resolve(__dirname, '../src', file), 'utf8')
  vm.runInNewContext(ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, jsx: ts.JsxEmit.ReactJSX, target: ts.ScriptTarget.ES2022 } }).outputText, { exports, require: n => mocks[n] || {} })
  return exports
}

function play(token, locked = false) {
  return { case_title: token, background: '', dilemma: '', base_metrics: null, play_locked: locked,
    nodes: [{ id: 1, idx: 1, title: token, background: '', node_role: '', options: [{ key: 'C', label: '渠道策略' }, { key: 'A', label: '定价策略' }, { key: 'B', label: '营销策略' }] }] }
}
function session(token, locked = false) {
  return { session_id: 11, student_name: '学生', play: play(token, locked), next_node_id: 1,
    case_version: 1, play_locked: locked, turns: [] }
}

function mount(overrides = {}, saved = false) {
  const hooks = [], pending = [], navs = [], storage = new Map(saved ? [['student_session:a', '11']] : [])
  let cursor = 0, token = 'a', tree
  const mocks = {
    react: {
      memo: (component) => component,
      useState(initial) { const i = cursor++; if (!(i in hooks)) hooks[i] = initial; return [hooks[i], (value) => { hooks[i] = typeof value === 'function' ? value(hooks[i]) : value }] },
      useRef(initial) { const i = cursor++; return hooks[i] ||= { current: initial } },
      useEffect(effect, deps) { const i = cursor++, prev = hooks[i]; if (!prev || deps.some((v, j) => !Object.is(v, prev.deps[j]))) pending.push(() => { prev?.cleanup?.(); hooks[i] = { deps, cleanup: effect() } }) },
    },
    'react/jsx-runtime': { jsx: (type, props) => ({ type, props }), jsxs: (type, props) => ({ type, props }) },
    '../../components/MetricComparison': { __esModule: true, default: 'MetricComparison' },
    './components/SettlementCard': { __esModule: true, default: 'SettlementCard' },
    './components/RoundMap': { __esModule: true, default: 'RoundMap' },
    '../../domain/decisionNarrative': loadModule('domain/decisionNarrative.ts'),
    antd: { Popconfirm: 'Popconfirm', Alert: 'Alert', Button: 'Button', Card: 'Card', Input: { TextArea: 'TextArea' }, Progress: 'Progress', Steps: 'Steps', Spin: 'Spin', Space: 'Space', Typography: { Paragraph: 'Paragraph', Text: 'Text', Title: 'Title' } },
    'react-router-dom': { useNavigate: () => (to) => navs.push(to) },
    '../../context/StudentTokenContext': { useStudentToken: () => token },
    '../../context/StudentAccountContext': { useStudentAccount: () => ({ id: 1, real_name: '学生' }) },
    '../../api/client': { playGet: async (t) => play(t), startStudent: async (t) => session(t), restoreStudent: async (t) => session(t), decide: async () => ({}), ...overrides },
  }
  const code = ts.transpileModule(fs.readFileSync(path.resolve(__dirname, '../src/pages/student/StudentPlayPage.tsx'), 'utf8'), { compilerOptions: {
    module: ts.ModuleKind.CommonJS, jsx: ts.JsxEmit.ReactJSX, target: ts.ScriptTarget.ES2022,
  } }).outputText
  const exports = {}
  vm.runInNewContext(code, { exports, require: (name) => { if (name in mocks) return mocks[name]; throw new Error(name) },
    Promise, Error, Event, Date, sessionStorage: { getItem: (k) => storage.get(k) || null, setItem: (k, v) => storage.set(k, v) },
    window: { dispatchEvent() {} } })
  function render() { cursor = 0; tree = exports.default(); while (pending.length) pending.shift()() }
  function all(type, node = tree) {
    if (!node || typeof node !== 'object') return []
    if (Array.isArray(node)) return node.flatMap((n) => all(type, n ?? null))
    return [...(node.type === type ? [node.props] : []), ...all(type, node.props?.children ?? null)]
  }
  render()
  return { all, navs, navigate(next) { token = next; render() }, close() { for (const h of hooks) h?.cleanup?.() },
    async flush() { for (let i = 0; i < 4; i++) { await new Promise(setImmediate); render() } } }
}

function notes(page) { return page.all('div').filter((d) => d.role === 'note').map((d) => JSON.stringify(d)) }

test('locked case without a record cannot be started and shows the reason', async () => {
  const page = mount({ playGet: async (t) => play(t, true) })
  await page.flush()
  assert.ok(!page.all('Button').some((b) => b.children === '开始推演'), 'locked case must not offer 开始推演')
  const joined = notes(page).join('')
  assert.match(joined, /教师已停止该案例的推演/)
  assert.match(joined, /无法开始新的推演记录/)
  page.close()
})

test('locked case keeps an existing record viewable in read-only mode', async () => {
  const page = mount({ playGet: async (t) => play(t, true), restoreStudent: async (t) => session(t, true) }, true)
  await page.flush()
  const joined = notes(page).join('')
  assert.match(joined, /只读模式/)
  assert.match(joined, /推演记录已保留/)
  assert.ok(!page.all('Button').some((b) => b.children === '确认提交本回合'), 'locked case must not offer submit')
  assert.ok(!page.all('Button').some((b) => b.children === '开始推演'), 'locked case must not offer start')
  assert.ok(!page.all('Button').some((b) => b.children === '修改此决策及后续节点'), 'locked case must not offer rollback')
  page.close()
})

test('unlocked case keeps the normal start flow', async () => {
  const page = mount({})
  await page.flush()
  assert.ok(page.all('Button').some((b) => b.children === '开始推演'))
  assert.equal(notes(page).length, 0, 'no lock notice when the case is open')
  page.close()
})
