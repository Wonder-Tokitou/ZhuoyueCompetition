# 阶段 5 验收记录 — 好感度、评分与结局（T5.1 / T5.2）

日期：2026-10-21
范围：好感度侧栏（T5.1）+ 结算卡与结局（T5.2）。

## 代码交付

- `components/MoodBar.tsx`（新）：右侧竖排 3 条（店长粉 #db2777 / 财务蓝 #2563eb / 市场紫 #9333ea），宽 8px 圆角；`transition: height .4s`（reduced-motion 下 `transition: none`）；`role="progressbar"` + aria-valuenow/min/max；本轮增量 +N/−N 浮字（`@keyframes galgame-float-up` 1s 上浮消失，key 按轮次触发重放）。
- `engine/persistence.ts`：`rebuildFromSession` 升级——除好感度外，分数同样用 turns 逐轮累计（netProfitDelta 用营收环比、cashFlowAmount 填 0，与 financial_state 缺失时的结算口径一致）；`GalgameHistoryEntry` 增加 `netProfit?`。修复 `state.play` 可为 null 的崩溃（`state.play?.base_metrics ?? null`）。
- `GalgamePlayPage.tsx`：
  - 结算时计算 outcome（risk/Δ净利润/现金净流量/份额环比）→ `scoreRound` → 新分数 + 整句分项 → 好感度 `applyAffection` → 写入本地 save；
  - 结算卡升级：营收/毛利率/市场份额/现金流/净利润（financial_state 缺失显示 — 并注明"本案例未开启财务仿真，净利润按营收环比估算"）+ 本局分数 + 整句分项列表；
  - 结局页 `FinishedCard`：结局名 + 3–5 句台词 + CG 占位（success/normal/fail 三色）+ 总分 + 「查看经营日记」（逐轮展示幕标题/所选 label/摘要）+ 「查看 AI 复盘」（Link 到 `/student/:token/review?session=<id>`）。
- `dev/preview.tsx`：新增 `/student/:studentToken/review` 路由（复用主线 `StudentReviewPage`）以联调跳转。
- `galgame.css`：moodbar / 浮字动画 / 结算分数与分项 / 结局页全套样式 + reduced-motion 兜底。

## 浏览器端到端实测（真实后端，学生蔡徐坤）

| 验证项 | 结果 |
|---|---|
| MoodBar 初始 | 店长 70 / 财务 60 / 市场 65，progressbar aria-valuenow 齐全 ✓ |
| 选激进后 | 财务 60→50（浮字 −10）、市场 65→75（浮字 +10）、店长不变 ✓（T5.1 验收） |
| 第 1 局全激进 | 分数 52→67→87，breakdown 整句 3 条（净利−1.5 / 现金正 / 激进匹配份额涨）→ 结局「连锁霸主」success ✓（>80） |
| 第 2 局全保守 | 分数 65→62→77 → 结局「稳中求进」normal ✓（50–80） |
| 结算卡内容 | 5 项指标 + 净利润"—"+ 口径注明 + 本局分数 + 分项整句 ✓ |
| 重载一致性 | 从服务器重建后分数/好感度/结局与结算时一致（87 / 连锁霸主）✓ |
| 经营日记 | 展开显示 3 轮（第 N 轮 · 幕标题 · 所选 label · 摘要）✓ |
| AI 复盘跳转 | `/student/benchmark-demo-v4/review?session=7` 页面正常显示本轮复盘 ✓ |

好感度累计验证（激进→保守→稳健）：70/60/65 →(0,−10,+10)→ 70/50/75 →(0,+10,−10)→ 70/60/65 →(+6,+2,+2)→ **76/62/67**，DOM/aria/条高一致 ✓

## 三分数段复现

- **>80 success**：全激进 → 87 「连锁霸主」✓（真实复现）
- **50–80 normal**：全保守 → 77 「稳中求进」✓（真实复现）
- **<50 fail**：**本案例无法自然复现**——根因：案例 `simulation.enabled=false` 时后端不下发 `financial_state`，结算时 `cashFlowAmount=0`（D5 现金分项恒 +5，地板偏高），且本案例净利数据总体上行（实测各轮 Δ∈[−1.5, +4]），无连续亏损路径。清单 T5.2 失败处理已落地：净利退化按营收环比估算并在 UI 注明。fail 结局映射（`endingOf(<50)='fail'` + `end.fail` 台词段）由既有单测覆盖（31 条支线单测含 endingOf 三档）。

## 回归

- `npm test`：126/126 pass，fail 0（期间发现并修复 rebuildFromSession 对 `play:null` 的崩溃）
- `npx tsc -b`：0 错
- App.tsx 无 galgame 引用（隔离保持）

## 已知环境现象

- 浏览器"查看结局"切换瞬间偶发白屏（vite HMR 时序，强制刷新 `?t=` 即恢复，非代码缺陷；重载后数据一致性已验证）。

## 截图

- `stage5-ending.png`（219x869，结局页：连锁霸主 / cg.ending.success / 总分 82 / MoodBar 76-62-67 / 查看经营日记）
