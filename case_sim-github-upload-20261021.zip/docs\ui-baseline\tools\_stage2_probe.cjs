/**
 * 阶段 2（学生端换肤）取证脚本 —— 由阶段 0 的 _shot.cjs 派生，只加取证字段，不改原脚本。
 *
 * 取证两档宽度：
 *   375px（移动）：底色、卡片圆角/阴影/边框、主按钮渐变、输入框圆角、横向溢出、整页截图
 *   1280px（桌面）：html 画布底色是否同为暖色（Q3 增补项）
 *
 * 用法：
 *   node _stage2_probe.cjs --token <student_access_token> [--session <id>]
 *                          [--out-prefix stage-2] [--outdir ..]
 *
 * 依赖：Node 22 自带 WebSocket；本机 Chrome（--headless=new）。不需要 playwright。
 */
const { spawn } = require('node:child_process')
const fs = require('node:fs')
const os = require('node:os')
const path = require('node:path')

const CHROME = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
const PORT = 9334
const BASE = 'http://127.0.0.1:8110'
const CASE_TOKEN = 'benchmark-demo-v4'

function arg(name, fallback) {
  const i = process.argv.indexOf(`--${name}`)
  return i >= 0 && process.argv[i + 1] ? process.argv[i + 1] : fallback
}

const TOKEN = arg('token')
const SESSION = arg('session')
const PREFIX = arg('out-prefix', 'stage-2')
const OUTDIR = path.resolve(arg('outdir', path.join(__dirname, '..')))

if (!TOKEN) {
  console.error('missing --token')
  process.exit(2)
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

async function browserWs() {
  for (let i = 0; i < 60; i++) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/version`)
      const json = await res.json()
      if (json.webSocketDebuggerUrl) return json.webSocketDebuggerUrl
    } catch { /* 还没起来 */ }
    await sleep(250)
  }
  throw new Error('chrome 调试端口未就绪')
}

function client(ws) {
  let id = 0
  const waiting = new Map()
  ws.addEventListener('message', (ev) => {
    const msg = JSON.parse(ev.data)
    if (msg.id && waiting.has(msg.id)) {
      const { resolve, reject } = waiting.get(msg.id)
      waiting.delete(msg.id)
      msg.error ? reject(new Error(JSON.stringify(msg.error))) : resolve(msg.result)
    }
  })
  return (method, params = {}, sessionId) => new Promise((resolve, reject) => {
    const mid = ++id
    waiting.set(mid, { resolve, reject })
    ws.send(JSON.stringify({ id: mid, method, params, ...(sessionId ? { sessionId } : {}) }))
  })
}

const PROBE = `(() => {
  const cs = (el) => el ? getComputedStyle(el) : null
  const pick = (sel, props) => {
    const el = document.querySelector(sel)
    const s = cs(el)
    if (!s) return null
    const out = {}
    for (const p of props) out[p] = s[p]
    return out
  }
  return JSON.stringify({
    viewport: { width: innerWidth, height: innerHeight },
    overflow: {
      scrollWidth: document.documentElement.scrollWidth,
      clientWidth: document.documentElement.clientWidth,
      bodyScrollWidth: document.body.scrollWidth,
    },
    bodyClass: document.body.className,
    htmlBg: cs(document.documentElement).backgroundColor,
    bodyBg: cs(document.querySelector('body.student-body')).backgroundColor,
    shellBg: pick('.student-shell', ['backgroundColor']),
    mainBg: pick('.student-main', ['backgroundColor']),
    card: pick('.ant-card', ['borderTopWidth', 'borderTopColor', 'borderTopLeftRadius', 'boxShadow', 'backgroundColor']),
    cardHead: pick('.ant-card-head', ['paddingLeft', 'paddingRight', 'borderBottomColor']),
    cardTitle: pick('.ant-card-head-title', ['fontSize']),
    primaryBtn: pick('.ant-btn-primary', ['backgroundImage', 'backgroundColor', 'borderTopColor', 'boxShadow']),
    input: pick('.ant-input', ['borderTopLeftRadius', 'borderTopRightRadius']),
    secondary: pick('.ant-typography-secondary', ['color']),
    bodyColor: cs(document.querySelector('body.student-body')).color,
    counts: {
      cards: document.querySelectorAll('.ant-card').length,
      metrics: document.querySelectorAll('.metric-card').length,
      optionCards: document.querySelectorAll('.strategy-option-card').length,
      primaryBtns: document.querySelectorAll('.ant-btn-primary').length,
    },
    textHead: document.body.innerText.replace(/\\s+/g, ' ').slice(0, 240),
  })
})()`

;(async () => {
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'stage2-chrome-'))
  const chrome = spawn(CHROME, [
    '--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
    '--no-proxy-server', '--hide-scrollbars', '--force-device-scale-factor=2',
    `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`, 'about:blank',
  ], { stdio: 'ignore' })

  try {
    const wsUrl = await browserWs()
    const ws = new WebSocket(wsUrl)
    await new Promise((res, rej) => { ws.addEventListener('open', res); ws.addEventListener('error', rej) })
    const send = client(ws)

    const { targetId } = await send('Target.createTarget', { url: 'about:blank' })
    const { sessionId } = await send('Target.attachToTarget', { targetId, flatten: true })
    const call = (m, p) => send(m, p, sessionId)

    await call('Page.enable')
    await call('Runtime.enable')
    await call('Emulation.setDeviceMetricsOverride', { width: 375, height: 812, deviceScaleFactor: 2, mobile: true })

    const boot = [
      `try { sessionStorage.setItem('student_access_token', ${JSON.stringify(TOKEN)}) } catch (e) {}`,
      SESSION ? `try { sessionStorage.setItem('student_session:${CASE_TOKEN}', ${JSON.stringify(SESSION)}) } catch (e) {}` : '',
    ].join('\n')
    await call('Page.addScriptToEvaluateOnNewDocument', { source: boot })

    await call('Page.navigate', { url: `${BASE}/student/${CASE_TOKEN}` })
    await sleep(4500)

    const mobile = JSON.parse((await call('Runtime.evaluate', { expression: PROBE, returnByValue: true })).result.value)
    mobile.authenticated = !mobile.textHead.includes('请先登录学生账号')
    const shot375 = await call('Page.captureScreenshot', { format: 'png', captureBeyondViewport: true, fromSurface: true })
    const file375 = path.join(OUTDIR, `${PREFIX}-375.png`)
    fs.writeFileSync(file375, Buffer.from(shot375.data, 'base64'))

    // 已完成会话没有 TextArea，输入框圆角改从 AI 助教面板里的真实 antd 输入框取证
    await call('Runtime.evaluate', { expression: "document.querySelector('.ant-float-btn')?.click()" })
    await sleep(900)
    const tutor = JSON.parse((await call('Runtime.evaluate', {
      expression: `JSON.stringify({
        panelOpen: !!document.querySelector('.student-tutor-panel'),
        inputCount: document.querySelectorAll('.ant-input').length,
        input: (() => {
          const el = document.querySelector('.ant-input')
          if (!el) return null
          const s = getComputedStyle(el)
          return { radius: s.borderTopLeftRadius, fontSize: s.fontSize, selector: el.className }
        })(),
      })`,
      returnByValue: true,
    })).result.value)

    // 桌面档：看 body 限宽 1280px 之外露出的 html 画布底色
    await call('Emulation.setDeviceMetricsOverride', { width: 1440, height: 900, deviceScaleFactor: 1, mobile: false })
    await call('Page.reload')
    await sleep(3500)
    const desktop = JSON.parse((await call('Runtime.evaluate', { expression: PROBE, returnByValue: true })).result.value)
    const shotDesktop = await call('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false, fromSurface: true })
    const fileDesktop = path.join(OUTDIR, `${PREFIX}-1440.png`)
    fs.writeFileSync(fileDesktop, Buffer.from(shotDesktop.data, 'base64'))

    console.log(JSON.stringify({
      url: `${BASE}/student/${CASE_TOKEN}`,
      session: SESSION || null,
      mobile375: mobile,
      desktop1440: desktop,
      tutorInput375: tutor,
      saved: {
        mobile: `SAVED=${file375} BYTES=${fs.statSync(file375).size}`,
        desktop: `SAVED=${fileDesktop} BYTES=${fs.statSync(fileDesktop).size}`,
      },
    }, null, 2))
    ws.close()
  } finally {
    chrome.kill()
  }
})().catch((e) => { console.error('FAILED:', e.message); process.exit(1) })
