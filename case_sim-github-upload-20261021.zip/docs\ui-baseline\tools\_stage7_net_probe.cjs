/**
 * 阶段 7 · C7 DoD 验证：教师看板打开 30 秒内请求数 ≤ 7（不随学生人数增长）。
 * 用 CDP Network 域统计真实 XHR/fetch 请求数。
 */
const { spawn } = require('node:child_process')
const fs = require('node:fs')
const os = require('node:os')
const path = require('node:path')

const CHROME = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
const PORT = 9340
const BASE = 'http://127.0.0.1:8110'
const TOKEN = process.argv[2]
if (!TOKEN) { console.error('missing token'); process.exit(2) }

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
async function browserWs() {
  for (let i = 0; i < 60; i++) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/version`)
      const json = await res.json()
      if (json.webSocketDebuggerUrl) return json.webSocketDebuggerUrl
    } catch { /* 未就绪 */ }
    await sleep(250)
  }
  throw new Error('chrome 调试端口未就绪')
}
function client(ws) {
  let id = 0
  const waiting = new Map()
  ws.addEventListener('message', (ev) => {
    const msg = JSON.parse(ev.data)
    if (msg.id && waiting.has(msg.id)) {
      const { resolve, reject } = waiting.get(msg.id)
      waiting.delete(msg.id)
      msg.error ? reject(new Error(JSON.stringify(msg.error))) : resolve(msg.result)
      return
    }
  })
  return (method, params = {}, sessionId) => new Promise((resolve, reject) => {
    const mid = ++id
    waiting.set(mid, { resolve, reject })
    ws.send(JSON.stringify({ id: mid, method, params, ...(sessionId ? { sessionId } : {}) }))
  })
}

;(async () => {
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'stage7net-'))
  const chrome = spawn(CHROME, [
    '--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
    '--no-proxy-server', '--hide-scrollbars', `--remote-debugging-port=${PORT}`,
    `--user-data-dir=${profile}`, 'about:blank',
  ], { stdio: 'ignore' })
  try {
    const wsUrl = await browserWs()
    const ws = new WebSocket(wsUrl)
    await new Promise((res, rej) => { ws.addEventListener('open', res); ws.addEventListener('error', rej) })
    const send = client(ws)
    const { targetId } = await send('Target.createTarget', { url: 'about:blank' })
    const { sessionId } = await send('Target.attachToTarget', { targetId, flatten: true })
    const call = (m, p) => send(m, p, sessionId)
    await call('Page.enable')
    await call('Network.enable')
    await call('Runtime.enable')
    const started = Date.now()
    const requests = []
    ws.addEventListener('message', (ev) => {
      const msg = JSON.parse(ev.data)
      if (msg.method === 'Network.requestWillBeSent' && msg.sessionId === sessionId) {
        const u = msg.params.request.url || ''
        if (u.startsWith(BASE) && !u.includes('.js') && !u.includes('.css') && !u.includes('.png') && !u.includes('.ico')) {
          requests.push({ at: ((Date.now() - started) / 1000).toFixed(1) + 's', url: u.replace(BASE, '') })
        }
      }
    })
    await call('Page.navigate', { url: `${BASE}/teacher/${TOKEN}/students` })
    await sleep(30000)
    console.log(JSON.stringify({ windowSeconds: 30, requestCount: requests.length, requests }, null, 2))
    ws.close()
  } finally {
    chrome.kill()
  }
})().catch((e) => { console.error('FAILED:', e.message); process.exit(1) })
