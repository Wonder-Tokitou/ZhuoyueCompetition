import { memo } from 'react'

/**
 * 关卡式进度：三段经营路 + 三个站点（替代 antd <Steps>）。
 *
 * 两条硬约束（见执行清单阶段 5 的 C5）：
 * 1. 只吃三个数字 props，**不自己发请求**——数据源必须是父组件已有的 state.turns.length / next_node_id，
 *    否则每轮多一次进度请求，200 人在线时比整个换肤改造的影响都大。
 * 2. 纯 CSS 绘制（连接线走 ::before），不引图片、不引图标字体、不引新依赖。
 *
 * 无障碍：容器 role="list"、节点 role="listitem"、当前节点 aria-current="step" 且可 Tab 聚焦，
 * 节点的可访问名是「第 N 轮 进行中/已完成/未开始」——视觉文字做了 aria-hidden，避免被读两遍。
 */
export type RoundMapProps = { total: number; current: number; done: number }

function RoundMapBase({ total, current, done }: RoundMapProps) {
  if (total <= 0) return null
  return (
    <ul className="round-map" role="list" aria-label="推演进度">
      {Array.from({ length: total }, (_, i) => {
        const round = i + 1
        const isDone = round <= done
        const isCurrent = !isDone && round === current
        const status = isDone ? '已完成' : isCurrent ? '进行中' : '未开始'
        const nodeClass = ['round-node', isDone ? 'is-done' : '', isCurrent ? 'is-current' : ''].filter(Boolean).join(' ')
        return (
          <li
            key={round}
            className={nodeClass}
            role="listitem"
            aria-current={isCurrent ? 'step' : undefined}
            aria-label={`第 ${round} 轮 ${status}`}
            tabIndex={isCurrent ? 0 : undefined}
          >
            <span className="dot" aria-hidden="true">{round}</span>
            <span className="round-label" aria-hidden="true">第 {round} 轮<br />{status}</span>
          </li>
        )
      })}
    </ul>
  )
}

/** C4：三个 props 都是基本类型，浅比较天然命中，父级其他状态变化不会重绘这条进度路。 */
const RoundMap = memo(RoundMapBase)

export default RoundMap
