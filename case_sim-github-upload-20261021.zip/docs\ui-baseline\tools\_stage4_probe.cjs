/**
 * 阶段 4（财务卡图标与趋势）取证脚本。
 *
 * 取证点：
 *   1. 每张 .metric-card 的 .metric-label::before 是否注入了 emoji（图标只能走 CSS）
 *   2. label 的文本节点是否仍是原文（营收 / 毛利率 / 市场份额 / 现金流），emoji 不得进 textContent
 *   3. aria-label 是否生效（accessible name 不含 emoji）
 *   4. 营收数字的 tabular-nums / letter-spacing
 *   5. 趋势箭头的 transition 与颜色
 *   6. 第 5 张（净利润）卡的图标：真实数据无 net_profit，改用「注入一个占位卡读 computed ::before」验证 nth-child(5) 规则
 *   7. 新增 Image / Font 静态资源请求数（应为 0）
 *
 * 用法：node _stage4_probe.cjs --token <token> --session <id> [--outdir ..]
 */
const { spawn } = require('node:child_process')
const fs = require('node:fs')
const os = require('node:os')
const path = require('node:path')

const CHROME = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
const PORT = 9336
const BASE = 'http://127.0.0.1:8110'
const CASE_TOKEN = 'benchmark-demo-v4'

function arg(name, fallback) {
  const i = process.argv.indexOf(`--${name}`)
  return i >= 0 && process.argv[i + 1] ? process.argv[i + 1] : fallback
}
const TOKEN = arg('token')
const SESSION = arg('session')
const OUTDIR = path.resolve(arg('outdir', path.join(__dirname, '..')))
if (!TOKEN) { console.error('missing --token'); process.exit(2) }

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

async function browserWs() {
  for (let i = 0; i < 60; i++) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/version`)
      const json = await res.json()
      if (json.webSocketDebuggerUrl) return json.webSocketDebuggerUrl
    } catch { /* 未就绪 */ }
    await sleep(250)
  }
  throw new Error('chrome 调试端口未就绪')
}

function client(ws, onEvent) {
  let id = 0
  const waiting = new Map()
  ws.addEventListener('message', (ev) => {
    const msg = JSON.parse(ev.data)
    if (msg.id && waiting.has(msg.id)) {
      const { resolve, reject } = waiting.get(msg.id)
      waiting.delete(msg.id)
      msg.error ? reject(new Error(JSON.stringify(msg.error))) : resolve(msg.result)
      return
    }
    if (msg.method && onEvent) onEvent(msg)
  })
  return (method, params = {}, sessionId) => new Promise((resolve, reject) => {
    const mid = ++id
    waiting.set(mid, { resolve, reject })
    ws.send(JSON.stringify({ id: mid, method, params, ...(sessionId ? { sessionId } : {}) }))
  })
}

const PROBE = `(() => {
  const cards = [...document.querySelectorAll('.student-metrics .metric-card')]
  const info = cards.map((el) => {
    const label = el.querySelector('.metric-label')
    const value = el.querySelector('.metric-value')
    const cs = label ? getComputedStyle(label, '::before') : null
    const ls = label ? getComputedStyle(label) : null
    const vs = value ? getComputedStyle(value) : null
    return {
      className: el.className,
      labelText: JSON.stringify(label?.textContent || ''),
      ariaLabel: label?.getAttribute('aria-label') || null,
      beforeContent: cs?.content || null,
      beforeFontFamily: cs?.fontFamily || null,
      beforeFontSize: cs?.fontSize || null,
      labelFontSize: ls?.fontSize || null,
      valueFontSize: vs?.fontSize || null,
      valueFontWeight: vs?.fontWeight || null,
      letterSpacing: vs?.letterSpacing || null,
      fontVariantNumeric: vs?.fontVariantNumeric || null,
      metricNote: el.querySelector('.metric-note')?.textContent || null,
    }
  })
  const trend = document.querySelector('.metric-trend')
  const trendCs = trend ? getComputedStyle(trend) : null

  // 第 5 张卡：注入占位后读 nth-child(5) 的 ::before，再移除
  let fifth = null
  const box = document.querySelector('.student-metrics')
  if (box && cards.length === 4) {
    const probe = document.createElement('div')
    probe.className = 'metric-card'
    probe.innerHTML = '<span class="metric-label" aria-label="净利润">x</span>'
    box.appendChild(probe)
    const before = getComputedStyle(probe.querySelector('.metric-label'), '::before')
    fifth = { beforeContent: before.content, beforeFontFamily: before.fontFamily }
    probe.remove()
  }

  return {
    count: cards.length,
    cards: info,
    trend: trend ? {
      text: trend.textContent,
      color: trendCs.color,
      transition: trendCs.transitionProperty + ' ' + trendCs.transitionDuration,
    } : null,
    fifthCardRule: fifth,
    fifthCardInjected: !!fifth,
    overflow: { scrollWidth: document.documentElement.scrollWidth, clientWidth: document.documentElement.clientWidth },
  }
})()`

;(async () => {
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'stage4-chrome-'))
  const chrome = spawn(CHROME, [
    '--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
    '--no-proxy-server', '--hide-scrollbars', '--force-device-scale-factor=2',
    `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`, 'about:blank',
  ], { stdio: 'ignore' })

  try {
    const wsUrl = await browserWs()
    const ws = new WebSocket(wsUrl)
    await new Promise((res, rej) => { ws.addEventListener('open', res); ws.addEventListener('error', rej) })
    const events = []
    const send = client(ws, (m) => events.push(m))
    const { targetId } = await send('Target.createTarget', { url: 'about:blank' })
    const { sessionId } = await send('Target.attachToTarget', { targetId, flatten: true })
    const call = (m, p) => send(m, p, sessionId)

    await call('Page.enable')
    await call('Runtime.enable')
    await call('Network.enable')
    await call('Emulation.setDeviceMetricsOverride', { width: 375, height: 812, deviceScaleFactor: 2, mobile: true })

    await call('Page.addScriptToEvaluateOnNewDocument', {
      source: [
        `try { sessionStorage.setItem('student_access_token', ${JSON.stringify(TOKEN)}) } catch (e) {}`,
        SESSION ? `try { sessionStorage.setItem('student_session:${CASE_TOKEN}', ${JSON.stringify(SESSION)}) } catch (e) {}` : '',
      ].join('\n'),
    })
    events.length = 0
    await call('Page.navigate', { url: `${BASE}/student/${CASE_TOKEN}` })
    await sleep(4500)

    const result = (await call('Runtime.evaluate', { expression: PROBE, returnByValue: true })).result.value

    const types = events
      .filter((m) => m.method === 'Network.requestWillBeSent')
      .map((m) => m.params?.type)
      .reduce((acc, t) => { acc[t] = (acc[t] || 0) + 1; return acc }, {})
    const fontOrImg = types.Font || 0
    const img = types.Image || 0

    const shot = await call('Page.captureScreenshot', { format: 'png', captureBeyondViewport: true, fromSurface: true })
    const file = path.join(OUTDIR, 'stage-4-metrics-375.png')
    fs.writeFileSync(file, Buffer.from(shot.data, 'base64'))

    console.log(JSON.stringify({
      ...result,
      requests: { byType: types, font: fontOrImg, image: img, emojiFontRequests: fontOrImg },
      saved: `SAVED=${file} BYTES=${fs.statSync(file).size}`,
    }, null, 2))
    ws.close()
  } finally {
    chrome.kill()
  }
})().catch((e) => { console.error('FAILED:', e.message); process.exit(1) })
