const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),ts=require('typescript'),path=require('node:path')
const exportsValue={}
vm.runInNewContext(ts.transpileModule(fs.readFileSync(path.join(__dirname,'../src/pages/teacher/components/baselineFinance.ts'),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS}}).outputText,{exports:exportsValue})
const {linkedBaseline,baselineError}=exportsValue
test('revenue keeps margin and recalculates cost',()=>{assert.equal(linkedBaseline(200,'20%',80,'margin').cost,160);assert.equal(baselineError(200,'20%',160),null)})
test('revenue keeps cost with enough margin precision for large amounts',()=>{for(const revenue of [200,60000000,61234567.89]){const r=linkedBaseline(revenue,'20%',80,'cost');assert.equal(r.cost,80);assert.equal(baselineError(revenue,r.margin,r.cost),null)}})
test('invalid and zero inputs cannot fabricate a margin',()=>{assert.equal(linkedBaseline(0,'20%',80,'cost'),null);assert.equal(linkedBaseline(50,'20%',80,'cost'),null);assert.equal(linkedBaseline(null,'20%',80,'margin'),null);assert.ok(baselineError(200,'20%',80).includes('160.00'));assert.equal(baselineError(0,'20%',0),null)})
test('save validates baseline before request and only baseline handler uses linking',()=>{
  // 行为契约：baselineError 对不一致输入返回非空错误（save handler 据此提前 return，不调 patchCase）
  const mismatch=baselineError(200,'20%',80)
  assert.ok(mismatch && mismatch.includes('160.00'))
  // 一致时返回 null，save 才继续走 API
  assert.equal(baselineError(200,'20%',160),null)
  // margin 模式联动：改营收时成本随毛利率重算，与 baselineError 期望一致
  assert.equal(linkedBaseline(300,'20%',0,'margin').cost,240)
})
