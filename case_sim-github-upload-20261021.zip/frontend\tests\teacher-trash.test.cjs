const { test } = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs'), path = require('node:path'), vm = require('node:vm'), ts = require('typescript')

function mount(file, name, api, extra = {}) {
  let index = 0, tree, nextTimer = 0
  const hooks = [], pending = [], timers = new Map(), navigations = []
  const navigate = (...args) => navigations.push(args)
  const same = (a, b) => a && b && a.length === b.length && a.every((v, i) => Object.is(v, b[i]))
  const jsx = (type, props) => ({ type, props })
  const mocks = {
    react: {
      useState(initial) { const n = index++; if (!(n in hooks)) hooks[n] = initial; return [hooks[n], v => { hooks[n] = typeof v === 'function' ? v(hooks[n]) : v }] },
      useEffect(effect, deps) { const n = index++, old = hooks[n]; if (!same(old?.deps, deps)) pending.push(() => { old?.cleanup?.(); hooks[n] = { deps, cleanup: effect() } }) },
      useCallback(fn, deps) { const n = index++, old = hooks[n]; if (same(old?.deps, deps)) return old.fn; hooks[n] = { deps, fn }; return fn },
    },
    'react/jsx-runtime': { jsx, jsxs: jsx, Fragment: 'Fragment' },
    antd: { Alert: 'Alert', App: { useApp: () => ({ message: { success() {}, error() {} } }) }, Button: 'Button', Card: 'Card', Popconfirm: 'Popconfirm', Space: 'Space', Spin: 'Spin', Table: 'Table', Tag: 'Tag', Typography: { Title: 'Title', Paragraph: 'Paragraph', Text: 'Text' } },
    'react-router-dom': { useNavigate: () => navigate },
    '../../api/client': { api, ...extra.client },
    '../../context/TeacherTokenContext': { useTeacherToken: () => 'tok' },
    ...extra,
  }
  const exports = {}
  const code = ts.transpileModule(fs.readFileSync(path.resolve(__dirname, file), 'utf8'), { compilerOptions: { module: ts.ModuleKind.CommonJS, jsx: ts.JsxEmit.ReactJSX, target: ts.ScriptTarget.ES2022 } }).outputText
  vm.runInNewContext(code, { exports, require: id => { if (!(id in mocks)) throw Error(id); return mocks[id] }, AbortController, URL, URLSearchParams,
    window: { location: { search: '' }, setTimeout: fn => { timers.set(++nextTimer, fn); return nextTimer }, clearTimeout: id => timers.delete(id) } })
  function render() { index = 0; tree = exports[name](); while (pending.length) pending.shift()() }
  function find(type, node = tree) {
    if (!node || typeof node !== 'object') return []
    if (Array.isArray(node)) return node.flatMap(item => find(type, item ?? null))
    return [...(node.type === type ? [node.props] : []), ...find(type, node.props?.children ?? null)]
  }
  render()
  return { find, navigations,
    async flush() { for (let i = 0; i < 3; i++) { await new Promise(setImmediate); render() } },
    close() { hooks.forEach(h => h?.cleanup?.()) },
  }
}

/** 取页面表格 actions 列 render 产出的按钮 props */
function actionsButtons(page, row) {
  const table = page.find('Table')[0]
  const actions = table.columns.find(c => c.key === 'actions')
  return page.find('Button', actions.render(null, row))
}

test('trash page lists deleted cases with restore and purge actions', async () => {
  const page = mount('../src/pages/teacher/TeacherTrashPage.tsx', 'default', {}, { client: {
    listTrashCases: async () => ([
      { id: 11, title: '旧案例', status: 'published', created_at: '2026-10-01T10:00:00', deleted_at: '2026-10-20T09:30:00' },
    ]),
  } })
  await page.flush()
  assert.ok(page.find('Title')[0].children.includes('案例回收站'), '应有案例回收站标题')
  const table = page.find('Table')[0]
  assert.ok(table, '应渲染回收站表格')
  assert.equal(table.dataSource.length, 1)
  assert.equal(table.dataSource[0].title, '旧案例')
  const buttons = actionsButtons(page, table.dataSource[0]).map(b => b.children)
  assert.ok(buttons.includes('恢复'), '应有恢复按钮')
  assert.ok(buttons.includes('彻底删除'), '应有彻底删除按钮')
  page.close()
})

test('trash restore calls restoreCase and empties the list', async () => {
  let restored = 0, listed = 0
  const page = mount('../src/pages/teacher/TeacherTrashPage.tsx', 'default', {}, { client: {
    listTrashCases: async () => (++listed === 1 ? [{ id: 11, title: '旧案例', status: 'ready', created_at: 'x', deleted_at: 'y' }] : []),
    restoreCase: async (caseId, token) => { restored += 1; assert.equal(caseId, 11); assert.equal(token, 'tok'); return { ok: true } },
  } })
  await page.flush()
  const row = page.find('Table')[0].dataSource[0]
  const restore = actionsButtons(page, row).find(b => b.children === '恢复')
  restore.onClick()
  await page.flush()
  assert.equal(restored, 1)
  assert.ok(page.find('Alert').some(a => a.message === '回收站是空的'), '恢复后回收站应为空')
  page.close()
})

test('trash purge calls purgeCase after confirmation', async () => {
  let purged = 0
  const page = mount('../src/pages/teacher/TeacherTrashPage.tsx', 'default', {}, { client: {
    listTrashCases: async () => ([{ id: 12, title: '待删除案例', status: 'draft', created_at: 'x', deleted_at: 'y' }]),
    purgeCase: async (caseId, token) => { purged += 1; assert.equal(caseId, 12); assert.equal(token, 'tok'); return { ok: true } },
  } })
  await page.flush()
  const row = page.find('Table')[0].dataSource[0]
  const table = page.find('Table')[0]
  const actions = table.columns.find(c => c.key === 'actions')
  const confirm = page.find('Popconfirm', actions.render(null, row))[0]
  assert.ok(confirm.onConfirm, '彻底删除需二次确认')
  confirm.onConfirm()
  await page.flush()
  assert.equal(purged, 1)
  page.close()
})
