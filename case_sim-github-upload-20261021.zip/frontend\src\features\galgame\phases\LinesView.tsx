import type { Affection } from '../engine/dialogueEngine'
import type { DialogueLine } from '../data/dialogueTree'
import type { CharacterExpression } from '../components/CharacterSprite'
import SceneBackground from '../components/SceneBackground'
import CharacterSprite from '../components/CharacterSprite'
import DialogueBox from '../components/DialogueBox'
import MoodBar from '../components/MoodBar'

const CFO = '财务'

type SpeakerId = 'manager' | 'cfo' | 'cmo'

/**
 * P2-D2：三角色表情按财数动态切换。
 * manager：净利 < 0 或份额环比 < 0 → worried；两者都 > 0 → happy；否则 calm。
 * cmo：份额环比 > 0 → excited；< 0 → worried；否则 calm。
 * cfo：现金流 < 0 → anxious；净利 > 0 → excited；否则 calm。
 */
export function managerExpression(netProfit: number, shareDelta: number): CharacterExpression {
  if (netProfit < 0 || shareDelta < 0) return 'worried'
  if (netProfit > 0 && shareDelta > 0) return 'happy'
  return 'calm'
}

export function cmoExpression(shareDelta: number): CharacterExpression {
  if (shareDelta > 0) return 'excited'
  if (shareDelta < 0) return 'worried'
  return 'calm'
}

export function cfoExpression(cashFlow: number | null | undefined, netProfit: number): CharacterExpression {
  if (typeof cashFlow === 'number' && cashFlow < 0) return 'anxious'
  if (netProfit > 0) return 'excited'
  return 'calm'
}

/** 场景舞台：背景 + 三角色 + 对话框 + 好感度条。 */
export default function LinesView({
  act,
  netProfit,
  activeId,
  cashFlow,
  shareDelta,
  currentLine,
  showDialogue,
  dialogueKind,
  lineIdx,
  onAdvance,
  affection,
  deltas,
  round,
}: {
  act: number
  netProfit: number
  activeId: SpeakerId | null
  cashFlow: number | null
  shareDelta: number
  currentLine: DialogueLine | null
  showDialogue: boolean
  dialogueKind: string
  lineIdx: number
  onAdvance: () => void
  affection: Affection
  deltas: Affection | null
  round: number
}) {
  return (
    <div className="galgame-scene-wrap">
      <div className="galgame-scene">
        <SceneBackground act={act} netProfit={netProfit} crowd={2} messy={1} />
      </div>
      <div className="galgame-characters">
        <CharacterSprite
          id="manager"
          expression={managerExpression(netProfit, shareDelta)}
          active={activeId === 'manager'}
          dimmed={activeId !== null && activeId !== 'manager'}
        />
        <CharacterSprite
          id="cfo"
          expression={cfoExpression(cashFlow, netProfit)}
          active={activeId === 'cfo'}
          dimmed={activeId !== null && activeId !== 'cfo'}
        />
        <CharacterSprite
          id="cmo"
          expression={cmoExpression(shareDelta)}
          active={activeId === 'cmo'}
          dimmed={activeId !== null && activeId !== 'cmo'}
        />
      </div>
      {showDialogue && currentLine && (
        <DialogueBox
          key={`${dialogueKind}-${lineIdx}`}
          speaker={currentLine.speaker}
          avatar={currentLine.speaker === '店长' ? '👩‍💼' : currentLine.speaker === '市场' ? '🧑‍🚀' : currentLine.speaker === CFO ? '👨‍🔬' : '📖'}
          text={currentLine.text}
          onAdvance={onAdvance}
        />
      )}
      <MoodBar
        affection={affection}
        deltas={deltas}
        round={round}
      />
    </div>
  )
}
