"""班级扫码加入：教师建班 → 学生扫码加入（幂等、可多班）→ 名单与成员管理。

覆盖上一版"账号上单个班级字段"的升级：学生注册后通过扫码加入班级，
一门课一个班，一名学生可同时加入多个班级；历史 class_name 数据由 migrate() 自动转成成员关系。
"""
from sqlalchemy import select

from backend.app import migrations as migrations_module
from backend.app import models
from backend.app.migrations import migrate
from backend.tests.teacher_helpers import login_teacher
from backend.tests.test_student_workflow import env  # noqa: F401 (env 是 fixture)

STUDENT_TOKEN = 'benchmark-demo-v4'  # seed_demo_case 的固定令牌


def test_student_joins_classes_by_qr_code(env, monkeypatch):
    client, factory = env
    token = login_teacher(client, monkeypatch)

    # 1) 教师创建班级
    created = client.post('/api/teacher/classes', params={'token': token}, json={'name': '数据一班'}).json()
    assert created['member_count'] == 0
    assert created['join_code']

    # 2) 学生扫码加入：首次 joined=True，重复加入幂等 joined=False
    first = client.post(f"/api/student/join/{created['join_code']}").json()
    assert first['joined'] is True and first['class']['name'] == '数据一班'
    second_scan = client.post(f"/api/student/join/{created['join_code']}").json()
    assert second_scan['joined'] is False, '重复扫码不报错也不重复入库'

    # 3) 一名学生可加入多个班级（多门课）
    other = client.post('/api/teacher/classes', params={'token': token}, json={'name': '统计二班'}).json()
    assert client.post(f"/api/student/join/{other['join_code']}").json()['joined'] is True
    mine = client.get('/api/student/my-classes').json()
    assert {c['name'] for c in mine} == {'数据一班', '统计二班'}

    # 4) 教师名单回传每个学生加入的班级
    teacher_rows = client.get('/api/teacher/students', params={'token': token}).json()
    me = next(r for r in teacher_rows if r['username'])
    assert set(me['classes']) == {'数据一班', '统计二班'}

    # 5) 成员名单 + 手动添加/移除
    members = client.get(f"/api/teacher/classes/{created['id']}/members", params={'token': token}).json()
    assert [m['username'] for m in members] == [next(iter(teacher_rows))['username']]
    client.post('/api/teacher/students', params={'token': token},
                json={'username': 'manual-member', 'real_name': '手动加入', 'password': 'test-password'})
    assert client.post(f"/api/teacher/classes/{created['id']}/members", params={'token': token},
                       json={'username': 'manual-member'}).status_code == 200
    manual = next(r for r in client.get('/api/teacher/students', params={'token': token}).json()
                  if r['username'] == 'manual-member')
    removed = client.delete(f"/api/teacher/classes/{created['id']}/members/{manual['id']}",
                            params={'token': token})
    assert removed.status_code == 200
    names = {c['name'] for c in client.get('/api/student/my-classes').json()}
    assert '数据一班' in names and '统计二班' in names, '移除只影响被移出的学生'

    # 6) 无效邀请码 404；二维码接口返回 /api/media 路径
    assert client.post('/api/student/join/not-exist-code').status_code == 404
    qr = client.get(f"/api/teacher/classes/{created['id']}/qrcode", params={'token': token}).json()
    assert qr['qr_url'].startswith('/api/media/qrcode/class-')
    assert qr['join_url'] == f"/student/join/{created['join_code']}"


def test_legacy_class_names_are_migrated_to_memberships(env, monkeypatch):
    """历史数据迁移：student_account.class_name → class_group + class_membership。"""
    client, factory = env
    # migrate() 默认用全局 engine（真实文件库）；测试里指到本用例的内存库
    monkeypatch.setattr(migrations_module, "engine", factory.kw["bind"])
    token = login_teacher(client, monkeypatch)
    client.post('/api/teacher/students', params={'token': token},
                json={'username': 'legacy-a', 'real_name': '老数据甲', 'password': 'test-password',
                      'class_name': '历史一班'})
    client.post('/api/teacher/students', params={'token': token},
                json={'username': 'legacy-b', 'real_name': '老数据乙', 'password': 'test-password',
                      'class_name': '历史一班'})

    migrate()

    with factory() as db:
        group = db.scalar(select(models.ClassGroup).where(models.ClassGroup.name == '历史一班'))
        assert group is not None, '迁移应创建同名班级'
        members = db.scalars(select(models.ClassMembership).where(
            models.ClassMembership.class_id == group.id)).all()
        assert len(members) == 2, '同班两个学生都应转成成员关系'
    # 迁移后教师名单直接可见
    rows = client.get('/api/teacher/students', params={'token': token}).json()
    legacy_a = next(r for r in rows if r['username'] == 'legacy-a')
    assert '历史一班' in legacy_a['classes']
    # 再跑一次迁移必须幂等（不重复建班、不重复建成员）
    migrate()
    with factory() as db:
        groups = db.scalars(select(models.ClassGroup).where(models.ClassGroup.name == '历史一班')).all()
        assert len(groups) == 1
