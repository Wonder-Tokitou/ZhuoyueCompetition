/**
 * 会话 ID 存取（P1-F1）。
 * formal：复用主线 sessionStorage["student_session:<token>"]（现状不变）；
 * practice：localStorage["galgame_session:<token>:practice"]。
 * 铁律 13：practice 分支绝不写主线 student_session:<token>。
 */

export type GameMode = 'formal' | 'practice'

export function modeFromUrl(): GameMode {
  try {
    return new URLSearchParams(window.location.search).get('mode') === 'practice' ? 'practice' : 'formal'
  } catch {
    return 'formal'
  }
}

export function readSessionId(token: string, mode: GameMode): number | null {
  if (mode === 'practice') {
    const raw = globalThis.localStorage?.getItem(`galgame_session:${token}:practice`)
    const id = raw ? Number(raw) : NaN
    return Number.isFinite(id) && id > 0 ? id : null
  }
  const raw = globalThis.sessionStorage?.getItem(`student_session:${token}`)
  const id = raw ? Number(raw) : NaN
  return Number.isFinite(id) && id > 0 ? id : null
}

/** 写入会话 ID；practice 写 localStorage 专用键，绝不写 student_session:<token>。 */
export function persistSessionId(token: string, mode: GameMode, sessionId: number, studentName?: string): void {
  if (mode === 'practice') {
    globalThis.localStorage?.setItem(`galgame_session:${token}:practice`, String(sessionId))
    return
  }
  globalThis.sessionStorage?.setItem(`student_session:${token}`, String(sessionId))
  if (studentName) globalThis.sessionStorage?.setItem(`student_name:${token}`, studentName)
}
