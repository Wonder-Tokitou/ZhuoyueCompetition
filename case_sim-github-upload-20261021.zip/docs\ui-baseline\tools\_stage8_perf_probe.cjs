/**
 * 阶段 8 · C8 DoD 轻量验证：hover 动画期间是否出现 paint 风暴。
 * CDP Performance 域采样对比 hover 前后：transition 只含 transform（合成属性），
 * headless 无 GPU，Frames 增量应在合理范围，不应出现渲染线程卡死。
 * 说明：FPS/Paint 精确计数需真实设备，本脚本记录 headless 可测指标并标注限制。
 */
const { spawn } = require('node:child_process')
const fs = require('node:fs')
const os = require('node:os')
const path = require('node:path')

const CHROME = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
const PORT = 9342
const BASE = 'http://127.0.0.1:8110'
const CASE_TOKEN = 'benchmark-demo-v4'
const TOKEN = process.argv[2]
const SESSION = process.argv[3]
if (!TOKEN) { console.error('missing token'); process.exit(2) }

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
async function browserWs() {
  for (let i = 0; i < 60; i++) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/version`)
      const json = await res.json()
      if (json.webSocketDebuggerUrl) return json.webSocketDebuggerUrl
    } catch { /* 未就绪 */ }
    await sleep(250)
  }
  throw new Error('chrome 调试端口未就绪')
}
function client(ws) {
  let id = 0
  const waiting = new Map()
  ws.addEventListener('message', (ev) => {
    const msg = JSON.parse(ev.data)
    if (msg.id && waiting.has(msg.id)) {
      const { resolve, reject } = waiting.get(msg.id)
      waiting.delete(msg.id)
      msg.error ? reject(new Error(JSON.stringify(msg.error))) : resolve(msg.result)
      return
    }
  })
  return (method, params = {}, sessionId) => new Promise((resolve, reject) => {
    const mid = ++id
    waiting.set(mid, { resolve, reject })
    ws.send(JSON.stringify({ id: mid, method, params, ...(sessionId ? { sessionId } : {}) }))
  })
}

;(async () => {
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'stage8perf-'))
  const chrome = spawn(CHROME, [
    '--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
    '--no-proxy-server', '--hide-scrollbars', `--remote-debugging-port=${PORT}`,
    `--user-data-dir=${profile}`, 'about:blank',
  ], { stdio: 'ignore' })
  try {
    const wsUrl = await browserWs()
    const ws = new WebSocket(wsUrl)
    await new Promise((res, rej) => { ws.addEventListener('open', res); ws.addEventListener('error', rej) })
    const send = client(ws)
    const { targetId } = await send('Target.createTarget', { url: 'about:blank' })
    const { sessionId } = await send('Target.attachToTarget', { targetId, flatten: true })
    const call = (m, p) => send(m, p, sessionId)
    await call('Page.enable')
    await call('Runtime.enable')
    await call('Performance.enable')
    await call('Emulation.setDeviceMetricsOverride', { width: 375, height: 812, deviceScaleFactor: 2, mobile: false })
    await call('Page.addScriptToEvaluateOnNewDocument', {
      source: [
        `try { sessionStorage.setItem('student_access_token', ${JSON.stringify(TOKEN)}) } catch (e) {}`,
        SESSION ? `try { sessionStorage.setItem('student_session:${CASE_TOKEN}', ${JSON.stringify(SESSION)}) } catch (e) {}` : '',
      ].join('\n'),
    })
    await call('Page.navigate', { url: `${BASE}/student/${CASE_TOKEN}` })
    await sleep(5000)
    const ev = async (expr) => (await call('Runtime.evaluate', { expression: expr, returnByValue: true })).result.value
    const metrics = async () => {
      const r = await call('Performance.getMetrics')
      return Object.fromEntries(r.metrics.map((m) => [m.name, m.value]))
    }
    const before = await metrics()
    // 连续 hover 卡片/策略卡，触发 8 次 transform 动画
    for (let i = 0; i < 8; i++) {
      await ev(`(() => { const el = document.querySelector(i % 2 ? '.strategy-option-card' : '.student-page .ant-card'); if (el) el.scrollIntoView({ block: 'center' }); })()`)
      await sleep(120)
      const r = await ev(`(() => { const el = document.querySelector(i % 2 ? '.strategy-option-card' : '.student-page .ant-card'); if (!el) return null; const b = el.getBoundingClientRect(); return { x: Math.round(b.left + b.width / 2), y: Math.round(b.top + b.height / 2) } })()`)
      if (r) {
        await call('Input.dispatchMouseEvent', { type: 'mouseMoved', x: r.x, y: r.y })
        await sleep(260)
        await call('Input.dispatchMouseEvent', { type: 'mouseMoved', x: 5, y: 5 })
      }
      await sleep(120)
    }
    const after = await metrics()
    const keys = ['Frames', 'Tasks', 'ScriptDuration', 'LayoutDuration', 'RecalcStyleDuration', 'TaskDuration', 'JSHeapUsedSize']
    const diff = {}
    for (const k of keys) diff[k] = Math.round(((after[k] || 0) - (before[k] || 0)) * 100) / 100
    console.log(JSON.stringify({ hoverCycles: 8, metricsBefore: before, metricsAfter: after, delta: diff }, null, 2))
    ws.close()
  } finally {
    chrome.kill()
  }
})().catch((e) => { console.error('FAILED:', e.message); process.exit(1) })
