# galgame 支线 · 事实核对 facts.md

> 核对时间：2026-10-21。核对对象：`C:\Users\huang2006\Desktop\Work\upload2\case_sim-`（桌面副本，与执行清单 v3 使用的副本一致）。
> 每条记录"字符串锚点 + 文件:行 + 原文片段 + 是否符合"。与清单不一致处标注【清单需修订】。

## 1. App.tsx 旧路由所在行

- 锚点：`path="/student/:studentToken"`
- 位置：`frontend/src/App.tsx:57`
- 原文片段：`path="/student/:studentToken"`
- 是否符合：**符合**。清单校正表 #1 说"页面路由是 `/student/:studentToken`（`frontend/src/App.tsx:57`）"，实测一致。`/play/...` 确为后端 API 前缀（见第 4 条）。

## 2. StudentTokenContext.tsx 的 useParams 键名

- 锚点：`useParams<{ studentToken: string }>`
- 位置：`frontend/src/context/StudentTokenContext.tsx:12`
- 原文片段：`const { studentToken } = useParams<{ studentToken: string }>()`
- 是否符合：**符合**。清单说 `StudentTokenContext.tsx:12` 用 `useParams<{ studentToken: string }>`，实测一致。路由参数名必须是 `studentToken`（第 25 行 `throw new Error('缺少学生端令牌：请从 /student/{studentToken} 链接进入')`）。

## 3. student_labels.py 的风险词正则

- 锚点：`_RISK_WORDS = re.compile(r"保守|稳健|激进")`
- 位置：`backend/app/domain/student_labels.py:4`（使用在 7–11 行的 `student_label()`）
- 原文片段：`_RISK_WORDS = re.compile(r"保守|稳健|激进")`；`value = _RISK_WORDS.sub("", str(label or ""))`
- 是否符合：**符合（行号微调）**【清单需修订】。清单说 `student_labels.py:8`，实测正则定义在 `:4`、删除逻辑在 `:9`。事实（学生端 label 会被删掉"保守/稳健/激进"字样）成立，仅行号偏移。

## 4. student.py 的 409 submission_exists 分支

- 锚点：`"code": "submission_exists"`
- 位置：`backend/app/routers/student.py:238`（`start_session` 内）
- 原文片段：`raise HTTPException(409, detail={"code": "submission_exists", "session_id": existing.id, "message": "已有本案例推演记录，请从提交记录继续，或选择覆盖原记录后重做。"})`
- 是否符合：**符合（行号微调）**【清单需修订】。清单说 `student.py:231-239`，实测 409 抛出在 `:238`（231–239 是查询 existing 的区间）。事实成立。

## 5. StudentLayout.css 的 prefers-reduced-motion 块

- 锚点：`@media (prefers-reduced-motion: reduce)`
- 位置：`frontend/src/layouts/StudentLayout.css:353-355`
- 原文片段：`@media (prefers-reduced-motion: reduce) { *, *::before, *::after { animation-duration: .01ms !important; transition-duration: .01ms !important; scroll-behavior: auto !important; } }`
- 是否符合：**符合（行号修订）**【清单需修订】。清单称"当前副本 283 行"，实测文件总行数 **355**，reduce 块在 **353–355**（文件末尾全局块）。283 应为 v1 旧副本数字，此处作废。

## 附：与清单校正表其余条目的实测对照（T0.2 目标要求复核"第一、二章引用的 8 条事实"）

| # | 清单条目 | 实测锚点 | 是否符合 |
|---|---|---|---|
| 3 | 账号由 StudentLayout 注入（`StudentLayout.tsx:53`） | `frontend/src/layouts/StudentLayout.tsx:53` `<StudentAccountContext.Provider value={account}>`；`useStudentAccount()` 定义于 `context/StudentAccountContext.tsx:5`，`StudentPlayPage.tsx:75` 使用 | 符合 |
| 4 | `App.tsx` 改动为 import + 路由 2 行（开发期 0 改动） | 规划约束，非现状事实；当前 `App.tsx` 无任何 galgame 引用（`grep galgame src/App.tsx` 零命中） | 符合 |
| 6 | 选项按 sha256 打散 | `backend/app/routers/student.py:114` `options.sort(key=lambda option: hashlib.sha256((seed + ":" + option.key).encode()).hexdigest())`；`backend/app/domain/student_choices.py:10-12` `ordered_choices` 同算法 | 符合 |
| 8 | 学生端 S1 不下发 `risk_level` | `frontend/src/api/types.ts:74-75` `StudentNode extends NodeBase { options: OptionBrief[] }`；`OptionBrief`（:49-52）仅 `key + label`；`PlayResponse`（:260）注释"只有未选择选项的 risk_level / summary / metrics 不得提前下发" | 符合 |
| 1b | `/play/` 是后端 API 前缀 | `frontend/src/api/client.ts:145` `api.get<PlayResponse>(\`/play/${studentToken}\`)`；`:153-154` `restoreStudent`、`:163` `decide` 同前缀 | 符合 |

## 其他实测数字（与清单 v2 修订记录对照）

| 项 | 清单 v2 记录 | 本次实测 | 结论 |
|---|---|---|---|
| 前端测试数 | 85 例 | `# tests 85 / # pass 85 / # fail 0` | 一致 |
| StudentPlayPage.tsx 行数 | 318 行 | 321 行 | 【清单需修订】行号类描述，事实（约 320 行、一行不动）不受影响 |
| StudentLayout.css reduce 块 | 283 行 | 355 行（reduce 块在 353–355） | 【清单需修订】同上 |

## 结论

清单第一、二章引用的 8 条事实在当前副本全部成立，无方向性错误；仅有 4 处行号类描述需要按本表实际行号执行（已在各条标注）。支线可按清单继续开工。
