const { test } = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs'), path = require('node:path'), vm = require('node:vm'), ts = require('typescript')

function load(file, mocks = {}) {
  const exports = {}
  const source = fs.readFileSync(path.join(__dirname, '../src', file), 'utf8')
  vm.runInNewContext(ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, jsx: ts.JsxEmit.ReactJSX, target: ts.ScriptTarget.ES2022 } }).outputText, { exports, require: n => mocks[n] || {} })
  return exports
}

const jsx = (type, props) => ({ type, props })
const ANTD = { Modal: 'Modal', Button: 'Button', Space: 'Space', Typography: { Paragraph: 'Paragraph', Text: 'Text', Title: 'Title' } }

function card(props) {
  const { default: SettlementCard } = load('pages/student/components/SettlementCard.tsx', {
    react: {}, 'react/jsx-runtime': { jsx, jsxs: jsx }, antd: ANTD,
  })
  return SettlementCard(props)
}

const NARR = { deltaText: '营收 78.00 → 86.50 万元（+10.90%）', why: '你选择了「渠道策略」：降价或让利换来了更多客户。', nextFocus: '下一轮关注：能否把单笔利润提回来' }

test('settlement card is a modal titled with the round number, not an alert', () => {
  const modal = card({ open: true, round: 2, chosenLabel: '渠道策略', narrative: NARR, onClose: () => {} })
  assert.equal(modal.type, 'Modal', 'U1 红线：结算卡必须用 Modal，不能用 Alert（既有用例取第一个 Alert）')
  assert.equal(modal.props.open, true)
  assert.equal(modal.props.title, '本轮结算 · 第 2 轮')
})

test('settlement card shows the decision, the deltas, the cause and the next focus', () => {
  const json = JSON.stringify(card({ open: true, round: 1, chosenLabel: '渠道策略', narrative: NARR, onClose: () => {} }))
  assert.match(json, /渠道策略/, '你的决策')
  assert.match(json, /营收 78\.00 → 86\.50 万元/, '数字变化')
  assert.match(json, /降价或让利换来了更多客户/, '为什么')
  assert.match(json, /下一轮关注/, '下一轮关注')
})

test('settlement card has exactly one continue button that closes it', () => {
  let closed = 0
  const modal = card({ open: true, round: 1, chosenLabel: '渠道策略', narrative: NARR, onClose: () => { closed++ } })
  assert.equal(modal.props.footer.type, 'Button')
  assert.equal(modal.props.footer.props.children, '继续')
  modal.props.footer.props.onClick()
  assert.equal(closed, 1, '点「继续」必须关闭结算卡')
  modal.props.onCancel()
  assert.equal(closed, 2, '点遮罩关闭走同一条回调')
})

test('settlement card stays closed and inert when open is false', () => {
  const modal = card({ open: false, round: 3, chosenLabel: '定价策略', narrative: NARR, onClose: () => { assert.fail('closed card must not call onClose') } })
  assert.equal(modal.props.open, false)
})
