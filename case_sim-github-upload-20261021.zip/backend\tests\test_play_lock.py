"""教师"停止推演"开关（play_locked）的契约测试。

停止后：学生不能开始/提交/回退/覆盖/删除该案例的推演；
已有记录全部保留且仍可读取；恢复后业务照旧（409/200 语义不变）。
"""
from backend.tests.teacher_helpers import login_teacher
from backend.tests.test_student_workflow import URL, begin, complete, env  # noqa: F401 (env 是 fixture)


def _teacher_token(client, monkeypatch):
    return login_teacher(client, monkeypatch)


def _first_case_id(client, token):
    cases = client.get('/api/cases', params={'token': token}).json()
    return cases[0]['id']


def _lock(client, token, case_id, locked):
    return client.post(f'/api/cases/{case_id}/play-lock', params={'token': token}, json={'locked': locked})


def test_play_lock_blocks_writes_and_keeps_records(env, monkeypatch):
    client, _ = env
    state = begin(client)
    sid = complete(client, state)
    token = _teacher_token(client, monkeypatch)
    case_id = _first_case_id(client, token)

    assert client.get('/api/cases', params={'token': token}).json()[0]['play_locked'] is False

    assert _lock(client, token, case_id, True).status_code == 200
    assert client.get('/api/cases', params={'token': token}).json()[0]['play_locked'] is True

    # 学生端首屏仍可读，并带锁标记（前端据此切只读模式）
    assert client.get(URL).json()['play_locked'] is True

    # 不能开始新的推演
    blocked = client.post(URL + '/sessions', json={'student_name': 'student'})
    assert blocked.status_code == 403, blocked.text
    assert blocked.json()['detail']['code'] == 'case_locked'

    # 已有记录仍可读取（只读保留），"我的记录"列表也在
    restored = client.get(f'{URL}/sessions/{sid}')
    assert restored.status_code == 200, restored.text
    assert restored.json()['play_locked'] is True
    assert client.get('/api/student/records').json()[0]['session_id'] == sid

    # 写操作全被拒：回退 / 覆盖 / 删除 / 提交
    node = state['play']['nodes'][0]
    assert client.post(f'{URL}/sessions/{sid}/rollback/{node["idx"]}').status_code == 403
    assert client.post(f'{URL}/sessions/{sid}/reset').status_code == 403
    assert client.delete(f'{URL}/sessions/{sid}').status_code == 403
    denied = client.post(URL + '/decide', json={'session_id': sid, 'student_name': 'student',
        'node_id': node['id'], 'option_key': node['options'][0]['key'], 'duration_ms': 5})
    assert denied.status_code == 403, denied.text
    assert denied.json()['detail']['code'] == 'case_locked'


def test_play_unlock_restores_normal_flow(env, monkeypatch):
    client, _ = env
    state = begin(client)
    first, second = state['play']['nodes'][:2]

    def decide(node):
        return client.post(URL + '/decide', json={'session_id': state['session_id'], 'student_name': 'student',
            'node_id': node['id'], 'option_key': node['options'][0]['key'], 'duration_ms': 5})

    assert decide(first).status_code == 200
    token = _teacher_token(client, monkeypatch)
    case_id = _first_case_id(client, token)

    assert _lock(client, token, case_id, True).status_code == 200
    assert decide(second).status_code == 403

    assert _lock(client, token, case_id, False).status_code == 200
    resumed = decide(second)
    assert resumed.status_code == 200, resumed.text
