/**
 * 阶段 5（关卡式进度）取证脚本：抓 RoundMap 的三态 DOM / computed style / 无障碍属性。
 *
 * 用法：
 *   node _stage5_probe.cjs --token <token> --session <id> --name stage-5-a [--outdir ..]
 *
 * 取证点：
 *   1. .round-map 是否存在、role=list、子项数量 = 3
 *   2. 每站的 class（is-done / is-current）、圆点文字、aria-label、aria-current、tabindex
 *   3. 圆点的底色/描边/光环（computed）
 *   4. 当前站可否 focus（document.activeElement）
 *   5. .ant-steps 是否已彻底消失（P7）
 *   6. 上方「第 X / 3 轮 · 已提交 Y 轮」文本是否仍在
 *   7. 375px 是否横向溢出
 */
const { spawn } = require('node:child_process')
const fs = require('node:fs')
const os = require('node:os')
const path = require('node:path')

const CHROME = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
const PORT = 9337
const BASE = 'http://127.0.0.1:8110'
const CASE_TOKEN = 'benchmark-demo-v4'

function arg(name, fallback) {
  const i = process.argv.indexOf(`--${name}`)
  return i >= 0 && process.argv[i + 1] ? process.argv[i + 1] : fallback
}
const TOKEN = arg('token')
const SESSION = arg('session')
const NAME = arg('name', 'stage-5')
const OUTDIR = path.resolve(arg('outdir', path.join(__dirname, '..')))
if (!TOKEN) { console.error('missing --token'); process.exit(2) }

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

async function browserWs() {
  for (let i = 0; i < 60; i++) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/version`)
      const json = await res.json()
      if (json.webSocketDebuggerUrl) return json.webSocketDebuggerUrl
    } catch { /* 未就绪 */ }
    await sleep(250)
  }
  throw new Error('chrome 调试端口未就绪')
}

function client(ws) {
  let id = 0
  const waiting = new Map()
  ws.addEventListener('message', (ev) => {
    const msg = JSON.parse(ev.data)
    if (msg.id && waiting.has(msg.id)) {
      const { resolve, reject } = waiting.get(msg.id)
      waiting.delete(msg.id)
      msg.error ? reject(new Error(JSON.stringify(msg.error))) : resolve(msg.result)
      return
    }
  })
  return (method, params = {}, sessionId) => new Promise((resolve, reject) => {
    const mid = ++id
    waiting.set(mid, { resolve, reject })
    ws.send(JSON.stringify({ id: mid, method, params, ...(sessionId ? { sessionId } : {}) }))
  })
}

const PROBE = `(() => {
  const map = document.querySelector('.round-map')
  const nodes = map ? [...map.querySelectorAll('.round-node')] : []
  const dots = nodes.map((el) => {
    const dot = el.querySelector('.dot')
    const cs = dot ? getComputedStyle(dot) : null
    return {
      className: el.className,
      dot: dot?.textContent || null,
      label: (el.querySelector('.round-label')?.textContent || '').replace(/\\s+/g, ' '),
      ariaLabel: el.getAttribute('aria-label'),
      ariaCurrent: el.getAttribute('aria-current'),
      tabIndex: el.getAttribute('tabindex'),
      dotBg: cs?.backgroundColor || null,
      dotBorder: cs ? cs.borderTopColor + ' ' + cs.borderTopWidth : null,
      dotColor: cs?.color || null,
      dotShadow: cs?.boxShadow || null,
    }
  })
  const current = map ? map.querySelector('[aria-current="step"]') : null
  let focusOk = null
  if (current) { current.focus(); focusOk = document.activeElement === current }
  const progressText = [...document.querySelectorAll('.ant-card-body *')]
    .map((el) => el.textContent || '')
    .find((t) => /轮.*已提交/.test(t)) || null
  return {
    hasRoundMap: !!map,
    role: map?.getAttribute('role') || null,
    ariaLabelOfMap: map?.getAttribute('aria-label') || null,
    nodeCount: nodes.length,
    nodes: dots,
    currentFocusable: focusOk,
    antStepsCount: document.querySelectorAll('.ant-steps').length,
    progressText: progressText ? progressText.trim().slice(0, 60) : null,
    overflow: { scrollWidth: document.documentElement.scrollWidth, clientWidth: document.documentElement.clientWidth },
  }
})()`

;(async () => {
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'stage5-chrome-'))
  const chrome = spawn(CHROME, [
    '--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
    '--no-proxy-server', '--hide-scrollbars', '--force-device-scale-factor=2',
    `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`, 'about:blank',
  ], { stdio: 'ignore' })

  try {
    const wsUrl = await browserWs()
    const ws = new WebSocket(wsUrl)
    await new Promise((res, rej) => { ws.addEventListener('open', res); ws.addEventListener('error', rej) })
    const send = client(ws)
    const { targetId } = await send('Target.createTarget', { url: 'about:blank' })
    const { sessionId } = await send('Target.attachToTarget', { targetId, flatten: true })
    const call = (m, p) => send(m, p, sessionId)

    await call('Page.enable')
    await call('Runtime.enable')
    await call('Emulation.setDeviceMetricsOverride', { width: 375, height: 812, deviceScaleFactor: 2, mobile: true })
    await call('Page.addScriptToEvaluateOnNewDocument', {
      source: [
        `try { sessionStorage.setItem('student_access_token', ${JSON.stringify(TOKEN)}) } catch (e) {}`,
        SESSION ? `try { sessionStorage.setItem('student_session:${CASE_TOKEN}', ${JSON.stringify(SESSION)}) } catch (e) {}` : '',
      ].join('\n'),
    })
    await call('Page.navigate', { url: `${BASE}/student/${CASE_TOKEN}` })
    await sleep(4500)

    const raw = await call('Runtime.evaluate', { expression: PROBE, returnByValue: true })
    if (raw.exceptionDetails) throw new Error(JSON.stringify(raw.exceptionDetails))

    const shot = await call('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false, fromSurface: true })
    const file = path.join(OUTDIR, `${NAME}.png`)
    fs.writeFileSync(file, Buffer.from(shot.data, 'base64'))

    console.log(JSON.stringify({ ...raw.result.value, saved: `SAVED=${file} BYTES=${fs.statSync(file).size}` }, null, 2))
    ws.close()
  } finally {
    chrome.kill()
  }
})().catch((e) => { console.error('FAILED:', e.message); process.exit(1) })
