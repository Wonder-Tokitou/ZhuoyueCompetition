const { test } = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs'), path = require('node:path'), vm = require('node:vm'), ts = require('typescript')

function load(file, mocks = {}) {
  const exports = {}
  const source = fs.readFileSync(path.join(__dirname, '../src', file), 'utf8')
  vm.runInNewContext(ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, jsx: ts.JsxEmit.ReactJSX, target: ts.ScriptTarget.ES2022 } }).outputText, { exports, require: n => mocks[n] || {} })
  return exports
}

const { narrative } = load('domain/decisionNarrative.ts')

// gross_margin / market_share 是带 % 的字符串，revenue 是数字（见 api/types.ts 的 Metrics）
const m = (revenue, gross_margin) => ({ revenue, gross_margin, market_share: '20.0%', cash_flow: '平稳' })

test('revenue up with margin down explains trading price for volume', () => {
  const r = narrative(m(78, '60.0%'), m(86.5, '55.0%'), '渠道策略')
  assert.match(r.why, /降价或让利换来了更多客户/)
  assert.match(r.why, /渠道策略/)
})

test('revenue up with margin up explains volume and price rising together', () => {
  const r = narrative(m(78, '60.0%'), m(86.5, '63.0%'), '定价策略')
  assert.match(r.why, /量价齐升/)
})

test('revenue down with margin up explains shedding low margin business', () => {
  const r = narrative(m(86.5, '55.0%'), m(80, '61.0%'), '营销策略')
  assert.match(r.why, /主动收缩了低毛利业务/)
})

test('revenue down with margin down warns about share and profit pressure', () => {
  const r = narrative(m(86.5, '60.0%'), m(80, '55.0%'), '渠道策略')
  assert.match(r.why, /份额与利润同时承压/)
})

test('negative cash flow overrides next focus regardless of direction', () => {
  const rising = narrative(m(78, '60.0%'), m(86.5, '63.0%'), '定价策略', -12.5)
  assert.equal(rising.nextFocus, '现金流能否撑住下一轮扩张')
  const falling = narrative(m(86.5, '60.0%'), m(80, '55.0%'), '渠道策略', -0.01)
  assert.equal(falling.nextFocus, '现金流能否撑住下一轮扩张')
})

test('non negative cash flow keeps the direction specific focus', () => {
  assert.notEqual(narrative(m(78, '60.0%'), m(86.5, '63.0%'), '定价策略', 5).nextFocus, '现金流能否撑住下一轮扩张')
  assert.notEqual(narrative(m(78, '60.0%'), m(86.5, '63.0%'), '定价策略', null).nextFocus, '现金流能否撑住下一轮扩张')
})

test('delta text shows before and after for revenue and margin with signed changes', () => {
  const r = narrative(m(78, '60.0%'), m(86.5, '55.0%'), '渠道策略')
  assert.equal(r.deltaText, '营收 78.00 → 86.50 万元（+10.90%）；毛利率 60.0% → 55.0%（-5.00 个百分点）')
})

test('missing comparison baseline yields an explicit placeholder instead of invented numbers', () => {
  const r = narrative(null, m(86.5, '55.0%'), '渠道策略')
  assert.match(r.deltaText, /—/)
  assert.ok(!/\d/.test(r.deltaText.replace(/—/g, '')) || r.deltaText.includes('86.50'), 'before value must not be fabricated')
  assert.ok(r.why.length > 0)
  assert.ok(r.nextFocus.length > 0)
})

test('unchanged metrics are reported as flat rather than forced into a rising or falling story', () => {
  const r = narrative(m(80, '60.0%'), m(80, '60.0%'), '渠道策略')
  assert.match(r.why, /持平/)
})

test('zero baseline revenue does not produce an infinite percentage', () => {
  const r = narrative(m(0, '60.0%'), m(50, '62.0%'), '定价策略')
  assert.ok(!r.deltaText.includes('Infinity'), r.deltaText)
  assert.ok(!r.deltaText.includes('NaN'), r.deltaText)
})

test('unparsable margin strings fall back to the placeholder without throwing', () => {
  const r = narrative(m(78, '约60%（假设）'), m(86.5, '待定'), '渠道策略')
  assert.match(r.deltaText, /—/)
  assert.ok(r.why.length > 0)
})
