/**
 * 打字机（阶段 3 实现）。
 * 默认 30ms/字 setInterval 逐字追加，text 变化时重置；
 * skip() 立即置为全文并清定时器；
 * prefers-reduced-motion 为真时直接全文，不启动定时器；
 * 卸载必须 clearInterval（effect 返回清理函数）。
 */
import { useCallback, useEffect, useRef, useState } from 'react'

export function prefersReducedMotion(): boolean {
  if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') return false
  return window.matchMedia('(prefers-reduced-motion: reduce)').matches
}

export interface TypewriterState {
  shown: string
  done: boolean
  skip: () => void
}

export function useTypewriter(text: string, opts?: { speed?: number }): TypewriterState {
  const speed = opts?.speed ?? 30
  const [shown, setShown] = useState('')
  const [done, setDone] = useState(true)
  const timerRef = useRef<number | null>(null)

  useEffect(() => {
    if (timerRef.current !== null) {
      window.clearInterval(timerRef.current)
      timerRef.current = null
    }
    if (prefersReducedMotion() || text.length === 0) {
      setShown(text)
      setDone(true)
      return
    }
    setShown('')
    setDone(false)
    let i = 0
    timerRef.current = window.setInterval(() => {
      i += 1
      setShown(text.slice(0, i))
      if (i >= text.length) {
        if (timerRef.current !== null) window.clearInterval(timerRef.current)
        timerRef.current = null
        setDone(true)
      }
    }, speed)
    return () => {
      if (timerRef.current !== null) window.clearInterval(timerRef.current)
      timerRef.current = null
    }
  }, [text, speed])

  const skip = useCallback(() => {
    if (timerRef.current !== null) window.clearInterval(timerRef.current)
    timerRef.current = null
    setShown(text)
    setDone(true)
  }, [text])

  return { shown, done, skip }
}
