# 阶段 4 验收记录 — 决策接线与结算（T4.0 / T4.1 / T4.2）

日期：2026-10-21
范围：角色追问（T4.0）、选项面板（T4.1）、decide 接线（T4.2）——全清单唯一写数据的地方。

## 代码交付

- `dialogueTree.ts`：`askReason(act, risk)` 三种风险各一条追问 + `REASON_PHRASES`（每风险三选）+ `buildInputText(label, phrase, extra)`：
  - `【{label}】{短语}。{补充}`，补充为空省略后缀，跳过追问存 `【{label}】（未说明理由）`，绝不存空串。
- `ChoiceButtons.tsx`：A/B/C 竖排 + 原始 label，点击仅选中高亮（#db2777），未选中「就这么定」disabled；`<details>`「查看本轮经营数据」展示 current_metrics 四项（营收/毛利率/市场份额/现金流）；不加风险色。
- `GalgamePlayPage.tsx`：完整流程接线（封面→开始营业→actOpening→选择→reaction→追问→decide→restore 幂等→结算→nextAct→3 轮 finished）。
  - 实名：`useStudentAccount().real_name`（空名被后端 422 拒，已修复）。
  - 门闩 `page.current = {token, active, busy, nodeId, uncertain}`：decide 异常先 restore 核对，restore 也失败 → uncertain 锁定。
  - 连点只调一次 decide；`duration_ms = max(0, Date.now()-at)`；node_id 取 `nodes.find(n=>n.id===next_node_id).id`。
- `galgame.css`：场景改为 `.galgame-scene-wrap`（relative 定位上下文）+ 交互面板全套样式（choices/confirm/reason/metrics-fold/settlement/finished/error）。

## 浏览器端到端实测（真实后端 8110 + dev 5174，学生蔡徐坤 id=3）

前置清障：该学生在 benchmark-demo-v4 存在主线旧测试 session（id=3，昨日 20:48 完成）→ `DELETE /play/benchmark-demo-v4/sessions/3`（登录 Bearer）清理后重走。

| 步骤 | 结果 |
|---|---|
| 封面 4 句 → 开始营业 | ✓ 实名提交，无 409/422 |
| 第 1 轮：选 A（拓展1所高校）→ 财务反应 → balanced 追问 | ✓ 追问短语「两边都留余地/先看数据再决定/不把鸡蛋放一个篮子」 |
| 选短语 + 补充「现金流优先，再看回报」→ decide | ✓ 结算卡「第 1 轮结果」 |
| 第 2 轮：选 B（维持定价，保守） | ✓ 保守短语「先保现金/先把成本压下去/留点余量防风险」 |
| 第 3 轮：选 C（大规模广告，激进） | ✓ 激进短语「先抢份额/趁对手没反应先铺开/这笔钱能带来复购」 |
| 3 轮结算 → 查看结局 | ✓ 「三轮推演已完成」页 |
| 重启页面（sessionStorage 有 student_session） | ✓ restore 直接进收尾页 |

## 落库验证（SQLite 直查，session 表 id=7）

```
node_id=1  chosen_option=B  input_text=【拓展1所新高校，开设2家新店，稳步扩大品牌覆盖】先看数据再决定。现金流优先，再看回报  duration_ms=110122
node_id=2  chosen_option=A  input_text=【维持现有定价体系（美式12元/杯），小幅优化产品与控制成本】先保现金，活下来再说  duration_ms=48660
node_id=3  chosen_option=C  input_text=【大规模广告投放与高频促销补贴，营销预算占营收20%】先抢份额，规模优先  duration_ms=36536
```

- 写入的是主线 `session`/`turn` 表（id=7，student_id=3，case_id=1），无支线独立表 → 与主线共用同一 session/存档 ✓
- `input_text` 拼装严格符合 `【label】短语。补充`；无补充时省略后缀 ✓
- chosen_option 为后端下发的 option_key（B/A/C），与界面 label 一一对应 ✓

## 主线可见性（共用 session 关键验证）

浏览器进主线 `/student/records`：「研咖咖啡·高校市场扩张与定价决策 · 第 1 次 / 教师版本 1 / 2026-10-21 14:34:35 / 已提交 3/3 / 查看作答与已保存复盘」——支线的 3 轮提交完整出现在主线提交记录页 ✓

## 回归

- `npm test`：**126/126 pass，fail 0**
- `npx tsc -b`：0 错
- `App.tsx`：无 galgame/Galgame 引用（支线不进主线构建，隔离保持）

## 截图

- `stage4-finished.png`（219x869，收尾页：三角色 + 「三轮推演已完成」）
