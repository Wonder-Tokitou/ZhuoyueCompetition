# 文案断言冻结表（阶段 0 · T0.4）

> **生成时间**：2026-10-20 21:5x
> **扫描范围**：`frontend/tests/*.test.cjs` 共 18 个文件、65 个用例
> **扫描模式**：`assert.match` / `assert.strictEqual` / `assert.equal` / `.includes(` / `textContent` / 源码级 `src.includes(`
> **用途**：后续阶段只许改样式，不许改这里列出的字符串；改了就必然打红。
>
> 说明：`原文` 列一律照抄测试文件里的字面量，未做任何改写；`\`\`反引号内的模板拼接保留原写法。

---

## 1. 逐条清单

| 编号 | 测试文件 | 行号 | 被断言的原文 | 归属组件 | 风险 |
|---|---|---|---|---|---|
| A01 | tests/student-play.test.cjs | 54 | `开始推演` | StudentPlayPage 开始推演按钮（`Button` children） | 改按钮文案即红（同文件 50/66/166/175/203/216 行还用同串找元素，改了会 `undefined.onClick` 抛错） |
| A02 | tests/student-play.test.cjs | 63 | `确认提交本回合` | StudentPlayPage 提交区 `decision-submit` 按钮 | 同上，86/88/103/115/137/145/155 行均依赖该字面量取元素 |
| A03 | tests/student-play.test.cjs | 101 | `继续下一回合` | 已提交回合后的「继续」按钮 | 改名即红（126 行也用） |
| A04 | tests/student-play.test.cjs | 138 | `核对已保存进度` | uncertain（网络不确定）态的核对按钮 | 改名即红（143 行也用） |
| A05 | tests/student-play.test.cjs | 97 | `/渠道策略/` | 结果 `Alert type=success` 内的策略 label（数据来自 `play()` mock） | 选项 label 渲染丢失即红 |
| A06 | tests/student-play.test.cjs | 98 | `/你提交的策略/` | 结果 Alert 前缀文案 | 改文案即红 |
| A07 | tests/student-play.test.cjs | 156 | `/另一页面提交/` | 冲突 Alert（`acceptSaved` 分支） | 改文案即红 |
| A08 | tests/student-play.test.cjs | 157 | `/定价策略/` | 冲突 Alert 里「服务器实际保存的策略」label | 渲染丢失即红 |
| A09 | tests/student-play.test.cjs | 205 | `/已有本案例推演记录，请从「我的记录」继续/` | 409 `submission_exists` 的 Alert 文案（`SUBMISSION_EXISTS`） | 改一个字即红（含中文引号 `「」`） |
| A10 | tests/student-play.test.cjs | 206 / 218 | `我的记录` | 重复提交提示里的跳转入口按钮 | 入口文案改名或去掉入口即红 |
| A11 | tests/student-play.test.cjs | 217 | `案例已下架` | 后端 message 直出的 Alert 文案 | 后端原文透传契约，前端不许改写 |
| A12 | tests/progressive-display.test.cjs | 11 | `133.1` | `MetricsBar` 营收数值 | 数字格式/四舍五入改动即红 |
| A13 | tests/progressive-display.test.cjs | 12 | `净利润 -12.35 万元` | `MetricsBar` 净利润卡（label + 空格 + 两位小数 + 单位） | **最脆**：label 内尾随空格、`toFixed(2)`、`万元` 三者任一变化即红 |
| A14 | tests/progressive-display.test.cjs | 13 | `本期现金净流量 0.00 万元` | `MetricsBar` 现金流卡的 `metric-note` | 同上 |
| A15 | tests/progressive-display.test.cjs | 16 | `净利润`（`!old.includes`） | `MetricsBar` 无 `net_profit` 时**不得**出现净利润卡 | 「总是渲染净利润卡」这种改法会红 |
| A16 | tests/progressive-display.test.cjs | 17 | `<MetricComparison before={beforeLast} after={last.after_metrics} />` | StudentPlayPage 源码字面量 | 改组件名/props 命名即红（源码级断言） |
| A17 | tests/presentation.test.cjs | 24 | `现金流改善。` | AI 复盘文本清洗（`presentation`） | 断言还包含 `!html.includes('<details')` |
| A18 | tests/presentation.test.cjs | 38 | `利润改善。` | 同上（清洗后保留正文） | 改清洗规则即红 |
| A19 | tests/review-layout.test.cjs | 9 | `\n参考营收` | 复盘页「参考方案」段落换行结构 | 段落排版改动即红 |
| A20 | tests/review-layout.test.cjs | 13 | `本次推演开始时未设置参考方案`（`!includes`） | 复盘页：该文案**不许**再出现 | 加回来即红 |
| A21 | tests/review-layout.test.cjs | 14 | `标准路径结果已就绪`（`!includes`） | 复盘页：该文案**不许**再出现 | 加回来即红 |
| A22 | tests/review-layout.test.cjs | 15 | `AI 正在生成复盘分析` 或 `正在生成复盘，请稍候。` | 复盘页 loading 文案（二选一） | 两个都改即红 |
| A23 | tests/review-layout.test.cjs | 16 | `title="综合结论"` 且位于 `我的方案：</strong>` 之前 | 复盘页结论区的顺序契约 | 调整区块顺序即红 |
| A24 | tests/transport-error.test.cjs | 52 | `/已有本案例推演记录/` | `transport.ts` 409 结构化 detail 透传 | 丢弃后端 message 即红 |
| A25 | tests/transport-error.test.cjs | 60 | `请求参数不符合要求，请检查输入内容` | 422 数组 detail 的兜底文案（`GENERIC_DETAIL`） | 改兜底文案即红 |
| A26 | tests/transport-error.test.cjs | 65 | `案例已下架` | 字符串 detail 原样透传 | 同上 |
| A27 | tests/transport-error.test.cjs | 66 | `请求失败（HTTP 500）` | 无 detail 时的状态码兜底文案 | 改括号/空格即红 |
| A28 | tests/transport-error.test.cjs | 67 | `无法连接后端服务，请确认本地后端端口已启动` | 无响应的网络错误文案 | 改文案即红 |
| A29 | tests/task-workspace.test.cjs | 31 | `-2.00 万元` | `metricChange` 数值格式化（营收差） | 改格式即红 |
| A30 | tests/task-workspace.test.cjs | 32 | `0.00 万元` | `metricChange(0,0)` 零值保留 | 改「0 显示为空」即红 |
| A31 | tests/task-workspace.test.cjs | 33 | `+2.00 个百分点` | `metricChange` 百分比差（单位是「个百分点」不是「%」） | 改单位即红 |
| A32 | tests/task-workspace.test.cjs | 34 | `—` | 不可解析输入（`约20%（假设）`）的占位符 | 改成 `-`/`N/A` 即红 |
| A33 | tests/task-workspace.test.cjs | 84 | `财务基准与案例信息` | 教师端脏标记文案 | 改分区名即红 |
| A34 | tests/student-library.test.cjs | 65 | `教师案例` | 学生案例库 `Card.title` | 改标题即红 |
| A35 | tests/teacher-background.test.cjs | 169 | `V2: 节点不完整` | 教师端 AI 生成失败 Alert `description` | 改前缀 `V2:` 即红 |
| A36 | tests/impact-rules.test.cjs | 40 | `AI草稿已填入` | 教师端规则草稿提示 Alert | 改文案即红（注意 `AI草稿` 中间无空格） |
| A37 | tests/impact-rules.test.cjs | 53 | `未覆盖` | 教师端影响值未覆盖提示 | 改文案即红 |
| A38 | tests/teacher-background.test.cjs | 109 | `超时`（`!includes`） | 轮询重试时**不许**报「超时」 | 把重试写成超时错误即红 |

### 1.1 附：非文案但同样「改了就红」的契约

以下三类不是文案，但直接决定后续阶段能不能动结构，必须与冻结表同级看待。

| 编号 | 测试文件 | 行号 | 被断言的原文 | 归属组件 | 风险 |
|---|---|---|---|---|---|
| B01 | tests/student-play.test.cjs | 61 / 70 / 187 / 189 | `b.className === 'strategy-option'`（**严格等于**） | 策略卡内 `Button` | ⚠️ **阶段 3 头号杀手**：此断言用 `===` 精确比较，给按钮**追加任何** class（如 `strategy-option option-a`）都会让 `options(page)` 返回空数组，连带 6 个用例失败 |
| B02 | tests/student-play.test.cjs | 92 / 102 / 114 / 141 / 146 / 190 | `aria-pressed` | 策略卡 `Button` | 阶段 3 规定不许动 aria-pressed；改了 6 处断言全红 |
| B03 | tests/student-play.test.cjs | 23 | `antd: { ... Steps: 'Steps' ... }` | 测试的 antd mock | 阶段 5 换掉 `<Steps>` 后 mock 里仍保留 `Steps` 键即可（当前页面 L2 也从 antd 导入 Steps，删导入时一并处理） |
| B04 | tests/merged-calibration.test.cjs | 88 / 90 | `tableProps.columns.length === 6` | 教师端 `NodeSection` 选项表列数 | **该文件 0 条文案断言**，只有结构断言；列数/列 key 变动即红 |
| B05 | tests/merged-calibration.test.cjs | 93 | `!columnKeys.includes('financial_assumptions')` | 选项表不得出现旧金额列 | 加回即红 |
| B06 | tests/merged-calibration.test.cjs | 96 / 98 | `typeof impactCol.render === 'function'` 且返回值非空 | 第 6 列「递进影响」 | 该列改成纯文本即红 |
| B07 | tests/architecture.test.cjs | 10 | `!/from ['"][^'"]*pages\//` | `features/ai` 不得反向依赖 `pages/` | 阶段 5/6 新增组件放错目录（跨层引用）即红 |
| B08 | tests/architecture.test.cjs | 15 | `features/ai/StudentReview`（源码 `includes`）+ 16 行 `!page.includes('setTimeout')` | `StudentReviewPage` 必须挂 `features/ai/StudentReview`，且不许自己写 `setTimeout` | 把复盘轮询搬回页面即红 |

> 关于 B04–B06：清单 DoD 要求冻结表「覆盖 merged-calibration.test.cjs」。实际扫描结论是**该文件没有任何文案断言**（只有表结构断言），所以本表用 B04–B06 覆盖它，并在此明确标注类型差异——不是凑数，避免后续阶段误以为可以自由改表结构。

---

## 2. 冻结清单（F1–Fn）

> 阶段 2–8 期间，下列字符串**一字不许改**。若某阶段确实必须改，只能同步改断言期望值，禁止删用例、禁止 `test.skip`。

- **F1** `开始推演`
- **F2** `确认提交本回合`
- **F3** `继续下一回合`
- **F4** `核对已保存进度`
- **F5** `我的记录`
- **F6** `你提交的策略`
- **F7** `已有本案例推演记录，请从「我的记录」继续`（`StudentPlayPage.tsx:20` 的 `SUBMISSION_EXISTS`，含中文引号 `「」`；测试正则只匹配到「继续」为止，但前端常量本身就是这句）
- **F8** `另一页面提交`
- **F9** `案例已下架`
- **F10** `净利润 -12.35 万元`（即 `净利润 ` + 2 位小数 + ` 万元` 的拼接格式）
- **F11** `本期现金净流量 0.00 万元`
- **F12** `现金流改善。` / `利润改善。`
- **F13** `AI 正在生成复盘分析`（或 `正在生成复盘，请稍候。`）
- **F14** `综合结论`
- **F15** `请求参数不符合要求，请检查输入内容`
- **F16** `请求失败（HTTP 500）`
- **F17** `无法连接后端服务，请确认本地后端端口已启动`
- **F18** `-2.00 万元` / `0.00 万元` / `+2.00 个百分点` / `—`
- **F19** `教师案例`
- **F20** `V2: 节点不完整`
- **F21** `AI草稿已填入` / `未覆盖`
- **F22** `财务基准与案例信息`
- **F23** 策略卡 `Button` 的 `className` 必须**严格等于** `strategy-option`
- **F24** 策略卡 `Button` 的 `aria-pressed` 语义必须保留
- **F25** 教师端选项表列数必须为 6，且不含 `financial_assumptions` 列

---

## 3. 扫描结论

- 文案断言共 **38 条**（A01–A38），另有 **7 条**类名/结构/分层契约（B01–B07），合计 45 条冻结项 → 归并为 **F1–F25**。
- 覆盖到的测试文件：`student-play` / `progressive-display` / `presentation` / `review-layout` / `transport-error` / `task-workspace` / `student-library` / `teacher-background` / `impact-rules` / `merged-calibration` / `architecture`（11 个），占 18 个测试文件的 61%。
- **没有任何文案/类名断言的测试文件**：`baseline-finance`、`financials`、`idempotency`、`reference-path`、`student-tutor`、`student-review`、`student-library`（部分）——这些文件的中文只出现在 mock 数据里，不是断言目标。

### 3.1 三处与执行清单不一致的发现（进入阶段 1 前必须知道）

1. **清单阶段 5 说「现有文本『第 2 / 3 轮 · 已提交 1 轮』必须逐字保留，测试断言它」——不成立。**
   实测：该文案在 `StudentPlayPage.tsx:214` 是模板字符串拼出来的（`第 ${idx} / 3 轮` + ` · 已提交 ${n} 轮`），且 `finished` 时分支不同（显示「三轮推演已完成」）。全仓测试**没有任何断言引用它**。所以阶段 5 换 Steps 时，这行文本属于「建议保留」而非「测试强制」。
2. **清单阶段 3 说「meta 取值逻辑当前约在 225-229 行」——实际在 240-243 行**（文件共 277 行）。行号漂移不影响结论，但按行号改代码会改错位置。
3. **清单阶段 6 说「不许改 FAB 位置（right:16 bottom:80）」——`StudentLayout.css` 里没有这两条声明。**
   实际只有 `StudentLayout.css:146` 的 `position: fixed; z-index: 1000`（right/bottom 由 antd `FloatButton` 默认值提供）。即该约束是「别给 `.ant-float-btn` 加定位覆盖」，而不是「保持已有声明」。
