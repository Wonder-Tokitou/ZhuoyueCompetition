"""Stop any process listening on APP_PORT (8110 by default)."""
import os
import subprocess
import sys

ROOT = __import__("pathlib").Path(__file__).resolve().parents[1]


def load_port():
    env_path = ROOT / "backend/.env"
    port = 8110
    if env_path.exists():
        for line in env_path.read_text(encoding="utf-8", errors="ignore").splitlines():
            line = line.strip()
            if line.startswith("APP_PORT="):
                try:
                    port = int(line.split("=", 1)[1].strip())
                except ValueError:
                    pass
    return port


def main():
    port = load_port()
    print(f"正在停止监听 {port} 的进程...")
    if os.name == "nt":
        # PowerShell gives us reliable parsing of netstat-ish output.
        ps = subprocess.run(
            [
                "powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass",
                "-Command",
                f"Get-NetTCPConnection -LocalPort {port} -ErrorAction SilentlyContinue | "
                "Where-Object {{ $_.State -eq 'Listen' -and $_.OwningProcess -gt 0 }} | "
                "Select-Object -ExpandProperty OwningProcess -Unique",
            ],
            capture_output=True, text=True,
        )
        pids = {
            line.strip()
            for line in ps.stdout.splitlines()
            if line.strip().isdigit() and int(line.strip()) > 0
        }
        if not pids:
            print(f"未找到监听 {port} 的进程")
            return
        for pid in sorted(pids):
            print(f"  结束 PID {pid}")
            subprocess.run(["taskkill", "/F", "/PID", pid], capture_output=True)
    else:
        subprocess.run(f"lsof -ti:{port} | xargs -r kill -9", shell=True)
    print("完成")


if __name__ == "__main__":
    main()
